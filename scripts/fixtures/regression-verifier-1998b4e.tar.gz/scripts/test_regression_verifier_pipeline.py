from __future__ import annotations

import importlib.util
import io
import json
import os
import sys
import tarfile
import tempfile
import unittest
from pathlib import Path
from unittest import mock

if __package__:
    from .activate_direct_growth_v2 import benchmark_digest as repository_benchmark_digest
else:
    from activate_direct_growth_v2 import benchmark_digest as repository_benchmark_digest


SCRIPT = Path(__file__).with_name("regression_verifier_pipeline.py")
SPEC = importlib.util.spec_from_file_location("regression_verifier_pipeline", SCRIPT)
assert SPEC and SPEC.loader
pipeline = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = pipeline
SPEC.loader.exec_module(pipeline)


def approved_benchmark_source() -> tuple[str, tuple[str, str, str]]:
    digest = sorted(pipeline.RECONCILED_REGRESSION_BENCHMARK_SOURCES)[0]
    return digest, pipeline.RECONCILED_REGRESSION_BENCHMARK_SOURCES[digest]


def archive(entries: list[tuple[str, bytes | None, str]]) -> bytes:
    output = io.BytesIO()
    with tarfile.open(fileobj=output, mode="w:gz") as bundle:
        for name, body, kind in entries:
            info = tarfile.TarInfo(name)
            if kind == "dir":
                info.type = tarfile.DIRTYPE
                bundle.addfile(info)
            elif kind == "symlink":
                info.type = tarfile.SYMTYPE
                info.linkname = "target"
                bundle.addfile(info)
            else:
                assert body is not None
                info.size = len(body)
                bundle.addfile(info, io.BytesIO(body))
    return output.getvalue()


class RegressionVerifierPipelineTests(unittest.TestCase):
    def test_manifest_files_are_exact_content_addressed_basenames(self) -> None:
        job_id = "base-mainnet:test:1"
        candidate = pipeline.content_addressed_name("candidate", job_id)
        self.assertEqual(
            pipeline.manifest_file(
                Path("candidates"),
                candidate,
                pipeline.CANDIDATE_FILE,
                "candidate manifest file",
            ),
            Path("candidates") / candidate,
        )
        for unsafe in ("../candidate-" + "a" * 64 + ".json", "manifest.json", "C:\\secret"):
            with self.subTest(unsafe=unsafe), self.assertRaises(pipeline.PipelineError):
                pipeline.manifest_file(
                    Path("candidates"),
                    unsafe,
                    pipeline.CANDIDATE_FILE,
                    "candidate manifest file",
                )

    def test_signing_key_is_not_exposed_before_local_digest_validation(self) -> None:
        signer = "0x" + "1" * 40
        digest = "0x" + "2" * 64
        response_hash = "0x" + "3" * 64
        events: list[str] = []
        job = {
            "job_id": "base-mainnet:test:1",
            "verification_mode": "signed_quorum",
            "threshold": 1,
            "eligible_verifiers": [signer],
        }
        current = {
            **job,
            "verification_expires_at": 2_000_001_000,
            "bounty_contract": "0x" + "4" * 40,
        }

        def fake_digest(*_args, **_kwargs) -> str:
            events.append("digest")
            return digest

        def fake_run(command: list[str], *, env=None) -> str:
            self.assertNotIn("REGRESSION_VERIFIER_PRIVATE_KEY", env)
            self.assertIn("digest", events)
            if command[1:3] == ["wallet", "address"]:
                events.append("key-address")
                return signer
            if command[1:3] == ["wallet", "sign"]:
                events.append("key-sign")
                return "0x" + "5" * 130
            self.fail(f"unexpected command: {command}")

        with tempfile.TemporaryDirectory() as temporary, mock.patch.dict(
            os.environ,
            {"REGRESSION_VERIFIER_PRIVATE_KEY": "test-secret"},
            clear=False,
        ):
            root = Path(temporary)
            candidates = root / "candidates"
            output = root / "output"
            candidates.mkdir()
            candidate_file = pipeline.content_addressed_name("candidate", job["job_id"])
            pipeline.write_json(
                candidates / "manifest.json",
                {
                    "schema": pipeline.MANIFEST_SCHEMA,
                    "candidates": [{"job_id": job["job_id"], "file": candidate_file}],
                },
            )
            pipeline.write_json(
                candidates / candidate_file,
                {
                    "schema": pipeline.CANDIDATE_SCHEMA,
                    "job": job,
                    "outcome": {"verdict": "passed", "response_hash": response_hash},
                },
            )
            args = mock.Mock(
                private_key_env="REGRESSION_VERIFIER_PRIVATE_KEY",
                expected_signer=signer,
                candidates=candidates,
                output=output,
                api_base="https://api.agentbounties.app",
                network="base-mainnet",
                worker=Path("trusted-worker"),
                cast=Path("cast"),
                rpc_url="https://base-rpc.invalid",
            )
            with mock.patch.object(pipeline, "current_job", return_value=current), mock.patch.object(
                pipeline, "validate_candidate"
            ), mock.patch.object(
                pipeline, "attestation_digest", side_effect=fake_digest
            ), mock.patch.object(
                pipeline, "run", side_effect=fake_run
            ), mock.patch.object(
                pipeline.time, "time", return_value=2_000_000_000
            ):
                pipeline.command_sign(args)

        self.assertEqual(events, ["digest", "key-address", "key-sign"])

    def test_relay_key_is_not_exposed_before_exact_rpc_preflight(self) -> None:
        verifier = "0x" + "1" * 40
        keeper = "0x" + "2" * 40
        bounty = "0x" + "3" * 40
        response_hash = "0x" + "4" * 64
        signature = "0x" + "5" * 130
        job_id = "base-mainnet:test:relay"
        events: list[str] = []
        job = {
            "job_id": job_id,
            "verification_mode": "signed_quorum",
            "threshold": 1,
            "eligible_verifiers": [verifier],
            "bounty_contract": bounty,
        }

        def fake_preflight(*_args, **_kwargs) -> int:
            events.append("preflight")
            return 7

        def fake_immediate_nonce(*_args, **_kwargs) -> int:
            events.append("pre-send-nonce")
            return 7

        def fake_run(command: list[str], *, env=None) -> str:
            self.assertNotIn("BASE_KEEPER_PRIVATE_KEY", env)
            self.assertIn("preflight", events)
            if command[1:3] == ["wallet", "address"]:
                events.append("key-address")
                return keeper
            if command[1] == "send":
                events.append("send")
                self.assertIn("--chain", command)
                self.assertEqual(command[command.index("--chain") + 1], "8453")
                self.assertEqual(command[command.index("--nonce") + 1], "7")
                self.assertEqual(
                    command[command.index("--gas-limit") + 1],
                    str(pipeline.RELAY_GAS_LIMIT),
                )
                self.assertEqual(
                    command[command.index("--gas-price") + 1],
                    str(pipeline.RELAY_MAX_FEE_PER_GAS),
                )
                return '{"transactionHash":"0x' + "6" * 64 + '","status":"0x1"}'
            self.fail(f"unexpected command: {command}")

        with tempfile.TemporaryDirectory() as temporary, mock.patch.dict(
            os.environ,
            {"BASE_KEEPER_PRIVATE_KEY": "test-secret"},
            clear=False,
        ):
            root = Path(temporary)
            candidates = root / "candidates"
            attestations = root / "attestations"
            candidates.mkdir()
            attestations.mkdir()
            candidate_file = pipeline.content_addressed_name("candidate", job_id)
            attestation_file = pipeline.content_addressed_name("attestation", job_id)
            pipeline.write_json(
                candidates / "manifest.json",
                {
                    "schema": pipeline.MANIFEST_SCHEMA,
                    "candidates": [{"job_id": job_id, "file": candidate_file}],
                },
            )
            pipeline.write_json(
                candidates / candidate_file,
                {
                    "schema": pipeline.CANDIDATE_SCHEMA,
                    "job": job,
                    "outcome": {"verdict": "passed", "response_hash": response_hash},
                },
            )
            pipeline.write_json(
                attestations / "manifest.json",
                {
                    "schema": pipeline.ATTESTATION_SCHEMA,
                    "signer": verifier,
                    "attestations": [{"job_id": job_id, "file": attestation_file}],
                },
            )
            pipeline.write_json(
                attestations / attestation_file,
                {
                    "schema": pipeline.ATTESTATION_SCHEMA,
                    "job_id": job_id,
                    "bounty_contract": bounty,
                    "verifier": verifier,
                    "passed": True,
                    "response_hash": response_hash,
                    "deadline": 2_000_000_000,
                    "signature": signature,
                },
            )
            args = mock.Mock(
                keeper_key_env="BASE_KEEPER_PRIVATE_KEY",
                expected_keeper=keeper,
                verifier=[verifier],
                candidates=candidates,
                attestations=[attestations],
                api_base="https://api.agentbounties.app",
                network="base-mainnet",
                worker=Path("trusted-worker"),
                cast=Path("cast"),
                rpc_url="https://relay.invalid",
            )
            with mock.patch.object(pipeline, "current_job", return_value=job), mock.patch.object(
                pipeline, "validate_candidate"
            ), mock.patch.object(
                pipeline, "relay_rpc_preflight", side_effect=fake_preflight
            ), mock.patch.object(
                pipeline, "keeper_nonce_preflight", side_effect=fake_immediate_nonce
            ), mock.patch.object(
                pipeline, "run", side_effect=fake_run
            ):
                pipeline.command_relay(args)

        self.assertEqual(events, ["preflight", "key-address", "pre-send-nonce", "send"])

    def test_relay_rpc_preflight_rejects_unbounded_gas_before_key_use(self) -> None:
        commands: list[list[str]] = []

        def fake_run(command: list[str], *, env=None) -> str:
            self.assertNotIn("BASE_KEEPER_PRIVATE_KEY", env)
            commands.append(command)
            return {
                "chain-id": "8453",
                "call": "0x",
                "estimate": str(pipeline.RELAY_GAS_LIMIT + 1),
            }[command[1]]

        with mock.patch.object(pipeline, "run", side_effect=fake_run), mock.patch.object(
            pipeline, "canonical_bounty_rpc_preflight"
        ), self.assertRaisesRegex(pipeline.PipelineError, "gas estimate exceeds"):
            pipeline.relay_rpc_preflight(
                Path("cast"),
                "https://relay.invalid",
                "0x" + "1" * 40,
                "0x" + "2" * 40,
                "[]",
                {"PUBLIC_VALUE": "kept"},
            )
        self.assertEqual([command[1] for command in commands], ["chain-id", "call", "estimate"])

    def test_keeper_nonce_preflight_rejects_pending_keeper_nonce(self) -> None:
        commands: list[list[str]] = []

        def fake_run(command: list[str], *, env=None) -> str:
            self.assertNotIn("BASE_KEEPER_PRIVATE_KEY", env)
            commands.append(command)
            if command[1] == "chain-id":
                return "8453"
            if command[1] == "call":
                return "0x"
            if command[1] == "estimate":
                return "100000"
            if command[1] == "nonce":
                return "7" if command[command.index("--block") + 1] == "latest" else "8"
            self.fail(f"unexpected command: {command}")

        with mock.patch.object(pipeline, "run", side_effect=fake_run), self.assertRaisesRegex(
            pipeline.PipelineError, "another pending transaction"
        ):
            pipeline.keeper_nonce_preflight(
                Path("cast"),
                "https://relay.invalid",
                "0x" + "2" * 40,
                {"PUBLIC_VALUE": "kept"},
            )
        nonce_blocks = [
            command[command.index("--block") + 1]
            for command in commands
            if command[1] == "nonce"
        ]
        self.assertEqual(nonce_blocks, ["latest", "pending"])

    def test_keeper_nonce_preflight_requires_two_matching_rpcs(self) -> None:
        commands: list[list[str]] = []

        def fake_run(command: list[str], *, env=None) -> str:
            self.assertNotIn("BASE_KEEPER_PRIVATE_KEY", env)
            commands.append(command)
            return "8453" if command[1] == "chain-id" else "7"

        with mock.patch.object(pipeline, "run", side_effect=fake_run):
            nonce = pipeline.keeper_nonce_preflight(
                Path("cast"),
                "https://relay.invalid",
                "0x" + "2" * 40,
                {"PUBLIC_VALUE": "kept"},
            )
        self.assertEqual(nonce, 7)
        rpc_urls = {
            command[command.index("--rpc-url") + 1]
            for command in commands
            if "--rpc-url" in command
        }
        self.assertEqual(rpc_urls, {"https://relay.invalid", "https://mainnet.base.org"})

    def test_keeper_nonce_preflight_rejects_equal_but_stale_rpc_pair(self) -> None:
        def fake_run(command: list[str], *, env=None) -> str:
            if command[1] == "chain-id":
                return "8453"
            rpc_url = command[command.index("--rpc-url") + 1]
            return "7" if rpc_url == "https://relay.invalid" else "6"

        with mock.patch.object(pipeline, "run", side_effect=fake_run), self.assertRaisesRegex(
            pipeline.PipelineError, "independent nonce RPCs disagree"
        ):
            pipeline.keeper_nonce_preflight(
                Path("cast"),
                "https://relay.invalid",
                "0x" + "2" * 40,
                {"PUBLIC_VALUE": "kept"},
            )

    def test_canonical_bounty_preflight_rejects_wrong_nonempty_runtime(self) -> None:
        commands: list[list[str]] = []

        def fake_run(command: list[str], *, env=None) -> str:
            self.assertNotIn("BASE_KEEPER_PRIVATE_KEY", env)
            commands.append(command)
            return "0x60016000"

        with mock.patch.object(pipeline, "run", side_effect=fake_run), self.assertRaisesRegex(
            pipeline.PipelineError, "not the precommitted canonical clone"
        ):
            pipeline.canonical_bounty_rpc_preflight(
                Path("cast"),
                "https://relay.invalid",
                "0x" + "1" * 40,
                {"PUBLIC_VALUE": "kept"},
            )
        self.assertEqual(len(commands), 1)
        self.assertEqual(commands[0][1], "code")
        self.assertEqual(commands[0][commands[0].index("--block") + 1], "safe")

    def test_canonical_bounty_preflight_binds_factory_and_token(self) -> None:
        commands: list[list[str]] = []

        def fake_run(command: list[str], *, env=None) -> str:
            commands.append(command)
            if command[1] == "code":
                return pipeline.CANONICAL_BOUNTY_RUNTIME
            if command[-1] == "factory()(address)":
                return pipeline.CANONICAL_BOUNTY_FACTORY
            if command[-1] == "settlementToken()(address)":
                return pipeline.CANONICAL_SETTLEMENT_TOKEN
            self.fail(f"unexpected command: {command}")

        with mock.patch.object(pipeline, "run", side_effect=fake_run):
            pipeline.canonical_bounty_rpc_preflight(
                Path("cast"),
                "https://relay.invalid",
                "0x" + "1" * 40,
                {"PUBLIC_VALUE": "kept"},
            )
        self.assertEqual([command[1] for command in commands], ["code", "call", "call"])
        self.assertTrue(
            all(command[command.index("--block") + 1] == "safe" for command in commands)
        )

    def test_canonical_bounty_preflight_rejects_wrong_provenance(self) -> None:
        cases = (
            ("factory()(address)", "0x" + "3" * 40, "canonical factory"),
            ("settlementToken()(address)", "0x" + "4" * 40, "canonical Base USDC"),
        )
        for wrong_field, wrong_value, expected_error in cases:
            with self.subTest(field=wrong_field):
                def fake_run(command: list[str], *, env=None) -> str:
                    if command[1] == "code":
                        return pipeline.CANONICAL_BOUNTY_RUNTIME
                    if command[-1] == "factory()(address)":
                        return (
                            wrong_value
                            if wrong_field == "factory()(address)"
                            else pipeline.CANONICAL_BOUNTY_FACTORY
                        )
                    if command[-1] == "settlementToken()(address)":
                        return wrong_value
                    self.fail(f"unexpected command: {command}")

                with mock.patch.object(pipeline, "run", side_effect=fake_run), self.assertRaisesRegex(
                    pipeline.PipelineError, expected_error
                ):
                    pipeline.canonical_bounty_rpc_preflight(
                        Path("cast"),
                        "https://relay.invalid",
                        "0x" + "1" * 40,
                        {"PUBLIC_VALUE": "kept"},
                    )

    def test_candidate_validation_strips_signing_secrets_from_worker(self) -> None:
        digest, (repository, commit, subdirectory) = approved_benchmark_source()
        current = {
            "terms": {
                "document": {
                    "benchmark": {
                        "engine": "sandboxed_regression_v1",
                        "source": {
                            "kind": "github_commit",
                            "repository": repository,
                            "commit": commit,
                            "subdirectory": subdirectory,
                        },
                        "runner_manifest": {
                            "benchmark_digest": digest
                        },
                    }
                }
            }
        }
        with tempfile.TemporaryDirectory() as temporary, mock.patch.dict(
            os.environ,
            {"REGRESSION_VERIFIER_PRIVATE_KEY": "test-secret", "PUBLIC_VALUE": "kept"},
            clear=False,
        ), mock.patch.object(pipeline, "run", return_value="ok") as invoked:
            pipeline.validate_candidate(
                Path("trusted-worker"),
                {"schema": pipeline.CANDIDATE_SCHEMA, "job": {}},
                current,
                Path(temporary),
                secret_names=("REGRESSION_VERIFIER_PRIVATE_KEY",),
            )
        environment = invoked.call_args.kwargs["env"]
        self.assertNotIn("REGRESSION_VERIFIER_PRIVATE_KEY", environment)
        self.assertEqual(environment["PUBLIC_VALUE"], "kept")

    def test_rpc_digest_must_equal_local_eip712_digest(self) -> None:
        good = "0x" + "1" * 64
        bad = "0x" + "2" * 64
        current = {"bounty_contract": "0x" + "3" * 40}

        def fake_run(command: list[str], *, env=None) -> str:
            self.assertNotIn("REGRESSION_VERIFIER_PRIVATE_KEY", env)
            if command[1] == "chain-id":
                return "8453"
            if command[1] == "code":
                return "0x60016000"
            if command[1] == "call":
                return bad
            self.fail(f"unexpected command: {command}")

        with mock.patch.object(pipeline, "run", side_effect=fake_run), mock.patch.object(
            pipeline, "canonical_bounty_rpc_preflight"
        ), mock.patch.object(pipeline, "local_attestation_digest", return_value=good):
            with self.assertRaisesRegex(
                pipeline.PipelineError,
                "differs from the local EIP-712 digest",
            ):
                pipeline.attestation_digest(
                    Path("cast"),
                    "https://secondary.invalid",
                    current,
                    "0x" + "4" * 40,
                    True,
                    "0x" + "5" * 64,
                    2_000_000_000,
                    {"PUBLIC_VALUE": "kept"},
                )

    def test_runner_selects_single_verifier_and_legacy_two_verifier_jobs(self) -> None:
        configured = ["0x" + "1" * 40, "0x" + "2" * 40]
        jobs = [
            {
                "job_id": "single",
                "verification_mode": "signed_quorum",
                "eligible_verifiers": configured[:1],
                "threshold": 1,
            },
            {
                "job_id": "legacy",
                "verification_mode": "signed_quorum",
                "eligible_verifiers": configured,
                "threshold": 2,
            },
            {
                "job_id": "unsupported",
                "verification_mode": "signed_quorum",
                "eligible_verifiers": [configured[1]],
                "threshold": 1,
            },
        ]
        self.assertEqual(
            [job["job_id"] for job in pipeline.selected_jobs(jobs, configured, 5)],
            ["single", "legacy"],
        )

    def test_command_run_continues_after_poison_job(self) -> None:
        configured = ["0x" + "1" * 40, "0x" + "2" * 40]
        selected = [
            {
                "job_id": "poison",
                "verification_mode": "signed_quorum",
                "eligible_verifiers": configured[:1],
                "threshold": 1,
            },
            {
                "job_id": "good",
                "verification_mode": "signed_quorum",
                "eligible_verifiers": configured,
                "threshold": 2,
            },
        ]

        def fake_run_job(
            worker: Path, staging: Path, job: dict, temporary: Path
        ) -> dict:
            del worker, staging, temporary
            if job["job_id"] == "poison":
                raise pipeline.PipelineError(
                    "downloaded source does not match submission evidence"
                )
            return {
                "schema": pipeline.CANDIDATE_SCHEMA,
                "job": job,
                "outcome": {"passed": True},
                "runner_revision": "test",
            }

        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "out"
            args = mock.Mock(
                verifier=configured,
                api_base="https://api.example.test",
                network="base-mainnet",
                max_jobs=5,
                max_scan=100,
                output=output,
                worker=Path("worker"),
                staging=Path(temporary) / "staging",
            )
            with (
                mock.patch.object(pipeline, "verification_jobs", return_value=selected),
                mock.patch.object(pipeline, "selected_jobs", return_value=selected),
                mock.patch.object(pipeline, "run_job", side_effect=fake_run_job),
            ):
                pipeline.command_run(args)
            manifest = json.loads((output / "manifest.json").read_text(encoding="utf-8"))
            self.assertEqual([item["job_id"] for item in manifest["candidates"]], ["good"])
            self.assertEqual(manifest["failures"][0]["job_id"], "poison")
            self.assertTrue((output / manifest["candidates"][0]["file"]).is_file())

    def exercise_batch(self, failures, *, maximum=1, scan=100, good=True):
        configured = ["0x" + "1" * 40]
        def job(name):
            return {"job_id": name, "verification_mode": "signed_quorum",
                    "eligible_verifiers": configured, "threshold": 1}
        jobs = [job(f"bad-{index}") for index in range(len(failures))]
        if good:
            jobs.append(job("good"))
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary)
            args = pipeline.parser().parse_args([
                "run", "--verifier", configured[0], "--worker", "unused-worker",
                "--staging", temporary, "--output", temporary,
                "--max-jobs", str(maximum), "--max-scan", str(scan)])
            outcomes = [*failures, {"schema": pipeline.CANDIDATE_SCHEMA}]
            with mock.patch.object(pipeline, "verification_jobs", return_value=jobs), \
                    mock.patch.object(pipeline, "run_job", side_effect=outcomes) as run_job:
                failure = None
                try:
                    pipeline.command_run(args)
                except pipeline.PipelineError as error:
                    failure = str(error)
            manifest = pipeline.read_json(output / "manifest.json")
            return manifest, run_job.call_count, failure

    def test_late_valid_job_survives_more_failures_than_candidate_limit(self):
        manifest, calls, error = self.exercise_batch([
            pipeline.PipelineError("digest mismatch") for _ in range(6)])
        self.assertIsNone(error)
        self.assertEqual(calls, 7)
        self.assertEqual(manifest["candidates"][0]["job_id"], "good")
        self.assertEqual(len(manifest["failures"]), 6)
        self.assertEqual(manifest["status"], "degraded")

    def test_expected_job_failures_do_not_abort_later_work(self):
        errors = [OSError("download failed"), ValueError("invalid JSON"),
                  TypeError("malformed value"), KeyError("snapshot"),
                  AttributeError("malformed nested object"),
                  pipeline.subprocess.TimeoutExpired("worker", 900),
                  tarfile.ReadError("bad archive"), EOFError("truncated archive")]
        manifest, calls, error = self.exercise_batch(errors)
        self.assertIsNone(error)
        self.assertEqual(calls, len(errors) + 1)
        self.assertEqual(len(manifest["failures"]), len(errors))
        self.assertEqual(len(manifest["candidates"]), 1)

    def test_all_failed_batch_saves_diagnostics_and_fails(self):
        manifest, calls, error = self.exercise_batch([pipeline.PipelineError("bad")], good=False)
        self.assertIn("no candidates", error)
        self.assertEqual(calls, 1)
        self.assertEqual(manifest["status"], "degraded")
        self.assertEqual(manifest["candidates"], [])

    def test_empty_batch_is_idle(self):
        manifest, calls, error = self.exercise_batch([], good=False)
        self.assertIsNone(error)
        self.assertEqual(calls, 0)
        self.assertEqual(manifest["status"], "idle")

    def test_scan_budget_is_separate_and_bounded(self):
        manifest, calls, error = self.exercise_batch([
            pipeline.PipelineError("bad") for _ in range(3)], scan=2)
        self.assertIn("no candidates", error)
        self.assertEqual(calls, 2)
        self.assertTrue(manifest["scan_limit_reached"])

    def test_malformed_job_and_duplicate_do_not_block_or_duplicate_candidate(self):
        signer = "0x" + "1" * 40
        good = {"job_id": "good", "verification_mode": "signed_quorum",
                "eligible_verifiers": [signer], "threshold": 1}
        jobs = [None, {**good, "job_id": "../bad"},
                {**good, "job_id": "bad-signers", "eligible_verifiers": None},
                good, good, {**good, "job_id": "another"}]
        with tempfile.TemporaryDirectory() as temporary:
            args = pipeline.parser().parse_args([
                "run", "--verifier", signer, "--worker", "unused-worker",
                "--staging", temporary, "--output", temporary, "--max-jobs", "2"])
            with mock.patch.object(pipeline, "fetch_json", return_value=jobs), \
                    mock.patch.object(pipeline, "run_job", return_value={}) as invoked:
                pipeline.command_run(args)
            manifest = pipeline.read_json(Path(temporary) / "manifest.json")
            self.assertEqual(invoked.call_count, 2)
            self.assertEqual(len(manifest["failures"]), 3)
            self.assertEqual([c["job_id"] for c in manifest["candidates"]], ["good", "another"])

    def test_signer_feed_remains_strict_for_malformed_jobs(self):
        with mock.patch.object(pipeline, "fetch_json", return_value=[None, {}]):
            with self.assertRaisesRegex(pipeline.PipelineError, "array of jobs"):
                pipeline.verification_jobs("https://example.test", "base-mainnet", "unused")
        with mock.patch.object(pipeline, "fetch_json", return_value={"jobs": []}):
            with self.assertRaisesRegex(pipeline.PipelineError, "array of jobs"):
                pipeline.verification_jobs("https://example.test", "base-mainnet", "unused",
                                           isolate_invalid_entries=True)

    def test_regression_job_rejects_zero_or_ambiguous_verifiers(self) -> None:
        base = {
            "verification_mode": "signed_quorum",
            "eligible_verifiers": ["0x" + "1" * 40],
            "threshold": 1,
        }
        self.assertEqual(pipeline.required_job_signers(base), base["eligible_verifiers"])
        for changed in (
            {**base, "threshold": 0},
            {**base, "threshold": 2},
            {
                **base,
                "threshold": 2,
                "eligible_verifiers": ["0x" + "1" * 40, "0x" + "1" * 40],
            },
        ):
            with self.subTest(changed=changed), self.assertRaises(pipeline.PipelineError):
                pipeline.required_job_signers(changed)

    def test_verifier_signing_uses_a_dedicated_rpc_configuration(self) -> None:
        workflow_root = SCRIPT.parent.parent / ".github" / "workflows"
        for name in (
            "regression-verifier-signing-reusable.yml",
            "regression-verifier-signer.yml",
        ):
            with self.subTest(workflow=name):
                workflow = (workflow_root / name).read_text(encoding="utf-8")
                self.assertIn("vars.REGRESSION_VERIFIER_RPC_URL", workflow)
                self.assertNotIn("vars.BASE_MAINNET_RPC_URL", workflow)

    def test_stale_runner_revision_skips_every_signing_job(self) -> None:
        workflow = (
            SCRIPT.parent.parent / ".github" / "workflows" / "regression-verifier-signer.yml"
        ).read_text(encoding="utf-8")
        self.assertIn('echo "authorized=false" >> "$GITHUB_OUTPUT"', workflow)
        self.assertIn('echo "authorized=true" >> "$GITHUB_OUTPUT"', workflow)
        self.assertEqual(
            workflow.count("if: needs.authorize-run.outputs.authorized == 'true'"),
            3,
        )
        self.assertNotIn("Refusing to sign a candidate from stale main", workflow)

    def test_artifact_reference_requires_an_exact_public_commit(self) -> None:
        expected = ("owner/repo", "a" * 40)
        self.assertEqual(
            pipeline.parse_github_commit_url(
                f"https://github.com/owner/repo/commit/{'a' * 40}"
            ),
            expected,
        )
        invalid = [
            f"http://github.com/owner/repo/commit/{'a' * 40}",
            f"https://user@github.com/owner/repo/commit/{'a' * 40}",
            f"https://github.com/owner/repo/commit/{'a' * 39}",
            f"https://github.com/owner/repo/commit/{'a' * 40}?download=1",
            f"https://evil.example/owner/repo/commit/{'a' * 40}",
        ]
        for value in invalid:
            with self.subTest(value=value), self.assertRaises(pipeline.PipelineError):
                pipeline.parse_github_commit_url(value)

    def test_safe_archive_strips_root_and_selects_committed_subdirectory(self) -> None:
        value = archive(
            [
                ("repo-root/bench", None, "dir"),
                ("repo-root/bench/test.txt", b"expected", "file"),
                ("repo-root/source.txt", b"ignored", "file"),
            ]
        )
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            pipeline.extract_snapshot(
                value,
                root,
                subdirectory="bench",
                max_bytes=100,
                max_files=2,
            )
            self.assertEqual((root / "test.txt").read_bytes(), b"expected")
            self.assertFalse((root / "source.txt").exists())

    def test_subdirectory_limits_ignore_unrelated_archive_entries(self) -> None:
        value = archive(
            [
                (f"repo-root/unrelated/{index}.txt", b"ignored", "file")
                for index in range(200)
            ]
            + [("repo-root/bench/test.txt", b"expected", "file")]
        )
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            pipeline.extract_snapshot(
                value,
                root,
                subdirectory="bench",
                max_bytes=100,
                max_files=1,
            )
            self.assertEqual((root / "test.txt").read_bytes(), b"expected")
            self.assertFalse((root / "unrelated").exists())

    def test_subdirectory_entry_guard_applies_after_selection(self) -> None:
        value = archive(
            [(f"repo-root/bench/{index}", None, "dir") for index in range(105)]
        )
        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaisesRegex(
                pipeline.PipelineError,
                "selected snapshot has too many entries",
            ):
                pipeline.extract_snapshot(
                    value,
                    Path(temporary),
                    subdirectory="bench",
                    max_bytes=100,
                    max_files=1,
                )

    def test_archive_transport_caps_are_independent_of_snapshot_limits(self) -> None:
        self.assertEqual(pipeline.MAX_GITHUB_SOURCE_ARCHIVE_BYTES, 256 * 1024 * 1024)
        self.assertEqual(pipeline.MAX_GITHUB_BENCHMARK_ARCHIVE_BYTES, 128 * 1024 * 1024)
        self.assertEqual(
            pipeline.MAX_GITHUB_SOURCE_ARCHIVE_UNCOMPRESSED_BYTES,
            512 * 1024 * 1024,
        )
        self.assertEqual(
            pipeline.MAX_GITHUB_BENCHMARK_ARCHIVE_UNCOMPRESSED_BYTES,
            256 * 1024 * 1024,
        )

    def test_unselected_member_cannot_exceed_whole_archive_budget(self) -> None:
        value = archive(
            [
                ("repo-root/unrelated/large.bin", b"0123456789", "file"),
                ("repo-root/bench/test.txt", b"expected", "file"),
            ]
        )
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            with self.assertRaisesRegex(
                pipeline.PipelineError,
                "archive exceeds the uncompressed input limit",
            ):
                pipeline.extract_snapshot(
                    value,
                    root,
                    subdirectory="bench",
                    max_bytes=100,
                    max_files=1,
                    max_archive_bytes=9,
                )
            self.assertFalse((root / "test.txt").exists())

    def test_archive_links_traversal_and_size_overrun_fail_closed(self) -> None:
        cases = [
            archive([("root/link", None, "symlink")]),
            archive([("root/../escape", b"bad", "file")]),
        ]
        for value in cases:
            with self.subTest(size=len(value)), tempfile.TemporaryDirectory() as temporary:
                with self.assertRaises(pipeline.PipelineError):
                    pipeline.extract_snapshot(
                        value,
                        Path(temporary),
                        subdirectory=None,
                        max_bytes=100,
                        max_files=2,
                    )

        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaises(pipeline.PipelineError):
                pipeline.extract_snapshot(
                    archive([("root/large", b"0123456789", "file")]),
                    Path(temporary),
                    subdirectory=None,
                    max_bytes=5,
                    max_files=2,
                )

    def test_benchmark_source_is_exact_and_commit_pinned(self) -> None:
        job = {
            "terms": {
                "document": {
                    "benchmark": {
                        "source": {
                            "kind": "github_commit",
                            "repository": "owner/repo",
                            "commit": "b" * 40,
                            "subdirectory": "benchmarks/task",
                        }
                    }
                }
            }
        }
        self.assertEqual(
            pipeline.benchmark_source(job),
            ("owner/repo", "b" * 40, "benchmarks/task"),
        )
        job["terms"]["document"]["benchmark"]["source"]["branch"] = "main"
        with self.assertRaises(pipeline.PipelineError):
            pipeline.benchmark_source(job)

    def test_only_exact_reconciled_benchmark_digests_are_signable(self) -> None:
        self.assertEqual(
            repository_benchmark_digest("benchmarks/distribution-v1/glama-onboarding-audit"),
            "sha256:240a940036f8af4937657d369a2abe2ecd6f0b47a1c6d68c71d8123d980db541",
        )
        for digest in (
            "sha256:240a940036f8af4937657d369a2abe2ecd6f0b47a1c6d68c71d8123d980db541",
            "sha256:" + "d" * 64,
        ):
            job = {
                "terms": {
                    "document": {
                        "benchmark": {
                            "engine": "sandboxed_regression_v1",
                            "source": {
                                "kind": "github_commit",
                                "repository": "other/copied-benchmark",
                                "commit": "b" * 40,
                                "subdirectory": "different/location",
                            },
                            "runner_manifest": {
                                "benchmark_digest": digest
                            },
                        }
                    }
                }
            }
            with self.assertRaisesRegex(pipeline.PipelineError, "independently reconciled"):
                pipeline.require_reconciled_regression_benchmark(job)

        digest, (repository, commit, subdirectory) = approved_benchmark_source()
        approved = json.loads(json.dumps(job))
        approved["terms"]["document"]["benchmark"]["runner_manifest"][
            "benchmark_digest"
        ] = digest
        approved["terms"]["document"]["benchmark"]["source"].update(
            {
                "repository": repository,
                "commit": commit,
                "subdirectory": subdirectory,
            }
        )
        pipeline.require_reconciled_regression_benchmark(approved)

        unsupported = json.loads(json.dumps(approved))
        unsupported["terms"]["document"]["benchmark"]["engine"] = "other_engine"
        with self.assertRaisesRegex(pipeline.PipelineError, "engine is unavailable"):
            pipeline.require_reconciled_regression_benchmark(unsupported)
        for changed_source in (
            {"repository": "relocated/repository"},
            {"commit": "b" * 40},
            {"subdirectory": "copied/path"},
        ):
            mismatched = json.loads(json.dumps(approved))
            mismatched["terms"]["document"]["benchmark"]["source"].update(changed_source)
            with self.assertRaisesRegex(pipeline.PipelineError, "immutable source tuple"):
                pipeline.require_reconciled_regression_benchmark(mismatched)

    def test_original_openhands_terms_use_only_the_exact_reconciled_alias(self) -> None:
        fixture = SCRIPT.parent.parent / "crates/chain-base/tests/fixtures/legacy-openhands-terms.json"
        job = {"terms": json.loads(fixture.read_text(encoding="utf-8"))}
        pipeline.require_reconciled_regression_benchmark(job)
        benchmark = job["terms"]["document"]["benchmark"]
        self.assertEqual(
            benchmark["runner_manifest"]["benchmark_digest"],
            repository_benchmark_digest("benchmarks/direct-growth-v2/openhands-integration"),
        )
        for key, value in (
            ("repository", "relocated/repository"),
            ("commit", "b" * 40),
            ("subdirectory", "benchmarks/direct-growth-v2/hermes-integration"),
        ):
            changed = json.loads(json.dumps(job))
            changed["terms"]["document"]["benchmark"]["source"][key] = value
            with self.assertRaisesRegex(pipeline.PipelineError, "immutable source tuple"):
                pipeline.require_reconciled_regression_benchmark(changed)
        changed = json.loads(json.dumps(job))
        changed["terms"]["document"]["benchmark"]["runner_manifest"]["benchmark_digest"] = (
            "sha256:b9b0d026347a2922f913e9a8ed3651dd74e7eba930598981a169da3bf42e7c3f"
        )
        with self.assertRaisesRegex(pipeline.PipelineError, "immutable source tuple"):
            pipeline.require_reconciled_regression_benchmark(changed)

    def test_glama_canary_uses_only_the_rehearsed_historical_tuple(self) -> None:
        digest = "sha256:eed1340e372c85f87f8718696c03973748fb3fbaec7b4e90041d77d3513f9656"
        repository, commit, subdirectory = pipeline.RECONCILED_REGRESSION_BENCHMARK_SOURCES[digest]
        job = {
            "terms": {
                "document": {
                    "benchmark": {
                        "engine": "sandboxed_regression_v1",
                        "source": {
                            "kind": "github_commit",
                            "repository": repository,
                            "commit": commit,
                            "subdirectory": subdirectory,
                        },
                        "runner_manifest": {"benchmark_digest": digest},
                    }
                }
            }
        }
        pipeline.require_reconciled_regression_benchmark(job)
        for key, value in (
            ("repository", "relocated/repository"),
            ("commit", pipeline.RECONCILED_REGRESSION_BENCHMARK_COMMIT),
            ("subdirectory", "benchmarks/copied-location"),
        ):
            changed = json.loads(json.dumps(job))
            changed["terms"]["document"]["benchmark"]["source"][key] = value
            with self.assertRaisesRegex(pipeline.PipelineError, "immutable source tuple"):
                pipeline.require_reconciled_regression_benchmark(changed)

    def test_runner_pulls_only_the_exact_committed_image(self) -> None:
        manifest = {
            "image": f"docker.io/library/python@sha256:{'a' * 64}",
            "platform": "linux/amd64",
        }
        with mock.patch.object(pipeline, "run", return_value="") as run:
            pipeline.pull_pinned_image(manifest, "docker")
        run.assert_called_once_with(
            [
                "docker",
                "pull",
                "--platform",
                "linux/amd64",
                manifest["image"],
            ]
        )
        for image in [
            "docker.io/library/python:3.12",
            f"DOCKER.IO/library/python@sha256:{'a' * 64}",
            f"docker.io/library/python@sha256:{'g' * 64}",
        ]:
            with self.subTest(image=image), self.assertRaises(pipeline.PipelineError):
                pipeline.pull_pinned_image(
                    {"image": image, "platform": "linux/amd64"},
                    "docker",
                )


if __name__ == "__main__":
    unittest.main()

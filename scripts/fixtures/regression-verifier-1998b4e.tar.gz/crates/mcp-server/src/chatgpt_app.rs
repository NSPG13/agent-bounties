use super::{
    agent_native_claim, fund_bounty_with_x402, get_paid_status, get_x402_relay_status,
    inspect_open_competition_v2, list_autonomous_bounties, list_autonomous_verification_jobs,
    list_opportunities, list_unfunded_bounties, mcp_base_url_from_env,
    plan_autonomous_attestation_settlement, plan_autonomous_bounty_claim,
    plan_autonomous_module_settlement, plan_autonomous_verification_attestation,
    prepare_agent_to_earn, prepare_autonomous_bounty_submission, prepare_open_competition_v2,
    proxy_hosted_json, public_base_url_from_env, publish_autonomous_submission_evidence,
    publish_unfunded_bounty, submit_unfunded_bounty_solution, tools, AgentNativeClaimArgs,
    AutonomousBountyFeedArgs, AutonomousVerificationJobsArgs, GetX402RelayStatusArgs,
    ListUnfundedBountiesArgs, ObservedInterface, ObservedProtocolEra, OpenCompetitionV2InspectArgs,
    OpenCompetitionV2MutationArgs, OpportunityListArgs, PaidStatusArgs,
    PlanAutonomousAttestationSettlementArgs, PlanAutonomousBountyClaimArgs,
    PlanAutonomousModuleSettlementArgs, PlanAutonomousVerificationAttestationArgs,
    PrepareAgentToEarnInput, PrepareAutonomousBountySubmissionArgs, PrepareBountyPostArgs,
    PublishAutonomousSubmissionEvidenceArgs, PublishUnfundedBountyArgs, SharedState,
    SubmitUnfundedBountySolutionArgs, ToolDescriptor, X402BountyFundingArgs,
};
#[cfg(test)]
use super::{AppState, ChatgptFileInput};
use axum::{
    extract::{Path, State},
    http::{header::ORIGIN, HeaderMap, HeaderValue, StatusCode},
    response::{IntoResponse, Response},
    Json,
};
use base64::Engine as _;
use db::{
    distribution_acquisition_token_hash, normalize_distribution_rail,
    sign_distribution_acquisition_token, DistributionCompetitionBinding, NewBountyImageAsset,
};
use domain::BountyImageReference;
use serde::{Deserialize, Serialize};
use serde_json::{json, Map, Value};
use sha2::{Digest, Sha256};
use std::{env, net::IpAddr};
use url::Url;
use uuid::Uuid;

const MCP_PROTOCOL_VERSION: &str = "2026-07-28";
const MCP_LEGACY_PROTOCOL_VERSION: &str = "2025-06-18";
const MCP_CATALOG_TTL_MS: u64 = 300_000;
const MCP_PROTOCOL_VERSION_META: &str = "io.modelcontextprotocol/protocolVersion";
const MCP_CLIENT_INFO_META: &str = "io.modelcontextprotocol/clientInfo";
const MCP_CLIENT_CAPABILITIES_META: &str = "io.modelcontextprotocol/clientCapabilities";
const MCP_SERVER_INFO_META: &str = "io.modelcontextprotocol/serverInfo";
const MCP_PROTOCOL_VERSION_HEADER: &str = "mcp-protocol-version";
const MCP_METHOD_HEADER: &str = "mcp-method";
const MCP_NAME_HEADER: &str = "mcp-name";
const MCP_ALLOWED_ORIGINS_ENV: &str = "MCP_ALLOWED_ORIGINS";
const ACQUISITION_HEADER: &str = "x-agent-bounties-acquisition-id";
const ATTRIBUTION_RAIL_HEADER: &str = "x-agent-bounties-attribution-rail";
const FIRST_TOUCH_RAIL_HEADER: &str = "x-agent-bounties-first-touch-rail";
const CANARY_HEADER: &str = "x-agent-bounties-canary";
const MEASUREMENT_ELIGIBLE_HEADER: &str = "x-agent-bounties-measurement-eligible";
const INTERNAL_ATTRIBUTION_META: &str = "agentbounties.internal/attribution";
const CHATGPT_SANDBOX_ENV: &str = "CHATGPT_APP_SANDBOX_MODE";
const FEED_WIDGET_URI: &str = "ui://agent-bounties/live-feed-v4.html";
const POST_PAGE_URL: &str = "https://agentbounties.app/post.html";
const FEED_WIDGET_HTML: &str = include_str!("../assets/chatgpt-bounty-feed-widget.html");
const BOUNTY_CARD_PREVIEW_HTML: &str = include_str!("../assets/chatgpt-bounty-card-preview.html");
const FEED_CARD_ART: &[u8] =
    include_bytes!("../../../site/assets/solarpunk/characters-helping.webp");
const MAX_BOUNTY_IMAGE_BYTES: usize = 5 * 1024 * 1024;
const REGRESSION_ENGINE: &str = "sandboxed_regression_v1";
const RECONCILED_REGRESSION_BENCHMARK_DIGESTS: &[&str] = &[
    "sha256:b61a96a7d07ca01337ea3576de734f5b62ccab966a6d0da42a8736cfc0287ce6",
    "sha256:b9b0d026347a2922f913e9a8ed3651dd74e7eba930598981a169da3bf42e7c3f",
    "sha256:30bb17e3e3916747144c7087f49fb1ce41ddaf1aec4d717f878d2840203895a2",
    "sha256:6c7a300bcdd84f125bf9811297d72f3717d5ebd65f326c5e23687f44ba553043",
    "sha256:94eff483d0fbba47037a1dedaae1e9339e23f218eb29ea3182fbc256e7e1c587",
    "sha256:63e28323ea17da7ef0fb79e447256540e28f9c7525a8657707aea1598ce05bff",
    "sha256:73fc58dcd45e551344f8889095b7d3a71546170ba7f05fb1876aaf6aa796ac3d",
    "sha256:3bfb647d41539693c9598a01d9f9f7953a285dfb7c1986a190560a8745f64731",
    "sha256:a14e53feada2f49b646d340a494c822ec3112a2a6c468ce1cdb21fd7ee23a3d7",
    "sha256:eed1340e372c85f87f8718696c03973748fb3fbaec7b4e90041d77d3513f9656",
];
const RECONCILED_REGRESSION_BENCHMARK_COMMIT: &str = "fa946859a3379b8c9128183e20dedb3b8319a646";
// Keep the paid-rail canary bound to the independently rehearsed historical tree.
const RECONCILED_GLAMA_CANARY_COMMIT: &str = "0fae18cf9be464132cde52dfb9d464d836e8f024";
const RECONCILED_GLAMA_CANARY_DIGEST: &str =
    "sha256:eed1340e372c85f87f8718696c03973748fb3fbaec7b4e90041d77d3513f9656";
const RECONCILED_REGRESSION_BENCHMARK_SOURCES: &[(&str, &str)] = &[
    (
        RECONCILED_REGRESSION_BENCHMARK_DIGESTS[0],
        "benchmarks/direct-growth-v2/a2a-agent-card",
    ),
    (
        RECONCILED_REGRESSION_BENCHMARK_DIGESTS[1],
        "benchmarks/direct-growth-v2/hermes-integration",
    ),
    (
        RECONCILED_REGRESSION_BENCHMARK_DIGESTS[2],
        "benchmarks/direct-growth-v2/openhands-integration",
    ),
    (
        RECONCILED_REGRESSION_BENCHMARK_DIGESTS[3],
        "benchmarks/direct-growth-v2/mini-swe-agent-environment",
    ),
    (
        RECONCILED_REGRESSION_BENCHMARK_DIGESTS[4],
        "benchmarks/direct-inventory-v1/rpc-failover",
    ),
    (
        RECONCILED_REGRESSION_BENCHMARK_DIGESTS[5],
        "benchmarks/direct-inventory-v1/inventory-breakdown",
    ),
    (
        RECONCILED_REGRESSION_BENCHMARK_DIGESTS[6],
        "benchmarks/direct-inventory-v1/wallet-liquidity",
    ),
    (
        RECONCILED_REGRESSION_BENCHMARK_DIGESTS[7],
        "benchmarks/direct-inventory-v1/replenishment-plan",
    ),
    (
        RECONCILED_REGRESSION_BENCHMARK_DIGESTS[8],
        "benchmarks/direct-inventory-v1/stalled-work",
    ),
    (
        RECONCILED_GLAMA_CANARY_DIGEST,
        "benchmarks/distribution-v1/glama-onboarding-audit",
    ),
];
const CHATGPT_ADVERTISED_TOOL_NAMES: &[&str] = &[
    "get_bounty_feed",
    "render_bounty_feed",
    "prepare_moonpay_onramp",
    "prepare_bounty_post",
    "prepare_bounty_action",
    "get_bounty_action_status",
    "list_bounty_comments",
    "add_bounty_comment",
    "create_share_bundle",
];
const CHATGPT_COMPATIBILITY_TOOL_NAMES: &[&str] = &["list_autonomous_bounties"];
const CORE_MCP_EXTENSION_TOOL_NAMES: &[&str] =
    &["inspect_open_competition_v2", "prepare_open_competition_v2"];

#[derive(Debug, Clone, Serialize, Deserialize)]
pub(super) struct McpDistributionAttribution {
    acquisition_id: Uuid,
    acquisition_token: String,
    first_touch_rail: String,
    current_rail: String,
    measurement_eligible: bool,
}
#[derive(Debug, Clone, Deserialize)]
struct ChatgptFeedArgs {
    network: Option<String>,
    view: Option<String>,
    source_type: Option<String>,
    work_state: Option<String>,
    payment_state: Option<String>,
    limit: Option<u32>,
}

#[derive(Debug, Clone, Deserialize)]
struct RenderFeedArgs {
    #[serde(default)]
    opportunity_ids: Vec<String>,
    #[serde(flatten)]
    feed: ChatgptFeedArgs,
}

#[derive(Debug, Clone, Deserialize)]
struct ListCommentsArgs {
    bounty_id: String,
}

#[derive(Debug, Clone, Deserialize)]
struct AddCommentArgs {
    bounty_id: String,
    body: String,
    author: Option<String>,
    comment_id: Option<String>,
}

#[derive(Debug, Clone, Deserialize)]
struct ShareBundleArgs {
    bounty_id: String,
    title: String,
    stage: String,
    bounty_url: Option<String>,
    status: String,
    reward: Option<String>,
    payment_state: Option<String>,
    bounty_image_url: Option<String>,
}

#[derive(Debug, Clone, Deserialize)]
struct PrepareBountyActionArgs {
    idempotency_key: String,
    action: String,
    network: Option<String>,
    opportunity_id: Option<String>,
    bounty_contract: Option<String>,
    bounty_id: Option<String>,
    actor_wallet: Option<String>,
    amount_base_units: Option<u64>,
    #[serde(default)]
    details: Value,
}

#[derive(Debug, Clone, Deserialize)]
struct PrepareMoonpayOnrampArgs {
    bounty_contract: String,
    amount_base_units: u64,
    intent_id: Option<String>,
}

#[derive(Debug, Clone, Deserialize)]
struct GetBountyActionStatusArgs {
    intent_id: String,
}

fn custom_tool_descriptors() -> Vec<ToolDescriptor> {
    vec![
        ToolDescriptor {
            name: "get_bounty_feed",
            description: "Use this when the user or mounted feed needs fresh structured bounty data without rendering another widget. It is a read-only projection; each item includes its authoritative next action and evidence boundary. Use render_bounty_feed to display the interactive feed.",
            input_schema: json!({
                "type": "object",
                "properties": {
                    "network": {"type": ["string", "null"], "enum": ["base-mainnet", "base-sepolia", null]},
                    "view": {"type": ["string", "null"], "enum": ["recent", "engineering", "creative", "urgent", "seeking_funding", "ready_to_earn", null]},
                    "source_type": {"type": ["string", "null"], "enum": ["unfunded_offchain", "legacy_bounty", "canonical_base", null]},
                    "work_state": {"type": ["string", "null"], "enum": ["open", "claimable", "in_progress", "submitted", "completed", null]},
                    "payment_state": {"type": ["string", "null"], "enum": ["none", "seeking_funding", "escrowed", "paid", null]},
                    "limit": {"type": ["integer", "null"], "minimum": 1, "maximum": 300}
                },
                "additionalProperties": false
            }),
            authorization: None,
        },
        ToolDescriptor {
            name: "render_bounty_feed",
            description: "Use this when the user wants the interactive Agent Bounties feed rendered inside ChatGPT. For model-selected results, call get_bounty_feed first and pass the chosen opportunity_ids; otherwise omit them to render the current filtered feed.",
            input_schema: json!({
                "type": "object",
                "properties": {
                    "opportunity_ids": {
                        "type": "array",
                        "maxItems": 30,
                        "uniqueItems": true,
                        "items": {"type": "string", "minLength": 1, "maxLength": 200},
                        "description": "Optional opportunity identifiers selected from get_bounty_feed."
                    },
                    "network": {"type": ["string", "null"], "enum": ["base-mainnet", "base-sepolia", null]},
                    "view": {"type": ["string", "null"], "enum": ["recent", "engineering", "creative", "urgent", "seeking_funding", "ready_to_earn", null]},
                    "source_type": {"type": ["string", "null"], "enum": ["unfunded_offchain", "legacy_bounty", "canonical_base", null]},
                    "work_state": {"type": ["string", "null"], "enum": ["open", "claimable", "in_progress", "submitted", "completed", null]},
                    "payment_state": {"type": ["string", "null"], "enum": ["none", "seeking_funding", "escrowed", "paid", null]},
                    "limit": {"type": ["integer", "null"], "minimum": 1, "maximum": 30}
                },
                "additionalProperties": false
            }),
            authorization: None,
        },
        ToolDescriptor {
            name: "list_bounty_comments",
            description: "Use this when the user wants to read durable public in-chat comments on a bounty card. Comments are separate from canonical funding, verification, settlement, and payment evidence.",
            input_schema: json!({"type": "object", "properties": {"bounty_id": {"type": "string", "minLength": 1, "maxLength": 200}}, "required": ["bounty_id"], "additionalProperties": false}),
            authorization: None,
        },
        ToolDescriptor {
            name: "add_bounty_comment",
            description: "Use this when the user explicitly wants to comment on a bounty in the live in-chat feed. This publishes a bounded durable public comment and returns a share-ready follow-up; it never funds, claims, verifies, settles, or proves payment.",
            input_schema: json!({
                "type": "object",
                "properties": {
                    "bounty_id": {"type": "string", "minLength": 1, "maxLength": 200},
                    "body": {"type": "string", "minLength": 1, "maxLength": 500},
                    "author": {"type": ["string", "null"], "maxLength": 60},
                    "comment_id": {"type": ["string", "null"], "format": "uuid", "maxLength": 128}
                },
                "required": ["bounty_id", "body"],
                "additionalProperties": false
            }),
            authorization: None,
        },
        ToolDescriptor {
            name: "create_share_bundle",
            description: "Use this after every meaningful bounty step to create a concise social caption, hashtags, and safe share intents. It is a pure formatter and never claims that a plan, hash, or hosted record is canonical evidence.",
            input_schema: json!({
                "type": "object",
                "properties": {
                    "bounty_id": {"type": "string", "minLength": 1, "maxLength": 200},
                    "title": {"type": "string", "minLength": 1, "maxLength": 200},
                    "stage": {"type": "string", "minLength": 1, "maxLength": 40, "description": "Short factual stage label such as terms prepared, funding requested, solving, completed, verified, or commented."},
                    "bounty_url": {"type": "string", "minLength": 1, "maxLength": 12000},
                    "status": {"type": "string", "minLength": 1, "maxLength": 80},
                    "reward": {"type": ["string", "null"], "maxLength": 80},
                    "payment_state": {"type": ["string", "null"], "maxLength": 80},
                    "bounty_image_url": {"type": ["string", "null"], "description": "Optional first-party image URL from the selected bounty projection."}
                },
                "required": ["bounty_id", "title", "stage", "bounty_url", "status"],
                "additionalProperties": false
            }),
            authorization: None,
        },
        ToolDescriptor {
            name: "prepare_moonpay_onramp",
            description: "Use this when a person funding one canonical Base bounty needs Base USDC. It prepares a first-party HTTPS handoff to the existing MoonPay onramp page without opening checkout, moving money, requesting card data, or claiming that the bounty was funded.",
            input_schema: json!({
                "type": "object",
                "properties": {
                    "bounty_contract": {"type": "string", "pattern": "^0x[0-9a-fA-F]{40}$"},
                    "amount_base_units": {"type": "integer", "minimum": 1, "maximum": 1_000_000_000_000_u64, "description": "Planned bounty contribution in 6-decimal USDC base units."},
                    "intent_id": {"type": ["string", "null"], "format": "uuid", "description": "Optional hosted funding-intent identifier to preserve the return boundary."}
                },
                "required": ["bounty_contract", "amount_base_units"],
                "additionalProperties": false
            }),
            authorization: None,
        },
        ToolDescriptor {
            name: "prepare_bounty_action",
            description: "Use this when the person wants to post, fund, solve, complete, or verify a bounty after ChatGPT has collected the details conversationally and received explicit confirmation. It creates one idempotent first-party review session and returns an HTTPS authorization URL. It never asks ChatGPT for a wallet signature, private key, seed phrase, payment authorization, or verifier signature, and it never claims the action is complete.",
            input_schema: json!({
                "type": "object",
                "properties": {
                    "idempotency_key": {"type": "string", "minLength": 8, "maxLength": 200, "pattern": "^[A-Za-z0-9:._-]+$"},
                    "action": {"type": "string", "enum": ["post", "fund", "solve", "complete", "verify"]},
                    "network": {"type": ["string", "null"], "enum": ["base-mainnet", "base-sepolia", null]},
                    "opportunity_id": {"type": ["string", "null"], "minLength": 1, "maxLength": 200},
                    "bounty_contract": {"type": ["string", "null"], "pattern": "^0x[0-9a-fA-F]{40}$"},
                    "bounty_id": {"type": ["string", "null"], "pattern": "^0x[0-9a-fA-F]{64}$"},
                    "actor_wallet": {"type": ["string", "null"], "pattern": "^0x[0-9a-fA-F]{40}$"},
                    "amount_base_units": {"type": ["integer", "null"], "minimum": 1},
                    "details": {"type": "object", "description": "Bounded action-specific draft or evidence fields for first-party review."}
                },
                "required": ["idempotency_key", "action"],
                "additionalProperties": false
            }),
            authorization: None,
        },
        ToolDescriptor {
            name: "get_bounty_action_status",
            description: "Use this when the person returns from first-party wallet review and the in-chat card needs to refresh one hosted bounty action. Confirmed status requires the exact indexed canonical event. A prepared session, signature, transaction hash, or receipt is never reported as completion or payment.",
            input_schema: json!({
                "type": "object",
                "properties": {
                    "intent_id": {"type": "string", "format": "uuid"}
                },
                "required": ["intent_id"],
                "additionalProperties": false
            }),
            authorization: None,
        },
    ]
}

pub(super) async fn prepare_bounty_post_handoff(
    state: &SharedState,
    args: &PrepareBountyPostArgs,
    attribution: Option<&McpDistributionAttribution>,
) -> Result<Value, String> {
    // Fail closed on every non-file field before downloading or persisting an
    // optional approved image.
    let mut stable_args = args.clone();
    stable_args.posting_operation_id = Some(prepared_posting_operation_id(args)?);
    let args = &stable_args;
    let validation_image = sandbox_bounty_image_reference(args)?;
    let validation_handoff = build_bounty_post_handoff(args, validation_image.as_ref())?;
    let handoff = if validation_image.is_none() {
        validation_handoff
    } else {
        let image = persist_chatgpt_bounty_image(state, args).await?;
        build_bounty_post_handoff(args, Some(&image))?
    };
    attach_distribution_attribution(state, args, handoff, attribution).await
}

async fn attach_distribution_attribution(
    state: &SharedState,
    args: &PrepareBountyPostArgs,
    mut handoff: Value,
    attribution: Option<&McpDistributionAttribution>,
) -> Result<Value, String> {
    let Some(attribution) = attribution else {
        return Ok(handoff);
    };
    let store = state.store.as_ref().ok_or_else(|| {
        "durable distribution attribution is unavailable for this rail".to_string()
    })?;
    let request_fingerprint = Sha256::digest(
        serde_json::to_vec(args)
            .map_err(|error| format!("could not fingerprint the prepared handoff: {error}"))?,
    )
    .iter()
    .map(|byte| format!("{byte:02x}"))
    .collect::<String>();
    let reserved = store
        .reserve_distribution_handoff(
            attribution.acquisition_id,
            &request_fingerprint,
            chrono::Utc::now(),
        )
        .await
        .map_err(|error| format!("could not persist the attributed handoff: {error}"))?;
    let post_url = handoff
        .get("post_url")
        .and_then(Value::as_str)
        .ok_or_else(|| "prepared handoff did not contain a post URL".to_string())?;
    let mut post_url =
        Url::parse(post_url).map_err(|_| "prepared handoff post URL is invalid".to_string())?;
    post_url
        .query_pairs_mut()
        .append_pair("acquisition", &attribution.acquisition_token)
        .append_pair("handoff", &reserved.id.to_string());
    if post_url.as_str().len() > 12_000 {
        return Err(
            "the attributed bounty is too large for a safe browser handoff; shorten the goal or acceptance criteria"
                .to_string(),
        );
    }
    let object = handoff
        .as_object_mut()
        .ok_or_else(|| "prepared handoff is not an object".to_string())?;
    object.insert("post_url".to_string(), Value::String(post_url.to_string()));
    object.insert(
        "attribution".to_string(),
        json!({
            "acquisition_id": attribution.acquisition_token,
            "handoff_id": reserved.id,
            "first_touch_rail": attribution.first_touch_rail,
            "current_rail": attribution.current_rail,
            "terms_publish_headers": {
                "x-agent-bounties-acquisition-id": attribution.acquisition_token,
                "x-agent-bounties-handoff-id": reserved.id,
            },
            "authority": "analytics_only"
        }),
    );
    Ok(handoff)
}

fn distribution_request_fingerprint(arguments: &Value) -> String {
    hex::encode(Sha256::digest(
        serde_json::to_vec(arguments).unwrap_or_else(|_| b"invalid-json-value".to_vec()),
    ))
}

fn competition_preparation_binding(
    result: &Value,
    attribution: &McpDistributionAttribution,
) -> Result<DistributionCompetitionBinding, String> {
    if !result
        .get("http_status")
        .and_then(Value::as_u64)
        .is_some_and(|status| (200..300).contains(&status))
    {
        return Err("creation API did not return a successful HTTP status".to_string());
    }
    let plan: chain_base::OpenCompetitionV2CreationPlan = serde_json::from_value(
        result
            .pointer("/body/plan")
            .cloned()
            .ok_or("creation result has no plan")?,
    )
    .map_err(|_| "creation result has an invalid plan".to_string())?;
    if plan.schema_version != "agent-bounties/open-competition-v2-creation-plan-v1"
        || plan.protocol_version != "agent-bounties/open-competition-v2-beta3"
    {
        return Err("creation attribution requires the supported Beta3 plan".to_string());
    }
    let network_name = match plan.network.name.as_str() {
        "Base" => "base-mainnet",
        "Base Sepolia" => "base-sepolia",
        name => name,
    };
    let expected_network = chain_base::base_network_descriptor(network_name)
        .map_err(|_| "creation plan has an unsupported network".to_string())?;
    if plan.network.chain_id != expected_network.chain_id {
        return Err("creation plan network and chain ID disagree".to_string());
    }
    let network = match expected_network.chain_id {
        8_453 => "base-mainnet",
        84_532 => "base-sepolia",
        _ => return Err("creation plan has an unsupported chain ID".to_string()),
    };
    let creates: Vec<_> = plan
        .wallet_calls
        .iter()
        .filter(|call| call.function.starts_with("createCompetition("))
        .collect();
    if creates.len() != 1 {
        return Err("creation plan must contain exactly one factory creation call".to_string());
    }
    let create = creates[0];
    let address = |value: &str| {
        chain_base::normalize_evm_address(value)
            .map(|value| value.to_ascii_lowercase())
            .map_err(|_| "creation plan has an invalid address".to_string())
    };
    let creator = address(
        create
            .from
            .as_deref()
            .ok_or("creation plan has no creator")?,
    )?;
    let bounty_id = plan.bounty_id.to_ascii_lowercase();
    if bounty_id.len() != 66
        || !bounty_id.starts_with("0x")
        || !bounty_id[2..].bytes().all(|byte| byte.is_ascii_hexdigit())
    {
        return Err("creation plan has an invalid bounty ID".to_string());
    }
    Ok(DistributionCompetitionBinding {
        acquisition_id: attribution.acquisition_id,
        protocol_version: plan.protocol_version,
        network: network.to_string(),
        factory_contract: address(&create.to)?,
        bounty_id,
        competition_contract: address(&plan.predicted_competition)?,
        creator_wallet: creator,
        // Timestamp the successfully parsed response, never the earlier request.
        prepared_at: chrono::Utc::now(),
    })
}

async fn attach_competition_preparation_attribution(
    state: &SharedState,
    mut result: Value,
    attribution: Option<&McpDistributionAttribution>,
) -> Result<Value, String> {
    let Some(attribution) = attribution else {
        return Ok(result);
    };
    let binding = competition_preparation_binding(&result, attribution)?;
    state
        .store
        .as_ref()
        .ok_or("durable competition attribution is unavailable")?
        .bind_distribution_competition(&binding)
        .await
        .map_err(|_| "competition preparation attribution could not be preserved".to_string())?;
    result.as_object_mut().ok_or("creation response is not an object")?.insert(
        "attribution".to_string(),
        json!({
            "authority": "analytics_only",
            "state": "unsigned_preparation_recorded",
            "first_touch_rail": attribution.first_touch_rail,
            "current_rail": attribution.current_rail,
            "measurement_eligible": attribution.measurement_eligible,
            "protocol_version": binding.protocol_version,
            "network": binding.network,
            "factory_contract": binding.factory_contract,
            "bounty_id": binding.bounty_id,
            "competition_contract": binding.competition_contract,
            "evidence_boundary": "A preparation is not creation, funding, activation, or settlement. Only matching confirmed canonical events establish those outcomes."
        }),
    );
    Ok(result)
}

async fn record_prepare_handoff_failure(
    state: &SharedState,
    attribution: Option<&McpDistributionAttribution>,
    request_fingerprint: &str,
    failure_code: &str,
) {
    let (Some(store), Some(attribution)) = (state.store.as_ref(), attribution) else {
        return;
    };
    let _ = store
        .record_distribution_handoff_failure(
            attribution.acquisition_id,
            request_fingerprint,
            failure_code,
            chrono::Utc::now(),
        )
        .await;
}

pub(super) fn build_bounty_post_handoff(
    args: &PrepareBountyPostArgs,
    image: Option<&BountyImageReference>,
) -> Result<Value, String> {
    let title = bounded_text(&args.title, "title", 200)?;
    let goal = bounded_text(&args.goal, "goal", 4_000)?;
    if args.acceptance_criteria.is_empty() || args.acceptance_criteria.len() > 20 {
        return Err("acceptance_criteria must contain between 1 and 20 items".to_string());
    }
    let acceptance_criteria = args
        .acceptance_criteria
        .iter()
        .map(|criterion| bounded_text(criterion, "acceptance criterion", 1_000))
        .collect::<Result<Vec<_>, _>>()?;
    let solver_reward = parse_usdc(&args.solver_reward_usdc, "solver_reward_usdc")?;
    let verifier_reward = parse_usdc(&args.verifier_reward_usdc, "verifier_reward_usdc")?;
    let meta_child = validate_prepared_parent(args.meta_child.as_ref())?;
    let qualifying_child_draft = meta_child.is_some()
        && solver_reward > 0
        && verifier_reward >= 10_000
        && verifier_reward % 2 == 0
        && solver_reward.checked_add(verifier_reward) == Some(1_000_000);
    if solver_reward < 2_000_000 && !qualifying_child_draft {
        return Err("public bounties require at least 2 USDC for the solver".to_string());
    }
    if verifier_reward < 10_000 {
        return Err("public bounties require at least 0.01 USDC for the verifier".to_string());
    }
    let target = solver_reward
        .checked_add(verifier_reward)
        .ok_or_else(|| "combined USDC target is too large".to_string())?;
    let source_url = optional_https_url(args.source_url.as_deref(), "source_url")?;
    let task_window_days = args.task_window_days.unwrap_or(30);
    if !(1..=30).contains(&task_window_days) {
        return Err("task_window_days must be from 1 to 30".to_string());
    }
    let discovery_source = args
        .discovery_source
        .as_deref()
        .map(|value| bounded_text(value, "discovery_source", 500))
        .transpose()?;
    let review_mode = args.review_mode.as_deref().unwrap_or("automated");
    match review_mode {
        "creator" => {
            if meta_child.is_some() || args.benchmark.is_some() || args.evidence_schema.is_some() {
                return Err("Creator review cannot replace a meta-child verifier or an automated benchmark. Omit benchmark and evidence_schema when explicitly selecting creator review.".to_string());
            }
            let deadline = args.delivery_deadline.as_deref().ok_or(
                "Creator review requires the exact agreed delivery_deadline with timezone offset.",
            )?;
            let parsed = chrono::DateTime::parse_from_rfc3339(deadline).map_err(|_| {
                "delivery_deadline must be an ISO timestamp including its timezone offset"
                    .to_string()
            })?;
            let now = chrono::Utc::now();
            if parsed <= now || parsed > now + chrono::Duration::days(366) {
                return Err(
                    "Creator review requires a future delivery deadline within 366 days."
                        .to_string(),
                );
            }
        }
        "automated" => {
            if args.delivery_deadline.is_some() {
                return Err("An automated benchmark does not enforce a calendar delivery deadline. Select creator review or explicitly agree a relative work window.".to_string());
            }
            validate_prepared_verifier(args.benchmark.as_ref(), args.evidence_schema.as_ref())?;
        }
        _ => return Err("review_mode must be creator or automated".to_string()),
    }
    let posting_operation_id = prepared_posting_operation_id(args)?;
    validate_prepared_reference(args.reference_attachment.as_ref())?;
    match (
        image,
        args.image_prompt.as_deref(),
        args.image_alt_text.as_deref(),
        args.bounty_image.as_ref(),
    ) {
        (None, None, None, None) => {}
        (Some(image), Some(prompt), Some(alt_text), Some(_)) => {
            let image_prompt = bounded_text(prompt, "image_prompt", 4_000)?;
            let image_alt_text = bounded_text(alt_text, "image_alt_text", 500)?;
            if image.source != "chatgpt_user_generated"
                || image.prompt != image_prompt
                || image.alt_text != image_alt_text
            {
                return Err(
                    "the stored bounty image must match the prompt and alt text approved in the AI conversation"
                        .to_string(),
                );
            }
        }
        _ => {
            return Err(
                "bounty_image, image_prompt, and image_alt_text must be supplied together or all omitted"
                    .to_string(),
            );
        }
    }

    let mut post_url = Url::parse(POST_PAGE_URL).expect("static post URL is valid");
    {
        let mut query = post_url.query_pairs_mut();
        query.append_pair("from", "ai-app");
        query.append_pair("operation_id", &posting_operation_id.to_string());
        query.append_pair("reviewMode", review_mode);
        if let Some(deadline) = &args.delivery_deadline {
            query.append_pair("deliveryDeadline", deadline);
        }
        if let Some(parent) = &meta_child {
            query.append_pair(
                "parentBounty",
                parent["parent_bounty_contract"]
                    .as_str()
                    .expect("validated parent"),
            );
            if let Some(solver) = parent["intended_child_solver"].as_str() {
                query.append_pair("intendedChildSolver", solver);
            }
        }
        if let Some(reference) = &args.reference_attachment {
            query.append_pair(
                "referenceAttachment",
                &serde_json::to_string(reference)
                    .map_err(|_| "reference_attachment could not be encoded")?,
            );
        }
        query.append_pair("title", &title);
        query.append_pair("goal", &goal);
        for criterion in &acceptance_criteria {
            query.append_pair("criterion", criterion);
        }
        query.append_pair("solverReward", &format_usdc(solver_reward));
        query.append_pair("verifierReward", &format_usdc(verifier_reward));
        query.append_pair("taskWindowDays", &task_window_days.to_string());
        query.append_pair("crowdfund", if args.crowdfund { "true" } else { "false" });
        if let Some(source_url) = &source_url {
            query.append_pair("sourceUrl", source_url);
        }
        query.append_pair(
            "discoverySource",
            discovery_source
                .as_deref()
                .unwrap_or("AI assistant via MCP"),
        );
        if let Some(benchmark) = args.benchmark.as_ref() {
            query.append_pair(
                "benchmark",
                &serde_json::to_string(benchmark)
                    .map_err(|_| "benchmark could not be encoded for browser review".to_string())?,
            );
        }
        if let Some(evidence_schema) = args.evidence_schema.as_ref() {
            query.append_pair(
                "evidenceSchema",
                &serde_json::to_string(evidence_schema).map_err(|_| {
                    "evidence_schema could not be encoded for browser review".to_string()
                })?,
            );
        }
        if let Some(image) = image {
            query.append_pair("imageUrl", &image.asset_url);
            query.append_pair("imageSha256", &image.sha256);
            query.append_pair("imageMimeType", &image.mime_type);
            query.append_pair("imagePrompt", &image.prompt);
            query.append_pair("imageAlt", &image.alt_text);
        }
    }
    if post_url.as_str().len() > 12_000 {
        return Err(
            "the prepared bounty is too large for a safe browser handoff; shorten the goal or acceptance criteria"
                .to_string(),
        );
    }

    Ok(json!({
        "schema": "agent-bounties/chatgpt-post-handoff-v1",
        "state": "review_required_not_published",
        "posting_operation_id": posting_operation_id,
        "review_mode": review_mode,
        "delivery_deadline": args.delivery_deadline,
        "meta_child": meta_child,
        "reference_attachment": args.reference_attachment,
        "verification_prepared": review_mode == "creator" || args.benchmark.is_some(),
        "review_disclosure": if review_mode == "creator" { Some("The creator reviews every published check and confirms the verdict. The creator-review reserve is paid to the creator on pass or fail. This is human review; wallet and legal confirmations remain with the creator.") } else { None },
        "title": title,
        "goal": goal,
        "acceptance_criteria": acceptance_criteria,
        "solver_reward_usdc": format_usdc(solver_reward),
        "verifier_reward_usdc": format_usdc(verifier_reward),
        "target_usdc": format_usdc(target),
        "task_window_days": task_window_days,
        "initial_funding_usdc": if args.crowdfund { "0".to_string() } else { format_usdc(target) },
        "crowdfund": args.crowdfund,
        "source_url": source_url,
        "benchmark": args.benchmark,
        "evidence_schema": args.evidence_schema,
        "image": image,
        "post_url": post_url.as_str(),
        "bounty_created": false,
        "wallet_signature_requested": false,
        "next_action": "Open the secure handoff, review every field, and choose whether to deposit 0 USDC now or fully fund. Then connect the creator wallet and approve only the exact Base transaction shown by that wallet.",
        "evidence_boundary": "No bounty id or contract exists yet. Only confirmed CanonicalBountyCreated proves creation; FundingAdded and BountyBecameClaimable prove funding and claimability."
    }))
}

fn prepared_posting_operation_id(args: &PrepareBountyPostArgs) -> Result<uuid::Uuid, String> {
    if let Some(id) = args.posting_operation_id {
        return Ok(id);
    }
    // An unchanged request remains the same journey across MCP retries. This is
    // only an identifier: every persisted draft still requires its owner's session.
    let bytes = serde_json::to_vec(args).map_err(|_| "could not identify the posting operation")?;
    Ok(uuid::Uuid::new_v5(&uuid::Uuid::NAMESPACE_URL, &bytes))
}

fn validate_prepared_reference(reference: Option<&Value>) -> Result<(), String> {
    let Some(value) = reference else {
        return Ok(());
    };
    // Same immutable homepage originals as site/posting-reference.js. Validate
    // before fetching any optional cover image; this descriptor cannot fetch URLs.
    let (hash, length) = match (value["phase"].as_str(), value["variant"].as_str()) {
        (Some("dawn"), Some("desktop")) => (
            "a7cdaf198c5ed18cf4921d5d5a180353d7f461f96906822cfc3489e229d0c29a",
            202068,
        ),
        (Some("dawn"), Some("mobile")) => (
            "ded24e4a5aaa0593caf7411ba998bc8e36dea6cb6a5042b69762035645858629",
            96120,
        ),
        (Some("day"), Some("desktop")) => (
            "f9143ee70ca0551bc97562c89c96cc56b4a54391ab4034315148253b757fcaef",
            256228,
        ),
        (Some("day"), Some("mobile")) => (
            "7a62291ef8cafe5ce7371a55c79e44432cfe338c8e884d98c95b3fd1a4a172cd",
            98768,
        ),
        (Some("dusk"), Some("desktop")) => (
            "73e5628a4184a854654df37cc6cf46d18ba14a5f45962619a6606c5627bb24a9",
            255156,
        ),
        (Some("dusk"), Some("mobile")) => (
            "6a478e020ba6362ce8899d761d858e4dd6ba35221bc89fc76a078bd911bad5ad",
            113114,
        ),
        (Some("night"), Some("desktop")) => (
            "06fc595b47101033af0ac00a71b4052f31c84d924cc1078e37a42e855d7883fa",
            149004,
        ),
        (Some("night"), Some("mobile")) => (
            "9705a9ccb07c91ff4cdb360fc6dc6393c5fb7f149bb7479877b9bef4dfcc8b9c",
            61982,
        ),
        _ => {
            return Err(
                "reference_attachment must identify a supported homepage background".to_string(),
            )
        }
    };
    let asset_url = format!("https://raw.githubusercontent.com/NSPG13/agent-bounties/933c9c446a76d26f148a4f2defacf6453d02a7b2/site/assets/solarpunk/scene-{}{}.webp", value["phase"].as_str().unwrap(), if value["variant"] == "mobile" { "-mobile" } else { "" });
    let valid = value.as_object().is_some_and(|object| {
        object.len() == 10
            && object.keys().all(|key| {
                [
                    "version",
                    "kind",
                    "phase",
                    "variant",
                    "source_url",
                    "asset_url",
                    "captured_at",
                    "sha256",
                    "mime_type",
                    "byte_length",
                ]
                .contains(&key.as_str())
            })
    }) && value["version"] == 1
        && value["kind"] == "homepage_background"
        && value["source_url"] == "https://agentbounties.app/"
        && value["asset_url"] == asset_url
        && value["sha256"] == format!("sha256:{hash}")
        && value["byte_length"] == length
        && value["mime_type"] == "image/webp"
        && value["captured_at"]
            .as_str()
            .and_then(|time| chrono::DateTime::parse_from_rfc3339(time).ok())
            .is_some_and(|time| time <= chrono::Utc::now() + chrono::Duration::minutes(5));
    if !valid {
        return Err(
            "reference_attachment does not match its immutable image, digest and capture time"
                .to_string(),
        );
    }
    Ok(())
}

fn validate_prepared_parent(value: Option<&Value>) -> Result<Option<Value>, String> {
    let Some(value) = value else { return Ok(None) };
    let object = value.as_object().ok_or("meta_child must be an object")?;
    if object
        .keys()
        .any(|key| !["parent_bounty_contract", "intended_child_solver"].contains(&key.as_str()))
    {
        return Err("meta_child contains unsupported fields".to_string());
    }
    let address = |key: &str| -> Result<Option<String>, String> {
        match object.get(key) {
            None | Some(Value::Null) if key != "parent_bounty_contract" => Ok(None),
            Some(Value::String(value)) => {
                let normalized = chain_base::normalize_evm_address(value)
                    .map_err(|_| format!("{key} must be an EVM address"))?;
                if normalized.eq_ignore_ascii_case("0x0000000000000000000000000000000000000000") {
                    return Err(format!("{key} must not be the zero address"));
                }
                Ok(Some(normalized.to_ascii_lowercase()))
            }
            _ => Err(format!("{key} must be an EVM address")),
        }
    };
    Ok(Some(
        json!({"parent_bounty_contract": address("parent_bounty_contract")?, "intended_child_solver": address("intended_child_solver")?}),
    ))
}

fn validate_prepared_verifier(
    benchmark: Option<&Value>,
    evidence_schema: Option<&Value>,
) -> Result<(), String> {
    match (benchmark, evidence_schema) {
        (None, None) => return Ok(()),
        (None, Some(_)) => {
            return Err("benchmark is required when evidence_schema is supplied".to_string())
        }
        (Some(_), None) => {
            return Err("evidence_schema is required when benchmark is supplied".to_string())
        }
        (Some(_), Some(_)) => {}
    }
    let benchmark = benchmark.expect("matched benchmark presence");
    let evidence_schema = evidence_schema.expect("matched evidence schema presence");
    for (value, label) in [
        (benchmark, "benchmark"),
        (evidence_schema, "evidence_schema"),
    ] {
        let encoded = serde_json::to_vec(value)
            .map_err(|_| format!("{label} could not be encoded safely"))?;
        if encoded.len() > 20_000 {
            return Err(format!("{label} exceeds the 20,000-byte handoff limit"));
        }
        if !value.is_object() {
            return Err(format!("{label} must be an object"));
        }
    }
    if evidence_schema.get("type").and_then(Value::as_str) != Some("object") {
        return Err("evidence_schema.type must be object".to_string());
    }
    let required = evidence_schema
        .get("required")
        .and_then(Value::as_array)
        .ok_or_else(|| {
            "evidence_schema.required must include source_snapshot_digest".to_string()
        })?;
    if !required
        .iter()
        .any(|field| field.as_str() == Some("source_snapshot_digest"))
    {
        return Err("evidence_schema must require source_snapshot_digest".to_string());
    }
    let source_digest = evidence_schema
        .get("properties")
        .and_then(Value::as_object)
        .and_then(|properties| properties.get("source_snapshot_digest"))
        .and_then(Value::as_object)
        .ok_or_else(|| {
            "evidence_schema.properties.source_snapshot_digest is required".to_string()
        })?;
    if source_digest.get("type").and_then(Value::as_str) != Some("string")
        || source_digest.get("pattern").and_then(Value::as_str) != Some("^sha256:[0-9a-f]{64}$")
    {
        return Err(
            "evidence_schema.source_snapshot_digest must require sha256:<64 lowercase hex>"
                .to_string(),
        );
    }
    if benchmark.get("engine").and_then(Value::as_str) != Some(REGRESSION_ENGINE) {
        return Err(format!("benchmark.engine must be {REGRESSION_ENGINE}"));
    }
    let source = benchmark
        .get("source")
        .and_then(Value::as_object)
        .ok_or_else(|| "benchmark.source must be an object".to_string())?;
    if source.get("kind").and_then(Value::as_str) != Some("github_commit") {
        return Err("benchmark.source.kind must be github_commit".to_string());
    }
    let repository = source
        .get("repository")
        .and_then(Value::as_str)
        .ok_or_else(|| "benchmark.source.repository is required".to_string())?;
    let repository_parts = repository.split('/').collect::<Vec<_>>();
    if repository_parts.len() != 2
        || repository_parts.iter().any(|part| {
            part.is_empty()
                || part.len() > 100
                || !part
                    .bytes()
                    .all(|byte| byte.is_ascii_alphanumeric() || matches!(byte, b'.' | b'_' | b'-'))
        })
    {
        return Err("benchmark.source.repository must be owner/repository".to_string());
    }
    let commit = source
        .get("commit")
        .and_then(Value::as_str)
        .ok_or_else(|| "benchmark.source.commit is required".to_string())?;
    if commit.len() != 40
        || !commit
            .bytes()
            .all(|byte| byte.is_ascii_hexdigit() && !byte.is_ascii_uppercase())
    {
        return Err(
            "benchmark.source.commit must be 40 lowercase hexadecimal characters".to_string(),
        );
    }
    let subdirectory = source
        .get("subdirectory")
        .and_then(Value::as_str)
        .ok_or_else(|| "benchmark.source.subdirectory is required".to_string())?;
    if subdirectory.is_empty()
        || subdirectory.len() > 500
        || subdirectory.starts_with('/')
        || subdirectory.ends_with('/')
        || subdirectory.contains('\\')
        || subdirectory
            .split('/')
            .any(|part| part.is_empty() || matches!(part, "." | ".."))
    {
        return Err("benchmark.source.subdirectory must be a normalized non-root path".to_string());
    }
    let runner = benchmark
        .get("runner_manifest")
        .and_then(Value::as_object)
        .ok_or_else(|| "benchmark.runner_manifest must be an object".to_string())?;
    let expected_runner_keys = [
        "schema_version",
        "image",
        "command",
        "workdir",
        "benchmark_digest",
        "timeout_seconds",
        "cpu_millis",
        "memory_bytes",
        "pids_limit",
        "max_output_bytes",
        "tmpfs_bytes",
        "max_source_bytes",
        "max_source_files",
        "max_benchmark_bytes",
        "max_benchmark_files",
        "platform",
        "test_seed",
    ];
    if runner.len() != expected_runner_keys.len()
        || expected_runner_keys
            .iter()
            .any(|key| !runner.contains_key(*key))
    {
        return Err(
            "benchmark.runner_manifest must contain the complete regression-sandbox-v1 field set"
                .to_string(),
        );
    }
    if runner.get("schema_version").and_then(Value::as_str)
        != Some("agent-bounties/regression-sandbox-v1")
    {
        return Err(
            "benchmark.runner_manifest.schema_version must be agent-bounties/regression-sandbox-v1"
                .to_string(),
        );
    }
    let image = runner
        .get("image")
        .and_then(Value::as_str)
        .ok_or_else(|| "benchmark.runner_manifest.image is required".to_string())?;
    let image_parts = image.split('@').collect::<Vec<_>>();
    if image_parts.len() != 2
        || image_parts[0].is_empty()
        || image_parts[0].starts_with('-')
        || image_parts[0].contains("..")
        || image_parts[0].bytes().any(|byte| {
            !(byte.is_ascii_lowercase()
                || byte.is_ascii_digit()
                || matches!(byte, b'.' | b'/' | b':' | b'_' | b'-'))
        })
        || !valid_sha256_digest(image_parts[1])
    {
        return Err(
            "benchmark.runner_manifest.image must be one lowercase OCI reference pinned by sha256 digest"
                .to_string(),
        );
    }
    let command = runner
        .get("command")
        .and_then(Value::as_array)
        .ok_or_else(|| "benchmark.runner_manifest.command must be an array".to_string())?;
    if command.is_empty() || command.len() > 64 {
        return Err(
            "benchmark.runner_manifest.command must contain 1 to 64 direct argv entries"
                .to_string(),
        );
    }
    let mut command_bytes = 0usize;
    for argument in command {
        let argument = argument.as_str().ok_or_else(|| {
            "benchmark.runner_manifest.command entries must be strings".to_string()
        })?;
        if argument.is_empty() || argument.len() > 4_096 || argument.contains(['\0', '\n', '\r']) {
            return Err(
                "benchmark.runner_manifest.command contains an invalid argv entry".to_string(),
            );
        }
        command_bytes = command_bytes.saturating_add(argument.len());
    }
    if command_bytes > 16_384 {
        return Err("benchmark.runner_manifest.command exceeds the argv byte limit".to_string());
    }
    let executable = command[0]
        .as_str()
        .unwrap_or_default()
        .rsplit(['/', '\\'])
        .next()
        .unwrap_or_default()
        .to_ascii_lowercase();
    if matches!(
        executable.as_str(),
        "sh" | "bash" | "dash" | "zsh" | "cmd" | "cmd.exe" | "powershell" | "pwsh"
    ) {
        return Err(
            "benchmark.runner_manifest.command must use direct argv and cannot invoke a shell"
                .to_string(),
        );
    }
    if runner.get("workdir").and_then(Value::as_str) != Some("/workspace") {
        return Err("benchmark.runner_manifest.workdir must be /workspace".to_string());
    }
    let benchmark_digest = runner
        .get("benchmark_digest")
        .and_then(Value::as_str)
        .filter(|value| valid_sha256_digest(value))
        .ok_or_else(|| {
            "benchmark.runner_manifest.benchmark_digest must use sha256:<64 lowercase hex>"
                .to_string()
        })?;
    if !RECONCILED_REGRESSION_BENCHMARK_DIGESTS.contains(&benchmark_digest) {
        return Err(
            "sandboxed regression benchmark exact digest must be independently reconciled and approved before funding or verifier signing".to_string(),
        );
    }
    let approved_subdirectory = RECONCILED_REGRESSION_BENCHMARK_SOURCES.iter().find_map(
        |(digest, approved_subdirectory)| {
            (*digest == benchmark_digest).then_some(*approved_subdirectory)
        },
    );
    let approved_commit = (commit == RECONCILED_REGRESSION_BENCHMARK_COMMIT
        && benchmark_digest != RECONCILED_GLAMA_CANARY_DIGEST)
        || (commit == RECONCILED_GLAMA_CANARY_COMMIT
            && benchmark_digest == RECONCILED_GLAMA_CANARY_DIGEST);
    if !repository.eq_ignore_ascii_case("NSPG13/agent-bounties")
        || !approved_commit
        || approved_subdirectory != Some(subdirectory)
    {
        return Err(
            "sandboxed regression benchmark immutable source tuple must match its independently approved digest"
                .to_string(),
        );
    }
    let bounds = [
        ("timeout_seconds", 1, 900),
        ("cpu_millis", 100, 4_000),
        ("memory_bytes", 67_108_864, 4_294_967_296),
        ("pids_limit", 16, 512),
        ("max_output_bytes", 1_024, 16_777_216),
        ("tmpfs_bytes", 67_108_864, 4_294_967_296),
        ("max_source_bytes", 1, 2_147_483_648),
        ("max_source_files", 1, 100_000),
        ("max_benchmark_bytes", 1, 536_870_912),
        ("max_benchmark_files", 1, 50_000),
        ("test_seed", 0, 9_007_199_254_740_991),
    ];
    for (field, minimum, maximum) in bounds {
        if !runner
            .get(field)
            .and_then(Value::as_u64)
            .is_some_and(|value| (minimum..=maximum).contains(&value))
        {
            return Err(format!(
                "benchmark.runner_manifest.{field} is outside protocol bounds"
            ));
        }
    }
    if runner["tmpfs_bytes"].as_u64() > runner["memory_bytes"].as_u64() {
        return Err("benchmark.runner_manifest.tmpfs_bytes cannot exceed memory_bytes".to_string());
    }
    if !matches!(
        runner.get("platform").and_then(Value::as_str),
        Some("linux/amd64" | "linux/arm64")
    ) {
        return Err(
            "benchmark.runner_manifest.platform must be linux/amd64 or linux/arm64".to_string(),
        );
    }
    Ok(())
}

fn valid_sha256_digest(value: &str) -> bool {
    let Some(hex) = value.strip_prefix("sha256:") else {
        return false;
    };
    hex.len() == 64
        && hex
            .bytes()
            .all(|byte| byte.is_ascii_hexdigit() && !byte.is_ascii_uppercase())
}

async fn persist_chatgpt_bounty_image(
    state: &SharedState,
    args: &PrepareBountyPostArgs,
) -> Result<BountyImageReference, String> {
    let prompt = bounded_text(
        args.image_prompt
            .as_deref()
            .ok_or_else(|| "image_prompt is required when bounty_image is supplied".to_string())?,
        "image_prompt",
        4_000,
    )?;
    let alt_text = bounded_text(
        args.image_alt_text.as_deref().ok_or_else(|| {
            "image_alt_text is required when bounty_image is supplied".to_string()
        })?,
        "image_alt_text",
        500,
    )?;
    let bounty_image = args
        .bounty_image
        .as_ref()
        .ok_or_else(|| "bounty_image is required when image text is supplied".to_string())?;
    let file_id = bounded_text(&bounty_image.file_id, "bounty_image.file_id", 512)?;
    let download_url = validate_chatgpt_download_url(&bounty_image.download_url)?;
    let bytes = download_chatgpt_image(&download_url).await?;
    let mime_type = detect_bounty_image_mime(&bytes)
        .ok_or_else(|| "bounty_image must be a valid PNG, JPEG, or WebP file".to_string())?;
    if let Some(declared) = bounty_image
        .mime_type
        .as_deref()
        .map(str::trim)
        .filter(|value| !value.is_empty())
    {
        if declared != mime_type {
            return Err(format!(
                "bounty_image MIME mismatch: ChatGPT supplied {declared}, but the file is {mime_type}"
            ));
        }
    }
    if let Some(file_name) = bounty_image.file_name.as_deref() {
        bounded_text(file_name, "bounty_image.file_name", 255)?;
    }
    let sha256 = Sha256::digest(&bytes)
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect::<String>();
    let store = state.store.as_ref().ok_or_else(|| {
        "durable bounty image storage is unavailable; configure DATABASE_URL before posting"
            .to_string()
    })?;
    store
        .put_bounty_image_asset(&NewBountyImageAsset {
            sha256: sha256.clone(),
            mime_type: mime_type.to_string(),
            content: bytes,
        })
        .await
        .map_err(|error| format!("could not store the approved bounty image: {error}"))?;
    let asset_url = format!(
        "{}/public/bounty-images/{sha256}",
        mcp_base_url_from_env().trim_end_matches('/')
    );
    // file_id proves that ChatGPT supplied a file to this invocation, but it is
    // deliberately not persisted or exposed in public bounty terms.
    drop(file_id);
    Ok(BountyImageReference {
        source: "chatgpt_user_generated".to_string(),
        prompt,
        alt_text,
        asset_url,
        sha256,
        mime_type: mime_type.to_string(),
    })
}

fn validate_chatgpt_download_url(value: &str) -> Result<Url, String> {
    let url = Url::parse(value).map_err(|_| "bounty_image.download_url is invalid".to_string())?;
    if !chatgpt_file_url_is_allowed(&url) {
        return Err(
            "bounty_image.download_url must be an HTTPS ChatGPT/OpenAI file URL".to_string(),
        );
    }
    Ok(url)
}

fn chatgpt_file_url_is_allowed(url: &Url) -> bool {
    if url.scheme() != "https"
        || !url.username().is_empty()
        || url.password().is_some()
        || url.port_or_known_default() != Some(443)
    {
        return false;
    }
    let Some(host) = url.host_str().map(str::to_ascii_lowercase) else {
        return false;
    };
    if host.parse::<IpAddr>().is_ok() {
        return false;
    }
    host == "chatgpt.com"
        || host == "openai.com"
        || host.ends_with(".openai.com")
        || host == "oaiusercontent.com"
        || host.ends_with(".oaiusercontent.com")
}

async fn download_chatgpt_image(url: &Url) -> Result<Vec<u8>, String> {
    let client = reqwest::Client::builder()
        .redirect(reqwest::redirect::Policy::custom(|attempt| {
            if attempt.previous().len() >= 5 {
                attempt.error("too many ChatGPT file redirects")
            } else if chatgpt_file_url_is_allowed(attempt.url()) {
                attempt.follow()
            } else {
                attempt.error("ChatGPT file redirect left the allowed HTTPS hosts")
            }
        }))
        .timeout(std::time::Duration::from_secs(30))
        .build()
        .map_err(|error| format!("could not create the ChatGPT file client: {error}"))?;
    let mut response = client
        .get(url.clone())
        .send()
        .await
        .map_err(|error| format!("could not download the approved ChatGPT image: {error}"))?;
    if !response.status().is_success() {
        return Err(format!(
            "ChatGPT image download returned HTTP {}",
            response.status()
        ));
    }
    if response
        .content_length()
        .is_some_and(|length| length == 0 || length > MAX_BOUNTY_IMAGE_BYTES as u64)
    {
        return Err("bounty_image must contain between 1 byte and 5 MiB".to_string());
    }
    let mut bytes = Vec::new();
    while let Some(chunk) = response
        .chunk()
        .await
        .map_err(|error| format!("could not read the approved ChatGPT image: {error}"))?
    {
        if bytes.len().saturating_add(chunk.len()) > MAX_BOUNTY_IMAGE_BYTES {
            return Err("bounty_image exceeds the 5 MiB limit".to_string());
        }
        bytes.extend_from_slice(&chunk);
    }
    if bytes.is_empty() {
        return Err("bounty_image is empty".to_string());
    }
    Ok(bytes)
}

fn detect_bounty_image_mime(bytes: &[u8]) -> Option<&'static str> {
    if bytes.starts_with(b"\x89PNG\r\n\x1a\n") {
        Some("image/png")
    } else if bytes.starts_with(b"\xff\xd8\xff") {
        Some("image/jpeg")
    } else if bytes.len() >= 12 && bytes.starts_with(b"RIFF") && &bytes[8..12] == b"WEBP" {
        Some("image/webp")
    } else {
        None
    }
}

fn sandbox_bounty_image_reference(
    args: &PrepareBountyPostArgs,
) -> Result<Option<BountyImageReference>, String> {
    match (
        args.image_prompt.as_deref(),
        args.image_alt_text.as_deref(),
        args.bounty_image.as_ref(),
    ) {
        (None, None, None) => Ok(None),
        (Some(prompt), Some(alt_text), Some(_)) => Ok(Some(BountyImageReference {
            source: "chatgpt_user_generated".to_string(),
            prompt: bounded_text(prompt, "image_prompt", 4_000)?,
            alt_text: bounded_text(alt_text, "image_alt_text", 500)?,
            asset_url: "https://agentbounties.app/assets/solarpunk/characters-helping.webp"
                .to_string(),
            sha256: "0".repeat(64),
            mime_type: "image/webp".to_string(),
        })),
        _ => Err(
            "bounty_image, image_prompt, and image_alt_text must be supplied together or all omitted"
                .to_string(),
        ),
    }
}

pub(super) async fn mcp_post(
    State(state): State<SharedState>,
    headers: HeaderMap,
    Json(payload): Json<Value>,
) -> Response {
    mcp_post_inner(state, headers, payload, None).await
}

pub(super) async fn attributed_mcp_post(
    Path(rail): Path<String>,
    State(state): State<SharedState>,
    headers: HeaderMap,
    Json(payload): Json<Value>,
) -> Response {
    let Some(rail) = normalize_distribution_rail(&rail).map(str::to_string) else {
        return StatusCode::NOT_FOUND.into_response();
    };
    let canary_kind = match headers.get(CANARY_HEADER) {
        None => None,
        Some(value) => match value.to_str() {
            Ok(kind @ ("dry-run-v1" | "mainnet-v1")) => Some(kind.to_string()),
            _ => {
                return (
                    StatusCode::BAD_REQUEST,
                    "x-agent-bounties-canary must be dry-run-v1 or mainnet-v1.",
                )
                    .into_response()
            }
        },
    };
    let requested_measurement_eligible = canary_kind.is_none();
    let excluded = super::analytics_exclusion_is_authorized(&state, &headers);
    if excluded {
        return mcp_post_inner(state, headers, payload, None).await;
    }
    let Some(store) = state.store.as_ref() else {
        return (
            StatusCode::SERVICE_UNAVAILABLE,
            "Durable attribution is required on rail-specific MCP routes.",
        )
            .into_response();
    };
    let Some(signing_secret) = state.distribution_attribution_signing_secret.as_deref() else {
        return (
            StatusCode::SERVICE_UNAVAILABLE,
            "Rail attribution signing is not configured.",
        )
            .into_response();
    };
    let acquisition_token = match headers.get(ACQUISITION_HEADER) {
        Some(value) => match value.to_str() {
            Ok(value) if distribution_acquisition_token_hash(value, signing_secret).is_some() => {
                value.trim().to_string()
            }
            _ => {
                return (
                    StatusCode::BAD_REQUEST,
                    "Malformed x-agent-bounties-acquisition-id header.",
                )
                    .into_response()
            }
        },
        None => sign_distribution_acquisition_token(
            &format!("{}{}", Uuid::new_v4().simple(), Uuid::new_v4().simple()),
            signing_secret,
        )
        .unwrap_or_default(),
    };
    let Some(token_hash) = distribution_acquisition_token_hash(&acquisition_token, signing_secret)
    else {
        return (
            StatusCode::SERVICE_UNAVAILABLE,
            "Rail attribution signing secret must contain at least 32 bytes.",
        )
            .into_response();
    };
    let acquisition = match store
        .observe_distribution_acquisition(
            &rail,
            &token_hash,
            canary_kind.as_deref(),
            chrono::Utc::now(),
        )
        .await
    {
        Ok(acquisition) => acquisition,
        Err(db::DbError::DistributionAttributionConflict(message)) => {
            return (StatusCode::CONFLICT, message).into_response();
        }
        Err(_) => {
            let store = store.clone();
            let rail = rail.clone();
            tokio::spawn(async move {
                let _ = store
                    .record_distribution_rail_request(
                        &rail,
                        false,
                        requested_measurement_eligible,
                        chrono::Utc::now(),
                    )
                    .await;
            });
            return (
                StatusCode::SERVICE_UNAVAILABLE,
                "Durable attribution could not be recorded.",
            )
                .into_response();
        }
    };
    let measurement_eligible = acquisition.measurement_eligible;
    let attribution = McpDistributionAttribution {
        acquisition_id: acquisition.id,
        acquisition_token: acquisition_token.clone(),
        first_touch_rail: acquisition.first_touch_rail.clone(),
        current_rail: rail.clone(),
        measurement_eligible,
    };
    let mut response = mcp_post_inner(state.clone(), headers, payload, Some(attribution)).await;
    response.headers_mut().insert(
        ACQUISITION_HEADER,
        HeaderValue::from_str(&acquisition_token)
            .expect("validated attribution token is a header value"),
    );
    if let Some(canary_kind) = &acquisition.canary_kind {
        response.headers_mut().insert(
            CANARY_HEADER,
            HeaderValue::from_str(canary_kind).expect("bounded canary kind is a header value"),
        );
    }
    response.headers_mut().insert(
        MEASUREMENT_ELIGIBLE_HEADER,
        HeaderValue::from_static(if measurement_eligible {
            "true"
        } else {
            "false"
        }),
    );
    response.headers_mut().insert(
        ATTRIBUTION_RAIL_HEADER,
        HeaderValue::from_str(&rail).expect("approved rail is a header value"),
    );
    response.headers_mut().insert(
        FIRST_TOUCH_RAIL_HEADER,
        HeaderValue::from_str(&acquisition.first_touch_rail)
            .expect("approved first-touch rail is a header value"),
    );
    let succeeded = mcp_response_succeeded(&response);
    let store = store.clone();
    tokio::spawn(async move {
        let _ = store
            .record_distribution_rail_request(
                &rail,
                succeeded,
                measurement_eligible,
                chrono::Utc::now(),
            )
            .await;
    });
    response
}

async fn mcp_post_inner(
    state: SharedState,
    headers: HeaderMap,
    mut payload: Value,
    attribution: Option<McpDistributionAttribution>,
) -> Response {
    set_internal_attribution(&mut payload, attribution.as_ref());
    let era = mcp_protocol_era(&headers, &payload);
    let catalog_profile = mcp_catalog_profile(&headers, &payload);
    let excluded = super::analytics_exclusion_is_authorized(&state, &headers);
    let mut response = handle_mcp_post(state.clone(), headers, payload, era, catalog_profile).await;
    super::attest_analytics_exclusion(&mut response, excluded);
    let protocol_era = match era {
        McpProtocolEra::Legacy => ObservedProtocolEra::McpLegacy,
        McpProtocolEra::Modern => ObservedProtocolEra::McpModern,
    };
    if excluded {
        super::emit_interface_usage_excluded(protocol_era);
    } else if let Some(store) = state.store.clone() {
        let succeeded = mcp_response_succeeded(&response);
        tokio::spawn(async move {
            let _ = store
                .record_interface_usage(
                    ObservedInterface::Mcp,
                    protocol_era,
                    succeeded,
                    chrono::Utc::now(),
                )
                .await;
        });
    }
    response
}

fn set_internal_attribution(payload: &mut Value, attribution: Option<&McpDistributionAttribution>) {
    let requests = match payload {
        Value::Array(requests) => requests.iter_mut().collect::<Vec<_>>(),
        request => vec![request],
    };
    for request in requests {
        let Some(object) = request.as_object_mut() else {
            continue;
        };
        let params = object
            .entry("params")
            .or_insert_with(|| json!({}))
            .as_object_mut();
        let Some(params) = params else {
            continue;
        };
        let metadata = params
            .entry("_meta")
            .or_insert_with(|| json!({}))
            .as_object_mut();
        let Some(metadata) = metadata else {
            continue;
        };
        metadata.remove(INTERNAL_ATTRIBUTION_META);
        if let Some(attribution) = attribution {
            metadata.insert(
                INTERNAL_ATTRIBUTION_META.to_string(),
                serde_json::to_value(attribution)
                    .expect("distribution attribution is serializable"),
            );
        }
    }
}

async fn handle_mcp_post(
    state: SharedState,
    headers: HeaderMap,
    payload: Value,
    era: McpProtocolEra,
    catalog_profile: McpCatalogProfile,
) -> Response {
    if !mcp_origin_is_allowed(&headers) {
        return StatusCode::FORBIDDEN.into_response();
    }

    if era == McpProtocolEra::Modern {
        if payload.is_array() {
            return mcp_error_response(
                StatusCode::BAD_REQUEST,
                payload_id(&payload),
                -32600,
                "MCP 2026-07-28 accepts one JSON-RPC request per HTTP POST",
                None,
            );
        }
        if let Err(error) = validate_modern_request(&headers, &payload) {
            return error.into_response(payload_id(&payload));
        }
        let Some((status, response)) = handle_request(
            state,
            headers.clone(),
            payload,
            McpProtocolEra::Modern,
            catalog_profile,
        )
        .await
        else {
            return StatusCode::ACCEPTED.into_response();
        };
        let succeeded = json_rpc_payload_succeeded(&response);
        let mut http_response = (status, Json(response)).into_response();
        http_response
            .extensions_mut()
            .insert(McpJsonRpcSucceeded(succeeded));
        return http_response;
    }

    let responses = if let Some(batch) = payload.as_array() {
        let mut responses = Vec::new();
        for request in batch {
            if let Some((_, response)) = handle_request(
                state.clone(),
                headers.clone(),
                request.clone(),
                McpProtocolEra::Legacy,
                catalog_profile,
            )
            .await
            {
                responses.push(response);
            }
        }
        if responses.is_empty() {
            return StatusCode::ACCEPTED.into_response();
        }
        Value::Array(responses)
    } else if let Some((_, response)) = handle_request(
        state,
        headers.clone(),
        payload,
        McpProtocolEra::Legacy,
        catalog_profile,
    )
    .await
    {
        response
    } else {
        return StatusCode::ACCEPTED.into_response();
    };

    let succeeded = json_rpc_payload_succeeded(&responses);
    let mut response = (StatusCode::OK, Json(responses)).into_response();
    response
        .extensions_mut()
        .insert(McpJsonRpcSucceeded(succeeded));
    response
}

#[derive(Debug, Clone, Copy)]
struct McpJsonRpcSucceeded(bool);

fn json_rpc_payload_succeeded(payload: &Value) -> bool {
    match payload {
        Value::Array(items) => !items.is_empty() && items.iter().all(json_rpc_payload_succeeded),
        Value::Object(object) => {
            !object.contains_key("error")
                && object
                    .get("result")
                    .and_then(Value::as_object)
                    .and_then(|result| result.get("isError"))
                    .and_then(Value::as_bool)
                    != Some(true)
        }
        _ => false,
    }
}

fn mcp_response_succeeded(response: &Response) -> bool {
    response.status().is_success()
        && response
            .extensions()
            .get::<McpJsonRpcSucceeded>()
            .is_none_or(|outcome| outcome.0)
}

pub(super) async fn mcp_get(headers: HeaderMap) -> Response {
    if !mcp_origin_is_allowed(&headers) {
        return StatusCode::FORBIDDEN.into_response();
    }
    (
        StatusCode::METHOD_NOT_ALLOWED,
        [("allow", "POST")],
        "This stateless MCP endpoint accepts JSON-RPC over POST.",
    )
        .into_response()
}

pub(super) async fn attributed_mcp_get(Path(rail): Path<String>, headers: HeaderMap) -> Response {
    if normalize_distribution_rail(&rail).is_none() {
        return StatusCode::NOT_FOUND.into_response();
    }
    mcp_get(headers).await
}

pub(super) async fn mcp_delete(headers: HeaderMap) -> Response {
    if !mcp_origin_is_allowed(&headers) {
        return StatusCode::FORBIDDEN.into_response();
    }
    (StatusCode::METHOD_NOT_ALLOWED, [("allow", "POST")]).into_response()
}

pub(super) async fn attributed_mcp_delete(
    Path(rail): Path<String>,
    headers: HeaderMap,
) -> Response {
    if normalize_distribution_rail(&rail).is_none() {
        return StatusCode::NOT_FOUND.into_response();
    }
    mcp_delete(headers).await
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum McpProtocolEra {
    Legacy,
    Modern,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum McpCatalogProfile {
    Chatgpt,
    Core,
}

#[derive(Debug)]
struct McpProtocolError {
    status: StatusCode,
    code: i64,
    message: String,
    data: Option<Value>,
}

impl McpProtocolError {
    fn header_mismatch(message: impl Into<String>) -> Self {
        Self {
            status: StatusCode::BAD_REQUEST,
            code: -32020,
            message: message.into(),
            data: None,
        }
    }

    fn invalid_request(message: impl Into<String>) -> Self {
        Self {
            status: StatusCode::BAD_REQUEST,
            code: -32600,
            message: message.into(),
            data: None,
        }
    }

    fn invalid_params(message: impl Into<String>) -> Self {
        Self {
            status: StatusCode::BAD_REQUEST,
            code: -32602,
            message: message.into(),
            data: None,
        }
    }

    fn unsupported_version(requested: &str) -> Self {
        Self {
            status: StatusCode::BAD_REQUEST,
            code: -32022,
            message: format!("Unsupported MCP protocol version: {requested}"),
            data: Some(json!({
                "supported": [MCP_PROTOCOL_VERSION],
                "requested": requested
            })),
        }
    }

    fn into_response(self, id: Value) -> Response {
        mcp_error_response(self.status, id, self.code, &self.message, self.data)
    }
}

fn mcp_protocol_era(headers: &HeaderMap, payload: &Value) -> McpProtocolEra {
    let header_is_modern = headers
        .get(MCP_PROTOCOL_VERSION_HEADER)
        .is_some_and(|value| {
            value.to_str().map_or(true, |version| {
                !matches!(version, "2024-11-05" | "2025-03-26" | "2025-06-18")
            })
        });
    let body_has_request_metadata = payload
        .get("params")
        .and_then(|params| params.get("_meta"))
        .and_then(|metadata| metadata.get(MCP_PROTOCOL_VERSION_META))
        .is_some();
    let is_discovery = payload
        .get("method")
        .and_then(Value::as_str)
        .is_some_and(|method| method == "server/discover");

    if header_is_modern || body_has_request_metadata || is_discovery {
        McpProtocolEra::Modern
    } else {
        McpProtocolEra::Legacy
    }
}

fn mcp_catalog_profile(headers: &HeaderMap, payload: &Value) -> McpCatalogProfile {
    let exact_chatgpt_origin = headers
        .get(ORIGIN)
        .and_then(|value| value.to_str().ok())
        .and_then(normalized_mcp_origin)
        .is_some_and(|origin| {
            matches!(
                origin.as_str(),
                "https://chatgpt.com" | "https://chat.openai.com"
            )
        });
    let exact_openai_client = payload
        .get("params")
        .and_then(|params| params.get("_meta"))
        .and_then(|metadata| metadata.get(MCP_CLIENT_INFO_META))
        .and_then(|client_info| client_info.get("name"))
        .and_then(Value::as_str)
        == Some("openai-mcp");
    if exact_chatgpt_origin || exact_openai_client {
        McpCatalogProfile::Chatgpt
    } else {
        McpCatalogProfile::Core
    }
}

fn validate_modern_request(headers: &HeaderMap, request: &Value) -> Result<(), McpProtocolError> {
    let object = request
        .as_object()
        .ok_or_else(|| McpProtocolError::invalid_request("Invalid Request"))?;
    if object.get("jsonrpc").and_then(Value::as_str) != Some("2.0") {
        return Err(McpProtocolError::invalid_request(
            "jsonrpc must be exactly '2.0'",
        ));
    }
    if !object
        .get("id")
        .is_some_and(|id| id.is_string() || id.is_number())
    {
        return Err(McpProtocolError::invalid_request(
            "MCP 2026-07-28 HTTP messages must be JSON-RPC requests with a string or number id",
        ));
    }
    let method = object
        .get("method")
        .and_then(Value::as_str)
        .ok_or_else(|| McpProtocolError::invalid_request("method must be a string"))?;
    let params = object
        .get("params")
        .and_then(Value::as_object)
        .ok_or_else(|| McpProtocolError::invalid_params("params must be an object"))?;
    let metadata = params
        .get("_meta")
        .and_then(Value::as_object)
        .ok_or_else(|| McpProtocolError::invalid_params("params._meta must be an object"))?;
    let body_version = metadata
        .get(MCP_PROTOCOL_VERSION_META)
        .and_then(Value::as_str)
        .ok_or_else(|| {
            McpProtocolError::header_mismatch(format!(
                "params._meta.{MCP_PROTOCOL_VERSION_META} is required"
            ))
        })?;
    let header_version = required_header(headers, MCP_PROTOCOL_VERSION_HEADER)?;
    if header_version != body_version {
        return Err(McpProtocolError::header_mismatch(format!(
            "{MCP_PROTOCOL_VERSION_HEADER} header does not match request metadata"
        )));
    }
    if body_version != MCP_PROTOCOL_VERSION {
        return Err(McpProtocolError::unsupported_version(body_version));
    }

    let header_method = required_header(headers, MCP_METHOD_HEADER)?;
    if header_method != method {
        return Err(McpProtocolError::header_mismatch(format!(
            "{MCP_METHOD_HEADER} header does not match method"
        )));
    }

    if matches!(method, "tools/call" | "resources/read" | "prompts/get") {
        let source_field = if method == "resources/read" {
            "uri"
        } else {
            "name"
        };
        let body_name = params
            .get(source_field)
            .and_then(Value::as_str)
            .ok_or_else(|| {
                McpProtocolError::invalid_params(format!(
                    "{method} requires a string params.{source_field}"
                ))
            })?;
        let header_name = decode_mcp_header_value(required_header(headers, MCP_NAME_HEADER)?)?;
        if header_name != body_name {
            return Err(McpProtocolError::header_mismatch(format!(
                "{MCP_NAME_HEADER} header does not match params.{source_field}"
            )));
        }
    }

    if !metadata
        .get(MCP_CLIENT_CAPABILITIES_META)
        .is_some_and(Value::is_object)
    {
        return Err(McpProtocolError::invalid_params(format!(
            "params._meta.{MCP_CLIENT_CAPABILITIES_META} must be an object"
        )));
    }
    if let Some(client_info) = metadata.get(MCP_CLIENT_INFO_META) {
        let valid = client_info.as_object().is_some_and(|client_info| {
            client_info.get("name").is_some_and(Value::is_string)
                && client_info.get("version").is_some_and(Value::is_string)
        });
        if !valid {
            return Err(McpProtocolError::invalid_params(format!(
                "params._meta.{MCP_CLIENT_INFO_META} must include string name and version fields"
            )));
        }
    }
    Ok(())
}

fn required_header<'a>(headers: &'a HeaderMap, name: &str) -> Result<&'a str, McpProtocolError> {
    headers
        .get(name)
        .ok_or_else(|| McpProtocolError::header_mismatch(format!("missing {name} header")))?
        .to_str()
        .map_err(|_| McpProtocolError::header_mismatch(format!("malformed {name} header")))
}

fn decode_mcp_header_value(value: &str) -> Result<String, McpProtocolError> {
    const PREFIX: &str = "=?base64?";
    const SUFFIX: &str = "?=";
    if value.starts_with(PREFIX) {
        let encoded = value
            .strip_prefix(PREFIX)
            .and_then(|value| value.strip_suffix(SUFFIX))
            .ok_or_else(|| McpProtocolError::header_mismatch("malformed Base64 header sentinel"))?;
        let decoded = base64::engine::general_purpose::STANDARD
            .decode(encoded)
            .map_err(|_| McpProtocolError::header_mismatch("invalid Base64 header value"))?;
        return String::from_utf8(decoded)
            .map_err(|_| McpProtocolError::header_mismatch("Base64 header value is not UTF-8"));
    }
    Ok(value.to_string())
}

fn payload_id(payload: &Value) -> Value {
    payload.get("id").cloned().unwrap_or(Value::Null)
}

fn mcp_error_response(
    status: StatusCode,
    id: Value,
    code: i64,
    message: &str,
    data: Option<Value>,
) -> Response {
    (
        status,
        Json(json_rpc_error_with_data(id, code, message, data)),
    )
        .into_response()
}

async fn handle_request(
    state: SharedState,
    caller_headers: HeaderMap,
    request: Value,
    era: McpProtocolEra,
    catalog_profile: McpCatalogProfile,
) -> Option<(StatusCode, Value)> {
    let Some(object) = request.as_object() else {
        return Some((
            StatusCode::OK,
            json_rpc_error(Value::Null, -32600, "Invalid Request"),
        ));
    };
    let id = object.get("id").cloned();
    let Some(method) = object.get("method").and_then(Value::as_str) else {
        return Some((
            StatusCode::OK,
            json_rpc_error(id.unwrap_or(Value::Null), -32600, "Invalid Request"),
        ));
    };
    let id = id?;
    let params = object.get("params").cloned().unwrap_or_else(|| json!({}));
    let attribution = params
        .get("_meta")
        .and_then(|metadata| metadata.get(INTERNAL_ATTRIBUTION_META))
        .cloned()
        .and_then(|value| serde_json::from_value::<McpDistributionAttribution>(value).ok());

    let result = match method {
        "server/discover" if era == McpProtocolEra::Modern => Ok(discover_result()),
        "initialize" if era == McpProtocolEra::Legacy => Ok(initialize_result(&params)),
        "ping" if era == McpProtocolEra::Legacy => Ok(json!({})),
        "tools/list" => {
            let mut tools = mcp_tools_for_catalog(catalog_profile).await;
            if era == McpProtocolEra::Modern {
                tools.sort_by(|left, right| {
                    left.get("name")
                        .and_then(Value::as_str)
                        .cmp(&right.get("name").and_then(Value::as_str))
                });
            }
            Ok(json!({"tools": tools}))
        }
        "tools/call" => call_tool(state, caller_headers, &params, attribution.as_ref()).await,
        "resources/list" => Ok(json!({"resources": [feed_widget_resource_descriptor()]})),
        "resources/templates/list" => Ok(json!({"resourceTemplates": []})),
        "resources/read" => read_resource(&params),
        _ => {
            return Some((
                if era == McpProtocolEra::Modern {
                    StatusCode::NOT_FOUND
                } else {
                    StatusCode::OK
                },
                json_rpc_error(id, -32601, "Method not found"),
            ))
        }
    };

    Some(match result {
        Ok(mut result) => {
            if let Some(attribution) = attribution {
                attach_attribution_metadata(&mut result, &attribution);
            }
            (
                StatusCode::OK,
                json!({
                    "jsonrpc": "2.0",
                    "id": id,
                    "result": if era == McpProtocolEra::Modern {
                        modern_result(method, result)
                    } else {
                        result
                    }
                }),
            )
        }
        Err(error) => (
            if era == McpProtocolEra::Modern {
                StatusCode::BAD_REQUEST
            } else {
                StatusCode::OK
            },
            json_rpc_error(id, -32602, &error),
        ),
    })
}

fn attach_attribution_metadata(result: &mut Value, attribution: &McpDistributionAttribution) {
    let Some(object) = result.as_object_mut() else {
        return;
    };
    let metadata = object
        .entry("_meta")
        .or_insert_with(|| json!({}))
        .as_object_mut();
    if let Some(metadata) = metadata {
        metadata.insert(
            "agentbounties.app/acquisition".to_string(),
            json!({
                "acquisition_id": attribution.acquisition_token,
                "first_touch_rail": attribution.first_touch_rail,
                "current_rail": attribution.current_rail,
                "measurement_eligible": attribution.measurement_eligible,
                "request_header": ACQUISITION_HEADER,
                "authority": "analytics_only"
            }),
        );
    }
}

fn initialize_result(params: &Value) -> Value {
    let requested = params
        .get("protocolVersion")
        .and_then(Value::as_str)
        .unwrap_or(MCP_LEGACY_PROTOCOL_VERSION);
    // Exact whole-token membership: echo a requested version only when it is one
    // of the supported legacy tokens. Prefix/suffix lookalikes, unknown, missing,
    // and non-string input all deterministically select the server legacy version
    // instead of being echoed or rejected. The modern `MCP_PROTOCOL_VERSION` path
    // is enforced separately in `discover_result` and must not appear here.
    let protocol_version = match requested {
        "2024-11-05" | "2025-03-26" | "2025-06-18" => requested,
        _ => MCP_LEGACY_PROTOCOL_VERSION,
    };
    json!({
        "protocolVersion": protocol_version,
        "capabilities": mcp_server_capabilities(),
        "serverInfo": mcp_server_info(),
        "instructions": mcp_server_instructions()
    })
}

fn discover_result() -> Value {
    json!({
        "supportedVersions": [MCP_PROTOCOL_VERSION],
        "capabilities": mcp_server_capabilities(),
        "instructions": mcp_server_instructions()
    })
}

fn mcp_server_instructions() -> &'static str {
    let sandbox = chatgpt_sandbox_mode();
    let public_review = !sandbox && chatgpt_public_review_mode();
    if sandbox {
        "Sandbox mode is active. Use get_bounty_feed and render_bounty_feed to exercise the complete in-chat bounty UI. Use prepare_moonpay_onramp to exercise the external top-up handoff without opening MoonPay, and use prepare_bounty_action plus get_bounty_action_status to exercise the hosted bounty lifecycle without opening a wallet. Every tool returns deterministic fixture data and performs no network write, wallet action, public comment, publication, funding, claim, submission, verification, settlement, purchase, or payment. Never describe sandbox output as canonical evidence."
    } else if public_review {
        "Public review mode is active. Show only voluntary, unfunded community requests with no payment promise. Use render_bounty_feed for the compact in-chat work queue, publish_unfunded_bounty only when the user explicitly asks to publish a voluntary request, use your own AI account for task decomposition, and the comment and share tools for public collaboration. Funding, claiming, completion, verification, wallet, settlement, token, and payment actions are unavailable in this app configuration. Never imply otherwise or direct a user around this boundary."
    } else {
        "Use get_bounty_feed to inspect fresh structured bounty data, then render_bounty_feed to show the mounted read-only feed in ChatGPT. The widget has only Post bounty, Comment, Share, and Solve actions; each action starts a conversation. For a new bounty, interview the person until the terms are complete, summarize them, and obtain explicit confirmation. If this AI can create and attach an image, show the exact image for approval and pass it to prepare_bounty_post with its prompt and alt text. Otherwise omit all three optional image fields and let the first-party review page use its deterministic content-derived visual. Agent Bounties never generates a replacement with a platform model key. For fund, solve or claim, complete, or verify, call prepare_bounty_action and open only its first-party HTTPS authorization URL. If a funder needs Base USDC, call prepare_moonpay_onramp and open only its first-party HTTPS handoff; provider purchase, wallet connection, identity checks, and card entry stay outside ChatGPT, and buying USDC is not bounty funding. Never request or accept a wallet signature, private key, seed phrase, payment authorization, verifier signature, or card data in ChatGPT. Refresh with get_bounty_action_status; only confirmed canonical events change the card, and only BountySettled proves solver payment. Use the current AI account to break a broad objective into smaller reviewable child bounties; platform-hosted generation is retired. Use create_share_bundle after every meaningful step."
    }
}

fn mcp_server_capabilities() -> Value {
    json!({
        "tools": {"listChanged": false},
        "resources": {"subscribe": false, "listChanged": false}
    })
}

fn mcp_server_info() -> Value {
    let sandbox = chatgpt_sandbox_mode();
    let public_review = !sandbox && chatgpt_public_review_mode();
    json!({
        "name": if sandbox {
            "agent-bounties-sandbox"
        } else if public_review {
            "agent-bounties-community"
        } else {
            "agent-bounties"
        },
        "title": if sandbox {
            "Agent Bounties Sandbox"
        } else if public_review {
            "Agent Bounties Community"
        } else {
            "Agent Bounties"
        },
        "version": env!("CARGO_PKG_VERSION")
    })
}

fn modern_result(method: &str, mut result: Value) -> Value {
    let object = result
        .as_object_mut()
        .expect("every implemented MCP method returns an object result");
    object.insert("resultType".to_string(), json!("complete"));
    let metadata = object
        .entry("_meta".to_string())
        .or_insert_with(|| json!({}));
    if !metadata.is_object() {
        *metadata = json!({});
    }
    metadata[MCP_SERVER_INFO_META] = mcp_server_info();
    if matches!(
        method,
        "server/discover"
            | "tools/list"
            | "resources/list"
            | "resources/templates/list"
            | "resources/read"
    ) {
        object.insert("ttlMs".to_string(), json!(MCP_CATALOG_TTL_MS));
        object.insert("cacheScope".to_string(), json!("public"));
    }
    result
}

fn mcp_origin_is_allowed(headers: &HeaderMap) -> bool {
    let Some(origin) = headers.get(ORIGIN) else {
        return true;
    };
    let Ok(origin) = origin.to_str() else {
        return false;
    };
    mcp_origin_is_allowed_with_config(
        origin,
        env::var("MCP_BASE_URL").ok().as_deref(),
        env::var(MCP_ALLOWED_ORIGINS_ENV).ok().as_deref(),
    )
}

fn mcp_origin_is_allowed_with_config(
    origin: &str,
    mcp_base_url: Option<&str>,
    configured_origins: Option<&str>,
) -> bool {
    let Some(origin) = normalized_mcp_origin(origin) else {
        return false;
    };
    let defaults = [
        "https://chatgpt.com",
        "https://chat.openai.com",
        "https://agentbounties.app",
        "https://www.agentbounties.app",
        "https://mcp.agentbounties.app",
    ];
    if defaults.contains(&origin.as_str()) || is_loopback_http_origin(&origin) {
        return true;
    }
    if mcp_base_url
        .and_then(normalized_mcp_origin)
        .is_some_and(|allowed| allowed == origin)
    {
        return true;
    }
    configured_origins.is_some_and(|configured| {
        configured.split(',').any(|allowed| {
            normalized_mcp_origin(allowed.trim()).is_some_and(|allowed| allowed == origin)
        })
    })
}

fn normalized_mcp_origin(value: &str) -> Option<String> {
    let url = Url::parse(value).ok()?;
    if !url.username().is_empty()
        || url.password().is_some()
        || !matches!(url.path(), "" | "/")
        || url.query().is_some()
        || url.fragment().is_some()
        || url.host_str().is_none()
        || !matches!(url.scheme(), "http" | "https")
    {
        return None;
    }
    Some(url.origin().ascii_serialization())
}

fn is_loopback_http_origin(origin: &str) -> bool {
    let Ok(url) = Url::parse(origin) else {
        return false;
    };
    if url.scheme() != "http" {
        return false;
    }
    match url.host_str() {
        Some("localhost") => true,
        Some(host) => host
            .parse::<IpAddr>()
            .is_ok_and(|address| address.is_loopback()),
        None => false,
    }
}

async fn mcp_tools_for_catalog(catalog_profile: McpCatalogProfile) -> Vec<Value> {
    let sandbox = chatgpt_sandbox_mode();
    let public_review = !sandbox && chatgpt_public_review_mode();
    let tool_names = match catalog_profile {
        McpCatalogProfile::Chatgpt => chatgpt_tool_names(sandbox, public_review).to_vec(),
        McpCatalogProfile::Core => core_mcp_tool_names(),
    };
    let mut descriptors = tools().await.0;
    descriptors.extend(custom_tool_descriptors());
    descriptors
        .into_iter()
        .filter(|descriptor| tool_names.contains(&descriptor.name))
        .map(|descriptor| mcp_tool_descriptor_for_mode(descriptor, sandbox, public_review))
        .collect()
}

fn mcp_tool_descriptor_for_mode(
    descriptor: ToolDescriptor,
    sandbox: bool,
    _public_review: bool,
) -> Value {
    let public_review = false;
    let (read_only, destructive, open_world, idempotent) = if sandbox {
        (true, false, false, true)
    } else {
        tool_impact(descriptor.name)
    };
    let mut value = Map::new();
    value.insert("name".to_string(), json!(descriptor.name));
    value.insert("title".to_string(), json!(tool_title(descriptor.name)));
    let base_description = chatgpt_tool_description(descriptor.name, descriptor.description);
    let description = if sandbox {
        format!(
            "{base_description} Sandbox mode is active: this call returns simulated fixture data and performs no external write or wallet action."
        )
    } else if public_review {
        public_review_tool_description(descriptor.name, base_description).to_string()
    } else {
        base_description.to_string()
    };
    value.insert("description".to_string(), json!(description));
    value.insert(
        "inputSchema".to_string(),
        public_review_input_schema(descriptor.name, descriptor.input_schema, public_review),
    );
    value.insert(
        "annotations".to_string(),
        json!({
            "readOnlyHint": read_only,
            "destructiveHint": destructive,
            "openWorldHint": open_world,
            "idempotentHint": idempotent
        }),
    );
    let security_schemes = analytics_security_schemes(
        std::env::var("ANALYTICS_EXCLUSION_TOKEN").is_ok_and(|value| !value.trim().is_empty()),
    );
    value.insert("securitySchemes".to_string(), security_schemes.clone());
    let mut metadata = json!({
        "securitySchemes": security_schemes,
        "ui": {"visibility": ["model", "app"]},
        "agentBountiesSandbox": sandbox,
        "agentBountiesPublicReview": public_review
    });
    if matches!(descriptor.name, "get_bounty_feed" | "render_bounty_feed") {
        value.insert(
            "outputSchema".to_string(),
            feed_output_schema(public_review),
        );
    }
    if descriptor.name == "list_autonomous_bounties" {
        value.insert(
            "outputSchema".to_string(),
            autonomous_bounty_feed_output_schema(),
        );
    }
    if matches!(
        descriptor.name,
        "inspect_open_competition_v2" | "prepare_open_competition_v2"
    ) {
        value.insert(
            "outputSchema".to_string(),
            open_competition_v2_output_schema(),
        );
    }
    if matches!(
        descriptor.name,
        "prepare_bounty_action" | "get_bounty_action_status"
    ) {
        value.insert("outputSchema".to_string(), bounty_action_output_schema());
    }
    if descriptor.name == "prepare_moonpay_onramp" {
        value.insert("outputSchema".to_string(), moonpay_onramp_output_schema());
    }
    if matches!(
        descriptor.name,
        "list_bounty_comments" | "add_bounty_comment"
    ) {
        value.insert("outputSchema".to_string(), bounty_comments_output_schema());
    }
    if descriptor.name == "create_share_bundle" {
        value.insert("outputSchema".to_string(), share_bundle_output_schema());
    }
    if descriptor.name == "publish_unfunded_bounty" {
        value.insert(
            "outputSchema".to_string(),
            unfunded_bounty_output_schema(public_review),
        );
    }
    if descriptor.name == "compile_objective_with_cloud_agent" {
        value.insert(
            "outputSchema".to_string(),
            objective_plan_output_schema(public_review),
        );
    }
    if descriptor.name == "prepare_bounty_post" {
        metadata["openai/fileParams"] = json!(["bounty_image"]);
        value.insert("outputSchema".to_string(), post_handoff_output_schema());
    }
    let resource_uri = match descriptor.name {
        "render_bounty_feed" => Some(FEED_WIDGET_URI),
        _ => None,
    };
    if let Some(resource_uri) = resource_uri {
        metadata["ui"]["resourceUri"] = json!(resource_uri);
        metadata["openai/outputTemplate"] = json!(resource_uri);
        metadata["openai/toolInvocation/invoking"] = json!("Opening live bounty feed...");
        metadata["openai/toolInvocation/invoked"] = json!("Live feed ready");
    }
    value.insert("_meta".to_string(), metadata);
    Value::Object(value)
}

fn analytics_security_schemes(exclusion_link_enabled: bool) -> Value {
    if exclusion_link_enabled {
        json!([
            {"type": "noauth"},
            {"type": "oauth2", "scopes": [super::ANALYTICS_EXCLUSION_SCOPE]}
        ])
    } else {
        json!([{"type": "noauth"}])
    }
}

fn tool_impact(name: &str) -> (bool, bool, bool, bool) {
    match name {
        "prepare_moonpay_onramp" => (true, false, false, true),
        "prepare_bounty_post" => (false, true, true, true),
        "prepare_bounty_action" => (false, false, false, true),
        "get_bounty_action_status" => (false, false, false, true),
        "compile_objective_with_cloud_agent" => (false, false, true, false),
        "fund_bounty_with_x402" => (false, true, true, true),
        "agent_native_claim" => (false, true, true, true),
        "publish_unfunded_bounty" => (false, true, true, true),
        "submit_unfunded_bounty_solution" => (false, true, true, true),
        "publish_autonomous_submission_evidence" => (false, true, true, true),
        "add_bounty_comment" => (false, true, true, false),
        "inspect_open_competition_v2" => (true, false, false, true),
        "prepare_open_competition_v2" => (false, true, true, false),
        _ => (true, false, false, true),
    }
}

async fn call_tool(
    state: SharedState,
    caller_headers: HeaderMap,
    params: &Value,
    attribution: Option<&McpDistributionAttribution>,
) -> Result<Value, String> {
    let name = params
        .get("name")
        .and_then(Value::as_str)
        .ok_or_else(|| "tools/call requires a tool name".to_string())?;
    let arguments = params
        .get("arguments")
        .cloned()
        .unwrap_or_else(|| json!({}));

    if matches!(
        name,
        "draft_bounty_with_cloud_agent"
            | "compile_objective_with_cloud_agent"
            | "analyze_bounty_fit"
    ) {
        let mut result = tool_result(
            super::hosted_generation_removed().0,
            "Platform-hosted generation has been removed. Prepare the draft in your own AI account.",
            false,
        );
        result["isError"] = json!(true);
        return Ok(result);
    }

    let sandbox = chatgpt_sandbox_mode();
    let public_review = !sandbox && chatgpt_public_review_mode();
    if !chatgpt_tool_is_callable(name) {
        return Err(format!(
            "unknown or unavailable public ChatGPT app tool: {name}"
        ));
    }

    if sandbox {
        return sandbox_tool_result(name, &arguments).await;
    }
    if public_review {
        validate_public_review_tool_arguments(name, &arguments)?;
    }

    match name {
        "get_bounty_feed" => {
            let args: ChatgptFeedArgs = serde_json::from_value(arguments)
                .map_err(|error| format!("invalid get_bounty_feed arguments: {error}"))?;
            return Ok(tool_result(
                load_bounty_feed(args, &[]).await?,
                "Returned a fresh public opportunity projection. Funding, claimability, verification, settlement, and payment remain bound to each source’s authoritative evidence.",
                false,
            ));
        }
        "render_bounty_feed" => {
            let args: RenderFeedArgs = serde_json::from_value(arguments)
                .map_err(|error| format!("invalid render_bounty_feed arguments: {error}"))?;
            let opportunity_ids = args
                .opportunity_ids
                .iter()
                .map(|value| bounded_opportunity_id(value))
                .collect::<Result<Vec<_>, _>>()?;
            return Ok(tool_result(
                load_bounty_feed(args.feed, &opportunity_ids).await?,
                "Rendered the live Agent Bounties feed inside ChatGPT. Every card keeps work state, payment state, and canonical evidence boundaries separate.",
                false,
            ));
        }
        "list_bounty_comments" => {
            let args: ListCommentsArgs = serde_json::from_value(arguments)
                .map_err(|error| format!("invalid list_bounty_comments arguments: {error}"))?;
            let bounty_id = bounded_opportunity_id(&args.bounty_id)?;
            if public_review {
                ensure_public_review_opportunity_id(&bounty_id)?;
            }
            let mut comments = fetch_comments(&bounty_id).await?;
            if public_review {
                constrain_public_review_comments(&mut comments);
            }
            return Ok(tool_result(
                comments,
                "Returned public in-chat comments for this bounty. Comments are conversation context, not payment or verification evidence.",
                false,
            ));
        }
        "add_bounty_comment" => {
            let args: AddCommentArgs = serde_json::from_value(arguments)
                .map_err(|error| format!("invalid add_bounty_comment arguments: {error}"))?;
            let bounty_id = bounded_opportunity_id(&args.bounty_id)?;
            if public_review {
                ensure_public_review_opportunity_id(&bounty_id)?;
            }
            let body = bounded_text(&args.body, "body", 500)?;
            if public_review {
                ensure_public_review_noncommercial_text(&body)?;
            }
            let author = args
                .author
                .as_deref()
                .map(|value| bounded_text(value, "author", 60))
                .transpose()?
                .unwrap_or_else(|| "you".to_string());
            let id = match args.comment_id.as_deref() {
                Some(value) => Uuid::parse_str(value)
                    .map_err(|_| "comment_id must be a UUID when provided".to_string())?,
                None => Uuid::new_v4(),
            };
            let result = proxy_hosted_json(
                reqwest::Client::new()
                    .post(format!(
                        "{}/v1/opportunities/{}/comments",
                        public_base_url_from_env().trim_end_matches('/'),
                        bounty_id
                    ))
                    .json(&json!({
                        "id": id,
                        "author": author,
                        "body": body,
                    })),
            )
            .await
            .0;
            let mut value = legacy_result(result)?;
            if public_review {
                constrain_public_review_comments(&mut value);
            }
            return Ok(tool_result(
                value,
                "Comment published to the durable public bounty feed. Share the updated card when ready; comments remain conversation context, not payment or verification evidence.",
                false,
            ));
        }
        "create_share_bundle" => {
            let args: ShareBundleArgs = serde_json::from_value(arguments)
                .map_err(|error| format!("invalid create_share_bundle arguments: {error}"))?;
            return Ok(tool_result(build_share_bundle(&args, public_review)?, "Prepared a share-ready bounty card caption and social intents. Sharing is optional and does not change canonical payment state.", false));
        }
        "prepare_moonpay_onramp" => {
            let args: PrepareMoonpayOnrampArgs = serde_json::from_value(arguments)
                .map_err(|error| format!("invalid prepare_moonpay_onramp arguments: {error}"))?;
            return Ok(tool_result(
                build_moonpay_onramp_handoff(&args, false)?,
                "Prepared a first-party MoonPay top-up handoff. No checkout was opened, no purchase or wallet action occurred, and the bounty remains unfunded until a matching canonical FundingAdded event is indexed.",
                false,
            ));
        }
        "prepare_bounty_action" => {
            let args: PrepareBountyActionArgs = serde_json::from_value(arguments)
                .map_err(|error| format!("invalid prepare_bounty_action arguments: {error}"))?;
            let action = bounded_text(&args.action, "action", 16)?;
            if !matches!(
                action.as_str(),
                "post" | "fund" | "solve" | "complete" | "verify"
            ) {
                return Err("action must be post, fund, solve, complete, or verify".to_string());
            }
            let idempotency_key =
                bounded_public_key(&args.idempotency_key, "idempotency_key", 8, 200)?;
            let details = if args.details.is_null() {
                json!({})
            } else if args.details.is_object() {
                args.details
            } else {
                return Err("details must be an object".to_string());
            };
            let result = proxy_hosted_json(
                reqwest::Client::new()
                    .post(format!(
                        "{}/v1/chatgpt/action-intents",
                        public_base_url_from_env().trim_end_matches('/')
                    ))
                    .json(&json!({
                        "idempotency_key": idempotency_key,
                        "action": action,
                        "network": args.network,
                        "opportunity_id": args.opportunity_id,
                        "bounty_contract": args.bounty_contract,
                        "bounty_id": args.bounty_id,
                        "actor_wallet": args.actor_wallet,
                        "amount_base_units": args.amount_base_units,
                        "details": details,
                    })),
            )
            .await
            .0;
            return Ok(tool_result(
                without_action_details(legacy_result(result)?),
                "Prepared one first-party wallet-review session. No signature or payment credential entered ChatGPT, and the action remains unconfirmed until its exact canonical event is indexed.",
                true,
            ));
        }
        "get_bounty_action_status" => {
            let args: GetBountyActionStatusArgs = serde_json::from_value(arguments)
                .map_err(|error| format!("invalid get_bounty_action_status arguments: {error}"))?;
            let intent_id = Uuid::parse_str(&args.intent_id)
                .map_err(|_| "intent_id must be a UUID".to_string())?;
            let result = proxy_hosted_json(reqwest::Client::new().get(format!(
                "{}/v1/chatgpt/action-intents/{intent_id}",
                public_base_url_from_env().trim_end_matches('/')
            )))
            .await
            .0;
            return Ok(tool_result(
                without_action_details(legacy_result(result)?),
                "Refreshed the hosted action against indexed canonical events. A transaction hash or receipt alone never confirms the action; only BountySettled proves solver payment.",
                false,
            ));
        }
        "inspect_open_competition_v2" => {
            let args: OpenCompetitionV2InspectArgs =
                serde_json::from_value(arguments).map_err(|error| {
                    format!("invalid inspect_open_competition_v2 arguments: {error}")
                })?;
            return Ok(tool_result(
                legacy_result(inspect_open_competition_v2(State(state), Json(args)).await.0)?,
                "Returned indexed Open Competition V2 Beta3 state. Only CompetitionSettledV2 proves solver payment.",
                false,
            ));
        }
        "prepare_open_competition_v2" => {
            let args: OpenCompetitionV2MutationArgs =
                serde_json::from_value(arguments).map_err(|error| {
                    format!("invalid prepare_open_competition_v2 arguments: {error}")
                })?;
            let is_creation = args.operation == "create";
            let result = legacy_result(
                prepare_open_competition_v2(State(state.clone()), Json(args))
                    .await
                    .0,
            )?;
            let result = if is_creation {
                attach_competition_preparation_attribution(&state, result, attribution).await?
            } else {
                result
            };
            return Ok(tool_result(
                result,
                "Prepared one exact Open Competition V2 Beta3 action. A plan, signature, proof, or transaction hash is not canonical settlement evidence.",
                false,
            ));
        }
        _ => {}
    }

    let (legacy, narration) = match name {
        "fund_bounty_with_x402" => {
            let args: X402BountyFundingArgs = serde_json::from_value(arguments)
                .map_err(|error| format!("invalid fund_bounty_with_x402 arguments: {error}"))?;
            (
                fund_bounty_with_x402(State(state), Json(args)).await.0,
                "Requested the canonical x402 funding challenge. Only a confirmed FundingAdded event changes funding state; a challenge, signature, or transaction hash alone is not funding evidence.",
            )
        }
        "get_x402_relay_status" => {
            let args: GetX402RelayStatusArgs = serde_json::from_value(arguments)
                .map_err(|error| format!("invalid get_x402_relay_status arguments: {error}"))?;
            (
                get_x402_relay_status(State(state), Json(args)).await.0,
                "Returned the current relay status. Only a confirmed FundingAdded event changes the bounty's funded amount.",
            )
        }
        "prepare_agent_to_earn" => {
            let args: PrepareAgentToEarnInput = serde_json::from_value(arguments)
                .map_err(|error| format!("invalid prepare_agent_to_earn arguments: {error}"))?;
            (
                prepare_agent_to_earn(State(state), Json(args)).await.0,
                "Returned wallet-neutral claim readiness. A readiness response is not a claim, completion, verification, settlement, or payment.",
            )
        }
        "agent_native_claim" => {
            let args: AgentNativeClaimArgs = serde_json::from_value(arguments)
                .map_err(|error| format!("invalid agent_native_claim arguments: {error}"))?;
            (
                agent_native_claim(State(state), caller_headers.clone(), Json(args)).await.0,
                "Advanced the retry-safe claim flow. Only confirmed BountyClaimed proves that the solver owns the active round.",
            )
        }
        "plan_autonomous_bounty_claim" => {
            let args: PlanAutonomousBountyClaimArgs =
                serde_json::from_value(arguments).map_err(|error| {
                    format!("invalid plan_autonomous_bounty_claim arguments: {error}")
                })?;
            (
                plan_autonomous_bounty_claim(State(state), Json(args)).await.0,
                "Prepared the exact direct-wallet claim path. Only confirmed canonical claim events make a solver claim active.",
            )
        }
        "prepare_autonomous_bounty_submission" => {
            let args: PrepareAutonomousBountySubmissionArgs = serde_json::from_value(arguments)
                .map_err(|error| {
                    format!("invalid prepare_autonomous_bounty_submission arguments: {error}")
                })?;
            (
                prepare_autonomous_bounty_submission(State(state), Json(args)).await.0,
                "Prepared a bounded submission and evidence package. Preparation is not completion or verification evidence.",
            )
        }
        "publish_autonomous_submission_evidence" => {
            let args: PublishAutonomousSubmissionEvidenceArgs = serde_json::from_value(arguments)
                .map_err(|error| {
                format!("invalid publish_autonomous_submission_evidence arguments: {error}")
            })?;
            (
                publish_autonomous_submission_evidence(State(state), Json(args))
                    .await
                    .0,
                "Published hash-matched public submission evidence after the canonical SubmissionAdded event. Publication alone is not verification or payout.",
            )
        }
        "list_autonomous_verification_jobs" => {
            let args: AutonomousVerificationJobsArgs =
                serde_json::from_value(arguments).map_err(|error| {
                    format!("invalid list_autonomous_verification_jobs arguments: {error}")
                })?;
            (
                list_autonomous_verification_jobs(State(state), Json(args))
                    .await
                    .0,
                "Returned current hash-matched verification jobs. A job or verdict is not settlement evidence.",
            )
        }
        "plan_autonomous_verification_attestation" => {
            let args: PlanAutonomousVerificationAttestationArgs = serde_json::from_value(arguments)
                .map_err(|error| {
                    format!("invalid plan_autonomous_verification_attestation arguments: {error}")
                })?;
            (
                plan_autonomous_verification_attestation(State(state), Json(args)).await.0,
                "Prepared a verification attestation path. Only the configured canonical verifier/quorum transition proves verification.",
            )
        }
        "plan_autonomous_module_settlement" => {
            let args: PlanAutonomousModuleSettlementArgs = serde_json::from_value(arguments)
                .map_err(|error| {
                    format!("invalid plan_autonomous_module_settlement arguments: {error}")
                })?;
            (
                plan_autonomous_module_settlement(State(state), Json(args))
                    .await
                    .0,
                "Prepared the exact deterministic verifier transaction. Only a confirmed canonical settlement event proves the outcome and payout.",
            )
        }
        "plan_autonomous_attestation_settlement" => {
            let args: PlanAutonomousAttestationSettlementArgs = serde_json::from_value(arguments)
                .map_err(|error| {
                format!("invalid plan_autonomous_attestation_settlement arguments: {error}")
            })?;
            (
                plan_autonomous_attestation_settlement(State(state), Json(args))
                    .await
                    .0,
                "Prepared the exact signed-quorum settlement transaction. Signatures and plans are not canonical settlement evidence.",
            )
        }
        "get_paid_status" => {
            let args: PaidStatusArgs = serde_json::from_value(arguments)
                .map_err(|error| format!("invalid get_paid_status arguments: {error}"))?;
            (
                get_paid_status(State(state), caller_headers.clone(), Json(args)).await.0,
                "Returned reconciled payout status and the appropriate share trigger when canonical evidence exists.",
            )
        }
        "publish_unfunded_bounty" => {
            let args: PublishUnfundedBountyArgs = serde_json::from_value(arguments)
                .map_err(|error| format!("invalid publish_unfunded_bounty arguments: {error}"))?;
            (
                publish_unfunded_bounty(State(state), caller_headers.clone(), Json(args)).await.0,
                "Published the caller’s prepared voluntary request. No generated solution, payment promise, wallet action, or canonical bounty was created.",
            )
        }
        "list_unfunded_bounties" => {
            let args: ListUnfundedBountiesArgs = serde_json::from_value(arguments)
                .map_err(|error| format!("invalid list_unfunded_bounties arguments: {error}"))?;
            (
                list_unfunded_bounties(Json(args)).await.0,
                "Returned recent public unfunded bounty opportunities and their solutions. They are not yet canonical, funded, claimable, or guaranteed to pay.",
            )
        }
        "submit_unfunded_bounty_solution" => {
            let args: SubmitUnfundedBountySolutionArgs = serde_json::from_value(arguments)
                .map_err(|error| {
                    format!("invalid submit_unfunded_bounty_solution arguments: {error}")
                })?;
            (
                submit_unfunded_bounty_solution(State(state.clone()), caller_headers.clone(), Json(args)).await.0,
                "Published the registered agent's solution to the open unfunded bounty. This creates no payment claim.",
            )
        }
        "prepare_bounty_post" => {
            let request_fingerprint = distribution_request_fingerprint(&arguments);
            let args: PrepareBountyPostArgs = match serde_json::from_value(arguments) {
                Ok(args) => args,
                Err(error) => {
                    record_prepare_handoff_failure(
                        &state,
                        attribution,
                        &request_fingerprint,
                        "invalid_arguments",
                    )
                    .await;
                    return Err(format!("invalid prepare_bounty_post arguments: {error}"));
                }
            };
            let value = match prepare_bounty_post_handoff(&state, &args, attribution).await {
                Ok(value) => value,
                Err(error) => {
                    record_prepare_handoff_failure(
                        &state,
                        attribution,
                        &request_fingerprint,
                        "preparation_failed",
                    )
                    .await;
                    return Err(error);
                }
            };
            return Ok(tool_result(
                value,
                "Prepared a reviewable wallet handoff, preserving the exact approved AI-generated image when one was supplied. No bounty has been published or created yet.",
                true,
            ));
        }
        "list_autonomous_bounties" => {
            let args: AutonomousBountyFeedArgs = serde_json::from_value(arguments)
                .map_err(|error| format!("invalid list_autonomous_bounties arguments: {error}"))?;
            (
                list_autonomous_bounties(State(state), Json(args)).await.0,
                "Returned canonical, event-derived bounty inventory.",
            )
        }
        _ => return Err(format!("unknown or unavailable ChatGPT app tool: {name}")),
    };
    match legacy_result(legacy) {
        Ok(mut value) => {
            if public_review && name == "compile_objective_with_cloud_agent" {
                constrain_public_review_objective_plan(&mut value);
            }
            if public_review && name == "publish_unfunded_bounty" {
                strip_public_unfunded_navigation(&mut value);
            }
            Ok(tool_result(value, narration, false))
        }
        Err(error) => Ok(tool_error(error)),
    }
}

fn chatgpt_sandbox_mode() -> bool {
    env_flag(CHATGPT_SANDBOX_ENV)
}

fn chatgpt_public_review_mode() -> bool {
    // The production and developer-installed apps intentionally expose one
    // full hosted-execution product. The only alternate runtime is the
    // deterministic no-write sandbox.
    false
}

fn env_flag(name: &str) -> bool {
    env::var(name).ok().is_some_and(|value| {
        matches!(
            value.trim().to_ascii_lowercase().as_str(),
            "1" | "true" | "yes" | "on"
        )
    })
}

fn chatgpt_tool_names(_sandbox: bool, _public_review: bool) -> &'static [&'static str] {
    CHATGPT_ADVERTISED_TOOL_NAMES
}

fn core_mcp_tool_names() -> Vec<&'static str> {
    CHATGPT_ADVERTISED_TOOL_NAMES
        .iter()
        .chain(CHATGPT_COMPATIBILITY_TOOL_NAMES)
        .chain(CORE_MCP_EXTENSION_TOOL_NAMES)
        .copied()
        .collect()
}

fn chatgpt_tool_is_callable(name: &str) -> bool {
    CHATGPT_ADVERTISED_TOOL_NAMES.contains(&name)
        || CHATGPT_COMPATIBILITY_TOOL_NAMES.contains(&name)
        || CORE_MCP_EXTENSION_TOOL_NAMES.contains(&name)
}

fn validate_public_review_tool_arguments(name: &str, arguments: &Value) -> Result<(), String> {
    let fields: &[&str] = match name {
        "publish_unfunded_bounty" => &["title", "goal", "acceptance_criteria"],
        "compile_objective_with_cloud_agent" => &["objective", "context", "constraints"],
        "add_bounty_comment" => &["body"],
        "create_share_bundle" => &["title", "stage", "status"],
        _ => &[],
    };
    for field in fields {
        match arguments.get(*field) {
            Some(Value::String(value)) => ensure_public_review_noncommercial_text(value)?,
            Some(Value::Array(values)) => {
                for value in values.iter().filter_map(Value::as_str) {
                    ensure_public_review_noncommercial_text(value)?;
                }
            }
            _ => {}
        }
    }
    for forbidden in ["source_url", "bounty_url", "reward", "payment_state"] {
        if arguments
            .get(forbidden)
            .is_some_and(|value| !value.is_null())
        {
            return Err(format!(
                "{forbidden} is unavailable in public review mode; use only voluntary non-economic collaboration fields"
            ));
        }
    }
    Ok(())
}

fn ensure_public_review_noncommercial_text(value: &str) -> Result<(), String> {
    if public_review_text_is_noncommercial(value) {
        Ok(())
    } else {
        Err("public review mode accepts voluntary non-economic collaboration only; remove payment, reward, funding, wallet, token-transfer, checkout, provider, address, and external-link language".to_string())
    }
}

fn ensure_public_review_opportunity_id(value: &str) -> Result<(), String> {
    if value.starts_with("unfunded:") {
        Ok(())
    } else {
        Err("public review comments are available only for voluntary community requests returned by the public feed".to_string())
    }
}

fn public_review_text_is_noncommercial(value: &str) -> bool {
    let normalized = value.to_ascii_lowercase();
    if normalized.contains("http://")
        || normalized.contains("https://")
        || normalized.contains('$')
        || normalized
            .split(|character: char| !character.is_ascii_alphanumeric())
            .any(|token| {
                matches!(
                    token,
                    "pay"
                        | "paid"
                        | "paying"
                        | "payment"
                        | "payments"
                        | "payout"
                        | "payouts"
                        | "reward"
                        | "rewards"
                        | "fund"
                        | "funds"
                        | "funded"
                        | "funder"
                        | "funding"
                        | "crowdfund"
                        | "crowdfunding"
                        | "wallet"
                        | "wallets"
                        | "crypto"
                        | "cryptocurrency"
                        | "token"
                        | "tokens"
                        | "transfer"
                        | "transfers"
                        | "escrow"
                        | "usdc"
                        | "usd"
                        | "btc"
                        | "eth"
                        | "checkout"
                        | "purchase"
                        | "purchases"
                        | "buy"
                        | "sell"
                        | "tip"
                        | "tips"
                        | "donate"
                        | "donation"
                        | "compensation"
                        | "stripe"
                        | "paypal"
                        | "moonpay"
                        | "coinbase"
                        | "binance"
                ) || ((token.len() == 42 || token.len() == 66)
                    && token.starts_with("0x")
                    && token
                        .chars()
                        .skip(2)
                        .all(|character| character.is_ascii_hexdigit()))
            })
    {
        return false;
    }
    true
}

async fn sandbox_tool_result(name: &str, arguments: &Value) -> Result<Value, String> {
    let (value, narration, wallet_review) = match name {
        "get_bounty_feed" => {
            let args: ChatgptFeedArgs = serde_json::from_value(arguments.clone())
                .map_err(|error| format!("invalid get_bounty_feed arguments: {error}"))?;
            (
                sandbox_bounty_feed(args, &[])?,
                "Returned the safe Agent Bounties sandbox feed. Every item and lifecycle response is simulated and no external write can occur.",
                false,
            )
        }
        "render_bounty_feed" => {
            let args: RenderFeedArgs = serde_json::from_value(arguments.clone())
                .map_err(|error| format!("invalid render_bounty_feed arguments: {error}"))?;
            let opportunity_ids = args
                .opportunity_ids
                .iter()
                .map(|value| bounded_opportunity_id(value))
                .collect::<Result<Vec<_>, _>>()?;
            (
                sandbox_bounty_feed(args.feed, &opportunity_ids)?,
                "Rendered the complete Agent Bounties sandbox feed inside ChatGPT. Its cards are interactive, but every lifecycle result is simulated and performs no external write.",
                false,
            )
        }
        "prepare_moonpay_onramp" => {
            let args: PrepareMoonpayOnrampArgs = serde_json::from_value(arguments.clone())
                .map_err(|error| format!("invalid prepare_moonpay_onramp arguments: {error}"))?;
            (
                build_moonpay_onramp_handoff(&args, true)?,
                "Prepared a sandbox-labeled MoonPay handoff without opening a provider page, connecting a wallet, creating checkout, or moving funds.",
                false,
            )
        }
        "prepare_bounty_action" => {
            let args: PrepareBountyActionArgs = serde_json::from_value(arguments.clone())
                .map_err(|error| format!("invalid prepare_bounty_action arguments: {error}"))?;
            let action = bounded_text(&args.action, "action", 16)?;
            let id = sandbox_action_intent_id(&action)?;
            (
                sandbox_action_response(
                    &action,
                    id,
                    "review_required",
                    args.opportunity_id,
                    args.bounty_contract,
                    args.bounty_id,
                    args.amount_base_units,
                    args.details,
                ),
                "Prepared a sandbox-only first-party review session. No network write, wallet request, signature, transaction, or payment occurred.",
                true,
            )
        }
        "get_bounty_action_status" => {
            let args: GetBountyActionStatusArgs = serde_json::from_value(arguments.clone())
                .map_err(|error| format!("invalid get_bounty_action_status arguments: {error}"))?;
            let id = Uuid::parse_str(&args.intent_id)
                .map_err(|_| "intent_id must be a UUID".to_string())?;
            let action = sandbox_action_from_intent_id(id)?;
            (
                sandbox_action_response(
                    action,
                    id,
                    "confirmed",
                    None,
                    None,
                    None,
                    None,
                    json!({}),
                ),
                "Returned simulated canonical confirmation for UI testing only. No indexed event, settlement, or payment exists.",
                false,
            )
        }
        "list_bounty_comments" => {
            let args: ListCommentsArgs = serde_json::from_value(arguments.clone())
                .map_err(|error| format!("invalid list_bounty_comments arguments: {error}"))?;
            let bounty_id = bounded_opportunity_id(&args.bounty_id)?;
            let comments = sandbox_comments(&bounty_id);
            let comment_count = comments.len();
            (
                json!({
                    "sandbox": true,
                    "bounty_id": bounty_id,
                    "comments": comments,
                    "comment_count": comment_count,
                    "evidence_boundary": "Sandbox comments are ephemeral fixtures and were not published."
                }),
                "Returned ephemeral sandbox comments. No production comment was read or written.",
                false,
            )
        }
        "add_bounty_comment" => {
            let args: AddCommentArgs = serde_json::from_value(arguments.clone())
                .map_err(|error| format!("invalid add_bounty_comment arguments: {error}"))?;
            let bounty_id = bounded_opportunity_id(&args.bounty_id)?;
            let body = bounded_text(&args.body, "body", 500)?;
            let author = args
                .author
                .as_deref()
                .map(|value| bounded_text(value, "author", 60))
                .transpose()?
                .unwrap_or_else(|| "you".to_string());
            let comment_id = match args.comment_id.as_deref() {
                Some(value) => Uuid::parse_str(value)
                    .map_err(|_| "comment_id must be a UUID when provided".to_string())?,
                None => Uuid::parse_str("00000000-0000-4000-8000-00000000c001")
                    .expect("static sandbox comment UUID must be valid"),
            };
            let mut comments = sandbox_comments(&bounty_id);
            comments.push(json!({
                "id": comment_id,
                "author": author,
                "body": body,
                "created_at": "2026-07-25T18:05:00Z",
                "sandbox": true
            }));
            let comment_count = comments.len();
            (
                json!({
                    "sandbox": true,
                    "bounty_id": bounty_id,
                    "comments": comments,
                    "comment_count": comment_count,
                    "published": false,
                    "evidence_boundary": "This comment exists only in the current sandbox response and was not published."
                }),
                "Simulated a comment response without publishing anything.",
                false,
            )
        }
        "create_share_bundle" => {
            let args: ShareBundleArgs = serde_json::from_value(arguments.clone())
                .map_err(|error| format!("invalid create_share_bundle arguments: {error}"))?;
            let mut value = build_share_bundle(&args, false)?;
            mark_sandbox(
                &mut value,
                "This share bundle describes a sandbox interaction only and must not be represented as a live bounty event.",
            );
            (
                value,
                "Prepared a sandbox-labeled share bundle. No social post was opened or published.",
                false,
            )
        }
        "fund_bounty_with_x402" => {
            let signed = arguments
                .get("payment_signature")
                .and_then(Value::as_str)
                .is_some_and(|value| !value.trim().is_empty());
            let value = if signed {
                json!({
                    "sandbox": true,
                    "http_status": 202,
                    "body": {
                        "state": "sandbox_relay_complete",
                        "funded": false,
                        "canonical_event_id": null,
                        "next_action": "Sandbox complete. No relay, transaction, FundingAdded event, or USDC movement occurred."
                    },
                    "evidence_boundary": "A sandbox signature is not funding evidence and was not sent anywhere."
                })
            } else {
                json!({
                    "sandbox": true,
                    "http_status": 402,
                    "payment_required_header": "sandbox-x402-challenge",
                    "body": {
                        "state": "authorization_required",
                        "wallet_request": {
                            "method": "sandbox_sign",
                            "message": "Agent Bounties sandbox funding authorization"
                        }
                    },
                    "evidence_boundary": "This is a local fixture challenge. Do not submit a real wallet signature."
                })
            };
            (
                value,
                "Simulated the two-step x402 funding path. No wallet request, relay, transaction, or USDC movement occurred.",
                false,
            )
        }
        "get_x402_relay_status" => (
            json!({
                "sandbox": true,
                "state": "sandbox_relay_complete",
                "funded": false,
                "canonical_event_id": null,
                "evidence_boundary": "No relay or FundingAdded event exists."
            }),
            "Returned a simulated relay status without contacting a relay.",
            false,
        ),
        "prepare_agent_to_earn" => (
            json!({
                "sandbox": true,
                "ready": true,
                "wallet_address": arguments.get("wallet_address").cloned().unwrap_or(Value::Null),
                "checks": [
                    {"name": "sandbox_fixture", "passed": true},
                    {"name": "external_write_disabled", "passed": true}
                ],
                "evidence_boundary": "Readiness is simulated and is not a canonical claim."
            }),
            "Returned simulated claim readiness without reading a wallet or chain.",
            false,
        ),
        "agent_native_claim" => {
            let signed = arguments
                .get("wallet_signature")
                .and_then(Value::as_str)
                .is_some_and(|value| !value.trim().is_empty());
            let body = if signed {
                json!({
                    "state": "sandbox_claim_complete",
                    "claimed": false,
                    "canonical_event_id": null,
                    "next_action": "Sandbox complete. No BountyClaimed event exists."
                })
            } else {
                json!({
                    "state": "authorization_ready",
                    "wallet_request": {
                        "method": "sandbox_signTypedData",
                        "params": ["0x0000000000000000000000000000000000000000", {"sandbox": true}]
                    }
                })
            };
            (
                json!({
                    "sandbox": true,
                    "body": body,
                    "evidence_boundary": "No signature was transmitted and no canonical claim was created."
                }),
                "Simulated the approval-gated claim flow without signing or claiming.",
                false,
            )
        }
        "plan_autonomous_bounty_claim" => (
            sandbox_plan(name, "BountyClaimed"),
            "Prepared a sandbox-only claim plan. No transaction was created or broadcast.",
            false,
        ),
        "prepare_autonomous_bounty_submission" => {
            let bounty_contract = arguments
                .get("bounty_contract")
                .cloned()
                .unwrap_or_else(|| json!("0xabc1000000000000000000000000000000000001"));
            let network = arguments
                .get("network")
                .cloned()
                .unwrap_or_else(|| json!("base-mainnet"));
            let solver_wallet = arguments
                .get("solver_wallet")
                .cloned()
                .unwrap_or(Value::Null);
            let artifact_reference = arguments
                .get("artifact_reference")
                .cloned()
                .unwrap_or(Value::Null);
            let evidence = arguments
                .get("evidence")
                .cloned()
                .unwrap_or_else(|| json!({}));
            (
                json!({
                    "sandbox": true,
                    "bounty_contract": bounty_contract,
                    "bounty_id": format!("0x{}", "11".repeat(32)),
                    "round": 1,
                    "expected_canonical_event": "SubmissionAdded",
                    "signing_payload": {"sandbox": true, "method": "sandbox_submit"},
                    "evidence_publication": {
                        "network": network,
                        "bounty_contract": bounty_contract,
                        "bounty_id": format!("0x{}", "11".repeat(32)),
                        "round": 1,
                        "solver_wallet": solver_wallet,
                        "artifact_reference": artifact_reference,
                        "evidence": evidence,
                        "sandbox": true
                    },
                    "evidence_boundary": "This package is a fixture. No SubmissionAdded event or public evidence exists."
                }),
                "Prepared a sandbox completion package without signing, submitting, or publishing.",
                false,
            )
        }
        "publish_autonomous_submission_evidence" => (
            json!({
                "sandbox": true,
                "state": "sandbox_publication_complete",
                "published": false,
                "round": arguments.get("round").cloned().unwrap_or_else(|| json!(1)),
                "evidence_boundary": "No evidence was published and no verification state changed."
            }),
            "Simulated evidence publication without writing to a public service.",
            false,
        ),
        "list_autonomous_verification_jobs" => (
            sandbox_verification_jobs(),
            "Returned deterministic sandbox verification jobs. They are fixtures, not live verifier work.",
            false,
        ),
        "plan_autonomous_verification_attestation" => (
            sandbox_plan(name, "VerificationAttested"),
            "Prepared a sandbox attestation plan without signing or publishing an attestation.",
            false,
        ),
        "plan_autonomous_module_settlement" => (
            sandbox_plan(name, "BountySettled"),
            "Prepared a sandbox deterministic-verifier plan without creating or broadcasting a transaction.",
            false,
        ),
        "plan_autonomous_attestation_settlement" => (
            sandbox_plan(name, "BountySettled"),
            "Prepared a sandbox quorum-settlement plan without creating or broadcasting a transaction.",
            false,
        ),
        "get_paid_status" => (
            json!({
                "sandbox": true,
                "paid": false,
                "state": "sandbox_only",
                "canonical_event_id": null,
                "evidence_boundary": "No payout lookup occurred and no BountySettled event is claimed."
            }),
            "Returned a sandbox payout fixture. It is not payment evidence.",
            false,
        ),
        "compile_objective_with_cloud_agent" => {
            let objective = arguments
                .get("objective")
                .and_then(Value::as_str)
                .map(|value| bounded_text(value, "objective", 4_000))
                .transpose()?
                .unwrap_or_else(|| "Sandbox objective".to_string());
            (
                json!({
                    "sandbox": true,
                    "objective": objective,
                    "tasks": [
                        {
                            "title": "Specify the public contract",
                            "acceptance_criteria": ["Define the exact artifact and public evidence boundary."]
                        },
                        {
                            "title": "Implement the smallest working slice",
                            "acceptance_criteria": ["Deliver one independently testable outcome."]
                        },
                        {
                            "title": "Verify and publish evidence",
                            "acceptance_criteria": ["Run the committed checks and publish bounded evidence."]
                        }
                    ],
                    "published": false,
                    "evidence_boundary": "These are sandbox drafts. No child bounty was posted or funded."
                }),
                "Compiled three sandbox child-bounty drafts without calling a cloud agent or publishing anything.",
                false,
            )
        }
        "publish_unfunded_bounty" => {
            let title = arguments
                .get("title")
                .and_then(Value::as_str)
                .map(|value| bounded_text(value, "title", 200))
                .transpose()?
                .unwrap_or_else(|| "Sandbox bounty".to_string());
            (
                json!({
                    "sandbox": true,
                    "bounty_id": Uuid::new_v4(),
                    "title": title,
                    "public_url": "https://agentbounties.app/",
                    "funding_status": "sandbox_unfunded",
                    "published": false,
                    "payment_promised": false,
                    "evidence_boundary": "No public request, wallet, USDC commitment, or canonical bounty was created."
                }),
                "Simulated an unfunded bounty post without publishing it.",
                false,
            )
        }
        "list_unfunded_bounties" => (
            json!({
                "sandbox": true,
                "items": [{
                    "id": "sandbox-unfunded-1",
                    "title": "Sandbox unfunded request",
                    "funding_status": "unfunded",
                    "published": false
                }],
                "evidence_boundary": "This is fixture inventory only."
            }),
            "Returned sandbox unfunded inventory without reading production.",
            false,
        ),
        "submit_unfunded_bounty_solution" => (
            json!({
                "sandbox": true,
                "state": "sandbox_solution_complete",
                "published": false,
                "payment_claim_created": false,
                "evidence_boundary": "No solution was published and no payment claim exists."
            }),
            "Simulated an unfunded solution without publishing it.",
            false,
        ),
        "prepare_bounty_post" => {
            let args: PrepareBountyPostArgs = serde_json::from_value(arguments.clone())
                .map_err(|error| format!("invalid prepare_bounty_post arguments: {error}"))?;
            let image = sandbox_bounty_image_reference(&args)?;
            let mut value = build_bounty_post_handoff(&args, image.as_ref())?;
            mark_sandbox(
                &mut value,
                "The handoff is a sandbox fixture. No bounty was published, created, signed, or funded.",
            );
            (
                value,
                "Prepared a sandbox wallet-review card without publishing or requesting a wallet signature.",
                true,
            )
        }
        "list_autonomous_bounties" => {
            let items = sandbox_bounty_feed(
                ChatgptFeedArgs {
                    network: Some("base-mainnet".to_string()),
                    view: None,
                    source_type: Some("canonical_base".to_string()),
                    work_state: None,
                    payment_state: None,
                    limit: Some(30),
                },
                &[],
            )?["items"]
                .clone();
            (
                json!({
                    "sandbox": true,
                    "items": items,
                    "evidence_boundary": "This is deterministic sandbox inventory, not event-derived chain state."
                }),
                "Returned deterministic sandbox canonical inventory without reading a chain or indexer.",
                false,
            )
        }
        _ => {
            return Err(format!(
                "unknown or unavailable ChatGPT app sandbox tool: {name}"
            ))
        }
    };
    Ok(tool_result(value, narration, wallet_review))
}

fn build_moonpay_onramp_handoff(
    args: &PrepareMoonpayOnrampArgs,
    sandbox: bool,
) -> Result<Value, String> {
    let bounty_contract = args.bounty_contract.trim();
    if bounty_contract.len() != 42
        || !bounty_contract.starts_with("0x")
        || !bounty_contract[2..]
            .chars()
            .all(|character| character.is_ascii_hexdigit())
    {
        return Err("bounty_contract must be a 20-byte 0x-prefixed address".to_string());
    }
    if args.amount_base_units == 0 || args.amount_base_units > 1_000_000_000_000 {
        return Err("amount_base_units must be between 1 and 1000000000000".to_string());
    }
    let intent_id = args
        .intent_id
        .as_deref()
        .map(|value| {
            Uuid::parse_str(value)
                .map(|id| id.to_string())
                .map_err(|_| "intent_id must be a UUID when provided".to_string())
        })
        .transpose()?;
    let mut onramp_url = Url::parse("https://agentbounties.app/onramp.html")
        .expect("static MoonPay handoff URL is valid");
    {
        let mut query = onramp_url.query_pairs_mut();
        query.append_pair("from", "chatgpt-app");
        query.append_pair("bountyContract", &bounty_contract.to_ascii_lowercase());
        query.append_pair("amount", &format_usdc(args.amount_base_units));
        query.append_pair("return", "https://agentbounties.app/");
        if let Some(intent_id) = &intent_id {
            query.append_pair("intent", intent_id);
        }
        if sandbox {
            query.append_pair("sandbox", "1");
        }
    }
    Ok(json!({
        "schema_version": "agent-bounties/moonpay-onramp-handoff-v1",
        "provider": "moonpay",
        "state": "review_required_not_opened",
        "network": "base-mainnet",
        "asset": "USDC",
        "bounty_contract": bounty_contract.to_ascii_lowercase(),
        "planned_amount_base_units": args.amount_base_units,
        "planned_amount_usdc": format_usdc(args.amount_base_units),
        "intent_id": intent_id,
        "onramp_url": onramp_url.as_str(),
        "checkout_created": false,
        "purchase_completed": false,
        "bounty_funded": false,
        "canonical_funding_event": null,
        "sandbox": sandbox,
        "next_action": if sandbox {
            "Sandbox proof only. Do not open MoonPay or represent this handoff as a purchase or bounty contribution."
        } else {
            "Open the first-party handoff, connect the destination Base wallet, review MoonPay's final quote and eligibility, complete the optional purchase outside ChatGPT, return, and separately authorize the exact bounty contribution."
        },
        "evidence_boundary": if sandbox {
            "Sandbox handoff only. No provider checkout, purchase, wallet top-up, bounty funding, canonical event, settlement, or payment exists."
        } else {
            "Preparing or opening this handoff is not a purchase and a MoonPay purchase is not bounty funding. Only a matching indexed canonical FundingAdded event changes the bounty's funded state."
        }
    }))
}

fn sandbox_action_intent_id(action: &str) -> Result<Uuid, String> {
    let suffix = match action {
        "post" => 1,
        "fund" => 2,
        "solve" => 3,
        "complete" => 4,
        "verify" => 5,
        _ => return Err("action must be post, fund, solve, complete, or verify".to_string()),
    };
    Uuid::parse_str(&format!("00000000-0000-4000-8000-{suffix:012}"))
        .map_err(|_| "failed to build sandbox action intent".to_string())
}

fn sandbox_action_from_intent_id(id: Uuid) -> Result<&'static str, String> {
    match id.as_bytes()[15] {
        1 => Ok("post"),
        2 => Ok("fund"),
        3 => Ok("solve"),
        4 => Ok("complete"),
        5 => Ok("verify"),
        _ => Err("unknown sandbox action intent".to_string()),
    }
}

#[allow(clippy::too_many_arguments)]
fn sandbox_action_response(
    action: &str,
    intent_id: Uuid,
    status: &str,
    opportunity_id: Option<String>,
    bounty_contract: Option<String>,
    bounty_id: Option<String>,
    amount_base_units: Option<u64>,
    details: Value,
) -> Value {
    let expected_event = match action {
        "post" => "canonical_bounty_created",
        "fund" => "funding_added",
        "solve" => "bounty_claimed",
        "complete" => "submission_added",
        "verify" => "bounty_settled",
        _ => "sandbox_event",
    };
    json!({
        "schema_version": "agent-bounties/chatgpt-action-intent-v1",
        "intent_id": intent_id,
        "action": action,
        "status": status,
        "network": "base-mainnet",
        "opportunity_id": opportunity_id,
        "bounty_contract": bounty_contract,
        "bounty_id": bounty_id,
        "actor_wallet": null,
        "amount_base_units": amount_base_units,
        "details": if details.is_object() { details } else { json!({}) },
        "authorization_url": format!(
            "https://agentbounties.app/authorize.html?sandbox=1&intent={intent_id}"
        ),
        "expected_canonical_events": if action == "verify" {
            json!(["bounty_settled", "submission_rejected"])
        } else {
            json!([expected_event])
        },
        "transaction_hash": null,
        "canonical_event_id": null,
        "canonical_event_kind": if status == "confirmed" {
            Value::String(expected_event.to_string())
        } else {
            Value::Null
        },
        "confirmed_block": null,
        "paid": false,
        "expires_at": "2026-07-25T19:00:00Z",
        "share_after": true,
        "next_action": if status == "confirmed" {
            "Sandbox UI confirmation complete. Share only as a sandbox test."
        } else {
            "In production, open the first-party review URL. Sandbox mode never opens a wallet."
        },
        "sandbox": true,
        "evidence_boundary": "Sandbox fixture only. No hosted record, wallet request, signature, transaction, canonical event, settlement, or payment exists."
    })
}

fn sandbox_bounty_feed(args: ChatgptFeedArgs, opportunity_ids: &[String]) -> Result<Value, String> {
    let mut value = sandbox_feed_projection();
    let items = value
        .get_mut("items")
        .and_then(Value::as_array_mut)
        .ok_or_else(|| "sandbox projection did not contain items".to_string())?;
    items.retain(|item| {
        let id_matches = opportunity_ids.is_empty()
            || item
                .get("opportunity_id")
                .and_then(Value::as_str)
                .is_some_and(|id| opportunity_ids.iter().any(|selected| selected == id));
        let source_matches = args.source_type.as_deref().is_none_or(|expected| {
            item.get("source_type").and_then(Value::as_str) == Some(expected)
        });
        let work_matches = args.work_state.as_deref().is_none_or(|expected| {
            item.get("work_state").and_then(Value::as_str) == Some(expected)
        });
        let payment_matches = args.payment_state.as_deref().is_none_or(|expected| {
            item.get("payment_state").and_then(Value::as_str) == Some(expected)
        });
        let network_matches = args.network.as_deref().is_none_or(|expected| {
            value_network(item).map_or(expected == "base-mainnet", |actual| actual == expected)
        });
        let view_matches = match args.view.as_deref() {
            Some("seeking_funding") => {
                item.get("payment_state").and_then(Value::as_str) == Some("seeking_funding")
            }
            Some("ready_to_earn") => {
                item.get("work_state").and_then(Value::as_str) == Some("claimable")
            }
            Some("engineering") => item
                .get("categories")
                .and_then(Value::as_array)
                .is_some_and(|values| values.iter().any(|value| value == "engineering")),
            Some("creative") => item
                .get("categories")
                .and_then(Value::as_array)
                .is_some_and(|values| values.iter().any(|value| value == "creative")),
            Some("urgent") => item.get("work_state").and_then(Value::as_str) == Some("submitted"),
            Some("recent") | None => true,
            Some(_) => true,
        };
        id_matches
            && source_matches
            && work_matches
            && payment_matches
            && network_matches
            && view_matches
    });
    items.truncate(args.limit.unwrap_or(30).clamp(1, 30) as usize);
    Ok(value)
}

fn value_network(item: &Value) -> Option<&str> {
    item.get("opportunity_id")
        .and_then(Value::as_str)
        .and_then(|value| value.split(':').nth(1))
}

fn sandbox_feed_projection() -> Value {
    let money = |amount: u64| {
        json!({
            "amount": amount.to_string(),
            "currency": "USDC",
            "unit": "base_units",
            "decimals": 6
        })
    };
    json!({
        "schema_version": "agent-bounties/opportunity-projection-v1",
        "generated_at": "2026-07-25T18:00:00Z",
        "state_token": "00000000-0000-4000-8000-00000000feed",
        "network": "base-mainnet",
        "degraded": false,
        "sandbox": true,
        "sandbox_notice": "Safe ChatGPT host test. All cards and lifecycle responses are deterministic fixtures; no production read, write, wallet request, social post, or payment occurs.",
        "evidence_boundary": "Sandbox fixtures are not canonical bounty, funding, claim, submission, verification, settlement, or payment evidence.",
        "items": [
            {
                "opportunity_id": "canonical_base:base-mainnet:0xabc1000000000000000000000000000000000001",
                "source_id": "0xabc1000000000000000000000000000000000001",
                "source_type": "canonical_base",
                "title": "Ship the in-chat bounty feed",
                "goal": "Make every bounty lifecycle action work through the MCP Apps bridge and preserve canonical evidence boundaries.",
                "categories": ["engineering", "featured"],
                "skills": ["Rust", "MCP Apps", "UI"],
                "public_url": "https://agentbounties.app/",
                "work_state": "claimable",
                "payment_state": "escrowed",
                "payment_committed": true,
                "reward": money(3_500_000),
                "funded_amount": money(4_000_000),
                "funding_target": money(4_000_000),
                "bond": money(500_000),
                "verification_method": "signed quorum",
                "verification_ready": true,
                "evidence_boundary": "Sandbox only. In production, BountyClaimed, SubmissionAdded, and BountySettled remain authoritative.",
                "comments": [{"author": "maya", "body": "The card makes the state and reward easy to scan.", "sandbox": true}]
            },
            {
                "opportunity_id": "canonical_base:base-mainnet:0xabc2000000000000000000000000000000000002",
                "source_id": "0xabc2000000000000000000000000000000000002",
                "source_type": "canonical_base",
                "title": "Fund a deterministic documentation fix",
                "goal": "Exercise the two-step funding interaction without moving USDC or contacting a relay.",
                "categories": ["documentation"],
                "skills": ["Technical writing"],
                "public_url": "https://agentbounties.app/",
                "work_state": "open",
                "payment_state": "seeking_funding",
                "payment_committed": false,
                "reward": money(2_000_000),
                "funded_amount": money(400_000),
                "funding_target": money(2_200_000),
                "bond": money(200_000),
                "verification_method": "deterministic module",
                "verification_ready": true,
                "evidence_boundary": "Sandbox only. A challenge or fixture signature is not FundingAdded.",
                "comments": []
            },
            {
                "opportunity_id": "canonical_base:base-mainnet:0xabc3000000000000000000000000000000000003",
                "source_id": "0xabc3000000000000000000000000000000000003",
                "source_type": "canonical_base",
                "title": "Verify the submitted accessibility audit",
                "goal": "Exercise deterministic and signed-quorum verification plans against fixture evidence.",
                "categories": ["verification"],
                "skills": ["Accessibility", "Evidence review"],
                "public_url": "https://agentbounties.app/",
                "work_state": "submitted",
                "payment_state": "escrowed",
                "payment_committed": true,
                "reward": money(5_000_000),
                "funded_amount": money(5_500_000),
                "funding_target": money(5_500_000),
                "bond": money(500_000),
                "verification_method": "signed quorum",
                "verification_ready": true,
                "evidence_boundary": "Sandbox only. A fixture verdict or signature cannot prove settlement.",
                "comments": []
            },
            {
                "opportunity_id": "canonical_base:base-mainnet:0xabc4000000000000000000000000000000000004",
                "source_id": "0xabc4000000000000000000000000000000000004",
                "source_type": "canonical_base",
                "title": "Complete the claimed card accessibility pass",
                "goal": "Prepare a public artifact commitment and hash-matched evidence package entirely through the ChatGPT host bridge.",
                "categories": ["engineering", "completion"],
                "skills": ["Accessibility", "Evidence"],
                "public_url": "https://agentbounties.app/",
                "work_state": "in_progress",
                "payment_state": "escrowed",
                "payment_committed": true,
                "reward": money(4_000_000),
                "funded_amount": money(4_500_000),
                "funding_target": money(4_500_000),
                "bond": money(500_000),
                "verification_method": "signed quorum",
                "verification_ready": true,
                "evidence_boundary": "Sandbox only. Preparing or publishing fixture evidence is not SubmissionAdded, verification, settlement, or payment.",
                "comments": []
            },
            {
                "opportunity_id": "canonical_base:base-mainnet:0xabc5000000000000000000000000000000000005",
                "source_id": "0xabc5000000000000000000000000000000000005",
                "source_type": "canonical_base",
                "title": "Run the deterministic card verifier",
                "goal": "Exercise the committed deterministic-module verification branch without signing, broadcasting, or settling anything.",
                "categories": ["verification", "deterministic"],
                "skills": ["Proof review", "MCP Apps"],
                "public_url": "https://agentbounties.app/",
                "work_state": "submitted",
                "payment_state": "escrowed",
                "payment_committed": true,
                "reward": money(3_000_000),
                "funded_amount": money(3_300_000),
                "funding_target": money(3_300_000),
                "bond": money(300_000),
                "verification_method": "deterministic module",
                "verification_ready": true,
                "evidence_boundary": "Sandbox only. A proof or transaction plan is not BountySettled or solver payment.",
                "comments": []
            }
        ]
    })
}

fn sandbox_comments(opportunity_id: &str) -> Vec<Value> {
    if opportunity_id.contains("abc100") {
        vec![json!({
            "id": Uuid::nil(),
            "author": "maya",
            "body": "The card makes the state and reward easy to scan.",
            "created_at": "2026-07-25T18:00:00Z",
            "sandbox": true
        })]
    } else {
        Vec::new()
    }
}

fn sandbox_verification_jobs() -> Value {
    json!({
        "sandbox": true,
        "jobs": [
            {
                "sandbox": true,
                "bounty_contract": "0xabc3000000000000000000000000000000000003",
                "bounty_id": format!("0x{}", "22".repeat(32)),
                "round": 1,
                "verification_mode": "signed_quorum",
                "eligible_verifiers": [
                    "0x1111111111111111111111111111111111111111",
                    "0x2222222222222222222222222222222222222222"
                ],
                "threshold": 2,
                "verification_expires_at": chrono::Utc::now().timestamp() + 7_200,
                "terms": {"policy_hash": format!("0x{}", "33".repeat(32))},
                "submission_evidence": {
                    "artifact_hash": format!("0x{}", "44".repeat(32)),
                    "evidence_hash": format!("0x{}", "55".repeat(32))
                },
                "evidence_boundary": "Sandbox fixture only; no live verification job exists."
            },
            {
                "sandbox": true,
                "bounty_contract": "0xabc5000000000000000000000000000000000005",
                "bounty_id": format!("0x{}", "66".repeat(32)),
                "round": 1,
                "verification_mode": "deterministic_module",
                "eligible_verifiers": [],
                "threshold": 1,
                "verification_expires_at": chrono::Utc::now().timestamp() + 7_200,
                "terms": {
                    "policy_hash": format!("0x{}", "77".repeat(32)),
                    "verifier_module": "0x5555555555555555555555555555555555555555"
                },
                "submission_evidence": {
                    "artifact_hash": format!("0x{}", "88".repeat(32)),
                    "evidence_hash": format!("0x{}", "99".repeat(32))
                },
                "evidence_boundary": "Sandbox fixture only; no live deterministic verification job exists."
            }
        ],
        "evidence_boundary": "Sandbox fixtures only; no verification, transaction, settlement, or payment exists."
    })
}

fn sandbox_plan(tool_name: &str, expected_event: &str) -> Value {
    json!({
        "sandbox": true,
        "state": "sandbox_wallet_review",
        "tool": tool_name,
        "transaction_created": false,
        "transaction_broadcast": false,
        "expected_event": expected_event,
        "evidence_boundary": format!(
            "This is a sandbox plan. No signature, transaction, {expected_event} event, settlement, or payment exists."
        )
    })
}

fn mark_sandbox(value: &mut Value, evidence_boundary: &str) {
    if let Some(object) = value.as_object_mut() {
        object.insert("sandbox".to_string(), json!(true));
        object.insert("evidence_boundary".to_string(), json!(evidence_boundary));
    }
}

async fn load_bounty_feed(
    mut args: ChatgptFeedArgs,
    opportunity_ids: &[String],
) -> Result<Value, String> {
    let public_review = chatgpt_public_review_mode() && !chatgpt_sandbox_mode();
    if public_review {
        args.view = Some("recent".to_string());
        args.source_type = Some("unfunded_offchain".to_string());
        args.work_state = Some("open".to_string());
        args.payment_state = Some("none".to_string());
    }
    let mut value = legacy_result(
        list_opportunities(Json(OpportunityListArgs {
            network: args.network,
            view: args.view,
            source_type: args.source_type,
            work_state: args.work_state,
            payment_state: args.payment_state,
            limit: args.limit,
        }))
        .await
        .0,
    )?;
    if !opportunity_ids.is_empty() {
        let items = value
            .get_mut("items")
            .and_then(Value::as_array_mut)
            .ok_or_else(|| "opportunity projection did not contain items".to_string())?;
        items.retain(|item| {
            item.get("opportunity_id")
                .and_then(Value::as_str)
                .is_some_and(|id| opportunity_ids.iter().any(|selected| selected == id))
        });
    }
    if public_review {
        constrain_public_review_feed(&mut value)?;
    }
    let mut value = attach_comments(value, public_review).await;
    let state_token = value
        .get("generated_at")
        .and_then(Value::as_str)
        .unwrap_or_default()
        .to_string();
    if let Some(object) = value.as_object_mut() {
        object.insert("state_token".to_string(), json!(state_token));
        object.insert(
            "app_mode".to_string(),
            json!(if public_review {
                "public_review"
            } else {
                "full"
            }),
        );
        object.insert("commerce_enabled".to_string(), json!(!public_review));
    }
    Ok(value)
}

fn constrain_public_review_feed(value: &mut Value) -> Result<(), String> {
    let source = value
        .as_object()
        .ok_or_else(|| "opportunity projection was not an object".to_string())?;
    let generated_at = source
        .get("generated_at")
        .cloned()
        .unwrap_or_else(|| json!(chrono::Utc::now().to_rfc3339()));
    let network = source
        .get("network")
        .cloned()
        .unwrap_or_else(|| json!("base-mainnet"));
    let degraded = source
        .get("degraded")
        .cloned()
        .unwrap_or(Value::Bool(false));
    let items = source
        .get("items")
        .and_then(Value::as_array)
        .cloned()
        .ok_or_else(|| "opportunity projection did not contain items".to_string())?;
    let items = items
        .into_iter()
        .filter(|item| {
            item.get("source_type").and_then(Value::as_str) == Some("unfunded_offchain")
                && item.get("payment_state").and_then(Value::as_str) == Some("none")
                && item.get("work_state").and_then(Value::as_str) == Some("open")
        })
        .filter_map(|item| sanitize_public_review_item(&item))
        .collect::<Vec<_>>();
    let item_count = items.len();
    *value = json!({
        "schema_version": "agent-bounties/community-request-projection-v1",
        "generated_at": generated_at,
        "network": network,
        "applied_view": "recent",
        "degraded": degraded,
        "source_statuses": [{
            "source_type": "voluntary_request",
            "available": true,
            "authoritative_urls": [],
            "item_count": item_count,
            "error": null
        }],
        "items": items,
        "evidence_boundary": "Public review mode exposes voluntary community requests only. No reward, payment promise, wallet action, token transfer, paid-service checkout, claim, settlement, or payout is available."
    });
    Ok(())
}

fn sanitize_public_review_item(item: &Value) -> Option<Value> {
    let opportunity_id = item.get("opportunity_id")?.as_str()?;
    let title = item.get("title")?.as_str()?;
    let goal = item.get("goal").and_then(Value::as_str).unwrap_or_default();
    if !public_review_text_is_noncommercial(title) || !public_review_text_is_noncommercial(goal) {
        return None;
    }
    let acceptance_criteria = item
        .pointer("/evidence_requirements/acceptance_criteria")
        .and_then(Value::as_array)
        .cloned()
        .unwrap_or_default();
    if acceptance_criteria.iter().any(|criterion| {
        criterion
            .as_str()
            .is_some_and(|value| !public_review_text_is_noncommercial(value))
    }) {
        return None;
    }
    let public_strings = |field: &str| {
        item.get(field)
            .and_then(Value::as_array)
            .map(|values| {
                values
                    .iter()
                    .filter_map(Value::as_str)
                    .filter(|value| public_review_text_is_noncommercial(value))
                    .map(|value| json!(value))
                    .collect::<Vec<_>>()
            })
            .unwrap_or_default()
    };
    Some(json!({
        "opportunity_id": opportunity_id,
        "source_id": item.get("source_id").cloned().unwrap_or(Value::Null),
        "source_type": "voluntary_request",
        "request_status": "open",
        "title": title,
        "goal": goal,
        "categories": public_strings("categories"),
        "skills": public_strings("skills"),
        "public_url": public_review_card_url(opportunity_id, title, "open"),
        "work_state": "open",
        "access": "voluntary",
        "decision_authority": "The request poster may review public evidence.",
        "deadline": item.get("deadline").cloned().unwrap_or(Value::Null),
        "deadline_kind": item.get("deadline_kind").cloned().unwrap_or_else(|| json!("publication_expires_at")),
        "review_method": "public evidence review",
        "acceptance_criteria": acceptance_criteria,
        "created_at": item.get("created_at").cloned().unwrap_or(Value::Null),
        "updated_at": item.get("updated_at").cloned().unwrap_or(Value::Null),
        "evidence_boundary": "Voluntary community request only. No reward, payment promise, wallet action, token transfer, paid-service checkout, claim, settlement, or payout is available."
    }))
}

async fn attach_comments(mut value: Value, public_review: bool) -> Value {
    if let Some(items) = value.get_mut("items").and_then(Value::as_array_mut) {
        for item in items {
            if let Some(opportunity_id) = item.get("opportunity_id").and_then(Value::as_str) {
                let mut comments = fetch_comments(opportunity_id)
                    .await
                    .unwrap_or_else(|_| json!({"comments": []}));
                if public_review {
                    constrain_public_review_comments(&mut comments);
                }
                let comments = comments
                    .get("comments")
                    .cloned()
                    .unwrap_or_else(|| json!([]));
                if let Some(object) = item.as_object_mut() {
                    object.insert("comments".to_string(), comments);
                }
            }
        }
    }
    value
}

async fn fetch_comments(opportunity_id: &str) -> Result<Value, String> {
    let opportunity_id = bounded_opportunity_id(opportunity_id)?;
    let result = proxy_hosted_json(reqwest::Client::new().get(format!(
        "{}/v1/opportunities/{}/comments?limit=100",
        public_base_url_from_env().trim_end_matches('/'),
        opportunity_id
    )))
    .await
    .0;
    legacy_result(result)
}

fn constrain_public_review_comments(value: &mut Value) {
    let Some(object) = value.as_object_mut() else {
        return;
    };
    let comments = object
        .get_mut("comments")
        .and_then(Value::as_array_mut)
        .map(|comments| {
            comments.retain(|comment| {
                comment
                    .get("body")
                    .and_then(Value::as_str)
                    .is_some_and(public_review_text_is_noncommercial)
            });
            comments.len()
        })
        .unwrap_or(0);
    object.insert("comment_count".to_string(), json!(comments));
    object.insert(
        "evidence_boundary".to_string(),
        json!("Public comments are collaboration context only. Payment, wallet, token-transfer, reward, and paid-service solicitation are unavailable in public review mode."),
    );
}

fn build_share_bundle(args: &ShareBundleArgs, public_review: bool) -> Result<Value, String> {
    let bounty_id = bounded_text(&args.bounty_id, "bounty_id", 200)?;
    let title = bounded_text(&args.title, "title", 200)?;
    let stage = bounded_text(&args.stage, "stage", 40)?;
    let status = bounded_text(&args.status, "status", 80)?;
    let bounty_url = if public_review {
        for value in [&title, &stage, &status] {
            ensure_public_review_noncommercial_text(value)?;
        }
        public_review_card_url(&bounty_id, &title, &status)
    } else {
        safe_share_url(
            args.bounty_url
                .as_deref()
                .ok_or_else(|| "bounty_url is required outside public review mode".to_string())?,
        )?
    };
    let reward = args
        .reward
        .as_deref()
        .map(|value| bounded_text(value, "reward", 80))
        .transpose()?;
    let payment_state = args
        .payment_state
        .as_deref()
        .map(|value| bounded_text(value, "payment_state", 80))
        .transpose()?
        .unwrap_or_else(|| "not stated".to_string());
    let bounty_image_url = args
        .bounty_image_url
        .as_deref()
        .map(safe_share_image_url)
        .transpose()?;
    let reward_copy = reward
        .as_deref()
        .map(|value| format!(" Reward target: {value}."))
        .unwrap_or_default();
    let caption = if public_review {
        format!(
            "{stage}: {title}. Status: {status}. Voluntary community request; no payment promise. View the public bounty: {bounty_url} #AgentBounties"
        )
    } else {
        format!(
            "{stage}: {title}. Status: {status}.{reward_copy} Payment state: {payment_state}. View the bounty: {bounty_url} #AgentBounties"
        )
    };
    let encoded_caption = encode_component(&caption);
    let encoded_url = encode_component(&bounty_url);
    Ok(json!({
        "schema": "agent-bounties/chatgpt-share-bundle-v1",
        "bounty_id": bounty_id,
        "stage": stage,
        "share_url": bounty_url,
        "bounty_image_url": bounty_image_url,
        "caption": caption,
        "hashtags": if public_review {
            json!(["#AgentBounties", "#OpenSource", "#CommunityCollaboration"])
        } else {
            json!(["#AgentBounties", "#BuildInPublic", "#AIWork"])
        },
        "intents": {
            "x": format!("https://x.com/intent/post?text={encoded_caption}&url={encoded_url}"),
            "linkedin": format!("https://www.linkedin.com/sharing/share-offsite/?url={encoded_url}"),
            "facebook": format!("https://www.facebook.com/sharer/sharer.php?u={encoded_url}"),
            "instagram": "https://www.instagram.com/".to_string()
        },
        "instagram_caption": caption,
        "evidence_boundary": if public_review {
            "This share bundle describes a voluntary community request only. It contains no reward, payment promise, wallet action, token transfer, or paid-service checkout."
        } else {
            "This share bundle describes the selected stage only. A transaction hash, planner response, comment, or individual AI output is not canonical funding, verification, settlement, or payment evidence."
        },
        "next_action": "Copy the caption or open a social share intent, then return to the feed."
    }))
}

fn public_review_card_url(bounty_id: &str, title: &str, status: &str) -> String {
    let origin = chatgpt_widget_domain_from_value(env::var("MCP_BASE_URL").ok().as_deref());
    let mut url = Url::parse(&format!("{origin}/chatgpt/bounty-card-preview"))
        .expect("validated widget origin must form a URL");
    url.query_pairs_mut()
        .append_pair("id", &truncate_chars(bounty_id, 96))
        .append_pair("title", &truncate_chars(title, 200))
        .append_pair("status", &truncate_chars(status, 80))
        .append_pair("public_review", "1");
    url.to_string()
}

fn truncate_chars(value: &str, maximum: usize) -> String {
    value.chars().take(maximum).collect()
}

fn safe_share_url(value: &str) -> Result<String, String> {
    let value = bounded_text(value, "bounty_url", 12_000)?;
    let parsed =
        Url::parse(&value).map_err(|_| "bounty_url must be a valid public URL".to_string())?;
    let local_http =
        parsed.scheme() == "http" && matches!(parsed.host_str(), Some("localhost" | "127.0.0.1"));
    if parsed.scheme() != "https" && !local_http {
        return Err("bounty_url must use HTTPS (or local HTTP during development)".to_string());
    }
    Ok(parsed.to_string())
}

fn safe_share_image_url(value: &str) -> Result<String, String> {
    let value = bounded_text(value, "bounty_image_url", 2_048)?;
    let parsed =
        Url::parse(&value).map_err(|_| "bounty_image_url must be a valid URL".to_string())?;
    let host = parsed.host_str().unwrap_or_default();
    let first_party_image = parsed.scheme() == "https"
        && parsed.username().is_empty()
        && parsed.password().is_none()
        && ((host == "mcp.agentbounties.app"
            && parsed.path().starts_with("/public/bounty-images/"))
            || (host == "api.agentbounties.app"
                && parsed.path().starts_with("/public/opportunities/")
                && parsed.path().ends_with("/embed.svg"))
            || (host == "agentbounties.app" && parsed.path().starts_with("/assets/")));
    if !first_party_image {
        return Err("bounty_image_url must be a first-party Agent Bounties image URL".to_string());
    }
    Ok(parsed.to_string())
}

fn encode_component(value: &str) -> String {
    url::form_urlencoded::byte_serialize(value.as_bytes()).collect()
}

fn legacy_result(value: Value) -> Result<Value, String> {
    if let Some(error) = value.get("error").and_then(Value::as_str) {
        return Err(error.to_string());
    }
    value
        .pointer("/content/0/json")
        .cloned()
        .ok_or_else(|| "tool returned an invalid legacy response".to_string())
}

fn without_action_details(mut value: Value) -> Value {
    if let Some(object) = value.as_object_mut() {
        object.remove("details");
    }
    value
}

fn strip_public_review_economics(value: &mut Value) {
    match value {
        Value::Object(object) => {
            for key in [
                "solver_budget_usdc",
                "suggested_solver_reward_usdc",
                "settlement_policy",
            ] {
                object.remove(key);
            }
            for child in object.values_mut() {
                strip_public_review_economics(child);
            }
        }
        Value::Array(items) => {
            for item in items {
                strip_public_review_economics(item);
            }
        }
        _ => {}
    }
}

fn constrain_public_review_objective_plan(value: &mut Value) {
    strip_public_review_economics(value);
    let Some(source) = value.as_object() else {
        return;
    };
    let tasks = source
        .get("tasks")
        .and_then(Value::as_array)
        .map(|tasks| {
            tasks
                .iter()
                .enumerate()
                .filter_map(|(index, task)| {
                    let task = task.as_object()?;
                    let title = safe_public_review_generated_text(
                        task.get("title").and_then(Value::as_str),
                        &format!("Review task {}", index + 1),
                    );
                    let goal = safe_public_review_generated_text(
                        task.get("goal").and_then(Value::as_str),
                        "Complete the public deliverable for this task.",
                    );
                    let mut acceptance_criteria = task
                        .get("acceptance_criteria")
                        .and_then(Value::as_array)
                        .map(|criteria| {
                            criteria
                                .iter()
                                .filter_map(Value::as_str)
                                .filter(|criterion| {
                                    public_review_text_is_noncommercial(criterion)
                                })
                                .map(|criterion| json!(criterion))
                                .collect::<Vec<_>>()
                        })
                        .unwrap_or_default();
                    if acceptance_criteria.is_empty() {
                        acceptance_criteria.push(json!(
                            "Publish public evidence that the task goal is complete."
                        ));
                    }
                    Some(json!({
                        "task_id": task.get("task_id").cloned().unwrap_or_else(|| json!(format!("task-{}", index + 1))),
                        "title": title,
                        "goal": goal,
                        "depends_on": task.get("depends_on").cloned().unwrap_or_else(|| json!([])),
                        "acceptance_criteria": acceptance_criteria,
                        "effort_weight": task.get("effort_weight").cloned().unwrap_or_else(|| json!(1))
                    }))
                })
                .collect::<Vec<_>>()
        })
        .unwrap_or_default();
    let filtered_strings = |field: &str| {
        source
            .get(field)
            .and_then(Value::as_array)
            .map(|values| {
                values
                    .iter()
                    .filter_map(Value::as_str)
                    .filter(|value| public_review_text_is_noncommercial(value))
                    .map(|value| json!(value))
                    .collect::<Vec<_>>()
            })
            .unwrap_or_default()
    };
    let mut sanitized = json!({
        "schema_version": source.get("schema_version").cloned().unwrap_or_else(|| json!("agent-bounties/public-objective-plan-v1")),
        "provider": source.get("provider").cloned().unwrap_or(Value::Null),
        "model": source.get("model").cloned().unwrap_or(Value::Null),
        "title": safe_public_review_generated_text(source.get("title").and_then(Value::as_str), "Public collaboration plan"),
        "objective": safe_public_review_generated_text(source.get("objective").and_then(Value::as_str), "Complete the stated public objective."),
        "success_definition": safe_public_review_generated_text(
            source.get("success_definition").and_then(Value::as_str),
            "All task drafts satisfy their public acceptance criteria and the combined objective is complete."
        ),
        "tasks": tasks,
        "parallel_layers": source.get("parallel_layers").cloned().unwrap_or_else(|| json!([])),
        "questions": filtered_strings("questions"),
        "risk_flags": filtered_strings("risk_flags"),
        "published": false,
        "evidence_boundary": "Advisory non-economic task drafts only. Nothing was published, funded, claimed, verified, settled, sold, or transferred."
    });
    if let Some(object) = sanitized.as_object_mut() {
        for optional_string in ["provider", "model"] {
            if object.get(optional_string).is_some_and(Value::is_null) {
                object.remove(optional_string);
            }
        }
    }
    *value = sanitized;
}

fn safe_public_review_generated_text(value: Option<&str>, fallback: &str) -> String {
    value
        .filter(|value| public_review_text_is_noncommercial(value))
        .map(ToString::to_string)
        .unwrap_or_else(|| fallback.to_string())
}

fn strip_public_unfunded_navigation(value: &mut Value) {
    let Some(source) = value.as_object() else {
        return;
    };
    let bounty_id = source
        .get("bounty_id")
        .and_then(Value::as_str)
        .unwrap_or("voluntary-request");
    let title = source
        .get("title")
        .and_then(Value::as_str)
        .unwrap_or("Voluntary community request");
    *value = json!({
        "schema_version": "agent-bounties/voluntary-request-v1",
        "bounty_id": bounty_id,
        "status": source.get("status").cloned().unwrap_or_else(|| json!("open")),
        "title": title,
        "goal": source.get("goal").cloned().unwrap_or_else(|| json!("Complete the stated public request.")),
        "acceptance_criteria": source.get("acceptance_criteria").cloned().unwrap_or_else(|| json!([])),
        "public_url": public_review_card_url(bounty_id, title, "open"),
        "created_at": source.get("created_at").cloned().unwrap_or_else(|| json!("")),
        "expires_at": source.get("expires_at").cloned().unwrap_or_else(|| json!("")),
        "evidence_boundary": "Voluntary community request only. No reward, payment promise, wallet action, token transfer, paid-service checkout, claim, settlement, or payout is available."
    });
}

fn tool_result(value: Value, narration: &str, wallet_review: bool) -> Value {
    let structured_content = if value.is_object() {
        value
    } else {
        json!({"items": value})
    };
    let mut result = json!({
        "content": [{"type": "text", "text": narration}],
        "structuredContent": structured_content
    });
    if wallet_review {
        result["_meta"] = json!({
            "handoff_kind": "wallet_review",
            "private_key_requested": false,
            "seed_phrase_requested": false
        });
    }
    result
}

fn tool_error(error: String) -> Value {
    json!({
        "content": [{"type": "text", "text": error}],
        "isError": true
    })
}

fn read_resource(params: &Value) -> Result<Value, String> {
    let uri = params
        .get("uri")
        .and_then(Value::as_str)
        .ok_or_else(|| "resources/read requires uri".to_string())?;
    match uri {
        FEED_WIDGET_URI => Ok(json!({"contents": [feed_widget_resource_contents()]})),
        _ => Err("unknown resource URI".to_string()),
    }
}

fn feed_widget_resource_descriptor() -> Value {
    json!({
        "uri": FEED_WIDGET_URI,
        "name": "Agent Bounties live feed",
        "title": "Live bounty feed",
        "description": "An interactive, shareable feed of public bounty opportunities with lifecycle-aware actions.",
        "mimeType": "text/html;profile=mcp-app"
    })
}

fn feed_widget_resource_contents() -> Value {
    feed_widget_resource_contents_for_mode(chatgpt_public_review_mode() && !chatgpt_sandbox_mode())
}

fn feed_widget_resource_contents_for_mode(_public_review: bool) -> Value {
    let public_review = false;
    let widget_domain = chatgpt_widget_domain_from_value(env::var("MCP_BASE_URL").ok().as_deref());
    let mut redirect_domains = vec![
        widget_domain.clone(),
        "https://x.com".to_string(),
        "https://www.linkedin.com".to_string(),
        "https://www.instagram.com".to_string(),
    ];
    if !public_review {
        redirect_domains.push("https://agentbounties.app".to_string());
    }
    let resource_domains = vec![
        widget_domain.clone(),
        "https://api.agentbounties.app".to_string(),
        "https://agentbounties.app".to_string(),
    ];
    let widget_description = if public_review {
        "A branded, read-only community-request feed. People use the visible conversation actions to discuss posting, commenting, sharing, or solving without filling out forms in the widget."
    } else {
        "A branded, read-only live bounty feed. People use Post bounty, Comment, Share, and Solve to continue in conversation; the widget contains no forms, wallet controls, or payment fields."
    };
    json!({
        "uri": FEED_WIDGET_URI,
        "mimeType": "text/html;profile=mcp-app",
        "text": feed_widget_html_for_mode(public_review),
        "_meta": {
            "ui": {
                "prefersBorder": false,
                "domain": widget_domain.clone(),
                "csp": {
                    "connectDomains": [],
                    "resourceDomains": resource_domains.clone(),
                    "redirectDomains": redirect_domains.clone()
                }
            },
            "openai/widgetDescription": widget_description,
            "openai/widgetPrefersBorder": false,
            "openai/widgetDomain": widget_domain,
            "openai/widgetCSP": {
                "connect_domains": [],
                "resource_domains": resource_domains,
                "redirect_domains": redirect_domains
            }
        }
    })
}

fn chatgpt_widget_domain_from_value(value: Option<&str>) -> String {
    value
        .and_then(|value| Url::parse(value.trim()).ok())
        .filter(|url| {
            url.scheme() == "https"
                && url.host_str().is_some()
                && url.username().is_empty()
                && url.password().is_none()
        })
        .and_then(|url| {
            let host = url.host_str()?;
            Some(match url.port() {
                Some(port) => format!("https://{host}:{port}"),
                None => format!("https://{host}"),
            })
        })
        .unwrap_or_else(|| "https://mcp.agentbounties.app".to_string())
}

fn feed_widget_html_for_mode(public_review: bool) -> String {
    let encoded = base64::engine::general_purpose::STANDARD.encode(FEED_CARD_ART);
    let widget_domain = chatgpt_widget_domain_from_value(env::var("MCP_BASE_URL").ok().as_deref());
    let widget_domain_json = serde_json::to_string(&widget_domain)
        .unwrap_or_else(|_| "\"https://mcp.agentbounties.app\"".to_string());
    FEED_WIDGET_HTML
        .replace(
            "__BOUNTY_CARD_ART_DATA_URI__",
            &format!("data:image/webp;base64,{encoded}"),
        )
        .replace("__CHATGPT_APP_BASE_URL_JSON__", &widget_domain_json)
        .replace(
            "__CHATGPT_PUBLIC_REVIEW_MODE__",
            if public_review { "true" } else { "false" },
        )
}

pub(crate) fn bounty_card_preview_html() -> String {
    let encoded = base64::engine::general_purpose::STANDARD.encode(FEED_CARD_ART);
    BOUNTY_CARD_PREVIEW_HTML.replace(
        "__BOUNTY_CARD_ART_DATA_URI__",
        &format!("data:image/webp;base64,{encoded}"),
    )
}

fn post_handoff_output_schema() -> Value {
    json!({
        "type": "object",
        "properties": {
            "schema": {"type": "string"},
            "state": {"type": "string"},
            "posting_operation_id": {"type": "string", "format": "uuid"},
            "review_mode": {"type": "string", "enum": ["creator", "automated"]},
            "delivery_deadline": {"type": ["string", "null"], "format": "date-time"},
            "meta_child": {"type": ["object", "null"]},
            "reference_attachment": {"type": ["object", "null"]},
            "verification_prepared": {"type": "boolean"},
            "review_disclosure": {"type": ["string", "null"]},
            "title": {"type": "string"},
            "goal": {"type": "string"},
            "acceptance_criteria": {"type": "array", "items": {"type": "string"}},
            "solver_reward_usdc": {"type": "string"},
            "verifier_reward_usdc": {"type": "string"},
            "target_usdc": {"type": "string"},
            "task_window_days": {"type": "integer"},
            "initial_funding_usdc": {"type": "string"},
            "crowdfund": {"type": "boolean"},
            "source_url": {"type": ["string", "null"]},
            "benchmark": {"type": ["object", "null"]},
            "evidence_schema": {"type": ["object", "null"]},
            "image": {
                "anyOf": [
                    {
                        "type": "object",
                        "properties": {
                            "source": {"type": "string", "const": "chatgpt_user_generated"},
                            "prompt": {"type": "string"},
                            "alt_text": {"type": "string"},
                            "asset_url": {"type": "string"},
                            "sha256": {"type": "string"},
                            "mime_type": {"type": "string"}
                        },
                        "required": ["source", "prompt", "alt_text", "asset_url", "sha256", "mime_type"],
                        "additionalProperties": false
                    },
                    {"type": "null"}
                ]
            },
            "post_url": {"type": "string"},
            "bounty_created": {"type": "boolean"},
            "wallet_signature_requested": {"type": "boolean"},
            "next_action": {"type": "string"},
            "evidence_boundary": {"type": "string"}
        },
        "required": ["schema", "state", "title", "goal", "acceptance_criteria", "solver_reward_usdc", "verifier_reward_usdc", "target_usdc", "task_window_days", "initial_funding_usdc", "crowdfund", "image", "post_url", "bounty_created", "wallet_signature_requested", "next_action", "evidence_boundary"],
        "additionalProperties": false
    })
}

fn feed_output_schema(public_review: bool) -> Value {
    if public_review {
        let source_status = json!({
            "type": "object",
            "properties": {
                "source_type": {"type": "string", "enum": ["voluntary_request"]},
                "available": {"type": "boolean"},
                "authoritative_urls": {"type": "array", "items": {"type": "string"}, "maxItems": 0},
                "item_count": {"type": "integer"},
                "error": {"type": ["string", "null"]}
            },
            "required": ["source_type", "available", "authoritative_urls", "item_count", "error"],
            "additionalProperties": false
        });
        let comment = json!({
            "type": "object",
            "properties": {
                "id": {"type": "string"},
                "opportunity_id": {"type": "string"},
                "author": {"type": "string"},
                "body": {"type": "string"},
                "created_at": {"type": "string"}
            },
            "required": ["id", "author", "body", "created_at"],
            "additionalProperties": false
        });
        let item = json!({
            "type": "object",
            "properties": {
                "opportunity_id": {"type": "string"},
                "source_id": {"type": ["string", "null"]},
                "source_type": {"type": "string", "enum": ["voluntary_request"]},
                "request_status": {"type": "string", "enum": ["open"]},
                "title": {"type": "string"},
                "goal": {"type": "string"},
                "categories": {"type": "array", "items": {"type": "string"}},
                "skills": {"type": "array", "items": {"type": "string"}},
                "public_url": {"type": "string"},
                "work_state": {"type": "string", "enum": ["open"]},
                "access": {"type": "string", "enum": ["voluntary"]},
                "decision_authority": {"type": "string"},
                "deadline": {"type": ["string", "null"]},
                "deadline_kind": {"type": "string"},
                "review_method": {"type": "string"},
                "acceptance_criteria": {"type": "array", "items": {"type": "string"}},
                "created_at": {"type": ["string", "null"]},
                "updated_at": {"type": ["string", "null"]},
                "comments": {"type": "array", "items": comment},
                "evidence_boundary": {"type": "string"}
            },
            "required": [
                "opportunity_id", "source_id", "source_type", "request_status",
                "title", "goal", "categories", "skills", "public_url", "work_state",
                "access", "decision_authority", "deadline", "deadline_kind",
                "review_method", "acceptance_criteria", "created_at", "updated_at",
                "comments", "evidence_boundary"
            ],
            "additionalProperties": false
        });
        return json!({
            "type": "object",
            "properties": {
                "schema_version": {"type": "string", "enum": ["agent-bounties/community-request-projection-v1"]},
                "generated_at": {"type": "string"},
                "state_token": {"type": "string"},
                "network": {"type": "string"},
                "applied_view": {"type": "string", "enum": ["recent"]},
                "degraded": {"type": "boolean"},
                "source_statuses": {
                    "type": "array",
                    "items": source_status
                },
                "items": {
                    "type": "array",
                    "items": item
                },
                "app_mode": {"type": "string", "enum": ["public_review"]},
                "commerce_enabled": {"type": "boolean", "enum": [false]},
                "evidence_boundary": {"type": "string"}
            },
            "required": [
                "schema_version", "generated_at", "state_token", "network", "applied_view",
                "degraded", "source_statuses", "items", "app_mode", "commerce_enabled",
                "evidence_boundary"
            ],
            "additionalProperties": false
        });
    }
    json!({
        "type": "object",
        "properties": {
            "schema_version": {"type": "string"},
            "generated_at": {"type": "string"},
            "network": {"type": "string"},
            "items": {"type": "array", "items": {"type": "object"}},
            "degraded": {"type": "boolean"},
            "app_mode": {"type": "string", "enum": ["full", "sandbox"]},
            "commerce_enabled": {"type": "boolean"},
            "evidence_boundary": {"type": "string"}
        },
        "required": ["schema_version", "generated_at", "network", "items", "degraded", "evidence_boundary"],
        "additionalProperties": true
    })
}

fn moonpay_onramp_output_schema() -> Value {
    json!({
        "type": "object",
        "properties": {
            "schema_version": {"type": "string", "enum": ["agent-bounties/moonpay-onramp-handoff-v1"]},
            "provider": {"type": "string", "enum": ["moonpay"]},
            "state": {"type": "string", "enum": ["review_required_not_opened"]},
            "network": {"type": "string", "enum": ["base-mainnet"]},
            "asset": {"type": "string", "enum": ["USDC"]},
            "bounty_contract": {"type": "string", "pattern": "^0x[0-9a-f]{40}$"},
            "planned_amount_base_units": {"type": "integer", "minimum": 1, "maximum": 1_000_000_000_000_u64},
            "planned_amount_usdc": {"type": "string"},
            "intent_id": {"type": ["string", "null"], "format": "uuid"},
            "onramp_url": {"type": "string"},
            "checkout_created": {"type": "boolean", "enum": [false]},
            "purchase_completed": {"type": "boolean", "enum": [false]},
            "bounty_funded": {"type": "boolean", "enum": [false]},
            "canonical_funding_event": {"type": "null"},
            "sandbox": {"type": "boolean"},
            "next_action": {"type": "string"},
            "evidence_boundary": {"type": "string"}
        },
        "required": [
            "schema_version", "provider", "state", "network", "asset",
            "bounty_contract", "planned_amount_base_units", "planned_amount_usdc",
            "intent_id", "onramp_url", "checkout_created", "purchase_completed",
            "bounty_funded", "canonical_funding_event", "sandbox", "next_action",
            "evidence_boundary"
        ],
        "additionalProperties": false
    })
}

fn autonomous_bounty_feed_output_schema() -> Value {
    json!({
        "type": "object",
        "properties": {
            "items": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "bounty_id": {"type": "string"},
                        "bounty_contract": {"type": "string"},
                        "status": {"type": "string"},
                        "solver_reward": {"type": "string"},
                        "claim_bond": {"type": "string"},
                        "required_external_spend": {"type": "string"},
                        "gross_cash_margin": {"type": "string"},
                        "terms_hash": {"type": "string"},
                        "verification_ready": {"type": "boolean"},
                        "verification_readiness_reason": {"type": "string"}
                    },
                    "required": [
                        "bounty_id", "bounty_contract", "status", "solver_reward",
                        "claim_bond", "required_external_spend", "gross_cash_margin",
                        "terms_hash", "verification_ready",
                        "verification_readiness_reason"
                    ],
                    "additionalProperties": true
                }
            },
            "sandbox": {"type": "boolean"},
            "evidence_boundary": {"type": "string"}
        },
        "required": ["items"],
        "additionalProperties": true
    })
}

fn open_competition_v2_output_schema() -> Value {
    json!({
        "type": "object",
        "properties": {
            "schema_version": {"type": "string"},
            "status": {"type": "string"},
            "state": {"type": "string"},
            "activation_state": {"type": "string"},
            "error_code": {"type": "string"},
            "next_action": {"type": "string"},
            "evidence_boundary": {"type": "string"},
            "flows": {"type": "object"},
            "profile_support": {"type": "object"},
            "operations": {"type": "array", "items": {"type": "string"}},
            "execution_policy_hash": {"type": "string", "pattern": "^0x[0-9a-fA-F]{64}$"},
            "settlement_policy_hash": {"type": "string", "pattern": "^0x[0-9a-fA-F]{64}$"},
            "creation_nonce": {"type": "string", "pattern": "^0x[0-9a-fA-F]{64}$"},
            "side_effects": {"type": "object"},
            "safety": {"type": "array", "items": {"type": "string"}}
        },
        "additionalProperties": true
    })
}

fn bounty_action_output_schema() -> Value {
    json!({
        "type": "object",
        "properties": {
            "schema_version": {"type": "string"},
            "intent_id": {"type": "string", "format": "uuid"},
            "action": {"type": "string", "enum": ["post", "fund", "solve", "complete", "verify"]},
            "status": {"type": "string", "enum": ["review_required", "pending_confirmation", "confirmed", "failed", "expired"]},
            "network": {"type": "string"},
            "opportunity_id": {"type": ["string", "null"]},
            "bounty_contract": {"type": ["string", "null"]},
            "bounty_id": {"type": ["string", "null"]},
            "actor_wallet": {"type": ["string", "null"]},
            "amount_base_units": {"type": ["integer", "null"]},
            "authorization_url": {"type": "string"},
            "expected_canonical_events": {"type": "array", "items": {"type": "string"}},
            "transaction_hash": {"type": ["string", "null"]},
            "canonical_event_id": {"type": ["string", "null"], "format": "uuid"},
            "canonical_event_kind": {"type": ["string", "null"]},
            "confirmed_block": {"type": ["integer", "null"]},
            "paid": {"type": "boolean"},
            "expires_at": {"type": "string"},
            "share_after": {"type": "boolean"},
            "next_action": {"type": "string"},
            "evidence_boundary": {"type": "string"}
        },
        "required": [
            "schema_version", "intent_id", "action", "status", "network",
            "authorization_url", "expected_canonical_events", "paid", "expires_at",
            "share_after", "next_action", "evidence_boundary"
        ],
        "additionalProperties": true
    })
}

fn bounty_comments_output_schema() -> Value {
    json!({
        "type": "object",
        "properties": {
            "schema_version": {"type": "string"},
            "opportunity_id": {"type": "string"},
            "bounty_id": {"type": "string"},
            "comments": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "string"},
                        "opportunity_id": {"type": "string"},
                        "author": {"type": "string"},
                        "body": {"type": "string"},
                        "created_at": {"type": "string"}
                    },
                    "required": ["id", "author", "body", "created_at"],
                    "additionalProperties": true
                }
            },
            "comment_count": {"type": "integer"},
            "published": {"type": "boolean"},
            "share_after": {"type": "boolean"},
            "sandbox": {"type": "boolean"},
            "evidence_boundary": {"type": "string"}
        },
        "required": ["comments", "comment_count", "evidence_boundary"],
        "additionalProperties": true
    })
}

fn share_bundle_output_schema() -> Value {
    json!({
        "type": "object",
        "properties": {
            "schema": {"type": "string"},
            "bounty_id": {"type": "string"},
            "stage": {"type": "string"},
            "share_url": {"type": "string"},
            "bounty_image_url": {"type": ["string", "null"]},
            "caption": {"type": "string"},
            "hashtags": {"type": "array", "items": {"type": "string"}},
            "intents": {
                "type": "object",
                "properties": {
                    "x": {"type": "string"},
                    "linkedin": {"type": "string"},
                    "facebook": {"type": "string"},
                    "instagram": {"type": "string"}
                },
                "required": ["x", "linkedin", "facebook", "instagram"],
                "additionalProperties": false
            },
            "instagram_caption": {"type": "string"},
            "sandbox": {"type": "boolean"},
            "evidence_boundary": {"type": "string"},
            "next_action": {"type": "string"}
        },
        "required": [
            "schema", "bounty_id", "stage", "share_url", "bounty_image_url", "caption", "hashtags",
            "intents", "instagram_caption", "evidence_boundary", "next_action"
        ],
        "additionalProperties": true
    })
}

fn unfunded_bounty_output_schema(public_review: bool) -> Value {
    if public_review {
        return json!({
            "type": "object",
            "properties": {
                "schema_version": {"type": "string"},
                "bounty_id": {"type": "string"},
                "status": {"type": "string", "enum": ["open"]},
                "title": {"type": "string"},
                "goal": {"type": "string"},
                "acceptance_criteria": {"type": "array", "items": {"type": "string"}},
                "public_url": {"type": "string"},
                "created_at": {"type": "string"},
                "expires_at": {"type": "string"},
                "evidence_boundary": {"type": "string"}
            },
            "required": [
                "schema_version", "bounty_id", "status", "title", "goal",
                "acceptance_criteria", "public_url", "created_at", "expires_at",
                "evidence_boundary"
            ],
            "additionalProperties": false
        });
    }
    json!({
        "type": "object",
        "properties": {
            "schema_version": {"type": "string"},
            "bounty_id": {"type": "string"},
            "bounty_kind": {"type": "string", "enum": ["unfunded_offchain"]},
            "funding_status": {"type": "string", "enum": ["unfunded"]},
            "status": {"type": "string", "enum": ["open"]},
            "title": {"type": "string"},
            "goal": {"type": "string"},
            "acceptance_criteria": {"type": "array", "items": {"type": "string"}},
            "source_url": {"type": ["string", "null"]},
            "wallet_required": {"type": "boolean", "enum": [false]},
            "initial_funding_usdc": {"type": "string", "enum": ["0"]},
            "payment_promised": {"type": "boolean", "enum": [false]},
            "canonical_bounty_created": {"type": "boolean", "enum": [false]},
            "public_url": {"type": "string"},
            "created_at": {"type": "string"},
            "expires_at": {"type": "string"},
            "evidence_boundary": {"type": "string"}
        },
        "required": [
            "schema_version", "bounty_id", "bounty_kind", "funding_status", "status",
            "title", "goal", "acceptance_criteria", "wallet_required",
            "initial_funding_usdc", "payment_promised", "canonical_bounty_created",
            "public_url", "created_at", "expires_at", "evidence_boundary"
        ],
        "additionalProperties": true
    })
}

fn objective_plan_output_schema(public_review: bool) -> Value {
    let mut schema = json!({
        "type": "object",
        "properties": {
            "schema_version": {"type": "string"},
            "provider": {"type": "string"},
            "model": {"type": "string"},
            "title": {"type": "string"},
            "objective": {"type": "string"},
            "success_definition": {"type": "string"},
            "tasks": {"type": "array", "items": {"type": "object"}},
            "parallel_layers": {
                "type": "array",
                "items": {"type": "array", "items": {"type": "string"}}
            },
            "solver_budget_usdc": {"type": ["string", "null"]},
            "execution_policy": {"type": "object"},
            "verification_policy": {"type": "object"},
            "settlement_policy": {"type": "object"},
            "questions": {"type": "array", "items": {"type": "string"}},
            "risk_flags": {"type": "array", "items": {"type": "string"}},
            "source_url": {"type": ["string", "null"]},
            "published": {"type": "boolean"},
            "sandbox": {"type": "boolean"},
            "next_action": {"type": "string"},
            "evidence_boundary": {"type": "string"}
        },
        "required": ["objective", "tasks", "evidence_boundary"],
        "additionalProperties": true
    });
    if public_review {
        if let Some(properties) = schema.get_mut("properties").and_then(Value::as_object_mut) {
            for field in [
                "solver_budget_usdc",
                "execution_policy",
                "verification_policy",
                "settlement_policy",
                "source_url",
                "next_action",
            ] {
                properties.remove(field);
            }
        }
        schema["additionalProperties"] = json!(false);
    }
    schema
}

fn public_review_input_schema(name: &str, mut schema: Value, public_review: bool) -> Value {
    if !public_review {
        return schema;
    }
    let Some(properties) = schema.get_mut("properties").and_then(Value::as_object_mut) else {
        return schema;
    };
    match name {
        "get_bounty_feed" | "render_bounty_feed" => {
            properties.remove("source_type");
            properties.remove("payment_state");
            if let Some(view) = properties.get_mut("view") {
                view["enum"] = json!(["recent", "engineering", "creative", "urgent", null]);
            }
            if let Some(work_state) = properties.get_mut("work_state") {
                work_state["enum"] = json!(["open", null]);
            }
        }
        "compile_objective_with_cloud_agent" => {
            properties.remove("solver_budget_usdc");
            properties.remove("source_url");
        }
        "create_share_bundle" => {
            properties.remove("bounty_url");
            properties.remove("bounty_image_url");
            properties.remove("reward");
            properties.remove("payment_state");
        }
        "publish_unfunded_bounty" => {
            properties.remove("source_url");
        }
        _ => {}
    }
    if let Some(required) = schema.get_mut("required").and_then(Value::as_array_mut) {
        required.retain(|field| {
            !matches!(
                field.as_str(),
                Some("source_url" | "bounty_url" | "reward" | "payment_state")
            )
        });
    }
    schema
}

fn public_review_tool_description<'a>(name: &str, fallback: &'a str) -> &'a str {
    match name {
        "get_bounty_feed" => "Use this when the user needs fresh structured data for voluntary, unfunded community requests. It returns no funded inventory, payment promise, claim, token action, or settlement action.",
        "render_bounty_feed" => "Use this when the user wants the interactive voluntary-request work queue rendered inside ChatGPT. This public configuration contains comments, sharing, and non-economic planning only.",
        "compile_objective_with_cloud_agent" => "Retired compatibility tool: returns hosted_generation_removed. Prepare the task plan in your own AI account.",
        "publish_unfunded_bounty" => "Use this when an authenticated user explicitly asks to publish their prepared voluntary request. A website account, wallet session, or operator credential is required. No model is called and no solution or payment is promised. The request expires from active discovery after seven days.",
        "list_bounty_comments" => "Use this when the user wants to read public comments on one voluntary community request. Comments are conversation context only.",
        "add_bounty_comment" => "Use this when the user explicitly wants to publish one bounded public comment on a voluntary community request. Do not include secrets or restricted personal data.",
        "create_share_bundle" => "Use this when the user wants a factual social caption and share image for a voluntary community request. Sharing is optional and creates no payment promise.",
        _ => fallback,
    }
}

fn chatgpt_tool_description(name: &str, fallback: &'static str) -> &'static str {
    match name {
        "get_bounty_feed" => "Use this when the model or mounted feed needs fresh structured bounty data without rendering another widget. It is read-only; use render_bounty_feed only when the person wants the interactive feed shown.",
        "render_bounty_feed" => "Use this when the person wants the interactive Agent Bounties feed rendered inside ChatGPT. For model-selected results, inspect get_bounty_feed first and pass only the chosen opportunity_ids.",
        "prepare_moonpay_onramp" => "Use this when a person funding one canonical Base bounty needs Base USDC. Prepare a first-party MoonPay handoff only; never request card data or identity documents in ChatGPT, never treat a MoonPay purchase as bounty funding, and require a separate canonical funding authorization.",
        "prepare_bounty_action" => "Use this when ChatGPT has gathered the required details conversationally and the person has explicitly confirmed a post, fund, solve or claim, complete, or verify action. Create one idempotent first-party authorization session; never request a wallet or verifier signature in ChatGPT and never describe prepared status as completion.",
        "get_bounty_action_status" => "Use this when the person returns from first-party authorization and the card needs canonical status. Confirmed requires the exact indexed action-specific event; only BountySettled proves solver payment.",
        "fund_bounty_with_x402" => "Use this when the person explicitly wants to fund one canonical Base bounty. Request the x402 challenge first, replay only with the exact wallet-signed authorization, and do not call a challenge, signature, relay, or transaction hash funding evidence.",
        "get_x402_relay_status" => "Use this when an earlier x402 funding response returned a relay_id that still needs canonical confirmation. Only a matching confirmed FundingAdded event changes funding state.",
        "prepare_agent_to_earn" => "Use this when the person has selected one funded claimable bounty and supplied a public Base wallet. Check wallet policy, bond, claimability, and verification readiness without requesting a secret or changing state.",
        "agent_native_claim" => "Use this when the person explicitly wants to solve one funded verification-ready bounty. Reuse one idempotency key, request at most the exact bounded wallet signature returned by the tool, and replay until BountyClaimed is confirmed.",
        "plan_autonomous_bounty_claim" => "Use this when the hosted claim relay is unavailable and the person wants the direct wallet fallback. It prepares bond-and-claim calls only; it does not claim the bounty.",
        "prepare_autonomous_bounty_submission" => "Use this when the active solver has completed a claimed bounty and wants to commit a public artifact and evidence. Preparation is not SubmissionAdded, verification, settlement, or payment.",
        "publish_autonomous_submission_evidence" => "Use this when confirmed SubmissionAdded exists and the solver wants to publish the exact artifact and evidence preimages matching the canonical commitments. This public write is not verification or payout proof.",
        "list_autonomous_verification_jobs" => "Use this when the person wants to verify submitted work. Return only indexed jobs whose committed verifier path is ready; do not invent a verifier mode or verdict.",
        "plan_autonomous_verification_attestation" => "Use this when a committed quorum verifier has evaluated the current indexed submission and needs the exact EIP-712 attestation payload. The plan and signature are not settlement evidence.",
        "plan_autonomous_module_settlement" => "Use this when the loaded verification job commits a deterministic module and the person wants its permissionless verifier transaction. A plan, broadcast, or transaction hash is not settlement or payment evidence.",
        "plan_autonomous_attestation_settlement" => "Use this when enough matching signatures from the precommitted verifier quorum are available and the person wants the permissionless settlement transaction. Only confirmed BountySettled proves solver payment.",
        "get_paid_status" => "Use this when the person asks whether a bounty solver was paid. Report paid language only for reconciled rail evidence; for autonomous-v1 this requires a matching confirmed BountySettled event.",
        "compile_objective_with_cloud_agent" => "Retired compatibility tool: returns hosted_generation_removed. Prepare the task plan in your own AI account.",
        "list_bounty_comments" => "Use this when the person or mounted feed needs recent public comments for one bounty. Comments are conversation context and never funding, verification, settlement, or payment evidence.",
        "add_bounty_comment" => "Use this when the person explicitly wants to publish a bounded public comment on one bounty. Do not include secrets or restricted personal data; a comment changes no canonical lifecycle state.",
        "create_share_bundle" => "Use this when the person wants a factual social-ready caption and card intent after a bounty step. Pass the selected projection's first-party bounty_image_url when available so the original approved image remains attached to the share package. Sharing is optional and changes no funding, claim, verification, settlement, or payment state.",
        "publish_unfunded_bounty" => "Use this when an authenticated person explicitly wants to publish their prepared voluntary request. Require their website account, wallet session, or operator credential and reuse one idempotency key. No model is called, no solution is generated, and no payment is promised.",
        "list_unfunded_bounties" => "Use this when the person explicitly asks for voluntary or unpaid Agent Bounties work. Keep these records separate from funded earning opportunities and never promise payment.",
        "submit_unfunded_bounty_solution" => "Use this when the authenticated caller owns the registered solver agent, controls its verified payout wallet, and explicitly wants to publish or replace its public solution to an open unfunded request. This public write creates no payment claim.",
        "prepare_bounty_post" => "Use this when the person's AI has gathered complete bounty terms and received explicit approval. Reuse posting_operation_id when resuming. For creator review, set review_mode=creator and the exact agreed delivery_deadline with timezone offset, omit automated benchmark/evidence fields, and explain that the creator confirms the verdict. Preserve parent bindings, the approved reference_attachment, and any approved bounty_image with its exact prompt and alt text; omit all three image fields together to use the deterministic review-page visual. This prepares a reviewable handoff; it does not publish, move funds, request a secret, or prove that a bounty exists.",
        "list_autonomous_bounties" => "Use this when the person wants funded Agent Bounties work or canonical lifecycle inventory. Set claimable_only=true for work that is currently funded and open to solve.",
        "inspect_open_competition_v2" => "New users start with operation=guide. Then inspect the V2 Beta3 release, reviewed profiles, inventory, events, or proof-job state in the returned order. Treat only CompetitionSettledV2 as payment evidence.",
        "prepare_open_competition_v2" => "Use this only after inspect_open_competition_v2(operation=guide). Match arguments to the selected operation's exact schema. Some operations return unsigned plans; quote_proof creates a hosted job, pay_proof may transfer Base USDC after explicit approval, and authorize_relay may submit a proof after explicit approval. Follow next_action and treat only CompetitionSettledV2 as payment evidence.",
        _ => fallback,
    }
}

fn tool_title(name: &str) -> &'static str {
    match name {
        "get_bounty_feed" => "Refresh bounty feed data",
        "render_bounty_feed" => "Open live bounty feed",
        "prepare_moonpay_onramp" => "Prepare MoonPay top-up",
        "prepare_bounty_action" => "Prepare secure bounty action",
        "get_bounty_action_status" => "Check canonical action status",
        "fund_bounty_with_x402" => "Request funding challenge",
        "get_x402_relay_status" => "Check funding relay",
        "prepare_agent_to_earn" => "Check claim readiness",
        "agent_native_claim" => "Solve bounty",
        "plan_autonomous_bounty_claim" => "Prepare claim path",
        "prepare_autonomous_bounty_submission" => "Prepare completion evidence",
        "publish_autonomous_submission_evidence" => "Publish completion evidence",
        "list_autonomous_verification_jobs" => "Load verification job",
        "plan_autonomous_verification_attestation" => "Prepare verification path",
        "plan_autonomous_module_settlement" => "Prepare deterministic verification",
        "plan_autonomous_attestation_settlement" => "Prepare quorum settlement",
        "get_paid_status" => "Check reconciled payout",
        "compile_objective_with_cloud_agent" => "Break objective into bounties",
        "list_bounty_comments" => "Read bounty comments",
        "add_bounty_comment" => "Comment on bounty",
        "create_share_bundle" => "Prepare share card",
        "publish_unfunded_bounty" => "Publish voluntary request",
        "list_unfunded_bounties" => "List unfunded bounties",
        "submit_unfunded_bounty_solution" => "Submit unfunded bounty solution",
        "prepare_bounty_post" => "Prepare bounty for wallet review",
        "list_autonomous_bounties" => "List canonical bounties",
        "inspect_open_competition_v2" => "Inspect V2 competition",
        "prepare_open_competition_v2" => "Prepare V2 action",
        _ => "Agent Bounties tool",
    }
}

fn bounded_text(value: &str, field: &str, max_chars: usize) -> Result<String, String> {
    let value = value.trim();
    let count = value.chars().count();
    if count == 0 {
        return Err(format!("{field} must not be empty"));
    }
    if count > max_chars {
        return Err(format!(
            "{field} must contain at most {max_chars} characters"
        ));
    }
    Ok(value.to_string())
}

fn bounded_public_key(
    value: &str,
    field: &str,
    minimum: usize,
    maximum: usize,
) -> Result<String, String> {
    let value = value.trim();
    let count = value.chars().count();
    if count < minimum
        || count > maximum
        || !value.chars().all(|character| {
            character.is_ascii_alphanumeric() || matches!(character, ':' | '.' | '_' | '-')
        })
    {
        return Err(format!(
            "{field} must contain {minimum}..{maximum} public identifier characters"
        ));
    }
    Ok(value.to_string())
}

fn bounded_opportunity_id(value: &str) -> Result<String, String> {
    let value = bounded_text(value, "bounty_id", 200)?;
    if !value.chars().all(|character| {
        character.is_ascii_alphanumeric() || matches!(character, ':' | '.' | '_' | '-')
    }) {
        return Err(
            "bounty_id must contain only public opportunity identifier characters".to_string(),
        );
    }
    Ok(value)
}

fn optional_https_url(value: Option<&str>, field: &str) -> Result<Option<String>, String> {
    let Some(value) = value.map(str::trim).filter(|value| !value.is_empty()) else {
        return Ok(None);
    };
    let parsed =
        Url::parse(value).map_err(|_| format!("{field} must be a valid public HTTPS URL"))?;
    if parsed.scheme() != "https" || parsed.host_str().is_none() {
        return Err(format!("{field} must be a valid public HTTPS URL"));
    }
    Ok(Some(parsed.to_string()))
}

fn parse_usdc(value: &str, field: &str) -> Result<u64, String> {
    let value = value.trim();
    let mut parts = value.split('.');
    let whole = parts
        .next()
        .filter(|value| !value.is_empty() && value.chars().all(|ch| ch.is_ascii_digit()))
        .ok_or_else(|| format!("{field} must be a positive USDC decimal with at most 6 places"))?;
    let fraction = parts.next().unwrap_or("");
    if parts.next().is_some()
        || fraction.len() > 6
        || !fraction.chars().all(|ch| ch.is_ascii_digit())
    {
        return Err(format!(
            "{field} must be a positive USDC decimal with at most 6 places"
        ));
    }
    let whole = whole
        .parse::<u64>()
        .map_err(|_| format!("{field} is too large"))?;
    if whole > 1_000_000 {
        return Err(format!("{field} must not exceed 1000000 USDC"));
    }
    let mut padded = fraction.to_string();
    padded.push_str(&"0".repeat(6 - padded.len()));
    let fraction = padded.parse::<u64>().unwrap_or(0);
    let amount = whole
        .checked_mul(1_000_000)
        .and_then(|amount| amount.checked_add(fraction))
        .ok_or_else(|| format!("{field} is too large"))?;
    if amount == 0 {
        return Err(format!("{field} must be greater than zero"));
    }
    Ok(amount)
}

fn format_usdc(amount: u64) -> String {
    let whole = amount / 1_000_000;
    let fraction = amount % 1_000_000;
    if fraction == 0 {
        return whole.to_string();
    }
    format!("{whole}.{fraction:06}")
        .trim_end_matches('0')
        .to_string()
}

fn json_rpc_error(id: Value, code: i64, message: &str) -> Value {
    json_rpc_error_with_data(id, code, message, None)
}

fn json_rpc_error_with_data(id: Value, code: i64, message: &str, data: Option<Value>) -> Value {
    let mut error = json!({"code": code, "message": message});
    if let Some(data) = data {
        error["data"] = data;
    }
    json!({
        "jsonrpc": "2.0",
        "id": id,
        "error": error
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use app::BountyNetwork;
    use chain_base::{AutonomousBountyRecoveryReservations, BaseRpcUrlConfig};
    use std::{
        collections::HashMap,
        sync::{Arc, Mutex},
    };

    fn valid_args() -> PrepareBountyPostArgs {
        PrepareBountyPostArgs {
            title: "Fix the reconciliation regression".to_string(),
            goal: "Make the committed regression test pass.".to_string(),
            acceptance_criteria: vec![
                "The committed test exits zero.".to_string(),
                "A regression test covers the prior failure.".to_string(),
            ],
            solver_reward_usdc: "2.00".to_string(),
            verifier_reward_usdc: "0.10".to_string(),
            source_url: Some("https://github.com/NSPG13/agent-bounties/issues/386".to_string()),
            crowdfund: false,
            task_window_days: None,
            review_mode: None,
            delivery_deadline: None,
            posting_operation_id: None,
            meta_child: None,
            reference_attachment: None,
            discovery_source: Some("ChatGPT user feedback".to_string()),
            benchmark: Some(json!({
                "engine": "sandboxed_regression_v1",
                "source": {
                    "kind": "github_commit",
                    "repository": "NSPG13/agent-bounties",
                    "commit": "fa946859a3379b8c9128183e20dedb3b8319a646",
                    "subdirectory": "benchmarks/direct-growth-v2/openhands-integration"
                },
                "runner_manifest": {
                    "schema_version": "agent-bounties/regression-sandbox-v1",
                    "image": "docker.io/library/python@sha256:d657ab0ade19f404a6ccc883ab399540de667aff751748ce23c07330c5a89e64",
                    "command": ["python", "/benchmark/check.py"],
                    "workdir": "/workspace",
                    "benchmark_digest": "sha256:30bb17e3e3916747144c7087f49fb1ce41ddaf1aec4d717f878d2840203895a2",
                    "timeout_seconds": 120,
                    "cpu_millis": 1000,
                    "memory_bytes": 536870912,
                    "pids_limit": 128,
                    "max_output_bytes": 1048576,
                    "tmpfs_bytes": 268435456,
                    "max_source_bytes": 67108864,
                    "max_source_files": 1000,
                    "max_benchmark_bytes": 1048576,
                    "max_benchmark_files": 100,
                    "platform": "linux/amd64",
                    "test_seed": 1
                }
            })),
            evidence_schema: Some(json!({
                "type": "object",
                "required": ["source_snapshot_digest"],
                "properties": {
                    "source_snapshot_digest": {
                        "type": "string",
                        "pattern": "^sha256:[0-9a-f]{64}$"
                    }
                },
                "additionalProperties": false
            })),
            image_prompt: Some(
                "Minimal editorial illustration of a reconciliation test becoming green."
                    .to_string(),
            ),
            image_alt_text: Some(
                "A clean code diff with a passing reconciliation check.".to_string(),
            ),
            bounty_image: Some(super::ChatgptFileInput {
                download_url: "https://files.oaiusercontent.com/example".to_string(),
                file_id: "file-example".to_string(),
                mime_type: Some("image/webp".to_string()),
                file_name: Some("reconciliation-bounty.webp".to_string()),
            }),
        }
    }

    #[test]
    fn internal_distribution_attribution_cannot_be_spoofed_by_mcp_clients() {
        let mut payload = json!({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/list",
            "params": {"_meta": {(INTERNAL_ATTRIBUTION_META): {
                "acquisition_token": "client-controlled",
                "first_touch_rail": "forged"
            }}}
        });
        set_internal_attribution(&mut payload, None);
        assert!(payload["params"]["_meta"]
            .get(INTERNAL_ATTRIBUTION_META)
            .is_none());

        let attribution = McpDistributionAttribution {
            acquisition_id: Uuid::nil(),
            acquisition_token: "aba1_test.signature".to_string(),
            first_touch_rail: "bankr".to_string(),
            current_rail: "cursor".to_string(),
            measurement_eligible: true,
        };
        set_internal_attribution(&mut payload, Some(&attribution));
        let observed = &payload["params"]["_meta"][INTERNAL_ATTRIBUTION_META];
        assert_eq!(observed["acquisition_id"], Uuid::nil().to_string());
        assert_eq!(observed["first_touch_rail"], "bankr");
        assert_eq!(observed["current_rail"], "cursor");
    }

    #[test]
    fn public_mcp_attribution_metadata_is_analytics_only() {
        let attribution = McpDistributionAttribution {
            acquisition_id: Uuid::new_v4(),
            acquisition_token: "aba1_test.signature".to_string(),
            first_touch_rail: "github".to_string(),
            current_rail: "github".to_string(),
            measurement_eligible: true,
        };
        let mut result = json!({"tools": []});
        attach_attribution_metadata(&mut result, &attribution);
        let metadata = &result["_meta"]["agentbounties.app/acquisition"];
        assert_eq!(metadata["authority"], "analytics_only");
        assert_eq!(metadata["request_header"], ACQUISITION_HEADER);
        assert_eq!(metadata["measurement_eligible"], true);
        assert!(metadata.get("acquisition_id").is_some());
        for forbidden in ["private_key", "wallet_signature", "payment_authority"] {
            assert!(metadata.get(forbidden).is_none());
        }
    }

    #[test]
    fn prepare_handoff_failure_fingerprint_is_stable_and_content_free() {
        let first = distribution_request_fingerprint(&json!({"title": "private task"}));
        let replay = distribution_request_fingerprint(&json!({"title": "private task"}));
        let changed = distribution_request_fingerprint(&json!({"title": "different task"}));
        assert_eq!(first, replay);
        assert_ne!(first, changed);
        assert_eq!(first.len(), 64);
        assert!(!first.contains("private"));
    }

    fn distribution_competition_fixture() -> Value {
        let api_body = json!({
            "state": "awaiting_wallet_calls",
            "plan": {
                "schema_version": "agent-bounties/open-competition-v2-creation-plan-v1",
                "protocol_version": "agent-bounties/open-competition-v2-beta3",
                "network": chain_base::base_network_descriptor("base-mainnet").unwrap(),
                "bounty_id": format!("0x{}", "2".repeat(64)),
                "predicted_competition": format!("0x{}", "3".repeat(40)),
                "funding_target": "2100000", "remaining_funding_after_creation": "0",
                "profitable_if_win": true, "public_inventory_eligible_after_confirmation": true,
                "wallet_calls": [{"from": format!("0x{}", "4".repeat(40)),
                    "to": format!("0x{}", "5".repeat(40)), "value_wei": 0,
                    "data": "0x", "function": "createCompetition(params,funding,nonce,risk)"}],
                "next_action": "Review unsigned calls", "evidence_boundary": "Unsigned preparation only"
            }
        });
        legacy_result(crate::mcp_json(json!({"http_status": 200, "body": api_body})).0).unwrap()
    }

    #[test]
    fn distribution_competition_binding_uses_the_validated_creation_call() {
        let attribution = McpDistributionAttribution {
            acquisition_id: Uuid::new_v4(),
            acquisition_token: "opaque".to_string(),
            first_touch_rail: "glama-paid".to_string(),
            current_rail: "cursor".to_string(),
            measurement_eligible: false,
        };
        let result = distribution_competition_fixture();
        let received_at = chrono::Utc::now();
        let binding = competition_preparation_binding(&result, &attribution).unwrap();
        assert!(binding.prepared_at >= received_at);
        assert_eq!(binding.acquisition_id, attribution.acquisition_id);
        assert_eq!(binding.network, "base-mainnet");
        for status in [json!(400), json!(503), Value::Null, json!("200")] {
            let mut invalid = result.clone();
            invalid["http_status"] = status;
            assert!(competition_preparation_binding(&invalid, &attribution).is_err());
        }
        assert_eq!(
            binding.creator_wallet,
            result["body"]["plan"]["wallet_calls"][0]["from"]
        );
        assert_eq!(
            binding.factory_contract,
            result["body"]["plan"]["wallet_calls"][0]["to"]
        );
        assert_eq!(
            binding.competition_contract,
            result["body"]["plan"]["predicted_competition"]
        );
        for (key, value) in [
            ("chain_id", json!(84532)),
            ("name", json!("unsupported-chain")),
        ] {
            let mut invalid = result.clone();
            invalid["body"]["plan"]["network"][key] = value;
            assert!(competition_preparation_binding(&invalid, &attribution).is_err());
        }
        for calls in [
            json!([]),
            json!([
                result["body"]["plan"]["wallet_calls"][0],
                result["body"]["plan"]["wallet_calls"][0]
            ]),
        ] {
            let mut invalid = result.clone();
            invalid["body"]["plan"]["wallet_calls"] = calls;
            assert!(competition_preparation_binding(&invalid, &attribution).is_err());
        }
    }

    #[test]
    fn distribution_competition_binding_normalizes_both_shared_network_descriptors() {
        let attribution = McpDistributionAttribution {
            acquisition_id: Uuid::new_v4(),
            acquisition_token: "opaque".to_string(),
            first_touch_rail: "mcp-so-paid".to_string(),
            current_rail: "mcp-so-paid".to_string(),
            measurement_eligible: false,
        };
        for network in ["base-mainnet", "base-sepolia"] {
            let descriptor = chain_base::base_network_descriptor(network).unwrap();
            let mut result = distribution_competition_fixture();
            result["body"]["plan"]["network"] = json!(descriptor);
            for name in [descriptor.name.as_str(), network] {
                result["body"]["plan"]["network"]["name"] = json!(name);
                let binding = competition_preparation_binding(&result, &attribution).unwrap();
                assert_eq!(binding.network, network);
            }
            result["body"]["plan"]["network"]["chain_id"] = json!(1);
            assert!(competition_preparation_binding(&result, &attribution).is_err());
        }
    }

    #[tokio::test]
    async fn distribution_competition_preparation_requires_durable_attribution() {
        let state = public_tool_test_state();
        let result = distribution_competition_fixture();
        let unchanged = attach_competition_preparation_attribution(&state, result.clone(), None)
            .await
            .unwrap();
        assert_eq!(unchanged, result);
        let attribution = McpDistributionAttribution {
            acquisition_id: Uuid::new_v4(),
            acquisition_token: "opaque".to_string(),
            first_touch_rail: "mcp-so-paid".to_string(),
            current_rail: "mcp-so-paid".to_string(),
            measurement_eligible: false,
        };
        assert!(
            attach_competition_preparation_attribution(&state, result, Some(&attribution))
                .await
                .unwrap_err()
                .contains("unavailable")
        );
    }

    #[tokio::test]
    async fn distribution_competition_reads_real_proxy_envelopes_after_response() {
        let api_body = distribution_competition_fixture()["body"].clone();
        let failed_body = api_body.clone();
        let router = axum::Router::new()
            .route(
                "/create",
                axum::routing::post(move || {
                    let mut body = api_body.clone();
                    async move {
                        tokio::time::sleep(std::time::Duration::from_millis(20)).await;
                        body["response_prepared_at"] = json!(chrono::Utc::now());
                        Json(body)
                    }
                }),
            )
            .route(
                "/unavailable",
                axum::routing::post(move || {
                    let body = failed_body.clone();
                    async move { (StatusCode::SERVICE_UNAVAILABLE, Json(body)) }
                }),
            );
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let socket = listener.local_addr().unwrap();
        let server = tokio::spawn(async move { axum::serve(listener, router).await.unwrap() });
        let attribution = McpDistributionAttribution {
            acquisition_id: Uuid::new_v4(),
            acquisition_token: "opaque".to_string(),
            first_touch_rail: "glama-paid".to_string(),
            current_rail: "glama-paid".to_string(),
            measurement_eligible: false,
        };
        for path in ["create", "unavailable"] {
            let proxied = crate::proxy_public_json_response_with_timeout(
                reqwest::Client::new().post(format!("http://{socket}/{path}")),
                "fixture API",
                5,
            )
            .await
            .0;
            let result = legacy_result(proxied).unwrap();
            let binding = competition_preparation_binding(&result, &attribution);
            if path == "create" {
                let response_time = chrono::DateTime::parse_from_rfc3339(
                    result["body"]["response_prepared_at"].as_str().unwrap(),
                )
                .unwrap();
                assert!(binding.unwrap().prepared_at >= response_time);
            } else {
                assert!(binding.unwrap_err().contains("HTTP status"));
            }
        }
        server.abort();
    }

    #[tokio::test]
    async fn attributed_mcp_rejects_unknown_canary_markers_before_processing() {
        let mut headers = HeaderMap::new();
        headers.insert(CANARY_HEADER, HeaderValue::from_static("unbounded-marker"));
        let response = attributed_mcp_post(
            Path("bankr".to_string()),
            State(public_tool_test_state()),
            headers,
            Json(json!({"jsonrpc": "2.0", "id": 1, "method": "tools/list"})),
        )
        .await;
        assert_eq!(response.status(), StatusCode::BAD_REQUEST);
    }

    #[test]
    fn handoff_is_prefilled_but_never_claims_creation_or_signature() {
        let args = valid_args();
        let image = sandbox_bounty_image_reference(&args).unwrap().unwrap();
        let handoff = build_bounty_post_handoff(&args, Some(&image)).unwrap();
        assert_eq!(
            handoff,
            build_bounty_post_handoff(&args, Some(&image)).unwrap()
        );
        let post_url = Url::parse(handoff["post_url"].as_str().unwrap()).unwrap();
        let pairs = post_url.query_pairs().collect::<Vec<_>>();

        assert_eq!(handoff["state"], "review_required_not_published");
        assert_eq!(handoff["target_usdc"], "2.1");
        assert_eq!(handoff["initial_funding_usdc"], "2.1");
        assert_eq!(handoff["bounty_created"], false);
        assert_eq!(handoff["wallet_signature_requested"], false);
        assert_eq!(handoff["benchmark"], *args.benchmark.as_ref().unwrap());
        assert_eq!(
            handoff["evidence_schema"],
            *args.evidence_schema.as_ref().unwrap()
        );
        assert_eq!(handoff["image"]["source"], "chatgpt_user_generated");
        assert!(pairs
            .iter()
            .any(|(key, value)| key == "from" && value == "ai-app"));
        assert!(pairs
            .iter()
            .any(|(key, value)| key == "title" && value == "Fix the reconciliation regression"));
        assert_eq!(
            pairs.iter().filter(|(key, _)| key == "criterion").count(),
            2
        );
        assert!(pairs.iter().any(|(key, value)| {
            key == "benchmark"
                && value.contains("benchmarks/direct-growth-v2/openhands-integration")
        }));
        assert!(pairs.iter().any(
            |(key, value)| key == "evidenceSchema" && value.contains("source_snapshot_digest")
        ));
    }

    #[test]
    fn creator_handoff_preserves_deadline_operation_reference_and_approved_image() {
        let mut args = valid_args();
        args.review_mode = Some("creator".to_string());
        let offset = chrono::FixedOffset::west_opt(6 * 3600).unwrap();
        let exact = (chrono::Utc::now() + chrono::Duration::days(2))
            .with_timezone(&offset)
            .to_rfc3339_opts(chrono::SecondsFormat::Secs, false);
        args.delivery_deadline = Some(exact.clone());
        args.benchmark = None;
        args.evidence_schema = None;
        args.posting_operation_id = Some(uuid::Uuid::new_v4());
        args.reference_attachment = Some(
            json!({"version":1, "kind":"homepage_background", "phase":"day", "variant":"desktop", "source_url":"https://agentbounties.app/", "asset_url":"https://raw.githubusercontent.com/NSPG13/agent-bounties/933c9c446a76d26f148a4f2defacf6453d02a7b2/site/assets/solarpunk/scene-day.webp", "sha256":"sha256:f9143ee70ca0551bc97562c89c96cc56b4a54391ab4034315148253b757fcaef", "mime_type":"image/webp", "byte_length":256228, "captured_at":chrono::Utc::now().to_rfc3339()}),
        );
        let image = sandbox_bounty_image_reference(&args).unwrap().unwrap();
        let handoff = build_bounty_post_handoff(&args, Some(&image)).unwrap();
        let replay = build_bounty_post_handoff(&args, Some(&image)).unwrap();
        assert_eq!(handoff, replay);
        let schema = post_handoff_output_schema();
        let properties = schema["properties"].as_object().unwrap();
        for key in handoff.as_object().unwrap().keys() {
            assert!(
                properties.contains_key(key),
                "undeclared handoff field {key}"
            );
        }
        for required in schema["required"].as_array().unwrap() {
            assert!(handoff.get(required.as_str().unwrap()).is_some());
        }
        assert_eq!(handoff["delivery_deadline"], exact);
        assert_eq!(handoff["review_mode"], "creator");
        assert_eq!(
            handoff["reference_attachment"],
            *args.reference_attachment.as_ref().unwrap()
        );
        assert_eq!(handoff["image"]["sha256"], image.sha256);
        let url = Url::parse(handoff["post_url"].as_str().unwrap()).unwrap();
        assert!(url
            .query_pairs()
            .any(|(key, value)| key == "deliveryDeadline" && value == exact));
        let original_reference = args.reference_attachment.clone();
        args.reference_attachment.as_mut().unwrap()["sha256"] = json!("sha256:invented");
        assert!(build_bounty_post_handoff(&args, Some(&image)).is_err());
        args.reference_attachment = original_reference;
        args.benchmark = Some(json!({"engine":"invented"}));
        assert!(build_bounty_post_handoff(&args, Some(&image)).is_err());
        args.benchmark = None;
        args.delivery_deadline = Some("2026-09-10T21:00:00".to_string());
        assert!(build_bounty_post_handoff(&args, Some(&image)).is_err());
        args.delivery_deadline = Some(exact);
        args.meta_child =
            Some(json!({"parent_bounty_contract":"0x1111111111111111111111111111111111111111"}));
        assert!(build_bounty_post_handoff(&args, Some(&image)).is_err());
    }

    #[test]
    fn parent_handoff_preserves_binding_without_asserting_qualification() {
        let mut args = valid_args();
        args.solver_reward_usdc = "0.98".to_string();
        args.verifier_reward_usdc = "0.02".to_string();
        args.meta_child = Some(
            json!({"parent_bounty_contract":"0x1111111111111111111111111111111111111111", "intended_child_solver":"0x2222222222222222222222222222222222222222"}),
        );
        let image = sandbox_bounty_image_reference(&args).unwrap().unwrap();
        let handoff = build_bounty_post_handoff(&args, Some(&image)).unwrap();
        assert_eq!(handoff["meta_child"], *args.meta_child.as_ref().unwrap());
        assert_eq!(handoff["bounty_created"], false);
        assert!(handoff["post_url"]
            .as_str()
            .unwrap()
            .contains("parentBounty="));
        args.review_mode = Some("automated".to_string());
        args.delivery_deadline = Some("2026-09-10T21:00:00-06:00".to_string());
        assert!(build_bounty_post_handoff(&args, Some(&image)).is_err());
    }

    #[test]
    fn verifier_handoff_rejects_incomplete_or_non_executable_inputs() {
        let mut glama_canary = valid_args();
        glama_canary.benchmark.as_mut().unwrap()["source"]["commit"] =
            json!(RECONCILED_GLAMA_CANARY_COMMIT);
        glama_canary.benchmark.as_mut().unwrap()["source"]["subdirectory"] =
            json!("benchmarks/distribution-v1/glama-onboarding-audit");
        glama_canary.benchmark.as_mut().unwrap()["runner_manifest"]["benchmark_digest"] =
            json!(RECONCILED_GLAMA_CANARY_DIGEST);
        let glama_image = sandbox_bounty_image_reference(&glama_canary)
            .unwrap()
            .unwrap();
        let glama_result = build_bounty_post_handoff(&glama_canary, Some(&glama_image));
        assert!(glama_result.is_ok(), "{glama_result:?}");
        for (field, value) in [
            ("commit", json!(RECONCILED_REGRESSION_BENCHMARK_COMMIT)),
            ("subdirectory", json!("benchmarks/copied-location")),
        ] {
            let mut altered = glama_canary.clone();
            altered.benchmark.as_mut().unwrap()["source"][field] = value;
            assert!(build_bounty_post_handoff(&altered, None)
                .unwrap_err()
                .contains("immutable source tuple"));
        }

        let mut args = valid_args();
        args.evidence_schema = None;
        assert!(build_bounty_post_handoff(&args, None)
            .unwrap_err()
            .contains("evidence_schema is required"));

        let mut args = valid_args();
        args.benchmark.as_mut().unwrap()["runner_manifest"]["image"] =
            json!("docker.io/library/python:latest");
        assert!(build_bounty_post_handoff(&args, None)
            .unwrap_err()
            .contains("image must be one lowercase OCI reference pinned by sha256 digest"));

        for image in [
            format!("docker.io/a@tag@sha256:{}", "b".repeat(64)),
            format!("docker.io/a..b@sha256:{}", "b".repeat(64)),
        ] {
            let mut args = valid_args();
            args.benchmark.as_mut().unwrap()["runner_manifest"]["image"] = json!(image);
            assert!(build_bounty_post_handoff(&args, None)
                .unwrap_err()
                .contains("image must be one lowercase OCI reference pinned by sha256 digest"));
        }

        let mut args = valid_args();
        args.verifier_reward_usdc = "0.009999".to_string();
        assert!(build_bounty_post_handoff(&args, None)
            .unwrap_err()
            .contains("at least 0.01 USDC"));

        let mut args = valid_args();
        args.evidence_schema = Some(json!({
            "type": "object",
            "additionalProperties": false
        }));
        assert!(build_bounty_post_handoff(&args, None)
            .unwrap_err()
            .contains("must include source_snapshot_digest"));

        let mut args = valid_args();
        args.benchmark.as_mut().unwrap()["source"]["repository"] = json!("other/copied-benchmark");
        args.benchmark.as_mut().unwrap()["source"]["subdirectory"] = json!("different/location");
        args.benchmark.as_mut().unwrap()["runner_manifest"]["benchmark_digest"] =
            json!(format!("sha256:{}", "d".repeat(64)));
        assert!(build_bounty_post_handoff(&args, None)
            .unwrap_err()
            .contains("independently reconciled"));

        for (field, value) in [
            ("repository", json!("other/repository")),
            ("commit", json!("b".repeat(40))),
            ("subdirectory", json!("benchmarks/copied-location")),
        ] {
            let mut args = valid_args();
            args.benchmark.as_mut().unwrap()["source"][field] = value;
            assert!(build_bounty_post_handoff(&args, None)
                .unwrap_err()
                .contains("immutable source tuple"));
        }
    }

    #[test]
    fn legacy_json_rpc_errors_are_not_successful_requests() {
        assert!(json_rpc_payload_succeeded(&json!({
            "jsonrpc": "2.0",
            "id": 1,
            "result": {"tools": []}
        })));
        assert!(!json_rpc_payload_succeeded(&json!({
            "jsonrpc": "2.0",
            "id": 1,
            "error": {"code": -32602, "message": "invalid arguments"}
        })));
        assert!(!json_rpc_payload_succeeded(&json!([
            {"jsonrpc": "2.0", "id": 1, "result": {}},
            {"jsonrpc": "2.0", "id": 2, "error": {"code": -32601, "message": "missing"}}
        ])));
        assert!(!json_rpc_payload_succeeded(&json!({
            "jsonrpc": "2.0",
            "id": 1,
            "result": {"content": [], "isError": true}
        })));
        assert!(!json_rpc_payload_succeeded(&json!([
            {"jsonrpc": "2.0", "id": 1, "result": {"content": [], "isError": false}},
            {"jsonrpc": "2.0", "id": 2, "result": {"content": [], "isError": true}}
        ])));
    }

    #[test]
    fn provider_neutral_handoff_allows_an_approved_bounty_without_an_image() {
        let mut args = valid_args();
        args.image_prompt = None;
        args.image_alt_text = None;
        args.bounty_image = None;

        assert!(sandbox_bounty_image_reference(&args).unwrap().is_none());
        let handoff = build_bounty_post_handoff(&args, None).unwrap();
        let post_url = Url::parse(handoff["post_url"].as_str().unwrap()).unwrap();
        let pairs = post_url.query_pairs().collect::<Vec<_>>();

        assert!(handoff["image"].is_null());
        assert_eq!(handoff["state"], "review_required_not_published");
        assert_eq!(handoff["bounty_created"], false);
        assert_eq!(handoff["wallet_signature_requested"], false);
        assert!(pairs
            .iter()
            .any(|(key, value)| key == "from" && value == "ai-app"));
        assert!(!pairs.iter().any(|(key, _)| key.starts_with("image")));
    }

    #[test]
    fn provider_neutral_handoff_rejects_partial_image_metadata() {
        let mut args = valid_args();
        args.bounty_image = None;
        assert!(sandbox_bounty_image_reference(&args)
            .unwrap_err()
            .contains("supplied together"));
    }

    #[test]
    fn production_runtime_has_one_full_product_profile() {
        assert!(!chatgpt_public_review_mode());
        assert_eq!(
            chatgpt_tool_names(false, chatgpt_public_review_mode()),
            CHATGPT_ADVERTISED_TOOL_NAMES
        );
        assert_eq!(
            chatgpt_tool_names(false, true),
            CHATGPT_ADVERTISED_TOOL_NAMES,
            "the removed public-review flag cannot reduce the product"
        );
        assert_eq!(CHATGPT_ADVERTISED_TOOL_NAMES.len(), 9);
        assert_eq!(
            CHATGPT_ADVERTISED_TOOL_NAMES,
            [
                "get_bounty_feed",
                "render_bounty_feed",
                "prepare_moonpay_onramp",
                "prepare_bounty_post",
                "prepare_bounty_action",
                "get_bounty_action_status",
                "list_bounty_comments",
                "add_bounty_comment",
                "create_share_bundle",
            ]
        );
        assert!(!CHATGPT_ADVERTISED_TOOL_NAMES.contains(&"list_autonomous_bounties"));
        assert_eq!(
            CHATGPT_COMPATIBILITY_TOOL_NAMES,
            ["list_autonomous_bounties"]
        );
    }

    #[test]
    fn moonpay_handoff_is_first_party_and_never_claims_purchase_or_funding() {
        let handoff = build_moonpay_onramp_handoff(
            &PrepareMoonpayOnrampArgs {
                bounty_contract: "0x1111111111111111111111111111111111111111".to_string(),
                amount_base_units: 3_500_000,
                intent_id: Some("00000000-0000-4000-8000-000000000002".to_string()),
            },
            false,
        )
        .unwrap();
        let onramp_url = Url::parse(handoff["onramp_url"].as_str().unwrap()).unwrap();
        assert_eq!(
            onramp_url.origin().ascii_serialization(),
            "https://agentbounties.app"
        );
        assert_eq!(onramp_url.path(), "/onramp.html");
        assert_eq!(handoff["provider"], "moonpay");
        assert_eq!(handoff["planned_amount_usdc"], "3.5");
        assert_eq!(handoff["checkout_created"], false);
        assert_eq!(handoff["purchase_completed"], false);
        assert_eq!(handoff["bounty_funded"], false);
        assert!(handoff["canonical_funding_event"].is_null());
        assert!(handoff["evidence_boundary"]
            .as_str()
            .unwrap()
            .contains("FundingAdded"));
    }

    #[test]
    fn handoff_rejects_non_https_sources_and_invalid_money() {
        let mut args = valid_args();
        let image = sandbox_bounty_image_reference(&args).unwrap().unwrap();
        args.source_url = Some("http://example.com/private".to_string());
        assert!(build_bounty_post_handoff(&args, Some(&image))
            .unwrap_err()
            .contains("HTTPS"));

        args.source_url = None;
        args.solver_reward_usdc = "0".to_string();
        assert!(build_bounty_post_handoff(&args, Some(&image))
            .unwrap_err()
            .contains("greater than zero"));

        args.solver_reward_usdc = "1.999999".to_string();
        assert!(build_bounty_post_handoff(&args, Some(&image))
            .unwrap_err()
            .contains("at least 2 USDC"));
    }

    #[test]
    fn chatgpt_image_downloads_are_host_and_magic_bounded() {
        for allowed in [
            "https://files.oaiusercontent.com/file.png?sig=opaque",
            "https://chatgpt.com/backend-api/files/example",
            "https://files.openai.com/example",
        ] {
            assert!(
                validate_chatgpt_download_url(allowed).is_ok(),
                "expected allowed ChatGPT file URL: {allowed}"
            );
        }
        for rejected in [
            "http://files.oaiusercontent.com/file.png",
            "https://openai.com.evil.example/file.png",
            "https://user:password@files.openai.com/file.png",
            "https://127.0.0.1/file.png",
            "https://example.com/file.png",
        ] {
            assert!(
                validate_chatgpt_download_url(rejected).is_err(),
                "expected rejected ChatGPT file URL: {rejected}"
            );
        }
        assert_eq!(
            detect_bounty_image_mime(b"\x89PNG\r\n\x1a\npayload"),
            Some("image/png")
        );
        assert_eq!(
            detect_bounty_image_mime(b"\xff\xd8\xffpayload"),
            Some("image/jpeg")
        );
        assert_eq!(
            detect_bounty_image_mime(b"RIFF\x00\x00\x00\x00WEBPpayload"),
            Some("image/webp")
        );
        assert_eq!(detect_bounty_image_mime(b"<svg></svg>"), None);
    }

    #[test]
    fn public_resource_catalog_exposes_only_the_live_feed_widget() {
        let descriptor = feed_widget_resource_descriptor();
        assert_eq!(descriptor["uri"], FEED_WIDGET_URI);
        assert_eq!(
            read_resource(&json!({"uri": FEED_WIDGET_URI})).unwrap()["contents"][0]["uri"],
            FEED_WIDGET_URI
        );
        assert_eq!(
            chatgpt_widget_domain_from_value(Some("https://community-mcp.example/path")),
            "https://community-mcp.example"
        );
        assert_eq!(
            chatgpt_widget_domain_from_value(Some("https://user:secret@example.com")),
            "https://mcp.agentbounties.app"
        );
    }

    #[tokio::test]
    async fn app_tools_have_required_annotations_and_widget_metadata() {
        let tools = mcp_tools_for_catalog(McpCatalogProfile::Chatgpt).await;
        for tool in &tools {
            assert!(
                tool["description"]
                    .as_str()
                    .is_some_and(|description| description.starts_with("Use this when")),
                "{} must tell ChatGPT when to choose it",
                tool["name"]
            );
            assert_eq!(
                tool["_meta"]["ui"]["visibility"],
                json!(["model", "app"]),
                "{} must be callable by the model and mounted widget",
                tool["name"]
            );
            assert_eq!(
                tool["outputSchema"]["type"], "object",
                "{} must declare its structured output contract",
                tool["name"]
            );
            if tool["name"] == "render_bounty_feed" {
                assert_eq!(tool["_meta"]["ui"]["resourceUri"], FEED_WIDGET_URI);
                assert_eq!(tool["_meta"]["openai/outputTemplate"], FEED_WIDGET_URI);
            } else {
                assert!(tool["_meta"]["ui"].get("resourceUri").is_none());
                assert!(tool["_meta"].get("openai/outputTemplate").is_none());
            }
        }
        let prepare = tools
            .iter()
            .find(|tool| tool["name"] == "prepare_bounty_action")
            .expect("hosted action preparation tool");
        let status = tools
            .iter()
            .find(|tool| tool["name"] == "get_bounty_action_status")
            .expect("canonical action status tool");
        assert_eq!(prepare["annotations"]["readOnlyHint"], false);
        assert_eq!(prepare["annotations"]["destructiveHint"], false);
        assert_eq!(prepare["annotations"]["openWorldHint"], false);
        assert_eq!(prepare["annotations"]["idempotentHint"], true);
        assert_eq!(
            prepare["outputSchema"]["properties"]["status"]["enum"],
            json!([
                "review_required",
                "pending_confirmation",
                "confirmed",
                "failed",
                "expired"
            ])
        );
        assert!(prepare["description"]
            .as_str()
            .unwrap()
            .starts_with("Use this when"));
        assert_eq!(status["annotations"]["readOnlyHint"], false);
        assert_eq!(status["annotations"]["destructiveHint"], false);
        assert_eq!(status["annotations"]["openWorldHint"], false);
        assert_eq!(status["annotations"]["idempotentHint"], true);

        let feed = tools
            .iter()
            .find(|tool| tool["name"] == "get_bounty_feed")
            .expect("feed tool");
        assert_eq!(feed["annotations"]["readOnlyHint"], true);
        assert!(feed["_meta"]["ui"].get("resourceUri").is_none());

        let render_feed = tools
            .iter()
            .find(|tool| tool["name"] == "render_bounty_feed")
            .expect("render feed tool");
        assert_eq!(render_feed["annotations"]["readOnlyHint"], true);
        assert_eq!(render_feed["_meta"]["ui"]["resourceUri"], FEED_WIDGET_URI);
        assert_eq!(
            render_feed["_meta"]["openai/outputTemplate"],
            FEED_WIDGET_URI
        );
        assert_eq!(
            render_feed["_meta"]["ui"]["visibility"],
            json!(["model", "app"])
        );
        assert_eq!(
            render_feed["outputSchema"]["required"],
            json!([
                "schema_version",
                "generated_at",
                "network",
                "items",
                "degraded",
                "evidence_boundary"
            ])
        );

        for name in [
            "prepare_bounty_action",
            "get_bounty_action_status",
            "list_bounty_comments",
            "add_bounty_comment",
            "create_share_bundle",
            "prepare_bounty_post",
        ] {
            assert!(
                tools.iter().any(|tool| tool["name"] == name),
                "missing public ChatGPT app tool: {name}"
            );
        }
        assert!(tools
            .iter()
            .all(|tool| tool["name"] != "list_autonomous_bounties"));
        for forbidden in [
            "fund_bounty_with_x402",
            "agent_native_claim",
            "plan_autonomous_bounty_claim",
            "prepare_autonomous_bounty_submission",
            "plan_autonomous_module_settlement",
            "plan_autonomous_attestation_settlement",
        ] {
            assert!(
                tools.iter().all(|tool| tool["name"] != forbidden),
                "direct wallet or settlement tool leaked into the public ChatGPT surface: {forbidden}"
            );
        }

        let comment = tools
            .iter()
            .find(|tool| tool["name"] == "add_bounty_comment")
            .expect("comment tool");
        assert_eq!(comment["annotations"]["readOnlyHint"], false);
        assert_eq!(comment["annotations"]["destructiveHint"], true);
        assert_eq!(comment["annotations"]["idempotentHint"], false);

        let post = tools
            .iter()
            .find(|tool| tool["name"] == "prepare_bounty_post")
            .expect("ChatGPT-account image handoff tool");
        assert_eq!(post["_meta"]["openai/fileParams"], json!(["bounty_image"]));
        assert!(post["_meta"]["ui"].get("resourceUri").is_none());
        assert!(!post["inputSchema"]["required"]
            .as_array()
            .unwrap()
            .iter()
            .any(|field| field == "bounty_image"));
        assert!(post["outputSchema"]["properties"]["image"]["anyOf"]
            .as_array()
            .unwrap()
            .iter()
            .any(|variant| variant["type"] == "null"));
    }

    #[test]
    fn optional_analytics_oauth_keeps_public_tools_anonymous() {
        assert_eq!(
            analytics_security_schemes(false),
            json!([{"type": "noauth"}])
        );
        assert_eq!(
            analytics_security_schemes(true),
            json!([
                {"type": "noauth"},
                {"type": "oauth2", "scopes": ["analytics:exclude-owner"]}
            ])
        );
    }

    fn public_tool_test_state() -> SharedState {
        Arc::new(AppState {
            network: Mutex::new(BountyNetwork::default()),
            eval_runs: Mutex::new(Vec::new()),
            base_rpc_urls: BaseRpcUrlConfig::default(),
            base_broadcast_enabled: false,
            stripe_secret_key: None,
            stripe_live_execution_enabled: false,
            stripe_api_base_url: "https://api.stripe.com".to_string(),
            stripe_payment_method_configuration: None,
            operator_api_token: None,
            analytics_exclusion_token: None,
            distribution_attribution_signing_secret: None,
            mcp_base_url: "http://127.0.0.1:8090".to_string(),
            oauth_authorizations: Mutex::new(HashMap::new()),
            oauth_codes: Mutex::new(HashMap::new()),
            store: None,
            recovery_reservations: AutonomousBountyRecoveryReservations::default(),
        })
    }

    #[tokio::test]
    async fn retired_generation_tools_return_permanent_errors_before_argument_validation() {
        for name in [
            "draft_bounty_with_cloud_agent",
            "compile_objective_with_cloud_agent",
            "analyze_bounty_fit",
        ] {
            let result = call_tool(
                public_tool_test_state(),
                HeaderMap::new(),
                &json!({"name": name, "arguments": "invalid legacy arguments"}),
                None,
            )
            .await
            .unwrap();
            assert_eq!(result["isError"], true);
            assert_eq!(result["structuredContent"]["http_status"], 410);
            assert_eq!(
                result["structuredContent"]["error_code"],
                "hosted_generation_removed"
            );
            assert_eq!(result["structuredContent"]["retryable"], false);
        }
    }

    fn modern_request(
        method: &'static str,
        mut params: Value,
        name: Option<&str>,
    ) -> (HeaderMap, Value) {
        params["_meta"] = json!({
            (MCP_PROTOCOL_VERSION_META): MCP_PROTOCOL_VERSION,
            (MCP_CLIENT_INFO_META): {
                "name": "agent-bounties-protocol-test",
                "version": "1.0.0"
            },
            (MCP_CLIENT_CAPABILITIES_META): {}
        });
        let mut headers = HeaderMap::new();
        headers.insert(
            MCP_PROTOCOL_VERSION_HEADER,
            MCP_PROTOCOL_VERSION.parse().unwrap(),
        );
        headers.insert(MCP_METHOD_HEADER, method.parse().unwrap());
        if let Some(name) = name {
            headers.insert(MCP_NAME_HEADER, name.parse().unwrap());
        }
        (
            headers,
            json!({
                "jsonrpc": "2.0",
                "id": "protocol-test",
                "method": method,
                "params": params
            }),
        )
    }

    #[tokio::test]
    async fn modern_discovery_is_stateless_typed_and_cacheable() {
        let (headers, request) = modern_request("server/discover", json!({}), None);
        assert_eq!(mcp_protocol_era(&headers, &request), McpProtocolEra::Modern);
        validate_modern_request(&headers, &request).unwrap();

        let (status, response) = handle_request(
            public_tool_test_state(),
            HeaderMap::new(),
            request,
            McpProtocolEra::Modern,
            McpCatalogProfile::Core,
        )
        .await
        .unwrap();
        let result = &response["result"];
        assert_eq!(status, StatusCode::OK);
        assert_eq!(result["supportedVersions"], json!([MCP_PROTOCOL_VERSION]));
        assert_eq!(result["resultType"], "complete");
        assert_eq!(result["ttlMs"], MCP_CATALOG_TTL_MS);
        assert_eq!(result["cacheScope"], "public");
        assert_eq!(
            result["_meta"][MCP_SERVER_INFO_META]["version"],
            env!("CARGO_PKG_VERSION")
        );
        assert_eq!(result["capabilities"]["tools"]["listChanged"], false);
        assert_eq!(result["capabilities"]["resources"]["subscribe"], false);
        assert!(result.get("protocolVersion").is_none());
    }

    #[tokio::test]
    async fn modern_tool_catalog_is_deterministic_typed_and_cacheable() {
        let (headers, request) = modern_request("tools/list", json!({}), None);
        validate_modern_request(&headers, &request).unwrap();
        let (_, response) = handle_request(
            public_tool_test_state(),
            HeaderMap::new(),
            request,
            McpProtocolEra::Modern,
            McpCatalogProfile::Core,
        )
        .await
        .unwrap();
        let result = &response["result"];
        let names = result["tools"]
            .as_array()
            .unwrap()
            .iter()
            .map(|tool| tool["name"].as_str().unwrap())
            .collect::<Vec<_>>();
        let mut sorted_names = names.clone();
        sorted_names.sort_unstable();

        assert_eq!(names, sorted_names);
        assert_eq!(result["resultType"], "complete");
        assert_eq!(result["ttlMs"], MCP_CATALOG_TTL_MS);
        assert_eq!(result["cacheScope"], "public");
        assert!(result["_meta"][MCP_SERVER_INFO_META].is_object());
        assert!(names.contains(&"list_autonomous_bounties"));
    }

    #[test]
    fn open_competition_v2_inspection_publishes_exact_operation_schemas() {
        let schema = OpenCompetitionV2InspectArgs::input_schema();
        let branches = schema["oneOf"].as_array().unwrap();
        let operations = branches
            .iter()
            .map(|branch| branch["properties"]["operation"]["const"].as_str().unwrap())
            .collect::<Vec<_>>();
        assert_eq!(
            operations,
            [
                "guide",
                "release",
                "profiles",
                "inventory",
                "events",
                "proof_job"
            ]
        );
        for branch in branches {
            assert_eq!(branch["additionalProperties"], false);
        }
        let proof_job = branches
            .iter()
            .find(|branch| branch["properties"]["operation"]["const"] == "proof_job")
            .unwrap();
        assert_eq!(proof_job["properties"]["job_id"]["format"], "uuid");
        assert!(proof_job["required"]
            .as_array()
            .unwrap()
            .contains(&json!("job_id")));
        let events = branches
            .iter()
            .find(|branch| branch["properties"]["operation"]["const"] == "events")
            .unwrap();
        assert_eq!(
            events["properties"]["bounty_id"]["pattern"],
            "^0x[0-9a-fA-F]{64}$"
        );
    }

    #[test]
    fn open_competition_v2_mutations_publish_exact_operation_schemas() {
        let schema = OpenCompetitionV2MutationArgs::input_schema();
        let expected = [
            "prepare_profile",
            "prepare_policies",
            "validate",
            "create",
            "fund",
            "quote_proof",
            "pay_proof",
            "prepare_proof",
            "authorize_relay",
            "prepare_action",
        ];
        assert_eq!(schema["properties"]["operation"]["enum"], json!(expected));
        assert_eq!(schema["allOf"].as_array().unwrap().len(), expected.len());
        for operation in expected {
            let rule = schema["allOf"]
                .as_array()
                .unwrap()
                .iter()
                .find(|rule| rule["if"]["properties"]["operation"]["const"] == operation)
                .unwrap_or_else(|| panic!("missing conditional schema for {operation}"));
            assert_eq!(
                rule["then"]["properties"]["arguments"]["$ref"],
                format!("#/$defs/{operation}")
            );
            if operation != "prepare_profile" {
                assert_eq!(schema["$defs"][operation]["additionalProperties"], false);
            }
        }
        assert_eq!(
            schema["$defs"]["prepare_profile"]["oneOf"]
                .as_array()
                .unwrap()
                .len(),
            2
        );
        assert_eq!(
            schema["$defs"]["prepare_profile"]["oneOf"][0]["properties"]["profile_id"]["const"],
            "structured-artifact-metric-v1"
        );
        assert_eq!(
            schema["$defs"]["prepare_profile"]["oneOf"][1]["properties"]["profile_id"]["const"],
            "public-vector-metric-v1"
        );
        assert_eq!(
            schema["$defs"]["prepare_action"]["properties"]["action"]["enum"],
            json!([
                "finalize_best_score",
                "cancel_funding",
                "expire_competition",
                "cancel_unavailable_verifier",
                "withdraw_refund_for"
            ])
        );
        assert!(
            schema["$defs"]["pay_proof"]["properties"]["payment_signature"]["description"]
                .as_str()
                .unwrap()
                .contains("explicit approval")
        );
        assert!(
            schema["$defs"]["authorize_relay"]["properties"]["solver_signature"]["description"]
                .as_str()
                .unwrap()
                .contains("explicit approval")
        );
    }

    #[tokio::test]
    async fn open_competition_v2_guide_covers_complete_safe_role_flows() {
        let response = inspect_open_competition_v2(
            State(public_tool_test_state()),
            Json(OpenCompetitionV2InspectArgs {
                operation: "guide".to_string(),
                network: None,
                state: None,
                bounty_id: None,
                job_id: None,
            }),
        )
        .await
        .0;
        let guide = response.pointer("/content/0/json").unwrap();
        assert_eq!(
            guide["schema_version"],
            "agent-bounties/open-competition-v2-mcp-guide-v1"
        );
        assert_eq!(guide["flows"]["post"].as_array().unwrap().len(), 8);
        assert_eq!(guide["flows"]["earn_hosted"].as_array().unwrap().len(), 6);
        assert_eq!(
            guide["flows"]["earn_byo_proof"].as_array().unwrap().len(),
            3
        );
        assert_eq!(guide["operations"].as_array().unwrap().len(), 10);
        let encoded = serde_json::to_string(guide).unwrap();
        for required in [
            "activation_state=public_beta",
            "quote_proof",
            "pay_proof",
            "payment_pending",
            "authorize_relay",
            "prepare_proof",
            "prepare_action",
            "prepare_policies",
            "structured-artifact-metric-v1",
            "public-vector-metric-v1",
            "CompetitionSettledV2",
            "private key",
        ] {
            assert!(encoded.contains(required), "guide omitted {required}");
        }
    }

    #[tokio::test]
    async fn open_competition_v2_prepares_public_vector_policy_exactly() {
        let response = prepare_open_competition_v2(
            State(public_tool_test_state()),
            Json(OpenCompetitionV2MutationArgs {
                operation: "prepare_profile".to_string(),
                arguments: json!({
                    "profile_id": "public-vector-metric-v1",
                    "network": "base-sepolia",
                    "mode": "minimize_absolute_error",
                    "threshold": "4",
                    "vectors": [
                        {"expected": 2, "weight": 3},
                        {"expected": 5, "weight": 2}
                    ]
                }),
            }),
        )
        .await
        .0;
        let profile = response.pointer("/content/0/json").unwrap();
        assert_eq!(
            profile["schema_version"],
            "agent-bounties/open-competition-v2-public-vector-profile-v1"
        );
        assert_eq!(
            profile["verification_policy_hash"],
            "0xc1e5661ee1066b8bf3699a878abf6f42d6ea175a2e80297e859e75b4ded7e2ff"
        );
        assert_eq!(profile["score_direction"], "lower_is_better");
        assert_eq!(profile["score_threshold"], "4");
    }

    #[tokio::test]
    async fn open_competition_v2_prepares_creation_commitments_exactly() {
        let response = prepare_open_competition_v2(
            State(public_tool_test_state()),
            Json(OpenCompetitionV2MutationArgs {
                operation: "prepare_policies".to_string(),
                arguments: json!({
                    "execution_policy": {"z": 2, "a": 1},
                    "settlement_policy": {
                        "winner_mode": "first_proven",
                        "payment_evidence": "CompetitionSettledV2"
                    },
                    "creation_nonce_seed": "creator-0xabc-task-42"
                }),
            }),
        )
        .await
        .0;
        let commitments = response.pointer("/content/0/json").unwrap();
        assert_eq!(
            commitments["execution_policy_hash"],
            "0x987da4b00590a3ba6bd86b025d9690e8c237fc0082c2265b7cef327408f71873"
        );
        assert_eq!(
            commitments["settlement_policy_hash"],
            "0xb887721b560948c99801f075508a0ab6131aac0f227ff4593cc8f82d2d87e7f3"
        );
        assert_eq!(
            commitments["creation_nonce"],
            "0x2b5e810153724cd493cec8a5c3e2280afedc99a54d78c5928be010837d69e133"
        );
    }

    #[tokio::test]
    async fn open_competition_v2_mutation_annotations_match_real_side_effects() {
        let tools = mcp_tools_for_catalog(McpCatalogProfile::Core).await;
        let descriptor = tools
            .iter()
            .find(|tool| tool["name"] == "prepare_open_competition_v2")
            .unwrap();
        assert_eq!(
            descriptor["annotations"],
            json!({
                "readOnlyHint": false,
                "destructiveHint": true,
                "openWorldHint": true,
                "idempotentHint": false
            })
        );
        assert!(descriptor["description"]
            .as_str()
            .unwrap()
            .contains("may transfer Base USDC"));
    }

    fn normalized_public_catalog_contract(mut descriptors: Vec<Value>) -> Value {
        descriptors.sort_by(|left, right| left["name"].as_str().cmp(&right["name"].as_str()));
        for descriptor in &mut descriptors {
            descriptor["securitySchemes"] = json!("deployment-configured");
            descriptor["_meta"]["securitySchemes"] = json!("deployment-configured");
        }
        Value::Array(descriptors)
    }

    // Explicit, read-only fixture regeneration aid; it never updates the approved
    // fixtures or relaxes the contract assertions below.
    #[tokio::test]
    #[ignore = "prints candidate digests for an intentional reviewed MCP contract change"]
    async fn print_reviewed_mcp_catalog_digests() {
        let mut digests = serde_json::Map::new();
        for (profile, key) in [
            (McpCatalogProfile::Chatgpt, "chatgpt"),
            (McpCatalogProfile::Core, "core"),
        ] {
            let contract = normalized_public_catalog_contract(mcp_tools_for_catalog(profile).await);
            digests.insert(
                key.to_string(),
                json!(app::hash_artifact(
                    &serde_json::to_string(&contract).unwrap()
                )),
            );
        }
        digests.insert(
            "advanced_http".to_string(),
            json!(app::hash_artifact(
                &serde_json::to_string(&tools().await.0).unwrap()
            )),
        );
        println!("{}", serde_json::to_string_pretty(&digests).unwrap());
    }

    #[tokio::test]
    async fn published_mcp_catalogs_match_the_reviewed_contract() {
        let fixture: Value =
            serde_json::from_str(include_str!("../fixtures/public-mcp-contract-v1.json"))
                .expect("public MCP contract fixture is valid JSON");
        assert_eq!(
            fixture["schema_version"],
            "agent-bounties/public-mcp-contract-v1"
        );

        for (profile, key) in [
            (McpCatalogProfile::Chatgpt, "chatgpt"),
            (McpCatalogProfile::Core, "core"),
        ] {
            let contract = normalized_public_catalog_contract(mcp_tools_for_catalog(profile).await);
            let names = contract
                .as_array()
                .expect("normalized catalog is an array")
                .iter()
                .map(|descriptor| descriptor["name"].as_str().unwrap())
                .collect::<Vec<_>>();
            let expected = &fixture["catalogs"][key];
            assert_eq!(
                names.len(),
                expected["tool_count"].as_u64().unwrap() as usize
            );
            assert_eq!(
                names,
                expected["tools"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .map(|name| name.as_str().unwrap())
                    .collect::<Vec<_>>()
            );

            let digest = app::hash_artifact(&serde_json::to_string(&contract).unwrap());
            assert_eq!(
                digest,
                expected["normalized_descriptors_sha256"]
                    .as_str()
                    .unwrap(),
                "{key} public MCP descriptor contract drifted; update the fixture and public documentation only for an intentional reviewed change"
            );
        }
    }

    #[tokio::test]
    async fn chatgpt_catalog_is_exactly_nine_while_core_eras_keep_compatibility() {
        let (_, modern_request) = modern_request("tools/list", json!({}), None);
        let (_, modern_chatgpt) = handle_request(
            public_tool_test_state(),
            HeaderMap::new(),
            modern_request.clone(),
            McpProtocolEra::Modern,
            McpCatalogProfile::Chatgpt,
        )
        .await
        .unwrap();
        let chatgpt_names = modern_chatgpt["result"]["tools"]
            .as_array()
            .unwrap()
            .iter()
            .map(|tool| tool["name"].as_str().unwrap())
            .collect::<Vec<_>>();
        assert_eq!(chatgpt_names.len(), 9);
        assert!(chatgpt_names
            .iter()
            .all(|name| CHATGPT_ADVERTISED_TOOL_NAMES.contains(name)));
        assert!(!chatgpt_names.contains(&"list_autonomous_bounties"));

        for era in [McpProtocolEra::Modern, McpProtocolEra::Legacy] {
            let (_, response) = handle_request(
                public_tool_test_state(),
                HeaderMap::new(),
                modern_request.clone(),
                era,
                McpCatalogProfile::Core,
            )
            .await
            .unwrap();
            let names = response["result"]["tools"]
                .as_array()
                .unwrap()
                .iter()
                .map(|tool| tool["name"].as_str().unwrap())
                .collect::<Vec<_>>();
            assert!(names.contains(&"list_autonomous_bounties"), "{era:?}");
        }
    }

    #[test]
    fn exact_chatgpt_metadata_selects_only_the_app_catalog() {
        for origin in ["https://chatgpt.com", "https://chat.openai.com"] {
            let mut headers = HeaderMap::new();
            headers.insert(ORIGIN, origin.parse().unwrap());
            assert_eq!(
                mcp_catalog_profile(&headers, &json!({})),
                McpCatalogProfile::Chatgpt
            );
        }
        assert_eq!(
            mcp_catalog_profile(&HeaderMap::new(), &json!({})),
            McpCatalogProfile::Core
        );
        let mut headers = HeaderMap::new();
        headers.insert(ORIGIN, "https://chatgpt.com.evil.example".parse().unwrap());
        assert_eq!(
            mcp_catalog_profile(&headers, &json!({})),
            McpCatalogProfile::Core
        );

        let (_, openai_request) = modern_request("tools/list", json!({}), None);
        let mut openai_request = openai_request;
        openai_request["params"]["_meta"][MCP_CLIENT_INFO_META]["name"] = json!("openai-mcp");
        assert_eq!(
            mcp_catalog_profile(&HeaderMap::new(), &openai_request),
            McpCatalogProfile::Chatgpt
        );
        openai_request["params"]["_meta"][MCP_CLIENT_INFO_META]["name"] =
            json!("openai-mcp-lookalike");
        assert_eq!(
            mcp_catalog_profile(&HeaderMap::new(), &openai_request),
            McpCatalogProfile::Core
        );
    }

    #[test]
    fn modern_headers_must_match_the_request_body() {
        let (mut headers, request) = modern_request("tools/list", json!({}), None);
        headers.insert(MCP_METHOD_HEADER, "resources/list".parse().unwrap());
        let error = validate_modern_request(&headers, &request).unwrap_err();
        assert_eq!(error.status, StatusCode::BAD_REQUEST);
        assert_eq!(error.code, -32020);

        let (mut headers, mut request) = modern_request("tools/list", json!({}), None);
        headers.insert(MCP_PROTOCOL_VERSION_HEADER, "2099-01-01".parse().unwrap());
        request["params"]["_meta"][MCP_PROTOCOL_VERSION_META] = json!("2099-01-01");
        let error = validate_modern_request(&headers, &request).unwrap_err();
        assert_eq!(error.code, -32022);
        assert_eq!(
            error.data.unwrap()["supported"],
            json!([MCP_PROTOCOL_VERSION])
        );
    }

    #[test]
    fn modern_name_header_supports_the_required_base64_sentinel() {
        let resource_uri = "ui://agent-bounties/世界.html";
        let encoded = format!(
            "=?base64?{}?=",
            base64::engine::general_purpose::STANDARD.encode(resource_uri)
        );
        let (mut headers, request) =
            modern_request("resources/read", json!({"uri": resource_uri}), None);
        headers.insert(MCP_NAME_HEADER, encoded.parse().unwrap());

        validate_modern_request(&headers, &request).unwrap();
        assert_eq!(decode_mcp_header_value(&encoded).unwrap(), resource_uri);
        assert_eq!(decode_mcp_header_value("ordinary?=").unwrap(), "ordinary?=");
        assert!(decode_mcp_header_value("=?base64?not-valid?=").is_err());
    }

    #[tokio::test]
    async fn legacy_initialize_remains_available_without_modern_metadata() {
        let request = json!({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {"protocolVersion": MCP_LEGACY_PROTOCOL_VERSION}
        });
        assert_eq!(
            mcp_protocol_era(&HeaderMap::new(), &request),
            McpProtocolEra::Legacy
        );
        let (status, response) = handle_request(
            public_tool_test_state(),
            HeaderMap::new(),
            request,
            McpProtocolEra::Legacy,
            McpCatalogProfile::Core,
        )
        .await
        .unwrap();
        assert_eq!(status, StatusCode::OK);
        assert_eq!(
            response["result"]["protocolVersion"],
            MCP_LEGACY_PROTOCOL_VERSION
        );
        assert!(response["result"].get("resultType").is_none());

        let mut legacy_headers = HeaderMap::new();
        legacy_headers.insert(
            MCP_PROTOCOL_VERSION_HEADER,
            MCP_LEGACY_PROTOCOL_VERSION.parse().unwrap(),
        );
        assert_eq!(
            mcp_protocol_era(
                &legacy_headers,
                &json!({"method": "tools/list", "params": {}})
            ),
            McpProtocolEra::Legacy
        );
        legacy_headers.insert(MCP_PROTOCOL_VERSION_HEADER, "2099-01-01".parse().unwrap());
        assert_eq!(
            mcp_protocol_era(
                &legacy_headers,
                &json!({"method": "tools/list", "params": {}})
            ),
            McpProtocolEra::Modern
        );
    }

    #[tokio::test]
    async fn legacy_initialize_selects_exact_supported_versions_and_falls_back_otherwise() {
        let supported = ["2024-11-05", "2025-03-26", "2025-06-18"];
        for version in supported {
            let request = json!({
                "jsonrpc": "2.0",
                "id": 2,
                "method": "initialize",
                "params": {"protocolVersion": version}
            });
            let (status, response) = handle_request(
                public_tool_test_state(),
                HeaderMap::new(),
                request,
                McpProtocolEra::Legacy,
                McpCatalogProfile::Core,
            )
            .await
            .unwrap();
            assert_eq!(status, StatusCode::OK);
            assert_eq!(response["result"]["protocolVersion"], version);
            assert!(response.get("error").is_none());
        }

        // Prefix/suffix lookalikes, unknown, missing, and non-string input all
        // deterministically select the server legacy version instead of being
        // echoed or rejected.
        let fallback = [
            json!({"protocolVersion": "2025-06-18-extra"}),
            json!({"protocolVersion": "x2025-06-18"}),
            json!({"protocolVersion": "2099-99-99"}),
            json!({}),
            json!({"protocolVersion": 42}),
        ];
        for params in fallback {
            let request = json!({
                "jsonrpc": "2.0",
                "id": 2,
                "method": "initialize",
                "params": params
            });
            let (status, response) = handle_request(
                public_tool_test_state(),
                HeaderMap::new(),
                request,
                McpProtocolEra::Legacy,
                McpCatalogProfile::Core,
            )
            .await
            .unwrap();
            assert_eq!(status, StatusCode::OK);
            assert_eq!(
                response["result"]["protocolVersion"],
                MCP_LEGACY_PROTOCOL_VERSION
            );
            assert!(response.get("error").is_none());
        }
    }

    #[tokio::test]
    async fn removed_handshake_methods_are_not_exposed_to_modern_clients() {
        let (headers, request) = modern_request("initialize", json!({}), None);
        validate_modern_request(&headers, &request).unwrap();
        let (status, response) = handle_request(
            public_tool_test_state(),
            HeaderMap::new(),
            request,
            McpProtocolEra::Modern,
            McpCatalogProfile::Core,
        )
        .await
        .unwrap();
        assert_eq!(status, StatusCode::NOT_FOUND);
        assert_eq!(response["error"]["code"], -32601);
    }

    #[test]
    fn origin_validation_is_exact_and_configurable() {
        assert!(mcp_origin_is_allowed_with_config(
            "https://chatgpt.com",
            None,
            None
        ));
        assert!(mcp_origin_is_allowed_with_config(
            "http://127.0.0.1:3000",
            None,
            None
        ));
        assert!(mcp_origin_is_allowed_with_config(
            "https://tenant.example",
            Some("https://tenant.example"),
            None
        ));
        assert!(mcp_origin_is_allowed_with_config(
            "https://client.example",
            None,
            Some("https://one.example, https://client.example")
        ));
        for rejected in [
            "null",
            "http://chatgpt.com",
            "https://chatgpt.com.evil.example",
            "https://user:secret@chatgpt.com",
            "https://chatgpt.com/path",
        ] {
            assert!(
                !mcp_origin_is_allowed_with_config(rejected, None, None),
                "expected rejected Origin: {rejected}"
            );
        }
    }

    #[tokio::test]
    async fn mounted_public_inventory_tool_is_callable_and_fails_closed() {
        let params = json!({
            "name": "list_autonomous_bounties",
            "arguments": {"network": "base-mainnet", "claimable_only": true}
        });
        let result = call_tool(public_tool_test_state(), HeaderMap::new(), &params, None)
            .await
            .unwrap();
        let encoded = serde_json::to_string(&result).unwrap();
        assert!(!encoded.contains("unknown or unavailable public ChatGPT app tool"));
        assert!(encoded.contains("DATABASE_URL"));
        assert!(!encoded.contains("\"paid\":true"));

        let error = call_tool(
            public_tool_test_state(),
            HeaderMap::new(),
            &json!({"name": "not_a_real_tool", "arguments": {}}),
            None,
        )
        .await
        .unwrap_err();
        assert!(error.contains("unknown or unavailable public ChatGPT app tool"));
    }

    #[test]
    fn feed_resource_is_embedded_as_an_interactive_mcp_app() {
        let contents = feed_widget_resource_contents_for_mode(false);
        let html = contents["text"].as_str().unwrap();
        assert_eq!(contents["mimeType"], "text/html;profile=mcp-app");
        assert_eq!(contents["uri"], FEED_WIDGET_URI);
        let redirect_domains = contents["_meta"]["openai/widgetCSP"]["redirect_domains"]
            .as_array()
            .expect("redirect domains");
        for expected in [
            "https://mcp.agentbounties.app",
            "https://agentbounties.app",
            "https://x.com",
            "https://www.linkedin.com",
            "https://www.instagram.com",
        ] {
            assert!(
                redirect_domains.iter().any(|value| value == expected),
                "missing redirect domain {expected}"
            );
        }
        assert!(html.contains("class=\"project-thumb\""));
        assert!(html.contains("bridgeNotify(\"ui/message\", message)"));
        assert!(html.contains("openai()?.sendFollowUpMessage"));
        assert!(!html.contains("ui/download-file"));
        assert!(!html.contains("__CHATGPT_PUBLIC_REVIEW_MODE__"));
        assert!(!contents["_meta"]["openai/widgetDescription"]
            .as_str()
            .unwrap()
            .to_ascii_lowercase()
            .contains("pokémon"));
        for outdated_term in ["collectible", "quest card", "instagram-inspired"] {
            assert!(
                !contents["_meta"]["openai/widgetDescription"]
                    .as_str()
                    .unwrap()
                    .to_ascii_lowercase()
                    .contains(outdated_term),
                "widget description contains outdated visual term {outdated_term}"
            );
        }
        assert!(html.contains("callTool(\"get_bounty_feed\""));
        for forbidden in [
            "callTool(\"add_bounty_comment\"",
            "callTool(\"create_share_bundle\"",
            "callTool(\"prepare_moonpay_onramp\"",
            "callTool(\"publish_unfunded_bounty\"",
            "callTool(\"compile_objective_with_cloud_agent\"",
            "callTool(\"prepare_bounty_action\"",
            "callTool(\"get_bounty_action_status\"",
            "fund_bounty_with_x402",
            "agent_native_claim",
            "wallet_signature",
            "PAYMENT-SIGNATURE",
            "plan_autonomous_module_settlement",
            "plan_autonomous_attestation_settlement",
        ] {
            assert!(
                !html.contains(forbidden),
                "feed widget must keep {forbidden} outside ChatGPT"
            );
        }
        for visible_control in [
            "data-action=\"post-bounty\"",
            "data-action=\"comment\"",
            "data-action=\"share\"",
            "data-action=\"solve\"",
            ">Post bounty<",
            ">Comment<",
            ">Share<",
            ">Solve<",
        ] {
            assert!(
                html.contains(visible_control),
                "feed widget must render {visible_control}"
            );
        }
        for forbidden_element in ["<input", "<textarea", "<select", "<form"] {
            assert!(
                !html.to_ascii_lowercase().contains(forbidden_element),
                "feed widget must not render {forbidden_element}"
            );
        }
        assert_eq!(html.matches("<button").count(), 4);
        assert!(html.contains("data:image/webp;base64,"));
        assert!(!html.contains("__BOUNTY_CARD_ART_DATA_URI__"));
        assert!(!html.contains("__CHATGPT_APP_BASE_URL_JSON__"));
        assert!(html.contains("bridgeRequest(\"tools/call\""));
        assert!(!html.contains("window.location.replace"));
        assert!(html.contains("Preview data · no writes"));
        assert!(html.contains("Safe fixture data"));
        assert!(!html.contains("open for competition"));
        assert!(!html.contains("ready to compete"));
        assert!(!html.contains("#2563eb"));
        assert!(html.contains("#020b08"));
        assert!(html.contains("#b9ef37"));
        assert!(html.contains("#18d9ac"));
        assert!(html.contains("#e8bd26"));
    }

    #[test]
    fn legacy_public_review_argument_cannot_reduce_the_widget() {
        let contents = feed_widget_resource_contents_for_mode(true);
        let redirect_domains = contents["_meta"]["ui"]["csp"]["redirectDomains"]
            .as_array()
            .expect("redirect domains");
        for expected in [
            "https://mcp.agentbounties.app",
            "https://agentbounties.app",
            "https://x.com",
            "https://www.linkedin.com",
            "https://www.instagram.com",
        ] {
            assert!(redirect_domains.iter().any(|domain| domain == expected));
        }
        assert!(contents["text"]
            .as_str()
            .unwrap()
            .contains("const APP_PUBLIC_REVIEW = false;"));
        assert!(contents["_meta"]["openai/widgetDescription"]
            .as_str()
            .unwrap()
            .contains("Post bounty, Comment, Share, and Solve"));
    }

    #[test]
    fn mounted_feed_result_does_not_claim_wallet_handoff() {
        let feed_result = tool_result(json!({"items": []}), "Rendered the live feed.", false);
        assert!(feed_result.get("_meta").is_none());

        let post_result = tool_result(
            json!({"state": "review_required_not_published"}),
            "Prepared wallet review.",
            true,
        );
        assert_eq!(post_result["_meta"]["handoff_kind"], "wallet_review");
        assert_eq!(post_result["_meta"]["private_key_requested"], false);
        assert_eq!(post_result["_meta"]["seed_phrase_requested"], false);
    }

    #[test]
    fn share_bundle_is_bounded_and_keeps_payment_evidence_explicit() {
        let args = ShareBundleArgs {
            bounty_id: "bounty-42".to_string(),
            title: "Ship the verifier dashboard".to_string(),
            stage: "verification".to_string(),
            bounty_url: Some("https://agentbounties.app/bounties/bounty-42".to_string()),
            status: "submitted; awaiting verifier".to_string(),
            reward: Some("12 USDC".to_string()),
            payment_state: Some("escrowed".to_string()),
            bounty_image_url: Some(format!(
                "https://mcp.agentbounties.app/public/bounty-images/{}",
                "ab".repeat(32)
            )),
        };
        let bundle = build_share_bundle(&args, false).unwrap();
        assert_eq!(bundle["stage"], "verification");
        assert!(bundle["caption"]
            .as_str()
            .unwrap()
            .contains("#AgentBounties"));
        assert!(bundle["intents"]["x"]
            .as_str()
            .unwrap()
            .contains("intent/post"));
        assert!(bundle["bounty_image_url"]
            .as_str()
            .unwrap()
            .contains("/public/bounty-images/"));
        assert!(bundle["evidence_boundary"]
            .as_str()
            .unwrap()
            .contains("not canonical"));

        let mut unsafe_args = args;
        unsafe_args.bounty_url = Some("javascript:alert(1)".to_string());
        assert!(build_share_bundle(&unsafe_args, false).is_err());
    }

    #[tokio::test]
    async fn sandbox_descriptors_are_read_only_and_explicit() {
        let mut descriptors = tools().await.0;
        descriptors.extend(custom_tool_descriptors());
        let sandbox_tools = descriptors
            .into_iter()
            .filter(|descriptor| CHATGPT_ADVERTISED_TOOL_NAMES.contains(&descriptor.name))
            .map(|descriptor| mcp_tool_descriptor_for_mode(descriptor, true, false))
            .collect::<Vec<_>>();

        assert_eq!(sandbox_tools.len(), CHATGPT_ADVERTISED_TOOL_NAMES.len());
        for tool in &sandbox_tools {
            assert_eq!(tool["annotations"]["readOnlyHint"], true, "{tool}");
            assert_eq!(tool["annotations"]["destructiveHint"], false, "{tool}");
            assert_eq!(tool["annotations"]["openWorldHint"], false, "{tool}");
            assert_eq!(tool["annotations"]["idempotentHint"], true, "{tool}");
            assert_eq!(tool["_meta"]["agentBountiesSandbox"], true, "{tool}");
            assert!(
                tool["description"]
                    .as_str()
                    .unwrap()
                    .contains("Sandbox mode is active"),
                "{tool}"
            );
        }
    }

    #[tokio::test]
    async fn legacy_public_review_argument_cannot_reduce_the_tool_surface() {
        let mut descriptors = tools().await.0;
        descriptors.extend(custom_tool_descriptors());
        let public_tools = descriptors
            .into_iter()
            .filter(|descriptor| chatgpt_tool_names(false, true).contains(&descriptor.name))
            .map(|descriptor| mcp_tool_descriptor_for_mode(descriptor, false, true))
            .collect::<Vec<_>>();

        assert_eq!(public_tools.len(), CHATGPT_ADVERTISED_TOOL_NAMES.len());
        for required in [
            "prepare_moonpay_onramp",
            "prepare_bounty_action",
            "get_bounty_action_status",
        ] {
            assert!(public_tools.iter().any(|tool| tool["name"] == required));
        }
        let feed = public_tools
            .iter()
            .find(|tool| tool["name"] == "get_bounty_feed")
            .unwrap();
        assert!(feed["inputSchema"]["properties"]
            .get("payment_state")
            .is_some());
        assert!(feed["inputSchema"]["properties"]
            .get("source_type")
            .is_some());
        assert_eq!(feed["_meta"]["agentBountiesPublicReview"], false);

        assert!(!public_tools
            .iter()
            .any(|tool| tool["name"] == "compile_objective_with_cloud_agent"));

        let share = public_tools
            .iter()
            .find(|tool| tool["name"] == "create_share_bundle")
            .unwrap();
        assert!(share["inputSchema"]["properties"]
            .get("bounty_url")
            .is_some());
        assert!(share["inputSchema"]["properties"].get("reward").is_some());
        assert!(share["inputSchema"]["properties"]
            .get("payment_state")
            .is_some());
    }

    #[test]
    fn public_review_feed_filter_is_fail_closed() {
        let mut projection = json!({
            "source_statuses": [
                {"source_type": "canonical_base", "authoritative_urls": ["https://api.agentbounties.app/v1/base/autonomous-bounties/feed?network=base-mainnet&claimable_only=true"]}
            ],
            "items": [
                {
                    "opportunity_id": "unfunded:volunteer-docs",
                    "source_id": "volunteer-docs",
                    "source_type": "unfunded_offchain",
                    "payment_state": "none",
                    "work_state": "open",
                    "title": "Publish an accessibility checklist",
                    "goal": "Write a concise public checklist.",
                    "public_url": "https://agentbounties.app/",
                    "next_action": {"action": "submit_unfunded_bounty_solution", "url": "https://agentbounties.app/paid"},
                    "reward": {"amount": "0", "currency": "USDC"},
                    "evidence_requirements": {"acceptance_criteria": ["Include keyboard-only checks."]}
                },
                {"source_type": "canonical_base", "payment_state": "escrowed", "work_state": "claimable"},
                {"source_type": "unfunded_offchain", "payment_state": "seeking_funding", "work_state": "open"},
                {
                    "opportunity_id": "unfunded:economic",
                    "source_type": "unfunded_offchain",
                    "payment_state": "none",
                    "work_state": "open",
                    "title": "Pay 10 USDC for this task",
                    "goal": "Transfer a token reward.",
                    "evidence_requirements": {"acceptance_criteria": []}
                }
            ]
        });
        constrain_public_review_feed(&mut projection).unwrap();
        assert_eq!(projection["items"].as_array().unwrap().len(), 1);
        let item = &projection["items"][0];
        assert!(item.get("reward").is_none());
        assert!(item.get("payment_state").is_none());
        assert!(item.get("payment_committed").is_none());
        assert!(item.get("payment_authority").is_none());
        assert!(item.get("competition_mode").is_none());
        assert!(item.get("verification_method").is_none());
        assert!(item.get("verification_ready").is_none());
        assert!(item.get("next_action").is_none());
        assert!(item.get("embeds").is_none());
        assert_eq!(item["source_type"], "voluntary_request");
        assert_eq!(item["request_status"], "open");
        assert_eq!(item["access"], "voluntary");
        assert!(item["public_url"]
            .as_str()
            .unwrap()
            .contains("/chatgpt/bounty-card-preview?"));
        assert!(item["public_url"]
            .as_str()
            .unwrap()
            .contains("public_review=1"));
        assert_eq!(projection["source_statuses"].as_array().unwrap().len(), 1);
        assert_eq!(
            projection["source_statuses"][0]["source_type"],
            "voluntary_request"
        );
        assert_eq!(
            projection["source_statuses"][0]["authoritative_urls"],
            json!([])
        );

        let mut plan = json!({
            "title": "Release plan",
            "objective": "Publish an onboarding guide",
            "success_definition": "The solver receives canonical payment.",
            "solver_budget_usdc": "10.00",
            "settlement_policy": {"asset": "USDC"},
            "source_url": "https://api.agentbounties.app/v1/opportunities",
            "next_action": "Fund the child tasks",
            "tasks": [{
                "task_id": "task-1",
                "title": "Pay the writer",
                "goal": "Create the guide",
                "acceptance_criteria": [
                    "Publish a concise guide.",
                    "Send 10 USDC to the wallet."
                ],
                "suggested_solver_reward_usdc": "10.00"
            }]
        });
        constrain_public_review_objective_plan(&mut plan);
        assert!(plan.get("solver_budget_usdc").is_none());
        assert!(plan.get("settlement_policy").is_none());
        assert!(plan.get("source_url").is_none());
        assert!(plan.get("next_action").is_none());
        assert!(plan["tasks"][0]
            .get("suggested_solver_reward_usdc")
            .is_none());
        assert_eq!(plan["tasks"][0]["title"], "Review task 1");
        assert_eq!(
            plan["tasks"][0]["acceptance_criteria"],
            json!(["Publish a concise guide."])
        );
        assert!(plan["success_definition"]
            .as_str()
            .unwrap()
            .starts_with("All task drafts"));

        let mut request = json!({
            "bounty_kind": "unfunded_offchain",
            "payment_promised": false,
            "upgrade_url": "https://agentbounties.app/#post-a-bounty"
        });
        strip_public_unfunded_navigation(&mut request);
        assert!(request.get("upgrade_url").is_none());
        assert!(request.get("payment_promised").is_none());
        assert!(request["public_url"]
            .as_str()
            .unwrap()
            .contains("public_review=1"));
    }

    #[test]
    fn public_review_rejects_commerce_language_and_external_links() {
        for blocked in [
            "Pay 10 USDC",
            "Connect a wallet",
            "Use MoonPay checkout",
            "Send the reward to 0x0000000000000000000000000000000000000000",
            "See https://example.com/offer",
        ] {
            assert!(
                ensure_public_review_noncommercial_text(blocked).is_err(),
                "{blocked}"
            );
        }
        for allowed in [
            "Publish an accessible onboarding checklist",
            "Review the public evidence and leave a constructive comment",
        ] {
            ensure_public_review_noncommercial_text(allowed).unwrap();
        }
        ensure_public_review_opportunity_id("unfunded:request-1").unwrap();
        assert!(ensure_public_review_opportunity_id(
            "canonical:base-mainnet:0x0000000000000000000000000000000000000000"
        )
        .is_err());
    }

    #[test]
    fn public_review_share_bundle_uses_only_the_noncommercial_card_origin() {
        let bundle = build_share_bundle(
            &ShareBundleArgs {
                bounty_id: "unfunded:community-request".to_string(),
                title: "Publish an accessibility checklist".to_string(),
                stage: "request shared".to_string(),
                bounty_url: None,
                status: "open".to_string(),
                reward: None,
                payment_state: None,
                bounty_image_url: None,
            },
            true,
        )
        .unwrap();
        assert!(bundle["share_url"]
            .as_str()
            .unwrap()
            .contains("/chatgpt/bounty-card-preview?"));
        assert!(!bundle["share_url"].as_str().unwrap().contains("reward="));
        assert!(bundle["caption"]
            .as_str()
            .unwrap()
            .contains("no payment promise"));
        assert!(!bundle["caption"].as_str().unwrap().contains("USDC"));
        assert!(bundle["evidence_boundary"]
            .as_str()
            .unwrap()
            .contains("paid-service checkout"));
    }

    #[tokio::test]
    async fn sandbox_lifecycle_contracts_never_claim_external_writes() {
        let render = sandbox_tool_result("render_bounty_feed", &json!({}))
            .await
            .unwrap();
        assert_eq!(render["structuredContent"]["sandbox"], true);
        assert_eq!(
            render["structuredContent"]["items"]
                .as_array()
                .unwrap()
                .len(),
            5
        );
        let cards = render["structuredContent"]["items"].as_array().unwrap();
        assert!(cards.iter().any(|item| item["work_state"] == "in_progress"));
        assert!(cards.iter().any(|item| {
            item["work_state"] == "submitted"
                && item["verification_method"] == "deterministic module"
        }));

        let comment = sandbox_tool_result(
            "add_bounty_comment",
            &json!({
                "bounty_id": "canonical_base:base-mainnet:0xabc1000000000000000000000000000000000001",
                "body": "Safe sandbox comment",
                "author": "tester",
                "comment_id": Uuid::new_v4()
            }),
        )
        .await
        .unwrap();
        assert_eq!(comment["structuredContent"]["published"], false);
        assert_eq!(comment["structuredContent"]["sandbox"], true);
        let comments = comment["structuredContent"]["comments"].as_array().unwrap();
        assert_eq!(comments.len(), 2);
        for item in comments {
            assert!(item["id"].is_string(), "{item}");
            assert!(item["author"].is_string(), "{item}");
            assert!(item["body"].is_string(), "{item}");
            assert!(item["created_at"].is_string(), "{item}");
        }

        for action in ["post", "fund", "solve", "complete", "verify"] {
            let prepared = sandbox_tool_result(
                "prepare_bounty_action",
                &json!({
                    "idempotency_key": format!("sandbox-{action}-flow"),
                    "action": action,
                    "network": "base-mainnet",
                    "opportunity_id": "canonical_base:base-mainnet:0xabc1000000000000000000000000000000000001",
                    "bounty_contract": if action == "post" {
                        Value::Null
                    } else {
                        json!("0xabc1000000000000000000000000000000000001")
                    },
                    "bounty_id": null,
                    "actor_wallet": null,
                    "amount_base_units": if action == "fund" { json!(1_000_000) } else { Value::Null },
                    "details": {}
                }),
            )
            .await
            .unwrap();
            let intent = &prepared["structuredContent"];
            assert_eq!(intent["sandbox"], true, "{action}");
            assert_eq!(intent["status"], "review_required", "{action}");
            assert_eq!(intent["transaction_hash"], Value::Null, "{action}");
            assert_eq!(intent["canonical_event_id"], Value::Null, "{action}");
            assert_eq!(intent["paid"], false, "{action}");

            let refreshed = sandbox_tool_result(
                "get_bounty_action_status",
                &json!({"intent_id": intent["intent_id"]}),
            )
            .await
            .unwrap();
            assert_eq!(refreshed["structuredContent"]["status"], "confirmed");
            assert_eq!(
                refreshed["structuredContent"]["canonical_event_id"],
                Value::Null
            );
            assert_eq!(refreshed["structuredContent"]["paid"], false);
        }
    }

    #[tokio::test]
    async fn sandbox_exercises_every_advertised_tool_with_stable_safe_results() {
        let bounty_id = "canonical_base:base-mainnet:0xabc1000000000000000000000000000000000001";
        let bounty_contract = "0xabc1000000000000000000000000000000000001";
        let action_arguments = json!({
            "idempotency_key": "sandbox-release-action-001",
            "action": "solve",
            "network": "base-mainnet",
            "opportunity_id": bounty_id,
            "bounty_contract": bounty_contract,
            "details": {}
        });
        let first_action = sandbox_tool_result("prepare_bounty_action", &action_arguments)
            .await
            .unwrap();
        let repeated_action = sandbox_tool_result("prepare_bounty_action", &action_arguments)
            .await
            .unwrap();
        assert_eq!(first_action, repeated_action);
        let intent_id = first_action["structuredContent"]["intent_id"].clone();

        let calls = [
            ("get_bounty_feed", json!({"view": "ready_to_earn"})),
            (
                "render_bounty_feed",
                json!({"opportunity_ids": [bounty_id]}),
            ),
            (
                "prepare_moonpay_onramp",
                json!({
                    "bounty_contract": bounty_contract,
                    "amount_base_units": 1_000_000
                }),
            ),
            (
                "prepare_bounty_post",
                json!({
                    "title": "Publish the sandbox release checklist",
                    "goal": "Create a deterministic release checklist for the MCP app.",
                    "acceptance_criteria": ["The checklist names every required release gate."],
                    "solver_reward_usdc": "2.00",
                    "verifier_reward_usdc": "0.10",
                    "task_window_days": 7,
                    "crowdfund": false,
                    "discovery_source": "ephemeral ChatGPT QA",
                    "image_prompt": "A bounded green release checklist on a dark background.",
                    "image_alt_text": "A green release checklist.",
                    "bounty_image": {
                        "download_url": "https://files.oaiusercontent.com/sandbox-fixture",
                        "file_id": "file-sandbox-fixture",
                        "mime_type": "image/png",
                        "file_name": "sandbox-checklist.png"
                    }
                }),
            ),
            ("prepare_bounty_action", action_arguments),
            ("get_bounty_action_status", json!({"intent_id": intent_id})),
            ("list_bounty_comments", json!({"bounty_id": bounty_id})),
            (
                "add_bounty_comment",
                json!({
                    "bounty_id": bounty_id,
                    "body": "Sandbox-only release comment",
                    "author": "operator-qa",
                    "comment_id": "00000000-0000-4000-8000-00000000c001"
                }),
            ),
            (
                "create_share_bundle",
                json!({
                    "bounty_id": bounty_id,
                    "title": "Sandbox release checklist",
                    "stage": "prepared",
                    "bounty_url": "https://agentbounties.app/",
                    "status": "sandbox only",
                    "reward": "2 USDC",
                    "payment_state": "sandbox"
                }),
            ),
        ];

        let mut called_names = Vec::new();
        for (name, arguments) in calls {
            let result = sandbox_tool_result(name, &arguments).await.unwrap();
            assert!(result.get("isError").is_none(), "{name}: {result}");
            assert_eq!(
                result["structuredContent"]["sandbox"], true,
                "{name}: {result}"
            );
            assert!(
                result["structuredContent"]["evidence_boundary"]
                    .as_str()
                    .is_some_and(|boundary| !boundary.is_empty()),
                "{name}: {result}"
            );
            called_names.push(name);
        }
        assert_eq!(called_names.as_slice(), CHATGPT_ADVERTISED_TOOL_NAMES);

        assert!(sandbox_tool_result("prepare_bounty_action", &json!({}))
            .await
            .is_err());
        assert!(sandbox_tool_result(
            "get_bounty_action_status",
            &json!({"intent_id": "not-a-uuid"})
        )
        .await
        .is_err());
        assert!(sandbox_tool_result("not_a_public_tool", &json!({}))
            .await
            .is_err());
    }

    #[test]
    fn sandbox_feed_filters_fixture_cards_without_network_access() {
        let seeking_funding = sandbox_bounty_feed(
            ChatgptFeedArgs {
                network: Some("base-mainnet".to_string()),
                view: Some("seeking_funding".to_string()),
                source_type: None,
                work_state: None,
                payment_state: Some("seeking_funding".to_string()),
                limit: Some(30),
            },
            &[],
        )
        .unwrap();
        let items = seeking_funding["items"].as_array().unwrap();
        assert_eq!(items.len(), 1);
        assert_eq!(items[0]["payment_state"], "seeking_funding");
        assert_eq!(seeking_funding["sandbox"], true);
    }

    #[test]
    fn call_tool_structured_content_is_always_an_object() {
        let result = tool_result(json!([{"id": 1}]), "List result", false);
        assert!(result["structuredContent"].is_object());
        assert_eq!(result["structuredContent"]["items"][0]["id"], 1);
    }

    #[test]
    fn comment_identifier_is_path_safe_before_hosted_request() {
        assert_eq!(
            bounded_opportunity_id("canonical:base-mainnet:0xabc").unwrap(),
            "canonical:base-mainnet:0xabc"
        );
        assert!(bounded_opportunity_id("bad/id").is_err());
        assert!(bounded_opportunity_id(" ").is_err());
    }
}

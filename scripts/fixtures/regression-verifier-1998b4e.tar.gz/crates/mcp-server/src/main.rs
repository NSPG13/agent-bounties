use app::{
    build_live_money_readiness_report, build_objective_canonical_evidence,
    AddFundingContributionRequest, ApproveRiskBountyRequest, ApproveRiskPayoutRequest,
    BountyNetwork, BountyStatusResponse, ClaimBountyRequest, CreateFundingIntentRequest,
    CreateHelpRequestRequest, FundQuoteRequest, LiveMoneyReadinessConfig, OpenPooledBountyRequest,
    PlanStripeTransferRequest, PostBountyRequest, RegisterAgentRequest, RegisterCapabilityRequest,
    RejectRiskEventRequest, RiskEventFilter, SubmitResultRequest, VerifySubmissionRequest,
};
use axum::{
    extract::{Form, MatchedPath, Path, Query, Request, State},
    http::{header, HeaderMap, HeaderValue, StatusCode},
    middleware::{self, Next},
    response::{IntoResponse, Redirect, Response},
    routing::{get, post},
    Json, Router,
};
use base64::{engine::general_purpose::URL_SAFE_NO_PAD, Engine as _};
use bounty_router::BountyRouter;
use chain_base::{
    autonomous_bounty_is_earning_ready, base_network_descriptor, broadcast_signed_transaction,
    build_autonomous_bounty_feed, build_autonomous_bounty_terms_record,
    build_autonomous_submission_evidence_record, build_autonomous_submission_preparation,
    build_autonomous_verification_jobs, decode_autonomous_bounty_logs,
    eth_get_transaction_receipt_request, eth_send_raw_transaction_request,
    fetch_transaction_receipt, normalize_evm_address,
    plan_canonical_child_bounty_terms as build_canonical_child_bounty_terms_plan,
    standing_meta_v2_parent_context, validate_attestation_request_against_feed,
    validate_autonomous_cancel_authority, validate_autonomous_creation_for_public_earning,
    AutonomousBountyAuthorizationSignature, AutonomousBountyContribution, AutonomousBountyCreate,
    AutonomousBountyFeedItem, AutonomousBountyRecoveryReservations,
    AutonomousBountySubmissionAuthorizationRequest, AutonomousBountyTxPlanner,
    AutonomousSignedAttestation, AutonomousVerificationAttestationRequest, BaseRpcUrlConfig,
    CanonicalChildBountyTermsRequest, EvmLog, PrepareAgentToEarnInput,
    StandingMetaV2ChildPreparationRequest,
};
use chrono::Utc;
use competition_metric_core::{
    verification_policy_hash, JournalScopeV2, PublicVectorCase, PublicVectorMode,
    PublicVectorProgramInput,
};
use db::{
    AttributionReliability, DiscoveryInterface, DiscoveryRouteFamily, ObservedInterface,
    ObservedProtocolEra, PostgresStore,
};
use domain::{
    Agent, AutonomousBountyTermsDocument, BountyStatus, CapabilityClass,
    DiscoverySubscriptionFilters, EvalRun, HelpRequest, Id, Money, Objective, ObjectiveAction,
    ObjectiveCanonicalEvidence, ObjectiveCreationDraft, PaymentRail, PayoutStatus, PrivacyLevel,
    SignedObjectiveAction, SignedObjectiveCreation,
};
use github_app::{
    bounty_check_output, claim_comment_plan, create_comment_plan, funding_comment_plan,
    parse_issue_form_bounty, proof_comment_plan, GitHubClaimCommentInput, GitHubCreateCommentInput,
    GitHubFundingCommentInput, GitHubProofComment,
};
use hmac::{Hmac, Mac};
use payments_stripe::{
    execute_stripe_request, CheckoutTopUpRequest, ConnectAccountSnapshot, StripeEventDeduper,
    StripePlanner, StripeRequestIntent, StripeWebhookEvent, STRIPE_API_BASE_URL,
};
use risk::RiskPolicy;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
#[cfg(test)]
use service_runtime::{
    canonical_mainnet_factory, CANONICAL_BASE_MAINNET_BOUNTY_FACTORY,
    CANONICAL_BASE_MAINNET_BOUNTY_IMPLEMENTATION,
};
use service_runtime::{
    eval_run_from_loop_suite, eval_run_from_suite, LiveMoneyRuntimeSettings, PlannerAddressError,
};
use sha2::{Digest, Sha256};
use std::collections::{BTreeSet, HashMap};
use std::env;
use std::sync::{Arc, Mutex};
use tower_http::cors::CorsLayer;
use url::Url;
use uuid::Uuid;

mod chatgpt_app;
mod moonpay;

#[derive(Debug)]
struct AppState {
    network: Mutex<BountyNetwork>,
    eval_runs: Mutex<Vec<EvalRun>>,
    base_rpc_urls: BaseRpcUrlConfig,
    base_broadcast_enabled: bool,
    stripe_secret_key: Option<String>,
    stripe_live_execution_enabled: bool,
    stripe_api_base_url: String,
    stripe_payment_method_configuration: Option<String>,
    operator_api_token: Option<String>,
    analytics_exclusion_token: Option<String>,
    distribution_attribution_signing_secret: Option<String>,
    mcp_base_url: String,
    oauth_authorizations: Mutex<HashMap<String, PendingOAuthAuthorization>>,
    oauth_codes: Mutex<HashMap<String, OAuthAuthorizationCode>>,
    store: Option<PostgresStore>,
    recovery_reservations: AutonomousBountyRecoveryReservations,
}

type SharedState = Arc<AppState>;
const OPERATOR_TOKEN_HEADER: &str = "x-operator-token";
const ANALYTICS_EXCLUSION_HEADER: &str = "x-agent-bounties-analytics-exclusion";
const ANALYTICS_EXCLUDED_HEADER: &str = "x-agent-bounties-analytics-excluded";
const ANALYTICS_EXCLUSION_SCOPE: &str = "analytics:exclude-owner";
const ANALYTICS_OAUTH_TOKEN_PREFIX: &str = "abx1";
const ANALYTICS_OAUTH_TOKEN_LIFETIME_SECONDS: i64 = 7_776_000;
const MAX_PENDING_OAUTH_AUTHORIZATIONS: usize = 512;
type AnalyticsHmacSha256 = Hmac<Sha256>;

async fn health() -> impl IntoResponse {
    health_response(&deployment_revision())
}

async fn chatgpt_bounty_card_preview() -> impl IntoResponse {
    chatgpt_bounty_card_preview_response()
}

async fn chatgpt_favicon() -> impl IntoResponse {
    (
        [
            (header::CONTENT_TYPE, "image/svg+xml"),
            (header::CACHE_CONTROL, "public, max-age=86400"),
        ],
        include_str!("../../../site/favicon.svg"),
    )
}

async fn public_bounty_image_asset(
    State(state): State<SharedState>,
    Path(sha256): Path<String>,
) -> Response {
    if sha256.len() != 64
        || !sha256
            .bytes()
            .all(|byte| byte.is_ascii_digit() || (b'a'..=b'f').contains(&byte))
    {
        return StatusCode::NOT_FOUND.into_response();
    }
    let Some(store) = state.store.as_ref() else {
        return StatusCode::SERVICE_UNAVAILABLE.into_response();
    };
    let asset = match store.get_bounty_image_asset(&sha256).await {
        Ok(Some(asset)) => asset,
        Ok(None) => return StatusCode::NOT_FOUND.into_response(),
        Err(_) => return StatusCode::INTERNAL_SERVER_ERROR.into_response(),
    };
    let content_type = match HeaderValue::from_str(&asset.mime_type) {
        Ok(value) => value,
        Err(_) => return StatusCode::INTERNAL_SERVER_ERROR.into_response(),
    };
    let mut headers = HeaderMap::new();
    headers.insert(header::CONTENT_TYPE, content_type);
    headers.insert(
        header::CACHE_CONTROL,
        HeaderValue::from_static("public, max-age=31536000, immutable"),
    );
    headers.insert(
        header::ACCESS_CONTROL_ALLOW_ORIGIN,
        HeaderValue::from_static("*"),
    );
    headers.insert(
        "x-content-type-options",
        HeaderValue::from_static("nosniff"),
    );
    (headers, asset.content).into_response()
}

fn chatgpt_bounty_card_preview_response() -> (HeaderMap, String) {
    let mut headers = HeaderMap::new();
    headers.insert(
        header::CONTENT_TYPE,
        HeaderValue::from_static("text/html; charset=utf-8"),
    );
    headers.insert(header::CACHE_CONTROL, HeaderValue::from_static("no-store"));
    headers.insert(
        "content-security-policy",
        HeaderValue::from_static(
            "default-src 'none'; img-src 'self' data: blob:; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'",
        ),
    );
    headers.insert("referrer-policy", HeaderValue::from_static("no-referrer"));
    headers.insert(
        "x-content-type-options",
        HeaderValue::from_static("nosniff"),
    );
    (headers, chatgpt_app::bounty_card_preview_html())
}

async fn observe_http_errors(request: Request, next: Next) -> Response {
    let method = request.method().clone();
    let route = request.extensions().get::<MatchedPath>().cloned();
    let response = next.run(request).await;
    if response.status().is_server_error() {
        service_runtime::http_observability::record_http_error(
            service_runtime::http_observability::HttpService::Mcp,
            method.as_str(),
            route.as_ref().map(MatchedPath::as_str),
            &deployment_revision(),
            response.status().as_u16(),
        );
    }
    response
}

fn deployment_revision() -> String {
    env::var("RENDER_GIT_COMMIT")
        .ok()
        .filter(|value| {
            value.len() == 40 && value.chars().all(|character| character.is_ascii_hexdigit())
        })
        .unwrap_or_else(|| "local".to_string())
}

fn interface_usage_excluded_event(protocol_era: ObservedProtocolEra, revision: &str) -> Value {
    let protocol_era = match protocol_era {
        ObservedProtocolEra::McpModern => "modern",
        ObservedProtocolEra::McpLegacy => "legacy",
        ObservedProtocolEra::NotApplicable | ObservedProtocolEra::McpHttpAdapter => {
            unreachable!("only protocol MCP requests emit exclusion evidence")
        }
    };
    json!({
        "event": "interface_usage_excluded",
        "interface": "mcp",
        "protocol_era": protocol_era,
        "success": true,
        "revision": revision,
    })
}

pub(crate) fn emit_interface_usage_excluded(protocol_era: ObservedProtocolEra) {
    eprintln!(
        "{}",
        interface_usage_excluded_event(protocol_era, &deployment_revision())
    );
}

fn health_response(revision: &str) -> impl IntoResponse {
    let mut headers = HeaderMap::new();
    headers.insert(
        "x-agent-bounties-revision",
        HeaderValue::from_str(revision).unwrap_or_else(|_| HeaderValue::from_static("invalid")),
    );
    headers.insert(
        "x-agent-bounties-protocol",
        HeaderValue::from_static("agent-bounties/autonomous-v1"),
    );
    (headers, "ok")
}

fn non_empty_secret(secret: String) -> Option<String> {
    let trimmed = secret.trim();
    if trimmed.is_empty() {
        None
    } else {
        Some(trimmed.to_string())
    }
}

fn require_operator(
    state: &SharedState,
    headers: &HeaderMap,
) -> Result<(), Json<serde_json::Value>> {
    if service_runtime::operator_token_is_authorized(
        state.operator_api_token.as_deref(),
        headers
            .get(OPERATOR_TOKEN_HEADER)
            .and_then(|value| value.to_str().ok()),
        headers
            .get("authorization")
            .and_then(|value| value.to_str().ok()),
    ) {
        Ok(())
    } else {
        Err(mcp_error("operator authorization required"))
    }
}

pub(crate) fn analytics_exclusion_is_authorized(state: &AppState, headers: &HeaderMap) -> bool {
    let authorization = headers
        .get(header::AUTHORIZATION)
        .and_then(|value| value.to_str().ok());
    let bearer = authorization.and_then(|value| value.trim().strip_prefix("Bearer "));
    state.analytics_exclusion_token.is_some()
        && service_runtime::operator_token_is_authorized(
            state.analytics_exclusion_token.as_deref(),
            headers
                .get(ANALYTICS_EXCLUSION_HEADER)
                .and_then(|value| value.to_str().ok()),
            None,
        )
        || state
            .analytics_exclusion_token
            .as_deref()
            .is_some_and(|secret| {
                bearer.is_some_and(|token| {
                    analytics_oauth_access_token_is_authorized(
                        secret,
                        token,
                        &state.mcp_base_url,
                        Utc::now(),
                    )
                })
            })
        || (state.operator_api_token.is_some()
            && service_runtime::operator_token_is_authorized(
                state.operator_api_token.as_deref(),
                headers
                    .get(OPERATOR_TOKEN_HEADER)
                    .and_then(|value| value.to_str().ok()),
                authorization,
            ))
}

pub(crate) fn attest_analytics_exclusion(response: &mut Response, excluded: bool) {
    if excluded {
        response
            .headers_mut()
            .insert(ANALYTICS_EXCLUDED_HEADER, HeaderValue::from_static("true"));
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct ToolDescriptor {
    name: &'static str,
    description: &'static str,
    input_schema: Value,
    #[serde(skip_serializing_if = "Option::is_none")]
    authorization: Option<ToolAuthorization>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct ToolAuthorization {
    kind: &'static str,
    header: &'static str,
    bearer: bool,
    required_when: &'static str,
}

macro_rules! tool_args {
    (
        $(#[$meta:meta])*
        struct $name:ident {
            $($(#[$field_meta:meta])* $field:ident: $field_type:ty),* $(,)?
        }
        schema |$schema_arg:ident: $schema_arg_type:ty| $schema:expr;
    ) => {
        #[derive(Debug, Clone, Serialize, Deserialize)]
        $(#[$meta])*
        struct $name {
            $($(#[$field_meta])* $field: $field_type),*
        }

        impl $name {
            fn input_schema($schema_arg: $schema_arg_type) -> Value {
                $schema
            }
        }
    };
    (
        $(#[$meta:meta])*
        struct $name:ident {
            $($(#[$field_meta:meta])* $field:ident: $field_type:ty),* $(,)?
        }
        schema $schema:expr;
    ) => {
        #[derive(Debug, Clone, Serialize, Deserialize)]
        $(#[$meta])*
        struct $name {
            $($(#[$field_meta])* $field: $field_type),*
        }

        impl $name {
            fn input_schema() -> Value {
                $schema
            }
        }
    };
}

macro_rules! tool_registry {
    ($($descriptor:expr),* $(,)?) => {
        vec![$($descriptor),*]
    };
}

tool_args! {
    struct RouteBlockedGoalArgs {
        goal: String,
        context: String,
        budget_minor: i64,
        currency: String,
        privacy: PrivacyLevel,
    }
    schema object_tool_schema(
        json!({
            "goal": string_property("Task, workflow, job, or goal where the requester is blocked."),
            "context": string_property("Relevant constraints, logs, artifacts, URLs, or prior attempts."),
            "budget_minor": integer_property("Maximum budget in minor units."),
            "currency": string_property("Lowercase currency code, for example usdc or usd."),
            "privacy": privacy_property()
        }),
        &["goal", "context", "budget_minor", "currency", "privacy"],
    );
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct OpenCompetitionV2PublicVectorProfileBody {
    network: Option<String>,
    mode: PublicVectorMode,
    threshold: String,
    vectors: Vec<OpenCompetitionV2PublicVectorPolicyCase>,
}

#[derive(Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
struct OpenCompetitionV2PublicVectorPolicyCase {
    expected: i64,
    weight: u32,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct OpenCompetitionV2PolicyBody {
    execution_policy: Value,
    settlement_policy: Value,
    creation_nonce_seed: String,
}

tool_args! {
    struct PlanObjectiveCreationArgs {
        draft: ObjectiveCreationDraft,
    }
    schema object_tool_schema(
        json!({
            "draft": object_property("Complete objective-v1 declaration with explicit participants, authority, beneficiaries, affected parties, resources, access, rights, privacy boundary, and requested verification policy.")
        }),
        &["draft"],
    );
}

tool_args! {
    struct ObjectiveIdArgs {
        objective_id: Id,
    }
    schema object_tool_schema(
        json!({"objective_id": uuid_property("Objective UUID.")}),
        &["objective_id"],
    );
}

tool_args! {
    struct PlanObjectiveActionArgs {
        objective_id: Id,
        action: ObjectiveAction,
    }
    schema object_tool_schema(
        json!({
            "objective_id": uuid_property("Objective UUID."),
            "action": object_property("Tagged objective-v1 action such as add_provider_proposal, accept_provider_proposal, offer_contribution, select_contribution_offer, submit_contribution, verify_contribution, submit_final_outcome, or verify_final_outcome.")
        }),
        &["objective_id", "action"],
    );
}

tool_args! {
    struct ApplyObjectiveActionArgs {
        objective_id: Id,
        signed_action: SignedObjectiveAction,
    }
    schema object_tool_schema(
        json!({
            "objective_id": uuid_property("Objective UUID."),
            "signed_action": object_property("Exact action plan plus its EIP-191 wallet approvals.")
        }),
        &["objective_id", "signed_action"],
    );
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct ChatgptFileInput {
    download_url: String,
    file_id: String,
    mime_type: Option<String>,
    file_name: Option<String>,
}

tool_args! {
    struct PrepareBountyPostArgs {
        title: String,
        goal: String,
        acceptance_criteria: Vec<String>,
        solver_reward_usdc: String,
        verifier_reward_usdc: String,
        task_window_days: Option<u8>,
        review_mode: Option<String>,
        delivery_deadline: Option<String>,
        posting_operation_id: Option<uuid::Uuid>,
        meta_child: Option<Value>,
        reference_attachment: Option<Value>,
        source_url: Option<String>,
        #[serde(default)]
        crowdfund: bool,
        discovery_source: Option<String>,
        benchmark: Option<Value>,
        evidence_schema: Option<Value>,
        image_prompt: Option<String>,
        image_alt_text: Option<String>,
        bounty_image: Option<ChatgptFileInput>,
    }
    schema object_tool_schema(
        json!({
            "title": {"type": "string", "minLength": 1, "maxLength": 200, "description": "Concise public bounty title."},
            "goal": {"type": "string", "minLength": 1, "maxLength": 4000, "description": "Public digital outcome the solver must deliver."},
            "acceptance_criteria": {
                "type": "array", "minItems": 1, "maxItems": 20,
                "items": {"type": "string", "minLength": 1, "maxLength": 1000},
                "description": "Binary or measurable public acceptance criteria."
            },
            "solver_reward_usdc": {"type": "string", "pattern": "^[0-9]+(\\.[0-9]{1,6})?$", "description": "Solver reward in display USDC, for example 2.00."},
            "verifier_reward_usdc": {"type": "string", "pattern": "^[0-9]+(\\.[0-9]{1,6})?$", "description": "Verifier reward and refundable claim bond in display USDC, for example 0.10. In creator mode, label this the creator-review reserve; it is paid to the creator on either verdict."},
            "task_window_days": {"type": ["integer", "null"], "minimum": 1, "maximum": 30, "description": "Optional bounded work window in days; defaults to 30."},
            "review_mode": {"type": ["string", "null"], "enum": ["creator", "automated", null], "description": "Creator review commits the creator as the sole human reviewer. The creator confirms the verdict; AI approval has no settlement authority."},
            "delivery_deadline": {"type": ["string", "null"], "format": "date-time", "description": "For creator review, the exact agreed calendar deadline as an ISO timestamp with timezone offset. Never replace it with days after claim. Omit automated benchmark and evidence_schema fields in creator mode."},
            "posting_operation_id": {"type": ["string", "null"], "format": "uuid", "description": "Stable posting journey identifier. Reuse it when resuming or retrying the same operation. If omitted, a deterministic identifier is derived from the unchanged preparation arguments."},
            "reference_attachment": {"type": ["object", "null"], "description": "Preserve the approved compact homepage-background snapshot descriptor, including its commit-pinned asset_url, sha256 and captured_at. The first-party review validates the pinned bytes; never replace the user's reference."},
            "meta_child": {"type": ["object", "null"], "description": "Preserve the routed parent binding. The review page verifies the canonical parent before applying any child economics.", "properties": {"parent_bounty_contract": {"type": "string", "pattern": "^0x[0-9a-fA-F]{40}$"}, "intended_child_solver": {"type": ["string", "null"], "pattern": "^0x[0-9a-fA-F]{40}$"}}, "required": ["parent_bounty_contract"], "additionalProperties": false},
            "source_url": nullable_string_property("Optional public HTTPS source issue or task URL."),
            "crowdfund": {"type": "boolean", "default": false, "description": "Keep false to fund on creation. Set true only to deposit 0 USDC now."},
            "discovery_source": nullable_string_property("Optional public attribution for how the poster found Agent Bounties."),
            "benchmark": {"type": ["object", "null"], "description": "Optional exact public sandboxed_regression_v1 benchmark. Supply this and evidence_schema together. The source commit, benchmark digest, OCI image, command, and resource limits are immutable bounty terms."},
            "evidence_schema": {"type": ["object", "null"], "description": "Optional public submission-evidence schema paired with benchmark. Supply both verifier fields or neither."},
            "image_prompt": {"type": "string", "minLength": 1, "maxLength": 4000, "description": "Optional exact prompt used to generate a user-approved bounty image. Supply this, image_alt_text, and bounty_image together, or omit all three to use the deterministic fallback visual."},
            "image_alt_text": {"type": "string", "minLength": 1, "maxLength": 500, "description": "Optional accessible description of the approved image. Supply this, image_prompt, and bounty_image together."},
            "bounty_image": {
                "type": "object",
                "description": "Optional approved image generated in a compatible AI conversation. Agent Bounties stores this exact file; omit it and both image text fields to use the deterministic fallback visual.",
                "properties": {
                    "download_url": {"type": "string"},
                    "file_id": {"type": "string"},
                    "mime_type": {"type": ["string", "null"]},
                    "file_name": {"type": ["string", "null"]}
                },
                "required": ["download_url", "file_id"],
                "additionalProperties": false
            }
        }),
        &[
            "title",
            "goal",
            "acceptance_criteria",
            "solver_reward_usdc",
            "verifier_reward_usdc"
        ],
    );
}

tool_args! {
    struct PublishUnfundedBountyArgs {
        title: String,
        goal: String,
        acceptance_criteria: Vec<String>,
        source_url: Option<String>,
        idempotency_key: String,
    }
    schema object_tool_schema(
        json!({
            "title": {"type": "string", "minLength": 1, "maxLength": 200, "description": "Concise public unfunded bounty title."},
            "goal": {"type": "string", "minLength": 1, "maxLength": 12000, "description": "Public digital outcome prepared by the caller."},
            "acceptance_criteria": {
                "type": "array", "minItems": 1, "maxItems": 20,
                "items": {"type": "string", "minLength": 1, "maxLength": 1000},
                "description": "Measurable criteria for agent solutions."
            },
            "source_url": nullable_string_property("Optional public HTTPS source URL supplied by the caller."),
            "idempotency_key": {"type": "string", "pattern": "^[A-Za-z0-9:_-]{1,128}$", "description": "Stable unique key for this ChatGPT publication attempt."}
        }),
        &["title", "goal", "acceptance_criteria", "idempotency_key"],
    );
}

tool_args! {
    #[derive(Default)]
    struct ListUnfundedBountiesArgs {
        limit: Option<u32>,
    }
    schema object_tool_schema(
        json!({
            "limit": {"type": ["integer", "null"], "minimum": 1, "maximum": 100, "description": "Optional number of recent unfunded bounties; defaults to 20."}
        }),
        &[],
    );
}

tool_args! {
    struct SubmitUnfundedBountySolutionArgs {
        bounty_id: Uuid,
        agent_id: Uuid,
        summary: String,
        deliverable_markdown: String,
        evidence: Value,
    }
    schema object_tool_schema(
        json!({
            "bounty_id": string_property("Public unfunded bounty UUID."),
            "agent_id": string_property("Registered Agent Bounties agent UUID."),
            "summary": {"type": "string", "minLength": 1, "maxLength": 1000},
            "deliverable_markdown": {"type": "string", "minLength": 1, "maxLength": 40000},
            "evidence": {"type": "object", "description": "Replayable public evidence; do not include secrets."}
        }),
        &["bounty_id", "agent_id", "summary", "deliverable_markdown", "evidence"],
    );
}

tool_args! {
    #[derive(Default)]
    struct AutonomousInventorySummaryArgs {
        network: Option<String>,
        claimable_only: Option<bool>,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_string_property("Network name; defaults to base-mainnet."),
            "claimable_only": {"type": ["boolean", "null"], "description": "Defaults to true."},
        }),
        &[],
    );
}

tool_args! {
    #[derive(Default)]
    struct SolverLeaderboardArgs {
        network: Option<String>,
        at: Option<String>,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_string_property("Defaults to base-mainnet."),
            "at": nullable_string_property("RFC3339 instant. Omit for current UTC periods."),
        }),
        &[],
    );
}

tool_args! {
    struct PlanStripeCheckoutTopUpArgs {
        organization_id: Uuid,
        amount_minor: i64,
        currency: String,
        success_url: Option<String>,
        cancel_url: Option<String>,
    }
    schema object_tool_schema(
        json!({
            "organization_id": uuid_property("Organization UUID credited after a paid webhook."),
            "amount_minor": integer_property("Top-up amount in minor units."),
            "currency": string_property("Stripe currency code."),
            "success_url": nullable_string_property("Optional Checkout success URL."),
            "cancel_url": nullable_string_property("Optional Checkout cancel URL.")
        }),
        &["organization_id", "amount_minor", "currency"],
    );
}

tool_args! {
    struct PlanStripeConnectAccountArgs {
        agent_id: Uuid,
    }
    schema object_tool_schema(
        json!({ "agent_id": uuid_property("Agent UUID.") }),
        &["agent_id"],
    );
}

tool_args! {
    struct PlanStripeConnectTransferArgs {
        payout_intent_id: Uuid,
        connected_account_id: String,
    }
    schema object_tool_schema(
        json!({
            "payout_intent_id": uuid_property("Stripe fiat payout intent UUID from bounty status."),
            "connected_account_id": string_property("Stripe connected account ID receiving the transfer.")
        }),
        &["payout_intent_id", "connected_account_id"],
    );
}

tool_args! {
    #[derive(Default)]
    struct LiveMoneyReadinessArgs {
        network: Option<String>,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-mainnet", "base-sepolia"], "Base network to inspect. Defaults to base-mainnet.")
        }),
        &[],
    );
}

tool_args! {
    #[derive(Default)]
    struct OpenCompetitionReadinessArgs {
        network: Option<String>,
        bounty_contract: String,
        solver: Option<String>,
        verifier_profile_id: Option<String>,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-mainnet", "base-sepolia"], "Base network to inspect. Defaults to base-mainnet."),
            "bounty_contract": string_property("Canonical open-competition bounty address."),
            "solver": nullable_string_property("Optional solver wallet for one-entry and capacity checks."),
            "verifier_profile_id": nullable_string_property("Approved deterministic verifier profile id.")
        }),
        &["bounty_contract"],
    );
}

tool_args! {
    #[derive(Default)]
    struct OpenCompetitionVerifierArgs {
        network: Option<String>,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-mainnet", "base-sepolia"], "Base network to inspect. Defaults to base-mainnet.")
        }),
        &[],
    );
}

tool_args! {
    struct OpenCompetitionCreationArgs {
        network: Option<String>,
        creator: String,
        creation_nonce: String,
        initial_funding: u64,
        verifier_profile_id: String,
        params: Value,
        funding_authorization: Option<Value>,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-mainnet", "base-sepolia"], "Base network containing the frozen release."),
            "creator": string_property("Creator wallet address."),
            "creation_nonce": string_property("Nonzero 32-byte creation nonce."),
            "initial_funding": { "type": "integer", "minimum": 0, "description": "Native USDC base units supplied at creation." },
            "verifier_profile_id": string_property("Exact approved verifier catalog profile id."),
            "params": { "type": "object", "description": "Deterministic terms, economics, deadlines, capacity, and verifier reward recipient.", "additionalProperties": true },
            "funding_authorization": { "type": ["object", "null"], "description": "Optional EIP-3009 authorization window, nonce, and signature. Omit for approval-and-create.", "additionalProperties": true }
        }),
        &["creator", "creation_nonce", "initial_funding", "verifier_profile_id", "params"],
    );
}

tool_args! {
    struct OpenCompetitionCommitArgs {
        network: Option<String>,
        bounty_contract: String,
        solver: String,
        commitment: String,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-mainnet", "base-sepolia"], "Base network containing the competition."),
            "bounty_contract": string_property("Canonical open-competition bounty address."),
            "solver": string_property("Wallet entering the competition."),
            "commitment": string_property("Public commitment only. Never include submission hashes or salt in this request.")
        }),
        &["bounty_contract", "solver", "commitment"],
    );
}

tool_args! {
    struct OpenCompetitionRevealArgs {
        network: Option<String>,
        bounty_contract: String,
        solver: String,
        commitment_envelope: Value,
        proof: String,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-mainnet", "base-sepolia"], "Base network containing the competition."),
            "bounty_contract": string_property("Canonical open-competition bounty address."),
            "solver": string_property("Same wallet recorded in the commitment envelope."),
            "commitment_envelope": { "type": "object", "description": "Locally recovered agent-bounties/open-competition-v1-commitment-v1 envelope.", "additionalProperties": true },
            "proof": string_property("Verifier-specific proof calldata as 0x-prefixed bytes.")
        }),
        &["bounty_contract", "solver", "commitment_envelope", "proof"],
    );
}

tool_args! {
    struct OpenCompetitionActionArgs {
        network: Option<String>,
        bounty_contract: String,
        #[serde(default)]
        arguments: Value,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-mainnet", "base-sepolia"], "Base network containing the competition."),
            "bounty_contract": string_property("Canonical open-competition bounty address."),
            "arguments": {
                "type": "object",
                "description": "Public commitment or reveal arguments only. Keep the reveal salt private until reveal; never include wallet secrets."
            }
        }),
        &["bounty_contract", "arguments"],
    );
}

tool_args! {
    struct OpenCompetitionEntrantActionArgs {
        network: Option<String>,
        wallet: String,
        bounty_contract: String,
        action: String,
        commitment: Option<String>,
        commitment_envelope: Option<Value>,
        proof: Option<String>,
        deadline_seconds: Option<u64>,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-mainnet", "base-sepolia"], "Base network containing the competition and entrant wallet."),
            "wallet": string_property("Canonical entrant-wallet contract owned by the solver."),
            "bounty_contract": string_property("Canonical open-competition bounty address."),
            "action": enum_property(&["commit", "reveal", "withdraw_bond"], "Exact policy-bound entrant action."),
            "commitment": nullable_string_property("Commit only: public nonzero commitment. Never include its salt."),
            "commitment_envelope": { "type": ["object", "null"], "description": "Reveal only: locally recovered commitment envelope.", "additionalProperties": true },
            "proof": nullable_string_property("Reveal only: verifier-specific 0x-prefixed proof bytes."),
            "deadline_seconds": { "type": ["integer", "null"], "minimum": 30, "maximum": 600, "description": "Optional action-signature lifetime; defaults to 300 seconds." }
        }),
        &["wallet", "bounty_contract", "action"],
    );
}

tool_args! {
    struct OpenCompetitionEntrantRelayArgs {
        idempotency_key: String,
        plan: Value,
        signature: String,
    }
    schema object_tool_schema(
        json!({
            "idempotency_key": string_property("Stable replay key for this exact wallet nonce, plan, and signature."),
            "plan": { "type": "object", "description": "Exact plan returned by prepare_open_competition_entrant_action.", "additionalProperties": true },
            "signature": string_property("Delegate EIP-712 signature for this exact plan. Never provide a private key or seed phrase.")
        }),
        &["idempotency_key", "plan", "signature"],
    );
}

tool_args! {
    struct GetOpenCompetitionEntrantRelayArgs {
        relay_id: String,
    }
    schema object_tool_schema(
        json!({
            "relay_id": string_property("Relay UUID returned by relay_open_competition_entrant_action.")
        }),
        &["relay_id"],
    );
}

tool_args! {
    #[derive(Default)]
    struct OpenCompetitionV2InspectArgs {
        operation: String,
        network: Option<String>,
        state: Option<String>,
        bounty_id: Option<String>,
        job_id: Option<String>,
    }
    schema open_competition_v2_inspect_schema();
}

tool_args! {
    struct OpenCompetitionV2MutationArgs {
        operation: String,
        arguments: Value,
    }
    schema open_competition_v2_mutation_schema();
}

tool_args! {
    #[derive(Default)]
    struct StandingMetaV4ReadinessArgs {
        network: Option<String>,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-mainnet", "base-sepolia"], "Base network to inspect. Defaults to base-mainnet.")
        }),
        &[],
    );
}

tool_args! {
    struct StandingMetaV4ActionArgs {
        network: Option<String>,
        #[serde(default)]
        arguments: Value,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-mainnet", "base-sepolia"], "Base network containing the configured V4 contracts."),
            "arguments": {
                "type": "object",
                "description": "Public contract-call arguments only. Never include a private key, seed phrase, or secret."
            }
        }),
        &["arguments"],
    );
}

tool_args! {
    struct PlanGitHubIssueBountyArgs {
        repository: String,
        issue_url: String,
        title: String,
        body: String,
    }
    schema object_tool_schema(
        json!({
            "repository": string_property("GitHub repository, for example owner/repo."),
            "issue_url": string_property("Canonical GitHub issue URL."),
            "title": string_property("Issue title."),
            "body": string_property("Rendered issue form markdown body.")
        }),
        &["repository", "issue_url", "title", "body"],
    );
}

tool_args! {
    struct PlanGitHubFundingCommentArgs {
        repository: String,
        issue_url: String,
        title: String,
        body: String,
        comment_body: String,
        contributor_login: Option<String>,
        comment_id: Option<String>,
        funding_api_base_url: Option<String>,
        #[serde(default)]
        existing_idempotency_keys: Vec<String>,
    }
    schema object_tool_schema(
        json!({
            "repository": string_property("GitHub repository, for example owner/repo."),
            "issue_url": string_property("Canonical GitHub issue URL for the paid bounty issue."),
            "title": string_property("Issue title."),
            "body": string_property("Rendered issue form markdown body."),
            "comment_body": string_property("GitHub issue comment body, for example `/agent-bounty fund 5 USDC via BaseUsdcEscrow`."),
            "contributor_login": nullable_string_property("Optional GitHub login that authored the funding signal."),
            "comment_id": nullable_string_property("Optional GitHub comment ID used to build an idempotency key."),
            "funding_api_base_url": nullable_string_property("Optional hosted API base URL to prefill the public StripeFiat funding page for Stripe funding comments."),
            "existing_idempotency_keys": string_array_property("Previously processed funding-comment idempotency keys for duplicate detection.")
        }),
        &["repository", "issue_url", "title", "body", "comment_body"],
    );
}

tool_args! {
    struct PlanGitHubCreateCommentArgs {
        repository: String,
        issue_url: String,
        title: String,
        body: String,
        comment_body: String,
        contributor_login: Option<String>,
        comment_id: Option<String>,
        #[serde(default)]
        existing_idempotency_keys: Vec<String>,
    }
    schema object_tool_schema(
        json!({
            "repository": string_property("GitHub repository, for example owner/repo."),
            "issue_url": string_property("Canonical HTTPS GitHub issue URL."),
            "title": string_property("Current issue title."),
            "body": string_property("Current issue body used as advisory draft context."),
            "comment_body": string_property("GitHub comment containing `/agent-bounty create <amount> USDC`."),
            "contributor_login": nullable_string_property("Optional GitHub login that authored the command."),
            "comment_id": nullable_string_property("Optional GitHub comment ID used for idempotency."),
            "existing_idempotency_keys": string_array_property("Previously processed create-comment keys for duplicate detection.")
        }),
        &["repository", "issue_url", "title", "body", "comment_body"],
    );
}

tool_args! {
    struct PlanSocialMentionDraftArgs {
        source_network: String,
        mention_url: String,
        mention_id: String,
        mention_text: String,
        author_handle: Option<String>,
    }
    schema object_tool_schema(
        json!({
            "source_network": string_property("Social network or connector name, for example farcaster."),
            "mention_url": string_property("Canonical HTTPS URL for the source mention."),
            "mention_id": string_property("Stable provider mention ID used for idempotency."),
            "mention_text": string_property("Mention text containing `/agent-bounty create <amount> USDC` and the requested outcome."),
            "author_handle": nullable_string_property("Optional public author handle.")
        }),
        &["source_network", "mention_url", "mention_id", "mention_text"],
    );
}

tool_args! {
    struct PlanGitHubClaimCommentArgs {
        repository: String,
        issue_url: String,
        title: String,
        body: String,
        comment_body: String,
        contributor_login: Option<String>,
        comment_id: Option<String>,
        claim_age_minutes: Option<u64>,
        #[serde(default)]
        progress_signal_count: u32,
        active_claim_login: Option<String>,
    }
    schema object_tool_schema(
        json!({
            "repository": string_property("GitHub repository, for example owner/repo."),
            "issue_url": string_property("Canonical GitHub issue URL for the paid bounty issue."),
            "title": string_property("Issue title."),
            "body": string_property("Rendered issue form markdown body."),
            "comment_body": string_property("GitHub issue comment body, for example `/agent-bounty claim` followed by `plan: ...`."),
            "contributor_login": nullable_string_property("Optional GitHub login that authored the claim signal."),
            "comment_id": nullable_string_property("Optional GitHub comment ID used to build a reservation id."),
            "claim_age_minutes": nullable_integer_property("Optional age of the active claim reservation in minutes."),
            "progress_signal_count": integer_property("Known count of external progress signals, such as PRs or progress comments."),
            "active_claim_login": nullable_string_property("Optional login that currently holds the active claim reservation.")
        }),
        &["repository", "issue_url", "title", "body", "comment_body"],
    );
}

tool_args! {
    struct PlanGitHubProofCommentArgs {
        bounty_id: Uuid,
        proof_url: String,
        verifier_summary: String,
        settlement_url: Option<String>,
    }
    schema object_tool_schema(
        json!({
            "bounty_id": uuid_property("Bounty UUID."),
            "proof_url": string_property("Public proof URL."),
            "verifier_summary": string_property("Verifier summary to include in the comment."),
            "settlement_url": nullable_string_property("Optional settlement transaction or record URL.")
        }),
        &["bounty_id", "proof_url", "verifier_summary", "settlement_url"],
    );
}

tool_args! {
    struct PlanGitHubProofCommentForProofArgs {
        proof_id: Uuid,
        settlement_url: Option<String>,
    }
    schema object_tool_schema(
        json!({
            "proof_id": uuid_property("Public proof record UUID."),
            "settlement_url": nullable_string_property("Optional settlement transaction or record URL.")
        }),
        &["proof_id", "settlement_url"],
    );
}

tool_args! {
    #[derive(Default)]
    struct SearchCapabilitiesArgs {
        class: Option<CapabilityClass>,
        template_slug: Option<String>,
        currency: Option<String>,
        max_price_minor: Option<i64>,
    }
    schema object_tool_schema(
        json!({
            "class": nullable_enum_property(&[
                "Coding", "Research", "Extraction", "Verification", "Documentation", "Ci",
                "BrowserWorkflow"
            ], "Optional capability class filter."),
            "template_slug": nullable_string_property("Optional reusable bounty template slug."),
            "currency": nullable_string_property("Optional lowercase currency code."),
            "max_price_minor": nullable_integer_property("Optional maximum acceptable minimum price in minor units.")
        }),
        &[],
    );
}

tool_args! {
    struct PlanAutonomousBountyCreationArgs {
        network: Option<String>, create: AutonomousBountyCreate,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-sepolia", "base-mainnet"], "Optional Base network; defaults to base-mainnet."),
            "create": autonomous_bounty_create_property()
        }),
        &["create"],
    );
}

tool_args! {
    struct PlanAutonomousBountyContributionArgs {
        network: Option<String>, contribution: AutonomousBountyContribution,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-sepolia", "base-mainnet"], "Optional Base network; defaults to base-mainnet."),
            "contribution": {
                "type": "object",
                "properties": {
                    "bounty_contract": string_property("Canonical bounty contract receiving USDC."),
                    "contributor": string_property("Funding agent or human wallet."),
                    "amount": money_property("Exact USDC contribution; it must not exceed remaining target funding.", false),
                    "authorization_nonce": nullable_string_property("Optional unique bytes32 for the one-signature EIP-3009 path."),
                    "authorization_valid_before": nullable_integer_property("Optional Unix expiry paired with authorization_nonce.")
                },
                "required": ["bounty_contract", "contributor", "amount"],
                "additionalProperties": false
            }
        }),
        &["contribution"],
    );
}

tool_args! {
    struct PlanAutonomousBountyAuthorizedCreationArgs {
        network: Option<String>, create: AutonomousBountyCreate,
        signature: AutonomousBountyAuthorizationSignature, relayer: Option<String>,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-sepolia", "base-mainnet"], "Optional Base network; defaults to base-mainnet."),
            "create": autonomous_bounty_create_property(),
            "signature": authorization_signature_property(),
            "relayer": nullable_string_property("Optional wallet that will sponsor and submit the factory transaction.")
        }),
        &["create", "signature"],
    );
}

tool_args! {
    struct PlanAutonomousBountyAuthorizedContributionArgs {
        network: Option<String>, contribution: AutonomousBountyContribution,
        signature: AutonomousBountyAuthorizationSignature, relayer: Option<String>,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-sepolia", "base-mainnet"], "Optional Base network; defaults to base-mainnet."),
            "contribution": {
                "type": "object",
                "properties": {
                    "bounty_contract": string_property("Indexed canonical bounty contract."),
                    "contributor": string_property("Wallet that signed the authorization."),
                    "amount": money_property("Exact USDC amount authorized.", false),
                    "authorization_nonce": string_property("Unique bytes32 signed in the authorization."),
                    "authorization_valid_before": integer_property("Unix expiry signed in the authorization.")
                },
                "required": ["bounty_contract", "contributor", "amount", "authorization_nonce", "authorization_valid_before"],
                "additionalProperties": false
            },
            "signature": authorization_signature_property(),
            "relayer": nullable_string_property("Optional wallet sponsoring the transaction.")
        }),
        &["contribution", "signature"],
    );
}

tool_args! {
    struct X402BountyFundingArgs {
        network: Option<String>, bounty_contract: String, amount: Option<u64>,
        relayer: Option<String>, payment_signature: Option<String>,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-sepolia", "base-mainnet"], "Optional Base network; defaults to base-mainnet."),
            "bounty_contract": string_property("Indexed canonical bounty contract."),
            "amount": nullable_integer_property("Optional USDC base-unit contribution; defaults to the remaining target."),
            "relayer": nullable_string_property("Optional gas-paying Base wallet for self-relay fallback. Omit it when the hosted relay is enabled."),
            "payment_signature": nullable_string_property("Optional base64 x402 v2 PaymentPayload copied from the PAYMENT-SIGNATURE header. Omit it to receive the exact challenge.")
        }),
        &["bounty_contract"],
    );
}

tool_args! {
    struct GetX402RelayStatusArgs { relay_id: Uuid }
    schema object_tool_schema(
        json!({ "relay_id": string_property("Relay UUID returned by fund_bounty_with_x402.") }),
        &["relay_id"],
    );
}

tool_args! {
    struct PlanAutonomousBountyClaimArgs {
        network: Option<String>, bounty_contract: String, solver: String,
        authorization_nonce: Option<String>, authorization_valid_before: Option<u64>,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-sepolia", "base-mainnet"], "Optional Base network; defaults to base-mainnet."),
            "bounty_contract": string_property("Fully funded canonical bounty contract."),
            "solver": string_property("Solver wallet that will receive payout if verification passes."),
            "authorization_nonce": nullable_string_property("Optional unique bytes32 for a one-signature EIP-3009 bond authorization."),
            "authorization_valid_before": nullable_integer_property("Optional Unix expiry for the bond authorization.")
        }),
        &["bounty_contract", "solver"],
    );
}

tool_args! {
    struct AgentNativeClaimArgs {
        idempotency_key: String, network: Option<String>, bounty_contract: String,
        solver_wallet: String, agent_id: Option<Uuid>,
        #[serde(default)]
        request_bond_sponsorship: bool,
        signature: Option<AutonomousBountyAuthorizationSignature>,
        wallet_signature: Option<String>, source: Option<String>,
    }
    schema object_tool_schema(
        json!({
            "idempotency_key": string_property("Stable 1-128 character key reused for every retry of this wallet+bounty claim."),
            "network": nullable_enum_property(&["base-sepolia", "base-mainnet"], "Optional Base network; defaults to base-mainnet."),
            "bounty_contract": string_property("Verified, funded, claimable, verification-ready canonical bounty contract."),
            "solver_wallet": string_property("Public Base payout wallet. Never provide a private key or seed phrase."),
            "agent_id": nullable_uuid_property("Optional registered agent UUID bound to solver_wallet and capability evidence."),
            "request_bond_sponsorship": boolean_property("Ask the configured sponsor vault to provide the exact capped USDC bond and call claim atomically after one solver signature. The response states availability and identifies the protocol/contract."),
            "signature": {
                "type": ["object", "null"],
                "description": "Legacy split signature. Omit when wallet_signature is provided.",
                "properties": authorization_signature_property()["properties"].clone(),
                "required": ["v", "r", "s"],
                "additionalProperties": false
            },
            "wallet_signature": nullable_string_property("Preferred unchanged 0x-prefixed 65-byte result returned by wallet_request. Do not provide this together with signature."),
            "source": nullable_string_property("Compact discovery/tool source such as github, mcp, curl, python, or cast.")
        }),
        &["idempotency_key", "bounty_contract", "solver_wallet", "request_bond_sponsorship"],
    );
}

tool_args! {
    struct PlanAutonomousBountyAuthorizedClaimArgs {
        network: Option<String>, bounty_contract: String, solver: String,
        authorization_nonce: String, authorization_valid_before: u64,
        signature: AutonomousBountyAuthorizationSignature, relayer: Option<String>,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-sepolia", "base-mainnet"], "Optional Base network; defaults to base-mainnet."),
            "bounty_contract": string_property("Fully funded canonical bounty contract."),
            "solver": string_property("Wallet that signed the claim-bond authorization."),
            "authorization_nonce": string_property("Unique bytes32 signed in the authorization."),
            "authorization_valid_before": integer_property("Unix expiry signed in the authorization."),
            "signature": authorization_signature_property(),
            "relayer": nullable_string_property("Optional wallet sponsoring the transaction.")
        }),
        &["bounty_contract", "solver", "authorization_nonce", "authorization_valid_before", "signature"],
    );
}

tool_args! {
    struct PlanAutonomousBountySubmissionArgs {
        network: Option<String>, bounty_contract: String, solver: String,
        submission_hash: String, evidence_hash: String,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-sepolia", "base-mainnet"], "Optional Base network; defaults to base-mainnet."),
            "bounty_contract": string_property("Claimed canonical bounty contract."),
            "solver": string_property("Wallet holding the current claim."),
            "submission_hash": string_property("0x-prefixed bytes32 artifact commitment."),
            "evidence_hash": string_property("0x-prefixed bytes32 evidence-package commitment.")
        }),
        &["bounty_contract", "solver", "submission_hash", "evidence_hash"],
    );
}

tool_args! {
    struct PlanAutonomousBountySubmissionAuthorizationArgs {
        network: Option<String>, submission: AutonomousBountySubmissionAuthorizationRequest,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-sepolia", "base-mainnet"], "Optional Base network; defaults to base-mainnet."),
            "submission": autonomous_submission_authorization_property()
        }),
        &["submission"],
    );
}

tool_args! {
    struct PrepareAutonomousBountySubmissionArgs {
        network: Option<String>, bounty_contract: String, solver_wallet: String,
        artifact_reference: String, evidence: Value,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-sepolia", "base-mainnet"], "Optional Base network; defaults to base-mainnet."),
            "bounty_contract": string_property("Indexed canonical bounty contract in claimed state."),
            "solver_wallet": string_property("Wallet that owns the active indexed claim."),
            "artifact_reference": string_property("Public repository, commit, artifact URI, or canonical result string to commit."),
            "evidence": {
                "type": "object",
                "description": "Public evidence object required by the bounty's immutable evidence schema; maximum encoded size is 256 KiB."
            }
        }),
        &["bounty_contract", "solver_wallet", "artifact_reference", "evidence"],
    );
}

tool_args! {
    struct PlanAutonomousVerificationAttestationArgs {
        network: Option<String>, attestation: AutonomousVerificationAttestationRequest,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-sepolia", "base-mainnet"], "Optional Base network; defaults to base-mainnet."),
            "attestation": autonomous_verification_attestation_property()
        }),
        &["attestation"],
    );
}

tool_args! {
    struct PlanAutonomousModuleSettlementArgs {
        network: Option<String>, bounty_contract: String, caller: Option<String>, proof: String,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-sepolia", "base-mainnet"], "Optional Base network; defaults to base-mainnet."),
            "bounty_contract": string_property("Submitted canonical deterministic-module bounty."),
            "caller": nullable_string_property("Optional wallet sponsoring the permissionless call."),
            "proof": string_property("0x-prefixed proof bytes consumed by the committed verifier module.")
        }),
        &["bounty_contract", "proof"],
    );
}

tool_args! {
    struct PlanAutonomousAttestationSettlementArgs {
        network: Option<String>, bounty_contract: String, caller: Option<String>,
        attestations: Vec<AutonomousSignedAttestation>,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-sepolia", "base-mainnet"], "Optional Base network; defaults to base-mainnet."),
            "bounty_contract": string_property("Submitted canonical quorum bounty."),
            "caller": nullable_string_property("Optional wallet sponsoring the relay."),
            "attestations": {
                "type": "array", "minItems": 1, "maxItems": 8,
                "items": autonomous_signed_attestation_property()
            }
        }),
        &["bounty_contract", "attestations"],
    );
}

tool_args! {
    struct PlanAutonomousLifecycleArgs {
        network: Option<String>, bounty_contract: String, caller: Option<String>,
    }
    schema |contract_description: &str| object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-sepolia", "base-mainnet"], "Optional Base network; defaults to base-mainnet."),
            "bounty_contract": string_property(contract_description),
            "caller": nullable_string_property("Optional wallet that will send the transaction; refund withdrawal requires it.")
        }),
        &["bounty_contract"],
    );
}

tool_args! {
    struct PlanAutonomousCancelArgs {
        network: Option<String>, bounty_contract: String, caller: String,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-sepolia", "base-mainnet"], "Optional Base network; defaults to base-mainnet."),
            "bounty_contract": string_property("Open or claimable canonical bounty contract."),
            "caller": string_property("Wallet sending the transaction. Before the funding deadline this must be the indexed creator.")
        }),
        &["bounty_contract", "caller"],
    );
}

tool_args! {
    struct PlanBoundedWalletCancelRefundArgs {
        network: Option<String>, bounty_contract: String, bounded_wallet: String, caller: String,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-sepolia", "base-mainnet"], "Optional Base network; defaults to base-mainnet."),
            "bounty_contract": string_property("Open or claimable canonical bounty created by the bounded wallet."),
            "bounded_wallet": string_property("BoundedAgentWalletV2 contract that created and funded the bounty."),
            "caller": string_property("Bounded wallet owner that will sign the transaction.")
        }),
        &["bounty_contract", "bounded_wallet", "caller"],
    );
}

tool_args! {
    struct DecodeAutonomousBountyEventsArgs { logs: Vec<EvmLog> }
    schema object_tool_schema(
        json!({
            "logs": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "address": string_property("Event-emitting factory or bounty contract."),
                        "topics": string_array_property("0x-prefixed 32-byte EVM log topics."),
                        "data": string_property("0x-prefixed ABI-encoded event data."),
                        "tx_hash": string_property("Confirmed transaction hash."),
                        "block_number": integer_property("Confirmed block number."),
                        "log_index": integer_property("Transaction log index."),
                        "occurred_at": nullable_string_property("Optional RFC3339 event timestamp.")
                    },
                    "required": ["address", "topics", "data", "tx_hash", "block_number", "log_index"],
                    "additionalProperties": false
                }
            }
        }),
        &["logs"],
    );
}

tool_args! {
    #[derive(Default)]
    struct ListAutonomousBountyEventsArgs { network: Option<String>, bounty_id: Option<String> }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-sepolia", "base-mainnet"], "Optional Base network; defaults to base-mainnet."),
            "bounty_id": nullable_string_property("Optional 0x-prefixed bytes32 autonomous bounty id filter.")
        }),
        &[],
    );
}

tool_args! {
    struct PublishAutonomousBountyTermsArgs {
        creator_wallet: String,
        document: AutonomousBountyTermsDocument,
    }
    schema object_tool_schema(
        json!({
            "creator_wallet": string_property("Wallet expected to create the canonical bounty."),
            "document": autonomous_bounty_terms_property()
        }),
        &["creator_wallet", "document"],
    );
}

tool_args! {
    struct GetAutonomousBountyTermsArgs { terms_hash: String }
    schema object_tool_schema(
        json!({ "terms_hash": string_property("0x-prefixed Keccak hash from a canonical bounty contract.") }),
        &["terms_hash"],
    );
}

tool_args! {
    struct PublishAutonomousSubmissionEvidenceArgs {
        network: Option<String>,
        bounty_contract: String,
        bounty_id: String,
        round: u64,
        solver_wallet: String,
        artifact_reference: String,
        evidence: Value,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-sepolia", "base-mainnet"], "Optional Base network; defaults to base-mainnet."),
            "bounty_contract": string_property("Indexed canonical submitted bounty contract."),
            "bounty_id": string_property("0x-prefixed canonical bounty id."),
            "round": integer_property("Current submission round."),
            "solver_wallet": string_property("Wallet that holds the indexed claim."),
            "artifact_reference": string_property("Public repository, commit, artifact URI, or canonical result string."),
            "evidence": object_property("Public evidence object evaluated under the immutable evidence schema.")
        }),
        &["bounty_contract", "bounty_id", "round", "solver_wallet", "artifact_reference", "evidence"],
    );
}

tool_args! {
    struct GetAutonomousSubmissionEvidenceArgs {
        network: Option<String>, bounty_contract: String, round: u64,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-sepolia", "base-mainnet"], "Optional Base network; defaults to base-mainnet."),
            "bounty_contract": string_property("Indexed canonical bounty contract."),
            "round": integer_property("Positive submission round.")
        }),
        &["bounty_contract", "round"],
    );
}

tool_args! {
    #[derive(Default)]
    struct AutonomousBountyFeedArgs { network: Option<String>, claimable_only: Option<bool> }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-sepolia", "base-mainnet"], "Optional Base network; defaults to base-mainnet."),
            "claimable_only": nullable_boolean_property("When true, return only fully funded unclaimed bounties.")
        }),
        &[],
    );
}

tool_args! {
    #[derive(Default)]
    struct OpportunityListArgs {
        network: Option<String>, view: Option<String>, source_type: Option<String>,
        work_state: Option<String>, payment_state: Option<String>, limit: Option<u32>,
    }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-sepolia", "base-mainnet"], "Optional canonical Base network; defaults to base-mainnet."),
            "view": nullable_enum_property(&["recent", "engineering", "creative", "urgent", "seeking_funding", "ready_to_earn"], "Optional deterministic discovery view. Inclusion factors are returned with each item."),
            "source_type": nullable_enum_property(&["unfunded_offchain", "legacy_bounty", "canonical_base"], "Optional authoritative-source filter."),
            "work_state": nullable_enum_property(&["open", "claimable", "in_progress", "submitted", "completed"], "Optional work-lifecycle filter."),
            "payment_state": nullable_enum_property(&["none", "seeking_funding", "escrowed", "paid"], "Optional payment-state filter."),
            "limit": nullable_integer_property("Optional combined result limit from 1 to 300.")
        }),
        &[],
    );
}

tool_args! {
    struct CreateDiscoverySubscriptionArgs {
        endpoint_url: String,
        #[serde(default)]
        filters: DiscoverySubscriptionFilters,
    }
    schema object_tool_schema(
        json!({
            "endpoint_url": string_property("Public HTTPS receiver URL. Private, loopback, link-local, credential-bearing, and redirect-based endpoints are rejected."),
            "filters": discovery_subscription_filters_property()
        }),
        &["endpoint_url"],
    );
}

tool_args! {
    struct ManageDiscoverySubscriptionArgs { subscription_id: Uuid, management_token: String }
    schema object_tool_schema(
        json!({
            "subscription_id": string_property("Discovery subscription UUID."),
            "management_token": string_property("Secret bbm_ management token returned only when the subscription was created.")
        }),
        &["subscription_id", "management_token"],
    );
}

tool_args! {
    #[derive(Default)]
    struct OpportunityConversionFunnelArgs { window_hours: Option<u32> }
    schema object_tool_schema(
        json!({ "window_hours": nullable_integer_property("Optional cohort lookback from 1 to 8760 hours; defaults to 720.") }),
        &[],
    );
}

tool_args! {
    #[derive(Default)]
    struct SiteAnalyticsArgs { window_hours: Option<u32> }
    schema object_tool_schema(
        json!({ "window_hours": nullable_integer_property("Optional lookback from 1 to 8760 hours; defaults to 720.") }),
        &[],
    );
}

tool_args! {
    #[derive(Default)]
    struct AutonomousVerificationJobsArgs { network: Option<String>, verifier: Option<String> }
    schema object_tool_schema(
        json!({
            "network": nullable_enum_property(&["base-sepolia", "base-mainnet"], "Optional Base network; defaults to base-mainnet."),
            "verifier": nullable_string_property("Optional committed verifier wallet; deterministic module jobs remain visible to any relayer.")
        }),
        &[],
    );
}

tool_args! {
    struct BroadcastBaseSignedTransactionArgs {
        signed_transaction: String,
        request_id: Option<u64>,
        network: Option<String>,
    }
    schema object_tool_schema(
        json!({
            "signed_transaction": string_property("0x-prefixed signed raw EVM transaction."),
            "request_id": nullable_integer_property("Optional JSON-RPC request id."),
            "network": nullable_enum_property(&["base-sepolia", "base-mainnet"], "Optional Base network; defaults to base-sepolia.")
        }),
        &["signed_transaction"],
    );
}

tool_args! {
    struct GetBaseTransactionReceiptArgs {
        tx_hash: String,
        request_id: Option<u64>,
        network: Option<String>,
    }
    schema object_tool_schema(
        json!({
            "tx_hash": string_property("0x-prefixed transaction hash."),
            "request_id": nullable_integer_property("Optional JSON-RPC request id."),
            "network": nullable_enum_property(&["base-sepolia", "base-mainnet"], "Optional Base network; defaults to base-mainnet.")
        }),
        &["tx_hash"],
    );
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let store = match env::var("DATABASE_URL") {
        Ok(database_url) => {
            let store = PostgresStore::connect(&database_url).await?;
            store.migrate().await?;
            Some(store)
        }
        Err(_) => None,
    };
    let network = if let Some(store) = &store {
        hydrate_network(store).await?
    } else {
        BountyNetwork::default()
    };
    let eval_runs = if let Some(store) = &store {
        store.list_eval_runs().await?
    } else {
        Vec::new()
    };
    let recovery_reservations_raw = env::var("BASE_RECOVERY_RESERVED_BOUNTY_CONTRACTS").ok();
    let recovery_reservations =
        AutonomousBountyRecoveryReservations::parse_csv(recovery_reservations_raw.as_deref())
            .map_err(|error| {
                anyhow::anyhow!("BASE_RECOVERY_RESERVED_BOUNTY_CONTRACTS is invalid: {error}")
            })?;
    let state: SharedState = Arc::new(AppState {
        network: Mutex::new(network),
        eval_runs: Mutex::new(eval_runs),
        base_rpc_urls: BaseRpcUrlConfig::from_env(),
        base_broadcast_enabled: env::var("ENABLE_BASE_TX_BROADCAST")
            .map(|value| value.eq_ignore_ascii_case("true"))
            .unwrap_or(false),
        stripe_secret_key: env::var("STRIPE_SECRET_KEY").ok(),
        stripe_live_execution_enabled: env::var("ENABLE_STRIPE_LIVE_EXECUTION")
            .map(|value| value.eq_ignore_ascii_case("true"))
            .unwrap_or(false),
        stripe_api_base_url: env::var("STRIPE_API_BASE_URL")
            .unwrap_or_else(|_| STRIPE_API_BASE_URL.to_string()),
        stripe_payment_method_configuration: env::var("STRIPE_PAYMENT_METHOD_CONFIGURATION")
            .ok()
            .and_then(non_empty_secret),
        operator_api_token: env::var("OPERATOR_API_TOKEN")
            .ok()
            .and_then(non_empty_secret),
        analytics_exclusion_token: env::var("ANALYTICS_EXCLUSION_TOKEN")
            .ok()
            .and_then(non_empty_secret),
        distribution_attribution_signing_secret: env::var(
            "DISTRIBUTION_ATTRIBUTION_SIGNING_SECRET",
        )
        .ok()
        .and_then(non_empty_secret),
        mcp_base_url: mcp_base_url_from_env().trim_end_matches('/').to_string(),
        oauth_authorizations: Mutex::new(HashMap::new()),
        oauth_codes: Mutex::new(HashMap::new()),
        store,
        recovery_reservations,
    });
    let app = Router::new()
        .route("/health", get(health))
        .route(
            "/chatgpt/bounty-card-preview",
            get(chatgpt_bounty_card_preview),
        )
        .route("/chatgpt/favicon.svg", get(chatgpt_favicon))
        .route(
            "/public/bounty-images/:sha256",
            get(public_bounty_image_asset),
        )
        .route("/llms.txt", get(llms_txt))
        .route(
            "/.well-known/openai-apps-challenge",
            get(openai_apps_challenge),
        )
        .route("/.well-known/glama.json", get(glama_claim_challenge))
        .route(
            "/schemas/discovery-manifest.v2.json",
            get(discovery_manifest_schema),
        )
        .route(
            "/.well-known/agent-bounties.json",
            get(agent_bounties_discovery),
        )
        .route(
            "/.well-known/oauth-protected-resource",
            get(oauth_protected_resource),
        )
        .route(
            "/.well-known/oauth-authorization-server",
            get(oauth_authorization_server),
        )
        .route("/oauth/register", post(oauth_register))
        .route(
            "/oauth/authorize",
            get(oauth_authorize).post(oauth_authorize_submit),
        )
        .route("/oauth/token", post(oauth_token))
        .route(
            "/mcp",
            get(chatgpt_app::mcp_get)
                .post(chatgpt_app::mcp_post)
                .delete(chatgpt_app::mcp_delete),
        )
        .route(
            "/r/:rail/mcp",
            get(chatgpt_app::attributed_mcp_get)
                .post(chatgpt_app::attributed_mcp_post)
                .delete(chatgpt_app::attributed_mcp_delete),
        )
        .route(
            "/v1/onramps/moonpay/checkout",
            post(moonpay::prepare_checkout),
        )
        .route("/tools", get(tools))
        .route("/tools/route_blocked_goal", post(route_blocked_goal))
        .route(
            "/tools/plan_objective_creation",
            post(plan_objective_creation),
        )
        .route("/tools/create_objective", post(create_objective))
        .route("/tools/list_objectives", get(list_objectives))
        .route("/tools/get_objective", post(get_objective))
        .route("/tools/plan_objective_action", post(plan_objective_action))
        .route(
            "/tools/apply_objective_action",
            post(apply_objective_action),
        )
        .route("/tools/reconcile_objective", post(reconcile_objective))
        .route("/tools/prepare_bounty_post", post(prepare_bounty_post))
        .route(
            "/tools/publish_unfunded_bounty",
            post(publish_unfunded_bounty),
        )
        .route(
            "/tools/list_unfunded_bounties",
            post(list_unfunded_bounties),
        )
        .route(
            "/tools/submit_unfunded_bounty_solution",
            post(submit_unfunded_bounty_solution),
        )
        .route(
            "/tools/draft_bounty_with_cloud_agent",
            post(retired_generation_http),
        )
        .route(
            "/tools/compile_objective_with_cloud_agent",
            post(retired_generation_http),
        )
        .route(
            "/tools/get_autonomous_inventory_summary",
            post(get_autonomous_inventory_summary),
        )
        .route(
            "/tools/get_solver_leaderboard",
            post(get_solver_leaderboard),
        )
        .route("/tools/register_agent", post(register_agent))
        .route("/tools/register_capability", post(register_capability))
        .route("/tools/search_capabilities", post(search_capabilities))
        .route("/tools/request_quotes", post(request_quotes))
        .route("/tools/fund_quote_as_bounty", post(fund_quote_as_bounty))
        .route("/tools/post_bounty", post(post_bounty))
        .route("/tools/open_pooled_bounty", post(open_pooled_bounty))
        .route("/tools/create_funding_intent", post(create_funding_intent))
        .route("/tools/add_bounty_funding", post(add_bounty_funding))
        .route(
            "/tools/list_claimable_bounties",
            get(list_claimable_bounties),
        )
        .route("/tools/claim_bounty", post(claim_bounty))
        .route("/tools/submit_result", post(submit_result))
        .route("/tools/request_verification", post(request_verification))
        .route("/tools/get_bounty_status", post(get_bounty_status))
        .route("/tools/get_paid_status", post(get_paid_status))
        .route(
            "/tools/plan_stripe_checkout_top_up",
            post(plan_stripe_checkout_top_up),
        )
        .route(
            "/tools/plan_stripe_connect_account",
            post(plan_stripe_connect_account),
        )
        .route(
            "/tools/plan_stripe_connect_transfer",
            post(plan_stripe_connect_transfer),
        )
        .route(
            "/tools/execute_stripe_checkout_top_up",
            post(execute_stripe_checkout_top_up),
        )
        .route(
            "/tools/execute_stripe_connect_account",
            post(execute_stripe_connect_account),
        )
        .route(
            "/tools/execute_stripe_connect_transfer",
            post(execute_stripe_connect_transfer),
        )
        .route(
            "/tools/reconcile_stripe_connect_snapshot",
            post(reconcile_stripe_connect_snapshot),
        )
        .route(
            "/tools/reconcile_stripe_transfer_event",
            post(reconcile_stripe_transfer_event),
        )
        .route(
            "/tools/reconcile_stripe_checkout_webhook",
            post(reconcile_stripe_checkout_webhook),
        )
        .route(
            "/tools/plan_github_issue_bounty",
            post(plan_github_issue_bounty),
        )
        .route(
            "/tools/plan_github_create_comment",
            post(plan_github_create_comment),
        )
        .route(
            "/tools/plan_github_funding_comment",
            post(plan_github_funding_comment),
        )
        .route(
            "/tools/plan_github_claim_comment",
            post(plan_github_claim_comment),
        )
        .route(
            "/tools/plan_social_mention_draft",
            post(plan_social_mention_draft),
        )
        .route(
            "/tools/plan_github_proof_comment",
            post(plan_github_proof_comment),
        )
        .route(
            "/tools/plan_github_proof_comment_for_proof",
            post(plan_github_proof_comment_for_proof),
        )
        .route(
            "/tools/broadcast_base_signed_transaction",
            post(broadcast_base_signed_transaction),
        )
        .route(
            "/tools/get_base_transaction_receipt",
            post(get_base_transaction_receipt),
        )
        .route(
            "/tools/plan_autonomous_canonical_child_terms",
            post(plan_autonomous_canonical_child_terms),
        )
        .route(
            "/tools/prepare_standing_meta_v2_child",
            post(prepare_standing_meta_v2_child),
        )
        .route(
            "/tools/plan_autonomous_bounty_creation",
            post(plan_autonomous_bounty_creation),
        )
        .route(
            "/tools/plan_autonomous_bounty_authorized_creation",
            post(plan_autonomous_bounty_authorized_creation),
        )
        .route(
            "/tools/plan_autonomous_bounty_contribution",
            post(plan_autonomous_bounty_contribution),
        )
        .route(
            "/tools/plan_autonomous_bounty_authorized_contribution",
            post(plan_autonomous_bounty_authorized_contribution),
        )
        .route("/tools/fund_bounty_with_x402", post(fund_bounty_with_x402))
        .route("/tools/get_x402_relay_status", post(get_x402_relay_status))
        .route("/tools/prepare_agent_to_earn", post(prepare_agent_to_earn))
        .route(
            "/tools/list_open_competition_verifiers",
            post(list_open_competition_verifiers),
        )
        .route(
            "/tools/prepare_open_competition_creation",
            post(prepare_open_competition_creation),
        )
        .route(
            "/tools/get_open_competition_readiness",
            post(get_open_competition_readiness),
        )
        .route(
            "/tools/prepare_open_competition_commit",
            post(prepare_open_competition_commit),
        )
        .route(
            "/tools/prepare_open_competition_reveal",
            post(prepare_open_competition_reveal),
        )
        .route(
            "/tools/get_open_competition_status",
            post(get_open_competition_status),
        )
        .route(
            "/tools/withdraw_open_competition_bond",
            post(withdraw_open_competition_bond),
        )
        .route(
            "/tools/prepare_open_competition_entrant_action",
            post(prepare_open_competition_entrant_action),
        )
        .route(
            "/tools/relay_open_competition_entrant_action",
            post(relay_open_competition_entrant_action),
        )
        .route(
            "/tools/get_open_competition_entrant_relay",
            post(get_open_competition_entrant_relay),
        )
        .route(
            "/tools/inspect_open_competition_v2",
            post(inspect_open_competition_v2),
        )
        .route(
            "/tools/prepare_open_competition_v2",
            post(prepare_open_competition_v2),
        )
        .route(
            "/tools/get_standing_meta_v4_readiness",
            post(get_standing_meta_v4_readiness),
        )
        .route(
            "/tools/prepare_standing_meta_v4_claim",
            post(prepare_standing_meta_v4_claim),
        )
        .route(
            "/tools/prepare_anonymous_stake_registration",
            post(prepare_anonymous_stake_registration),
        )
        .route(
            "/tools/set_anonymous_stake_availability",
            post(set_anonymous_stake_availability),
        )
        .route(
            "/tools/list_verification_assignments",
            post(list_verification_assignments),
        )
        .route(
            "/tools/submit_primary_verdict",
            post(submit_primary_verdict),
        )
        .route(
            "/tools/waive_verification_appeal",
            post(waive_verification_appeal),
        )
        .route(
            "/tools/open_verification_appeal",
            post(open_verification_appeal),
        )
        .route("/tools/submit_appeal_vote", post(submit_appeal_vote))
        .route(
            "/tools/finalize_verification_case",
            post(finalize_verification_case),
        )
        .route(
            "/tools/plan_autonomous_bounty_claim",
            post(plan_autonomous_bounty_claim),
        )
        .route("/tools/agent_native_claim", post(agent_native_claim))
        .route(
            "/tools/plan_autonomous_bounty_authorized_claim",
            post(plan_autonomous_bounty_authorized_claim),
        )
        .route(
            "/tools/plan_autonomous_bounty_submission",
            post(plan_autonomous_bounty_submission),
        )
        .route(
            "/tools/prepare_autonomous_bounty_submission",
            post(prepare_autonomous_bounty_submission),
        )
        .route(
            "/tools/plan_autonomous_bounty_submission_authorization",
            post(plan_autonomous_bounty_submission_authorization),
        )
        .route(
            "/tools/plan_autonomous_verification_attestation",
            post(plan_autonomous_verification_attestation),
        )
        .route(
            "/tools/plan_autonomous_module_settlement",
            post(plan_autonomous_module_settlement),
        )
        .route(
            "/tools/plan_autonomous_attestation_settlement",
            post(plan_autonomous_attestation_settlement),
        )
        .route(
            "/tools/plan_autonomous_expire_claim",
            post(plan_autonomous_expire_claim),
        )
        .route(
            "/tools/plan_autonomous_expire_submission",
            post(plan_autonomous_expire_submission),
        )
        .route(
            "/tools/plan_autonomous_cancel",
            post(plan_autonomous_cancel),
        )
        .route(
            "/tools/plan_autonomous_refund_withdrawal",
            post(plan_autonomous_refund_withdrawal),
        )
        .route(
            "/tools/plan_bounded_wallet_cancel_refund",
            post(plan_bounded_wallet_cancel_refund),
        )
        .route(
            "/tools/decode_autonomous_bounty_events",
            post(decode_autonomous_bounty_events),
        )
        .route(
            "/tools/list_autonomous_bounty_events",
            post(list_autonomous_bounty_events),
        )
        .route(
            "/tools/publish_autonomous_bounty_terms",
            post(publish_autonomous_bounty_terms),
        )
        .route(
            "/tools/get_autonomous_bounty_terms",
            post(get_autonomous_bounty_terms),
        )
        .route(
            "/tools/publish_autonomous_submission_evidence",
            post(publish_autonomous_submission_evidence),
        )
        .route(
            "/tools/get_autonomous_submission_evidence",
            post(get_autonomous_submission_evidence),
        )
        .route(
            "/tools/list_autonomous_bounties",
            post(list_autonomous_bounties),
        )
        .route("/tools/list_opportunities", post(list_opportunities))
        .route(
            "/tools/create_discovery_subscription",
            post(create_discovery_subscription),
        )
        .route(
            "/tools/get_discovery_subscription",
            post(get_discovery_subscription),
        )
        .route(
            "/tools/delete_discovery_subscription",
            post(delete_discovery_subscription),
        )
        .route(
            "/tools/get_opportunity_conversion_funnel",
            post(get_opportunity_conversion_funnel),
        )
        .route("/tools/get_site_analytics", post(get_site_analytics))
        .route("/tools/analyze_bounty_fit", post(retired_generation_http))
        .route(
            "/tools/list_autonomous_verification_jobs",
            post(list_autonomous_verification_jobs),
        )
        .route("/tools/run_bountybench", get(run_bountybench))
        .route("/tools/run_abusebench", get(run_abusebench))
        .route("/tools/run_judgebench", get(run_judgebench))
        .route("/tools/run_eval_loops", get(run_eval_loops))
        .route("/tools/get_eval_runs", get(get_eval_runs))
        .route("/tools/get_risk_policy", get(get_risk_policy))
        .route(
            "/tools/get_live_money_readiness",
            post(get_live_money_readiness),
        )
        .route("/tools/list_risk_events", post(list_risk_events))
        .route("/tools/list_risk_reviews", get(list_risk_reviews))
        .route("/tools/approve_risk_bounty", post(approve_risk_bounty))
        .route("/tools/approve_risk_payout", post(approve_risk_payout))
        .route("/tools/reject_risk_event", post(reject_risk_event))
        .layer(middleware::from_fn_with_state(
            state.clone(),
            observe_mcp_http_adapter,
        ))
        .layer(CorsLayer::permissive())
        .layer(middleware::from_fn(protect_mcp_responses))
        .layer(middleware::from_fn(observe_http_errors))
        .with_state(state);

    let bind_addr = service_bind_addr(
        env::var("MCP_BIND_ADDR").ok().as_deref(),
        env::var("PORT").ok().as_deref(),
        "127.0.0.1:8090",
    );
    let listener = tokio::net::TcpListener::bind(bind_addr).await?;
    axum::serve(listener, app).await?;
    Ok(())
}

fn service_bind_addr(configured: Option<&str>, port: Option<&str>, default_addr: &str) -> String {
    configured
        .filter(|value| !value.trim().is_empty())
        .map(str::to_string)
        .or_else(|| {
            port.filter(|value| !value.trim().is_empty())
                .map(|value| format!("0.0.0.0:{}", value.trim()))
        })
        .unwrap_or_else(|| default_addr.to_string())
}

fn is_mcp_http_adapter_path(path: &str) -> bool {
    path == "/tools" || path.starts_with("/tools/")
}

async fn protect_mcp_responses(request: Request, next: Next) -> Response {
    let path = request.uri().path();
    let private = path == "/mcp"
        || path.starts_with("/mcp/")
        || (path.starts_with("/r/") && path.ends_with("/mcp"))
        || is_mcp_http_adapter_path(path)
        || ["authorization", "cookie", "x-operator-token"]
            .iter()
            .any(|name| request.headers().contains_key(*name));
    let mut response = next.run(request).await;
    if private {
        response.headers_mut().insert(
            header::CACHE_CONTROL,
            HeaderValue::from_static("no-store, private"),
        );
        response.headers_mut().append(
            header::VARY,
            HeaderValue::from_static("Authorization, Cookie, X-Operator-Token"),
        );
    }
    response
}

fn mcp_discovery_route_family(path: &str) -> Option<DiscoveryRouteFamily> {
    match path {
        "/tools" => Some(DiscoveryRouteFamily::ProtocolOrientation),
        "/tools/list_opportunities"
        | "/tools/list_claimable_bounties"
        | "/tools/list_autonomous_bounties"
        | "/tools/list_unfunded_bounties"
        | "/tools/get_autonomous_inventory_summary" => Some(DiscoveryRouteFamily::OpportunityList),
        "/tools/get_bounty_status"
        | "/tools/get_paid_status"
        | "/tools/get_autonomous_bounty_terms"
        | "/tools/get_open_competition_status"
        | "/tools/get_open_competition_readiness"
        | "/tools/analyze_bounty_fit" => Some(DiscoveryRouteFamily::OpportunityDetail),
        "/tools/create_discovery_subscription"
        | "/tools/get_discovery_subscription"
        | "/tools/delete_discovery_subscription" => Some(DiscoveryRouteFamily::Alerts),
        _ => None,
    }
}

async fn observe_mcp_http_adapter(
    State(state): State<SharedState>,
    request: Request,
    next: Next,
) -> Response {
    let observed = is_mcp_http_adapter_path(request.uri().path());
    let discovery_route = mcp_discovery_route_family(request.uri().path());
    let excluded = analytics_exclusion_is_authorized(&state, request.headers());
    let mut response = next.run(request).await;
    attest_analytics_exclusion(&mut response, observed && excluded);
    if observed && !excluded {
        if let Some(store) = state.store.clone() {
            let succeeded = response.status().is_success();
            tokio::spawn(async move {
                let _ = store
                    .record_interface_usage(
                        ObservedInterface::Mcp,
                        ObservedProtocolEra::McpHttpAdapter,
                        succeeded,
                        Utc::now(),
                    )
                    .await;
            });
        }
        if let (Some(store), Some(route_family)) = (state.store.clone(), discovery_route) {
            let succeeded = response.status().is_success();
            tokio::spawn(async move {
                let _ = store
                    .record_discovery_route_usage(
                        DiscoveryInterface::Mcp,
                        route_family,
                        AttributionReliability::Observed,
                        succeeded,
                        Utc::now(),
                    )
                    .await;
            });
        }
    }
    response
}

async fn agent_bounties_discovery() -> Json<web_public::DiscoveryManifest> {
    let api_base_url = public_base_url_from_env();
    let mcp_base_url = mcp_base_url_from_env();
    Json(web_public::discovery_manifest(&api_base_url, &mcp_base_url))
}

async fn llms_txt() -> String {
    let api_base_url = public_base_url_from_env();
    let mcp_base_url = mcp_base_url_from_env();
    web_public::render_llms_txt(&api_base_url, &mcp_base_url)
}

async fn openai_apps_challenge() -> impl IntoResponse {
    openai_apps_challenge_response(env::var("OPENAI_APPS_CHALLENGE_TOKEN").ok())
}

fn openai_apps_challenge_response(configured: Option<String>) -> (StatusCode, HeaderMap, String) {
    let token = configured.map(|value| value.trim().to_string());
    let valid = token.as_deref().is_some_and(|value| {
        (8..=512).contains(&value.len())
            && value.chars().all(|character| character.is_ascii_graphic())
    });
    if !valid {
        return (StatusCode::NOT_FOUND, HeaderMap::new(), String::new());
    }
    let mut headers = HeaderMap::new();
    headers.insert(
        header::CONTENT_TYPE,
        HeaderValue::from_static("text/plain; charset=utf-8"),
    );
    headers.insert(header::CACHE_CONTROL, HeaderValue::from_static("no-store"));
    (
        StatusCode::OK,
        headers,
        token.expect("validated challenge token"),
    )
}

async fn glama_claim_challenge() -> impl IntoResponse {
    glama_claim_challenge_response(env::var("GLAMA_CLAIM_TOKEN").ok())
}

fn glama_claim_challenge_response(configured: Option<String>) -> (StatusCode, HeaderMap, String) {
    let token = configured.map(|value| value.trim().to_string());
    let valid = token.as_deref().is_some_and(|value| {
        (16..=512).contains(&value.len())
            && value.starts_with("glama_claim_")
            && value.chars().all(|character| {
                character.is_ascii_alphanumeric() || matches!(character, '_' | '-')
            })
    });
    if !valid {
        return (StatusCode::NOT_FOUND, HeaderMap::new(), String::new());
    }
    let mut headers = HeaderMap::new();
    headers.insert(
        header::CONTENT_TYPE,
        HeaderValue::from_static("application/json; charset=utf-8"),
    );
    headers.insert(header::CACHE_CONTROL, HeaderValue::from_static("no-store"));
    (
        StatusCode::OK,
        headers,
        json!({
            "$schema": "https://glama.ai/mcp/schemas/connector.json",
            "claim": token.expect("validated Glama claim token"),
        })
        .to_string(),
    )
}

#[derive(Debug, Clone, Deserialize)]
struct OAuthAuthorizationQuery {
    response_type: String,
    client_id: String,
    redirect_uri: String,
    code_challenge: String,
    code_challenge_method: String,
    scope: String,
    state: Option<String>,
    resource: Option<String>,
}

#[derive(Debug, Clone)]
struct PendingOAuthAuthorization {
    client_id: String,
    redirect_uri: String,
    code_challenge: String,
    scope: String,
    state: Option<String>,
    resource: String,
    expires_at: chrono::DateTime<Utc>,
}

#[derive(Debug, Clone)]
struct OAuthAuthorizationCode {
    client_id: String,
    redirect_uri: String,
    code_challenge: String,
    scope: String,
    resource: String,
    expires_at: chrono::DateTime<Utc>,
}

#[derive(Debug, Deserialize)]
struct OAuthAuthorizationForm {
    request_id: String,
    link_token: String,
}

#[derive(Debug, Deserialize)]
struct OAuthTokenRequest {
    grant_type: String,
    code: String,
    redirect_uri: String,
    client_id: String,
    code_verifier: String,
    resource: Option<String>,
}

#[derive(Debug, Serialize, Deserialize)]
struct AnalyticsOAuthClaims {
    iss: String,
    aud: String,
    scope: String,
    iat: i64,
    exp: i64,
}

fn analytics_oauth_access_token(
    secret: &str,
    audience: &str,
    now: chrono::DateTime<Utc>,
) -> Result<String, &'static str> {
    let claims = AnalyticsOAuthClaims {
        iss: audience.to_string(),
        aud: audience.to_string(),
        scope: ANALYTICS_EXCLUSION_SCOPE.to_string(),
        iat: now.timestamp(),
        exp: now.timestamp() + ANALYTICS_OAUTH_TOKEN_LIFETIME_SECONDS,
    };
    let payload = URL_SAFE_NO_PAD
        .encode(serde_json::to_vec(&claims).map_err(|_| "OAuth claims could not be encoded")?);
    let signed = format!("{ANALYTICS_OAUTH_TOKEN_PREFIX}.{payload}");
    let mut mac = AnalyticsHmacSha256::new_from_slice(secret.as_bytes())
        .map_err(|_| "OAuth signing key is invalid")?;
    mac.update(signed.as_bytes());
    Ok(format!(
        "{signed}.{}",
        URL_SAFE_NO_PAD.encode(mac.finalize().into_bytes())
    ))
}

fn analytics_oauth_access_token_is_authorized(
    secret: &str,
    token: &str,
    audience: &str,
    now: chrono::DateTime<Utc>,
) -> bool {
    if token.len() > 2048 {
        return false;
    }
    let mut segments = token.split('.');
    let (Some(prefix), Some(payload), Some(signature), None) = (
        segments.next(),
        segments.next(),
        segments.next(),
        segments.next(),
    ) else {
        return false;
    };
    if prefix != ANALYTICS_OAUTH_TOKEN_PREFIX {
        return false;
    }
    let Ok(signature) = URL_SAFE_NO_PAD.decode(signature) else {
        return false;
    };
    let Ok(mut mac) = AnalyticsHmacSha256::new_from_slice(secret.as_bytes()) else {
        return false;
    };
    mac.update(format!("{prefix}.{payload}").as_bytes());
    if mac.verify_slice(&signature).is_err() {
        return false;
    }
    let Ok(payload) = URL_SAFE_NO_PAD.decode(payload) else {
        return false;
    };
    let Ok(claims) = serde_json::from_slice::<AnalyticsOAuthClaims>(&payload) else {
        return false;
    };
    claims.iss == audience
        && claims.aud == audience
        && claims.scope == ANALYTICS_EXCLUSION_SCOPE
        && claims.iat <= now.timestamp() + 60
        && claims.exp > now.timestamp()
        && claims.exp - claims.iat == ANALYTICS_OAUTH_TOKEN_LIFETIME_SECONDS
}

#[derive(Debug, Deserialize)]
struct OAuthRegistrationRequest {
    redirect_uris: Vec<String>,
    #[serde(default)]
    grant_types: Vec<String>,
    #[serde(default)]
    response_types: Vec<String>,
    token_endpoint_auth_method: Option<String>,
}

async fn oauth_protected_resource(State(state): State<SharedState>) -> Response {
    if state.analytics_exclusion_token.is_none() {
        return StatusCode::NOT_FOUND.into_response();
    }
    let resource = state.mcp_base_url.clone();
    Json(json!({
        "resource": resource,
        "authorization_servers": [resource],
        "scopes_supported": [ANALYTICS_EXCLUSION_SCOPE],
        "resource_documentation": "https://agentbounties.app/docs/interaction-guide.html"
    }))
    .into_response()
}

async fn oauth_authorization_server(State(state): State<SharedState>) -> Response {
    if state.analytics_exclusion_token.is_none() {
        return StatusCode::NOT_FOUND.into_response();
    }
    let issuer = state.mcp_base_url.clone();
    Json(json!({
        "issuer": issuer,
        "authorization_endpoint": format!("{issuer}/oauth/authorize"),
        "token_endpoint": format!("{issuer}/oauth/token"),
        "registration_endpoint": format!("{issuer}/oauth/register"),
        "scopes_supported": [ANALYTICS_EXCLUSION_SCOPE],
        "response_types_supported": ["code"],
        "response_modes_supported": ["query"],
        "grant_types_supported": ["authorization_code"],
        "code_challenge_methods_supported": ["S256"],
        "token_endpoint_auth_methods_supported": ["none"],
        "client_id_metadata_document_supported": true
    }))
    .into_response()
}

fn valid_chatgpt_oauth_redirect(value: &str) -> bool {
    if value.len() > 512 {
        return false;
    }
    let Ok(url) = Url::parse(value) else {
        return false;
    };
    if url.scheme() != "https"
        || url.host_str() != Some("chatgpt.com")
        || url.query().is_some()
        || url.fragment().is_some()
    {
        return false;
    }
    url.path() == "/connector_platform_oauth_redirect"
        || url
            .path()
            .strip_prefix("/connector/oauth/")
            .is_some_and(|callback_id| {
                !callback_id.is_empty()
                    && callback_id.len() <= 200
                    && callback_id
                        .bytes()
                        .all(|byte| byte.is_ascii_alphanumeric() || matches!(byte, b'-' | b'_'))
            })
}

fn valid_oauth_client_id(value: &str) -> bool {
    if value.len() > 1024 {
        return false;
    }
    value
        .strip_prefix("agent-bounties-chatgpt-")
        .is_some_and(|id| Uuid::parse_str(id).is_ok())
        || Url::parse(value).is_ok_and(|url| {
            url.scheme() == "https"
                && url.host_str() == Some("chatgpt.com")
                && url.path().starts_with("/oauth/")
        })
}

fn oauth_scope_is_valid(scope: &str) -> bool {
    scope
        .split_ascii_whitespace()
        .eq([ANALYTICS_EXCLUSION_SCOPE])
}

async fn oauth_register(
    State(state): State<SharedState>,
    Json(request): Json<OAuthRegistrationRequest>,
) -> Response {
    if state.analytics_exclusion_token.is_none() {
        return StatusCode::NOT_FOUND.into_response();
    }
    if request.redirect_uris.len() != 1
        || !valid_chatgpt_oauth_redirect(&request.redirect_uris[0])
        || (!request.grant_types.is_empty()
            && request.grant_types != ["authorization_code".to_string()])
        || (!request.response_types.is_empty() && request.response_types != ["code".to_string()])
        || request
            .token_endpoint_auth_method
            .as_deref()
            .is_some_and(|method| method != "none")
    {
        return (
            StatusCode::BAD_REQUEST,
            Json(json!({"error": "invalid_client_metadata"})),
        )
            .into_response();
    }
    let client_id = format!("agent-bounties-chatgpt-{}", Uuid::new_v4());
    (
        StatusCode::CREATED,
        Json(json!({
            "client_id": client_id,
            "client_id_issued_at": Utc::now().timestamp(),
            "redirect_uris": request.redirect_uris,
            "grant_types": ["authorization_code"],
            "response_types": ["code"],
            "token_endpoint_auth_method": "none"
        })),
    )
        .into_response()
}

fn validate_oauth_authorization_request(request: &OAuthAuthorizationQuery, resource: &str) -> bool {
    request.response_type == "code"
        && valid_oauth_client_id(&request.client_id)
        && valid_chatgpt_oauth_redirect(&request.redirect_uri)
        && request.code_challenge_method == "S256"
        && (43..=128).contains(&request.code_challenge.len())
        && request
            .code_challenge
            .bytes()
            .all(|byte| byte.is_ascii_alphanumeric() || matches!(byte, b'-' | b'_'))
        && oauth_scope_is_valid(&request.scope)
        && request
            .state
            .as_ref()
            .is_none_or(|state| state.len() <= 512)
        && request.resource.as_deref() == Some(resource)
}

async fn oauth_authorize(
    State(state): State<SharedState>,
    Query(request): Query<OAuthAuthorizationQuery>,
) -> Response {
    if state.analytics_exclusion_token.is_none() {
        return StatusCode::NOT_FOUND.into_response();
    }
    let resource = state.mcp_base_url.clone();
    if !validate_oauth_authorization_request(&request, &resource) {
        return (
            StatusCode::BAD_REQUEST,
            Json(json!({
                "error": "invalid_request",
                "error_description": "ChatGPT OAuth requires an approved callback, resource, scope, and S256 PKCE challenge."
            })),
        )
            .into_response();
    }
    let request_id = Uuid::new_v4().to_string();
    let now = Utc::now();
    let accepted = {
        let mut pending = state
            .oauth_authorizations
            .lock()
            .expect("OAuth authorization mutex poisoned");
        pending.retain(|_, authorization| authorization.expires_at > now);
        if pending.len() >= MAX_PENDING_OAUTH_AUTHORIZATIONS {
            false
        } else {
            pending.insert(
                request_id.clone(),
                PendingOAuthAuthorization {
                    client_id: request.client_id,
                    redirect_uri: request.redirect_uri,
                    code_challenge: request.code_challenge,
                    scope: request.scope,
                    state: request.state,
                    resource,
                    expires_at: now + chrono::Duration::minutes(5),
                },
            );
            true
        }
    };
    if !accepted {
        return (
            StatusCode::TOO_MANY_REQUESTS,
            [(header::CACHE_CONTROL, "no-store")],
            "Too many pending authorization requests. Retry shortly.",
        )
            .into_response();
    }
    let html = format!(
        "<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Link operator analytics exclusion</title><style>body{{font:16px system-ui;background:#101410;color:#f4f7ee;max-width:42rem;margin:8vh auto;padding:2rem}}main{{border:1px solid #3f4b3f;border-radius:16px;padding:2rem}}label,input,button{{display:block;width:100%;box-sizing:border-box}}input,button{{margin-top:.6rem;padding:.8rem;border-radius:8px}}button{{background:#c8ff45;color:#101410;font-weight:700;border:0;margin-top:1rem}}</style></head><body><main><h1>Exclude this private connector from public usage</h1><p>Linking adds only the <code>{ANALYTICS_EXCLUSION_SCOPE}</code> scope. It grants no operator, wallet, payment, or mutation authority.</p><form method=\"post\" action=\"/oauth/authorize\"><input type=\"hidden\" name=\"request_id\" value=\"{request_id}\"><label for=\"link_token\">Analytics exclusion link token</label><input id=\"link_token\" name=\"link_token\" type=\"password\" autocomplete=\"off\" required><button type=\"submit\">Link private connector</button></form></main></body></html>"
    );
    let mut headers = HeaderMap::new();
    headers.insert(
        header::CONTENT_TYPE,
        HeaderValue::from_static("text/html; charset=utf-8"),
    );
    headers.insert(header::CACHE_CONTROL, HeaderValue::from_static("no-store"));
    headers.insert(
        "content-security-policy",
        HeaderValue::from_static(
            "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'",
        ),
    );
    (headers, html).into_response()
}

async fn oauth_authorize_submit(
    State(state): State<SharedState>,
    Form(form): Form<OAuthAuthorizationForm>,
) -> Response {
    let Some(configured) = state.analytics_exclusion_token.as_deref() else {
        return StatusCode::NOT_FOUND.into_response();
    };
    if !(64..=256).contains(&form.link_token.len())
        || form
            .link_token
            .bytes()
            .any(|byte| byte.is_ascii_whitespace())
    {
        return (
            StatusCode::UNAUTHORIZED,
            [(header::CACHE_CONTROL, "no-store")],
            "The analytics exclusion link token was not accepted.",
        )
            .into_response();
    }
    if !service_runtime::operator_token_is_authorized(
        Some(configured),
        Some(form.link_token.trim()),
        None,
    ) {
        return (
            StatusCode::UNAUTHORIZED,
            [(header::CACHE_CONTROL, "no-store")],
            "The analytics exclusion link token was not accepted.",
        )
            .into_response();
    }
    let now = Utc::now();
    let authorization = {
        let mut pending = state
            .oauth_authorizations
            .lock()
            .expect("OAuth authorization mutex poisoned");
        pending.retain(|_, authorization| authorization.expires_at > now);
        pending.remove(&form.request_id)
    };
    let Some(authorization) = authorization else {
        return (
            StatusCode::BAD_REQUEST,
            [(header::CACHE_CONTROL, "no-store")],
            "The authorization request expired or was already used.",
        )
            .into_response();
    };
    let code = Uuid::new_v4().to_string();
    state
        .oauth_codes
        .lock()
        .expect("OAuth code mutex poisoned")
        .insert(
            code.clone(),
            OAuthAuthorizationCode {
                client_id: authorization.client_id,
                redirect_uri: authorization.redirect_uri.clone(),
                code_challenge: authorization.code_challenge,
                scope: authorization.scope,
                resource: authorization.resource,
                expires_at: now + chrono::Duration::minutes(2),
            },
        );
    let mut redirect = Url::parse(&authorization.redirect_uri)
        .expect("validated ChatGPT redirect URI must remain valid");
    redirect.query_pairs_mut().append_pair("code", &code);
    if let Some(value) = authorization.state {
        redirect.query_pairs_mut().append_pair("state", &value);
    }
    Redirect::to(redirect.as_str()).into_response()
}

async fn oauth_token(
    State(state): State<SharedState>,
    Form(request): Form<OAuthTokenRequest>,
) -> Response {
    let Some(signing_secret) = state.analytics_exclusion_token.as_deref() else {
        return StatusCode::NOT_FOUND.into_response();
    };
    let authorization = state
        .oauth_codes
        .lock()
        .expect("OAuth code mutex poisoned")
        .remove(&request.code);
    let Some(authorization) = authorization else {
        return oauth_token_error("invalid_grant", "Authorization code is invalid or expired.");
    };
    if !(43..=128).contains(&request.code_verifier.len())
        || !request
            .code_verifier
            .bytes()
            .all(|byte| byte.is_ascii_alphanumeric() || matches!(byte, b'-' | b'_' | b'.' | b'~'))
    {
        return oauth_token_error("invalid_grant", "PKCE verifier is malformed.");
    }
    let challenge = URL_SAFE_NO_PAD.encode(Sha256::digest(request.code_verifier.as_bytes()));
    if request.grant_type != "authorization_code"
        || authorization.expires_at <= Utc::now()
        || request.client_id != authorization.client_id
        || request.redirect_uri != authorization.redirect_uri
        || request.resource.as_deref() != Some(authorization.resource.as_str())
        || challenge != authorization.code_challenge
    {
        return oauth_token_error(
            "invalid_grant",
            "Authorization code binding or PKCE verification failed.",
        );
    }
    let access_token =
        match analytics_oauth_access_token(signing_secret, &authorization.resource, Utc::now()) {
            Ok(token) => token,
            Err(description) => return oauth_token_error("server_error", description),
        };
    let mut response = Json(json!({
        "access_token": access_token,
        "token_type": "Bearer",
        "expires_in": ANALYTICS_OAUTH_TOKEN_LIFETIME_SECONDS,
        "scope": authorization.scope
    }))
    .into_response();
    response
        .headers_mut()
        .insert(header::CACHE_CONTROL, HeaderValue::from_static("no-store"));
    response
}

fn oauth_token_error(error: &str, description: &str) -> Response {
    let mut response = (
        StatusCode::BAD_REQUEST,
        Json(json!({"error": error, "error_description": description})),
    )
        .into_response();
    response
        .headers_mut()
        .insert(header::CACHE_CONTROL, HeaderValue::from_static("no-store"));
    response
}

fn public_base_url_from_env() -> String {
    env::var("PUBLIC_BASE_URL").unwrap_or_else(|_| "http://127.0.0.1:8080".to_string())
}

// An operator-configured service URL; never accept an upstream from tool arguments.
fn api_upstream_base_url_from_env() -> String {
    env::var("API_UPSTREAM_BASE_URL")
        .ok()
        .filter(|value| !value.trim().is_empty())
        .unwrap_or_else(public_base_url_from_env)
}

fn mcp_base_url_from_env() -> String {
    env::var("MCP_BASE_URL").unwrap_or_else(|_| "http://127.0.0.1:8090".to_string())
}

async fn discovery_manifest_schema() -> impl IntoResponse {
    (
        [(header::CONTENT_TYPE, "application/schema+json")],
        web_public::discovery_manifest_schema_json(),
    )
}

async fn tools() -> Json<Vec<ToolDescriptor>> {
    Json(tool_registry![
        tool(
            "route_blocked_goal",
            "Route a blocked agent goal into a template, quote, bounty, or verification step.",
            RouteBlockedGoalArgs::input_schema(),
        ),
        tool(
            "plan_objective_creation",
            "Validate an objective declaration and return the exact EIP-191 commitment the requesting party must sign. This plans no payment and creates no state.",
            PlanObjectiveCreationArgs::input_schema(),
        ),
        tool(
            "create_objective",
            "Create one objective from an unchanged creation plan and a valid requesting-party wallet signature.",
            object_tool_schema(
                json!({
                    "plan": object_property("Exact plan returned by plan_objective_creation."),
                    "approvals": array_property(object_property("EIP-191 wallet approval with participant_id and signature."), "Requesting-party approvals.")
                }),
                &["plan", "approvals"],
            ),
        ),
        tool(
            "list_objectives",
            "List coordinated objectives with explicit role records, dependency graphs, exact readiness blockers, and canonical payment evidence boundaries.",
            empty_tool_schema(),
        ),
        tool(
            "get_objective",
            "Get one objective, its immutable accepted value bundle, contribution states, dependency graph, and next actions.",
            ObjectiveIdArgs::input_schema(),
        ),
        tool(
            "plan_objective_action",
            "Validate one objective transition and return the revision-bound EIP-191 commitment and exact signer threshold. Actions keep offers, selection, submission, verification, in-kind value, and payment distinct.",
            PlanObjectiveActionArgs::input_schema(),
        ),
        tool(
            "apply_objective_action",
            "Apply an unchanged revision-bound objective action after recovering the precommitted participant, authority, provider, contributor, or verifier wallet threshold.",
            ApplyObjectiveActionArgs::input_schema(),
        ),
        tool(
            "reconcile_objective",
            "Permissionlessly refresh paid contribution and final completion states from indexed canonical BountySettled events. Plans, signatures, submissions, hosted rows, and raw verifier responses cannot prove payment.",
            ObjectiveIdArgs::input_schema(),
        ),
        tool(
            "prepare_bounty_post",
            "Use this when a person wants their current AI assistant to prepare a reviewable Agent Bounties draft. It returns a portable card and secure review URL, moves no funds, and requests no wallet signature.",
            PrepareBountyPostArgs::input_schema(),
        ),
        tool(
            "publish_unfunded_bounty",
            "Publish caller-prepared voluntary work with an authenticated website account, wallet session, or operator credential. Reuse one idempotency key. No model is called, no solution is generated, and no payment is promised.",
            PublishUnfundedBountyArgs::input_schema(),
        ),
        tool(
            "list_unfunded_bounties",
            "List voluntary requests. They are not claimable and promise no payment.",
            ListUnfundedBountiesArgs::input_schema(),
        ),
        tool(
            "submit_unfunded_bounty_solution",
            "Submit public voluntary work using the authenticated principal that owns the registered solver agent and controls its verified payout wallet. This creates no payment claim.",
            SubmitUnfundedBountySolutionArgs::input_schema(),
        ),
        tool(
            "get_autonomous_inventory_summary",
            "Read funded canonical work. Follow the returned next action.",
            AutonomousInventorySummaryArgs::input_schema(),
        ),
        tool(
            "get_solver_leaderboard",
            "Read today's and this week's canonical solver rankings. Follow next_action.",
            SolverLeaderboardArgs::input_schema(),
        ),
        tool(
            "register_agent",
            "Register an agent owned by the authenticated website account, wallet session, or operator. An optional payout wallet requires verified control. Use a stable Idempotency-Key header when retrying.",
            object_tool_schema(
                json!({
                    "handle": string_property("Public or local agent handle."),
                    "payout_wallet": nullable_string_property("Optional EVM payout wallet whose control has been verified for the authenticated principal.")
                }),
                &["handle"],
            ),
        ),
        tool(
            "request_quotes",
            "Create a help request and request solver quotes.",
            object_tool_schema(
                json!({
                    "requester_agent_id": uuid_property("Requester agent UUID."),
                    "goal": string_property("Work goal."),
                    "context": string_property("Work context and constraints."),
                    "budget_minor": integer_property("Budget in minor units."),
                    "currency": string_property("Currency code."),
                    "privacy": privacy_property(),
                    "required_confidence": nullable_number_property("Optional verifier confidence threshold.")
                }),
                &[
                    "requester_agent_id",
                    "goal",
                    "context",
                    "budget_minor",
                    "currency",
                    "privacy",
                ],
            ),
        ),
        tool(
            "post_bounty",
            "Post a funded bounty.",
            object_tool_schema(
                json!({
                    "title": string_property("Bounty title."),
                    "template_slug": string_property("Reusable bounty template slug."),
                    "amount_minor": integer_property("Funded amount in minor units."),
                    "currency": string_property("Currency code."),
                    "funding_mode": funding_mode_property(),
                    "privacy": privacy_property()
                }),
                &[
                    "title",
                    "template_slug",
                    "amount_minor",
                    "currency",
                    "funding_mode",
                    "privacy",
                ],
            ),
        ),
        tool(
            "open_pooled_bounty",
            "Open an unfunded pooled bounty target so multiple contributors can add funds before it becomes claimable.",
            object_tool_schema(
                json!({
                    "title": string_property("Bounty title."),
                    "template_slug": string_property("Reusable bounty template slug."),
                    "target_amount_minor": integer_property("Target amount in minor units before the bounty becomes claimable."),
                    "currency": string_property("Currency code."),
                    "funding_mode": funding_mode_property(),
                    "privacy": privacy_property()
                }),
                &[
                    "title",
                    "template_slug",
                    "target_amount_minor",
                    "currency",
                    "funding_mode",
                    "privacy",
                ],
            ),
        ),
        tool(
            "create_funding_intent",
            "Create a Stripe funding intent for a bounty. Base USDC funding uses the autonomous-v1 contract flow. The intent does not confirm funding until a verified webhook is reconciled.",
            object_tool_schema(
                json!({
                    "bounty_id": uuid_property("Bounty UUID."),
                    "contributor_agent_id": nullable_uuid_property("Optional contributor agent UUID."),
                    "source_organization_id": nullable_uuid_property("Stripe-funded organization UUID. Required for StripeFiat intents."),
                    "amount_minor": integer_property("Intent amount in minor units."),
                    "currency": string_property("Currency code for the rail partition."),
                    "rail": enum_property(&["StripeFiat"], "Stripe funding rail for this intent."),
                    "external_reference": nullable_string_property("Optional per-bounty idempotency reference for duplicate detection."),
                    "stripe_success_url": nullable_string_property("Optional Stripe Checkout success URL."),
                    "stripe_cancel_url": nullable_string_property("Optional Stripe Checkout cancel URL."),
                }),
                &["bounty_id", "amount_minor", "currency", "rail"],
            ),
        ),
        tool(
            "add_bounty_funding",
            "Add an applied funding contribution to a pooled bounty and return the updated funding summary.",
            object_tool_schema(
                json!({
                    "bounty_id": uuid_property("Pooled bounty UUID."),
                    "contributor_agent_id": nullable_uuid_property("Optional contributor agent UUID."),
                    "source_organization_id": nullable_uuid_property("Stripe-funded organization balance to reserve from when rail is StripeFiat."),
                    "amount_minor": integer_property("Contribution amount in minor units."),
                    "currency": string_property("Currency code."),
                    "rail": enum_property(&["Simulated", "StripeFiat"], "Legacy off-chain contribution rail. Base USDC uses the autonomous bounty contribution tools and canonical FundingAdded events."),
                    "external_reference": nullable_string_property("Optional per-bounty idempotency reference from the funding rail.")
                }),
                &["bounty_id", "amount_minor", "currency", "rail"],
            ),
        ),
        tool(
            "list_claimable_bounties",
            "List funded public bounty work that agents can claim immediately.",
            empty_tool_schema(),
        ),
        tool(
            "search_capabilities",
            "Search public solver capabilities before requesting quotes.",
            SearchCapabilitiesArgs::input_schema(),
        ),
        tool(
            "claim_bounty",
            "Claim claimable paid work.",
            bounty_solver_schema(),
        ),
        tool(
            "submit_result",
            "Submit an artifact and proof digest.",
            object_tool_schema(
                json!({
                    "bounty_id": uuid_property("Bounty UUID."),
                    "solver_agent_id": uuid_property("Claiming solver agent UUID."),
                    "artifact_uri": string_property("Artifact URI or location hint."),
                    "artifact_body": string_property("Artifact body used for deterministic hashing in local flows.")
                }),
                &[
                    "bounty_id",
                    "solver_agent_id",
                    "artifact_uri",
                    "artifact_body",
                ],
            ),
        ),
        tool(
            "request_verification",
            "Ask a verifier to check a submission.",
            object_tool_schema(
                json!({
                    "bounty_id": uuid_property("Bounty UUID."),
                    "submission_id": uuid_property("Submission UUID."),
                    "expected_artifact_digest": string_property("Expected SHA-256 digest for deterministic verifiers."),
                    "verifier_kind": nullable_enum_property(&[
                        "Manual",
                        "JsonSchema",
                        "DockerCommand",
                        "GitHubCi",
                        "HttpCallback",
                        "AiJudgeFilter"
                    ], "Optional verifier kind."),
                    "rubric": nullable_string_property("Optional human or AI-judge rubric."),
                    "evidence": nullable_object_property("Optional verifier evidence payload. For GitHubCi, include repository, pull_request_url, commit_sha, and check_run { id, name, status, conclusion, head_sha, html_url, repository.full_name }."),
                    "approved_risk_event_id": nullable_uuid_property("Optional approved payout risk event UUID that permits verification to continue after operator review.")
                }),
                &["bounty_id", "submission_id", "expected_artifact_digest"],
            ),
        ),
        tool(
            "get_bounty_status",
            "Read public bounty lifecycle and verification status. Private details require the resource owner or an explicitly granted participant session.",
            BountyIdArgs::input_schema(),
        ),
        tool(
            "get_paid_status",
            "Read payout status for a bounty or agent. After verified value, the response includes an ordered post_value_loop for sharing evidence, telling the human/operator, asking for a star/upvote, posting a useful bounty, and returning to funded work.",
            PaidStatusArgs::input_schema(),
        ),
        tool(
            "register_capability",
            "Publish capability and price bands for an agent owned by the authenticated caller.",
            object_tool_schema(
                json!({
                    "agent_id": uuid_property("Agent UUID."),
                    "class": enum_property(&[
                        "Coding",
                        "Research",
                        "Extraction",
                        "Verification",
                        "Documentation",
                        "Ci",
                        "BrowserWorkflow"
                    ], "Capability class."),
                    "template_slugs": string_array_property("Template slugs the agent can handle."),
                    "min_price_minor": integer_property("Minimum price in minor units."),
                    "max_price_minor": integer_property("Maximum price in minor units."),
                    "currency": string_property("Currency code."),
                    "latency_seconds": integer_property("Expected completion latency in seconds."),
                    "supported_verifiers": array_property(verifier_kind_property(), "Verifier kinds the agent supports.")
                }),
                &[
                    "agent_id",
                    "class",
                    "template_slugs",
                    "min_price_minor",
                    "max_price_minor",
                    "currency",
                    "latency_seconds",
                    "supported_verifiers",
                ],
            ),
        ),
        tool(
            "fund_quote_as_bounty",
            "Convert an accepted quote into a funded claimable bounty.",
            object_tool_schema(
                json!({
                    "quote_id": uuid_property("Quote UUID."),
                    "title": nullable_string_property("Optional bounty title override."),
                    "funding_mode": nullable_enum_property(&["Simulated", "StripeFiatLedger"], "Optional off-chain funding mode override. Base USDC uses autonomous-v1 tools.")
                }),
                &["quote_id"],
            ),
        ),
        tool(
            "plan_stripe_checkout_top_up",
            "Build a Stripe Checkout Session request intent for funding a fiat platform balance.",
            PlanStripeCheckoutTopUpArgs::input_schema(),
        ),
        tool(
            "plan_stripe_connect_account",
            "Build a Stripe Accounts v2 request intent for agent fiat payout onboarding.",
            PlanStripeConnectAccountArgs::input_schema(),
        ),
        tool(
            "plan_stripe_connect_transfer",
            "Build a Stripe Connect transfer request intent for a specific fiat payout intent. The transfer must still be executed and reconciled from Stripe evidence before payout is marked paid.",
            PlanStripeConnectTransferArgs::input_schema(),
        ),
        tool(
            "get_live_money_readiness",
            "Return non-secret Stripe/Base readiness gates for this hosted service before agents or operators rely on real-value movement.",
            LiveMoneyReadinessArgs::input_schema(),
        ),
        operator_tool(
            "execute_stripe_checkout_top_up",
            "Create a live Stripe Checkout Session for funding a fiat platform balance when operator-enabled.",
            PlanStripeCheckoutTopUpArgs::input_schema(),
            OPERATOR_TOKEN_REQUIRED_WHEN_CONFIGURED,
        ),
        operator_tool(
            "execute_stripe_connect_account",
            "Create a live Stripe Accounts v2 connected account when operator-enabled.",
            PlanStripeConnectAccountArgs::input_schema(),
            OPERATOR_TOKEN_REQUIRED_WHEN_CONFIGURED,
        ),
        operator_tool(
            "execute_stripe_connect_transfer",
            "Execute a Stripe Connect transfer for a fiat payout intent when operator-enabled. The payout is still marked paid only after transfer event reconciliation.",
            PlanStripeConnectTransferArgs::input_schema(),
            OPERATOR_TOKEN_REQUIRED_WHEN_CONFIGURED,
        ),
        operator_tool(
            "reconcile_stripe_connect_snapshot",
            "Apply Stripe Connect payout eligibility to blocked fiat payout intents.",
            object_tool_schema(
                json!({
                    "agent_id": uuid_property("Agent UUID."),
                    "connected_account_id": nullable_string_property("Stripe connected account ID."),
                    "payouts_enabled": boolean_property("Whether Stripe reports payouts enabled."),
                    "disabled_reason": nullable_string_property("Stripe disabled reason, if any."),
                    "currently_due": string_array_property("Currently due onboarding requirements.")
                }),
                &[
                    "agent_id",
                    "connected_account_id",
                    "payouts_enabled",
                    "disabled_reason",
                    "currently_due",
                ],
            ),
            OPERATOR_TOKEN_REQUIRED_WHEN_CONFIGURED,
        ),
        operator_tool(
            "reconcile_stripe_transfer_event",
            "Apply a Stripe transfer.created event as fiat payout evidence for a payout intent.",
            object_tool_schema(
                json!({
                    "id": string_property("Stripe transfer event ID."),
                    "type": string_property("Stripe event type, usually transfer.created."),
                    "payload": object_property("Normalized Stripe transfer payload with payout metadata.")
                }),
                &["id", "type", "payload"],
            ),
            OPERATOR_TOKEN_REQUIRED_WHEN_CONFIGURED,
        ),
        operator_tool(
            "reconcile_stripe_checkout_webhook",
            "Apply a paid Stripe Checkout top-up webhook to the platform ledger.",
            object_tool_schema(
                json!({
                    "id": string_property("Stripe event ID."),
                    "type": string_property("Stripe event type, usually checkout.session.completed."),
                    "payload": object_property("Normalized Stripe event payload.")
                }),
                &["id", "type", "payload"],
            ),
            OPERATOR_TOKEN_REQUIRED_WHEN_CONFIGURED,
        ),
        tool(
            "plan_github_issue_bounty",
            "Parse a GitHub paid-bounty issue form and produce check-run output for dogfooding.",
            PlanGitHubIssueBountyArgs::input_schema(),
        ),
        tool(
            "plan_github_create_comment",
            "Convert `/agent-bounty create <amount> USDC` on an existing GitHub issue into an idempotent, review-required draft and canonical wallet handoff. This never publishes terms or claims funding.",
            PlanGitHubCreateCommentArgs::input_schema(),
        ),
        tool(
            "plan_github_funding_comment",
            "Parse a GitHub public co-funding comment into an operator reconciliation signal without crediting funds.",
            PlanGitHubFundingCommentArgs::input_schema(),
        ),
        tool(
            "plan_social_mention_draft",
            "Plan a review-only bounty draft from a social mention. The hosted API keeps this disabled until an operator enables rollout and indexed canonical events prove at least three funded and two settled GitHub-originated bounties.",
            PlanSocialMentionDraftArgs::input_schema(),
        ),
        tool(
            "plan_github_claim_comment",
            "Parse a GitHub public claim or attempt comment into a reservation, stale-release, or review signal without authorizing settlement.",
            PlanGitHubClaimCommentArgs::input_schema(),
        ),
        tool(
            "plan_github_proof_comment",
            "Build a GitHub proof comment and check-run output after a bounty is accepted.",
            PlanGitHubProofCommentArgs::input_schema(),
        ),
        tool(
            "plan_github_proof_comment_for_proof",
            "Build a GitHub proof comment and check-run output from a stored public proof record.",
            PlanGitHubProofCommentForProofArgs::input_schema(),
        ),
        operator_tool(
            "broadcast_base_signed_transaction",
            "Broadcast a signed Base transaction through the configured RPC URL when operator-enabled.",
            BroadcastBaseSignedTransactionArgs::input_schema(),
            OPERATOR_TOKEN_REQUIRED_WHEN_CONFIGURED,
        ),
        tool(
            "get_base_transaction_receipt",
            "Fetch a Base transaction receipt. Canonical bounty state still comes from the autonomous indexer, not from this receipt alone.",
            GetBaseTransactionReceiptArgs::input_schema(),
        ),
        tool(
            "plan_autonomous_canonical_child_terms",
            "Validate the child task criteria and its task-specific deterministic verifier, then derive the parent-and-round benchmark commitment, minimum USDC target, and proof encoding. The parent cannot pass until a different wallet completes the child and receives canonical settlement.",
            object_tool_schema(
                json!({
                    "parent_bounty_id": string_property("Parent canonical bytes32 bounty ID."),
                    "parent_round": integer_property("Current positive parent claim round."),
                    "parent_solver": string_property("Active parent solver; this wallet must create the child."),
                    "parent_solver_reward": money_property("Parent solver reward; the child target must preserve at least this much USDC.", false),
                    "child_acceptance_criteria": {
                        "type": "array",
                        "description": "One to twenty explicit, deterministic acceptance criteria for the child task.",
                        "items": { "type": "string" },
                        "minItems": 1,
                        "maxItems": 20
                    },
                    "verifier_module": string_property("Deployed deterministic verifier for the child task. Do not pass the parent's canonical-child verifier or the leading-zero proof-of-work canary.")
                }),
                &[
                    "parent_bounty_id", "parent_round", "parent_solver", "parent_solver_reward",
                    "child_acceptance_criteria", "verifier_module"
                ],
            ),
        ),
        tool(
            "prepare_standing_meta_v2_child",
            "Prepare the exact fully funded 1 USDC regression child for a claimable routed-V3 parent. The legacy tool name is retained so existing agents do not break. It publishes immutable terms first and returns ordered wallet calls; recovery-reserved V2 and already-claimed parents fail closed.",
            object_tool_schema(
                json!({
                    "network": nullable_enum_property(&["base-mainnet"], "Optional network; routed standing-meta currently requires Base mainnet."),
                    "parent_bounty_contract": string_property("Exact claimable routed-V3 parent contract from ready-to-earn inventory."),
                    "parent_solver": string_property("Registered wallet that will publish the child terms, create/fund the child, and claim the parent."),
                    "intended_child_solver": string_property("Different pre-registered child-solver wallet whose participant ID also differs."),
                    "title": string_property("Concrete coding child title."),
                    "goal": string_property("Precise child outcome."),
                    "acceptance_criteria": {
                        "type": "array",
                        "description": "Explicit deterministic criteria evaluated by the immutable regression command.",
                        "items": {"type": "string"},
                        "minItems": 1,
                        "maxItems": 50
                    },
                    "benchmark_source": {
                        "type": "object",
                        "description": "Immutable public benchmark snapshot fetched by the verifier before execution.",
                        "properties": {
                            "kind": enum_property(&["github_commit"], "Exact supported source kind."),
                            "repository": string_property("GitHub owner/repository without a URL or .git suffix."),
                            "commit": string_property("Full 40-character Git commit SHA."),
                            "subdirectory": string_property("Normalized non-root benchmark directory inside the commit; '.', '..', absolute paths, and backslashes are rejected.")
                        },
                        "required": ["kind", "repository", "commit", "subdirectory"],
                        "additionalProperties": false
                    },
                    "runner_manifest": {
                        "type": "object",
                        "description": "Immutable sandboxed_regression_v1 runner. Image and benchmark inputs must be content-addressed; command is direct argv and never a shell.",
                        "properties": {
                            "schema_version": enum_property(&["agent-bounties/regression-sandbox-v1"], "Exact runner schema."),
                            "image": string_property("OCI image pinned with @sha256:<64 lowercase hex>."),
                            "command": string_array_property("Direct argv for the deterministic test command."),
                            "workdir": enum_property(&["/workspace"], "Fixed sandbox workdir."),
                            "benchmark_digest": string_property("sha256:<64 lowercase hex> staged benchmark snapshot digest."),
                            "timeout_seconds": integer_property("1-900 second timeout."),
                            "cpu_millis": integer_property("100-4000 CPU millicores."),
                            "memory_bytes": integer_property("64 MiB to 4 GiB memory cap."),
                            "pids_limit": integer_property("16-512 process cap."),
                            "max_output_bytes": integer_property("1024 bytes to 16 MiB output cap."),
                            "tmpfs_bytes": integer_property("64 MiB to 4 GiB tmpfs cap, not above memory."),
                            "max_source_bytes": integer_property("Maximum staged source bytes."),
                            "max_source_files": integer_property("Maximum staged source files."),
                            "max_benchmark_bytes": integer_property("Maximum staged benchmark bytes."),
                            "max_benchmark_files": integer_property("Maximum staged benchmark files."),
                            "platform": enum_property(&["linux/amd64", "linux/arm64"], "Pinned execution platform."),
                            "test_seed": integer_property("Committed deterministic test seed.")
                        },
                        "required": ["schema_version", "image", "command", "workdir", "benchmark_digest", "timeout_seconds", "cpu_millis", "memory_bytes", "pids_limit", "max_output_bytes", "tmpfs_bytes", "max_source_bytes", "max_source_files", "max_benchmark_bytes", "max_benchmark_files", "platform", "test_seed"],
                        "additionalProperties": false
                    },
                    "evidence_schema": nullable_object_property("Optional submission schema; defaults to a required sha256 source_snapshot_digest."),
                    "verifier_reward": nullable_object_property("Optional USDC money object; defaults to 100000 base units and is paid to the precommitted verifier path."),
                    "funding_deadline": nullable_integer_property("Optional child funding deadline; defaults to the immutable parent deadline."),
                    "claim_window_seconds": nullable_integer_property("Optional child claim window; defaults to 259200 seconds."),
                    "verification_window_seconds": nullable_integer_property("Optional child verification window; defaults to 259200 seconds."),
                    "creation_nonce": nullable_string_property("Optional bytes32 creation nonce; otherwise derived deterministically from the parent and task."),
                    "nonce_salt": nullable_string_property("Optional public salt for preparing a distinct child from otherwise identical task input."),
                    "source_url": nullable_string_property("Optional public task or issue URL."),
                    "discovery_source": nullable_string_property("Optional discovery attribution for the child poster.")
                }),
                &["parent_bounty_contract", "parent_solver", "intended_child_solver", "title", "goal", "acceptance_criteria", "benchmark_source", "runner_manifest"],
            ),
        ),
        tool(
            "plan_autonomous_bounty_creation",
            "Build the ordered Base USDC creation calls and one-signature authorization payload.",
            PlanAutonomousBountyCreationArgs::input_schema(),
        ),
        tool(
            "plan_autonomous_bounty_authorized_creation",
            "After signing the creation payload, build the single sponsored create-and-fund transaction.",
            PlanAutonomousBountyAuthorizedCreationArgs::input_schema(),
        ),
        tool(
            "plan_autonomous_bounty_contribution",
            "Build ordered calls and one-signature data for a pooled USDC contribution.",
            PlanAutonomousBountyContributionArgs::input_schema(),
        ),
        tool(
            "plan_autonomous_bounty_authorized_contribution",
            "After signing the contribution payload, build the single sponsored funding transaction.",
            PlanAutonomousBountyAuthorizedContributionArgs::input_schema(),
        ),
        tool(
            "fund_bounty_with_x402",
            "Fund one canonical bounty. Request the challenge, sign it, retry once, then wait for confirmed FundingAdded.",
            X402BountyFundingArgs::input_schema(),
        ),
        tool(
            "get_x402_relay_status",
            "Poll one x402 relay until confirmed FundingAdded.",
            GetX402RelayStatusArgs::input_schema(),
        ),
        tool(
            "prepare_agent_to_earn",
            "Check one public wallet against one bounty. Fix failed checks. Never provide secrets.",
            object_tool_schema(
                json!({
                    "network": enum_property(&["base-mainnet", "base-sepolia"], "Base network containing the canonical bounty."),
                    "wallet_address": string_property("Public Base solver and payout address. Never provide wallet secrets."),
                    "bounty_contract": string_property("Canonical bounty contract the agent intends to claim."),
                    "claim_bond_base_units": nullable_string_property("Optional expected claim bond from prior inventory, as a base-10 USDC base-unit string. The readiness service independently derives the live bond and fails on drift."),
                    "signing_capabilities": {
                        "type": "array",
                        "description": "Declare eip712_typed_data and eip3009_receive_with_authorization for the normal claim flow.",
                        "items": { "type": "string", "enum": ["eip712_typed_data", "eip3009_receive_with_authorization", "send_transaction", "wallet_send_calls"] },
                        "uniqueItems": true
                    },
                    "wallet_profile": nullable_enum_property(&["generic-evm", "metamask-agent-wallet", "circle-agent-wallet", "cdp-server-wallet", "privy-server-wallet"], "Optional declared provider profile used only for guidance; providers are never inferred from addresses."),
                    "policy": {
                        "type": "object",
                        "description": "Non-secret wallet policy declaration.",
                        "properties": {
                            "allowed_chain_ids": { "type": "array", "items": { "type": "integer", "minimum": 1 }, "uniqueItems": true },
                            "allowed_contracts": string_array_property("Contract allowlist containing canonical native USDC and the intended bounty contract."),
                            "per_transaction_usdc_base_units": nullable_string_property("Per-transaction USDC cap as a base-10 base-unit string."),
                            "rolling_24h_usdc_base_units": nullable_string_property("Rolling 24-hour USDC cap as a base-10 base-unit string."),
                            "human_approval_policy": nullable_enum_property(&["always", "out_of_policy", "never"], "When the wallet must escalate to a human; out_of_policy is recommended for bounded autonomy.")
                        },
                        "required": ["allowed_chain_ids", "allowed_contracts", "per_transaction_usdc_base_units", "rolling_24h_usdc_base_units", "human_approval_policy"],
                        "additionalProperties": false
                    }
                }),
                &["network", "wallet_address", "bounty_contract", "signing_capabilities", "policy"],
            ),
        ),
        tool(
            "list_open_competition_verifiers",
            "List exact approved deterministic verifier profiles. Factory provenance alone is never verifier approval.",
            OpenCompetitionVerifierArgs::input_schema(),
        ),
        tool(
            "prepare_open_competition_creation",
            "Prepare either approval-and-create or EIP-3009 authorized creation against the frozen release manifest and exact verifier catalog profile.",
            OpenCompetitionCreationArgs::input_schema(),
        ),
        tool(
            "get_open_competition_readiness",
            "Fail closed unless canonical runtime, terms, funding, deterministic verification, timing, entry capacity, sponsorship, relay support, R4 evidence, and monitoring all pass.",
            OpenCompetitionReadinessArgs::input_schema(),
        ),
        tool(
            "prepare_open_competition_commit",
            "Prepare a commitment-bound entry bond. Generic agent_native_claim is forbidden because open competition has no exclusive claim.",
            OpenCompetitionCommitArgs::input_schema(),
        ),
        tool(
            "prepare_open_competition_reveal",
            "Prepare the same wallet's later-block reveal. The first passing onchain reveal sequence wins; verifier response time does not order competitors.",
            OpenCompetitionRevealArgs::input_schema(),
        ),
        tool(
            "get_open_competition_status",
            "Read canonical competition, entry, reveal-sequence, winner, and settlement state.",
            OpenCompetitionActionArgs::input_schema(),
        ),
        tool(
            "withdraw_open_competition_bond",
            "Prepare a pull withdrawal for a still-committed losing entry after canonical settlement.",
            OpenCompetitionActionArgs::input_schema(),
        ),
        tool(
            "prepare_open_competition_entrant_action",
            "Prepare one exact policy-bound entrant-wallet action from canonical Base safe-block state.",
            OpenCompetitionEntrantActionArgs::input_schema(),
        ),
        tool(
            "relay_open_competition_entrant_action",
            "Submit one delegate-signed entrant action to the bounded hosted relayer. A broadcast is not canonical execution or payment evidence.",
            OpenCompetitionEntrantRelayArgs::input_schema(),
        ),
        tool(
            "get_open_competition_entrant_relay",
            "Poll one entrant relay through canonical Base safe-block reconciliation. Only BountySettled proves solver payment.",
            GetOpenCompetitionEntrantRelayArgs::input_schema(),
        ),
        tool(
            "inspect_open_competition_v2",
            "New users start with operation=guide. Then read release, profiles, active inventory, events, and proof-job state in the returned order. Only CompetitionSettledV2 proves solver payment.",
            OpenCompetitionV2InspectArgs::input_schema(),
        ),
        tool(
            "prepare_open_competition_v2",
            "After inspect_open_competition_v2(operation=guide), execute one typed V2 step. prepare_policies derives retry-safe creation commitments locally. Some operations only return unsigned plans; quote_proof creates a hosted job, pay_proof may transfer Base USDC after explicit approval, and authorize_relay may submit a proof after explicit approval. Follow next_action and treat only CompetitionSettledV2 as solver payment.",
            OpenCompetitionV2MutationArgs::input_schema(),
        ),
        tool(
            "get_standing_meta_v4_readiness",
            "Fail closed unless exact V4 terms, economics, sponsorship, VRF reserves and authorization, pool sizes, timing, appeals, R4 evidence, and monitoring all pass.",
            StandingMetaV4ReadinessArgs::input_schema(),
        ),
        tool(
            "prepare_standing_meta_v4_claim",
            "Prepare the required atomic V4 claim. It snapshots the active solver pool and requests VRF immediately; generic agent_native_claim is forbidden.",
            StandingMetaV4ActionArgs::input_schema(),
        ),
        tool(
            "prepare_anonymous_stake_registration",
            "Prepare one fixed 5 USDC solver or verifier role ticket without identity fields.",
            StandingMetaV4ActionArgs::input_schema(),
        ),
        tool(
            "set_anonymous_stake_availability",
            "Prepare an availability update for an already registered anonymous role ticket.",
            StandingMetaV4ActionArgs::input_schema(),
        ),
        tool(
            "list_verification_assignments",
            "Read request-bound primary or appellate assignment state; wallet assignment is not identity or unrelated-owner proof.",
            StandingMetaV4ActionArgs::input_schema(),
        ),
        tool(
            "submit_primary_verdict",
            "Prepare the selected primary wallet's verdict. Chainlink selected the wallet but did not judge the work.",
            StandingMetaV4ActionArgs::input_schema(),
        ),
        tool(
            "waive_verification_appeal",
            "Let the sole eligible appellant finalize an undisputed verdict immediately instead of waiting for the appeal deadline.",
            StandingMetaV4ActionArgs::input_schema(),
        ),
        tool(
            "open_verification_appeal",
            "Prepare the solver's appeal of rejection or creator's appeal of acceptance with the exact 0.10 USDC bond.",
            StandingMetaV4ActionArgs::input_schema(),
        ),
        tool(
            "submit_appeal_vote",
            "Prepare one selected appellate wallet's vote; three matching votes form an immediately finalizable majority.",
            StandingMetaV4ActionArgs::input_schema(),
        ),
        tool(
            "finalize_verification_case",
            "Prepare unappealed, appealed, or timeout finalization. A verdict is not payment; only canonical BountySettled proves payment.",
            StandingMetaV4ActionArgs::input_schema(),
        ),
        tool(
            "agent_native_claim",
            "Claim one bounty. Reuse the idempotency key, sign wallet_request once, then replay next_request until BountyClaimed is confirmed.",
            AgentNativeClaimArgs::input_schema(),
        ),
        tool(
            "plan_autonomous_bounty_claim",
            "Use after the hosted relay reports unavailable. Build the direct bond-and-claim calls.",
            PlanAutonomousBountyClaimArgs::input_schema(),
        ),
        tool(
            "plan_autonomous_bounty_authorized_claim",
            "After the solver signs the exact EIP-3009 bond returned by plan_autonomous_bounty_claim, build one gas-sponsorable transaction that deposits the bond and activates the claim.",
            PlanAutonomousBountyAuthorizedClaimArgs::input_schema(),
        ),
        tool(
            "plan_autonomous_bounty_submission",
            "Build the solver's submission commitment call. The hashes must identify the artifact and evidence evaluated by the immutable verifier policy.",
            PlanAutonomousBountySubmissionArgs::input_schema(),
        ),
        tool(
            "prepare_autonomous_bounty_submission",
            "Prepare one claimed bounty submission. Sign the returned payload, relay it, then publish the returned evidence after SubmissionAdded.",
            PrepareAutonomousBountySubmissionArgs::input_schema(),
        ),
        tool(
            "plan_autonomous_bounty_submission_authorization",
            "Build the exact EIP-712 submission authorization an active solver signs for a gas-sponsored submitWithSignature relay.",
            PlanAutonomousBountySubmissionAuthorizationArgs::input_schema(),
        ),
        tool(
            "plan_autonomous_verification_attestation",
            "Build the exact EIP-712 payload a committed verifier signs for the current indexed submission. The planner rejects stale rounds, changed hashes, unauthorized verifiers, and deadlines beyond verification expiry.",
            PlanAutonomousVerificationAttestationArgs::input_schema(),
        ),
        tool(
            "plan_autonomous_module_settlement",
            "Build the permissionless deterministic verifier transaction. A passing verifier call transfers solver and verifier rewards atomically; a plan or transaction hash is not payout evidence.",
            PlanAutonomousModuleSettlementArgs::input_schema(),
        ),
        tool(
            "plan_autonomous_attestation_settlement",
            "Build the permissionless quorum relay. The canonical contract validates each committed verifier signature and atomically pays on pass or reopens on reject.",
            PlanAutonomousAttestationSettlementArgs::input_schema(),
        ),
        tool(
            "plan_autonomous_expire_claim",
            "Build the permissionless transaction that reopens an expired claim.",
            PlanAutonomousLifecycleArgs::input_schema("Claimed canonical bounty contract."),
        ),
        tool(
            "plan_autonomous_expire_submission",
            "Build the permissionless transaction that reopens an expired submission.",
            PlanAutonomousLifecycleArgs::input_schema("Submitted canonical bounty contract."),
        ),
        tool(
            "plan_autonomous_cancel",
            "Delete an unclaimed bounty from active inventory by cancelling it on-chain. The caller must be the creator before the immutable funding deadline; after the deadline any caller may clean it up. Claimed bounties fail closed. Each funder then withdraws its own refund.",
            PlanAutonomousCancelArgs::input_schema(),
        ),
        tool(
            "plan_autonomous_refund_withdrawal",
            "Build a contributor's pull-refund transaction after cancellation.",
            PlanAutonomousLifecycleArgs::input_schema("Cancelled canonical bounty contract."),
        ),
        tool(
            "plan_bounded_wallet_cancel_refund",
            "Build one owner-signed BoundedAgentWalletV2 transaction that cancels an unclaimed canonical bounty and withdraws only that wallet's refund. Other contributors keep their independent refunds.",
            PlanBoundedWalletCancelRefundArgs::input_schema(),
        ),
        tool(
            "decode_autonomous_bounty_events",
            "Decode raw EVM logs into evidence-bound autonomous bounty events. Unknown token-transfer logs are ignored; malformed recognized protocol logs fail closed.",
            DecodeAutonomousBountyEventsArgs::input_schema(),
        ),
        tool(
            "list_autonomous_bounty_events",
            "Read persisted confirmed canonical factory and bounty events. Use BountySettled as payout evidence; a signature, plan, or transaction hash alone is not settlement.",
            ListAutonomousBountyEventsArgs::input_schema(),
        ),
        tool(
            "publish_autonomous_bounty_terms",
            "Publish a bounded public task document and receive deterministic Keccak commitments for the factory call. Publication is not funding or canonical listing; only a matching canonical factory event creates the bounty.",
            PublishAutonomousBountyTermsArgs::input_schema(),
        ),
        tool(
            "get_autonomous_bounty_terms",
            "Resolve and independently hash-check the exact public task specification committed by an on-chain termsHash.",
            GetAutonomousBountyTermsArgs::input_schema(),
        ),
        tool(
            "publish_autonomous_submission_evidence",
            "After SubmissionAdded is indexed, publish the exact public artifact reference and evidence object whose SHA-256 commitments match the current canonical submission. Conflicting replays fail closed.",
            PublishAutonomousSubmissionEvidenceArgs::input_schema(),
        ),
        tool(
            "get_autonomous_submission_evidence",
            "Retrieve hash-checked public evidence for a canonical bounty round so deterministic or AI verifier agents can evaluate it.",
            GetAutonomousSubmissionEvidenceArgs::input_schema(),
        ),
        tool(
            "list_autonomous_bounties",
            "List canonical bounties. Set claimable_only=true, then choose one verification-ready result.",
            AutonomousBountyFeedArgs::input_schema(),
        ),
        tool(
            "list_opportunities",
            "Discover open, claimable, in-progress, submitted, and completed opportunities across the existing unfunded, funding-needed, legacy, and canonical sources. Work state and payment state are separate; follow each item's authoritative URL and exact next action.",
            OpportunityListArgs::input_schema(),
        ),
        tool(
            "create_discovery_subscription",
            "Create a filtered signed-webhook subscription for public opportunity publication and state changes. The endpoint must be public HTTPS. The management token and HMAC signing secret are returned once; store them securely. This subscribes to discovery only and never proves funding, payment, verification, or agent independence.",
            CreateDiscoverySubscriptionArgs::input_schema(),
        ),
        tool(
            "get_discovery_subscription",
            "Inspect one discovery webhook subscription using the one-time management token returned at creation. The signing secret is never returned again.",
            ManageDiscoverySubscriptionArgs::input_schema(),
        ),
        tool(
            "delete_discovery_subscription",
            "Permanently unsubscribe a discovery webhook and delete its queued deliveries using its management token.",
            ManageDiscoverySubscriptionArgs::input_schema(),
        ),
        tool(
            "get_opportunity_conversion_funnel",
            "Measure the observable cross-lifecycle funnel from unfunded publication through canonical settlement. The response separates hosted plans, observed signatures, and confirmed events, and intentionally leaves independent_active_agents null because wallet identity does not prove independence.",
            OpportunityConversionFunnelArgs::input_schema(),
        ),
        tool(
            "get_site_analytics",
            "Measure privacy-minimized first-party visitors, sessions, acquisition channels, and observed site conversion actions. Browser-local IDs are not people or wallets; canonical lifecycle and settlement endpoints remain authoritative for payment claims.",
            SiteAnalyticsArgs::input_schema(),
        ),
        tool(
            "list_autonomous_verification_jobs",
            "List ready submissions. Run each job's committed verifier exactly.",
            AutonomousVerificationJobsArgs::input_schema(),
        ),
        tool(
            "run_bountybench",
            "Run deterministic routing eval fixtures.",
            empty_tool_schema(),
        ),
        tool(
            "run_abusebench",
            "Run deterministic abuse and payout-safety eval fixtures.",
            empty_tool_schema(),
        ),
        tool(
            "run_judgebench",
            "Run deterministic product-quality AI-judge filter fixtures.",
            empty_tool_schema(),
        ),
        tool(
            "run_eval_loops",
            "Run loop-based router, template, verifier, proof, and abuse eval harnesses.",
            empty_tool_schema(),
        ),
        tool(
            "get_eval_runs",
            "Return compact eval-run history recorded by this MCP server.",
            empty_tool_schema(),
        ),
        tool(
            "get_risk_policy",
            "Return deterministic risk and settlement policy limits before posting, claiming, or releasing paid work.",
            empty_tool_schema(),
        ),
        operator_tool(
            "list_risk_events",
            "List deterministic risk events that need operator review or explain blocked automatic flows.",
            object_tool_schema(
                json!({
                    "action": nullable_enum_property(&["Allow", "NeedsReview", "Block"], "Optional risk action filter."),
                    "surface": nullable_enum_property(&["HelpRequest", "Bounty", "Submission", "Verification", "Payout"], "Optional risk surface filter."),
                    "bounty_id": nullable_uuid_property("Optional bounty UUID filter."),
                    "agent_id": nullable_uuid_property("Optional agent UUID filter."),
                    "limit": nullable_integer_property("Optional maximum number of newest events to return, capped at 500.")
                }),
                &[],
            ),
            OPERATOR_TOKEN_REQUIRED_WHEN_CONFIGURED,
        ),
        operator_tool(
            "list_risk_reviews",
            "List operator review decisions recorded against deterministic risk events.",
            empty_tool_schema(),
            OPERATOR_TOKEN_REQUIRED_WHEN_CONFIGURED,
        ),
        operator_tool(
            "approve_risk_bounty",
            "Approve a NeedsReview bounty risk event into a funded claimable bounty after operator review.",
            object_tool_schema(
                json!({
                    "risk_event_id": uuid_property("Risk event UUID being approved."),
                    "title": string_property("Bounty title to bind to the reviewed risk subject."),
                    "template_slug": string_property("Bounty template slug."),
                    "amount_minor": integer_property("Bounty amount in minor units."),
                    "currency": string_property("Lowercase currency code, for example usdc."),
                    "funding_mode": funding_mode_property(),
                    "privacy": privacy_property(),
                    "operator_id": string_property("Human or service operator identifier."),
                    "note": string_property("Concise reason for approving this review item.")
                }),
                &[
                    "risk_event_id",
                    "title",
                    "template_slug",
                    "amount_minor",
                    "currency",
                    "funding_mode",
                    "privacy",
                    "operator_id",
                    "note",
                ],
            ),
            OPERATOR_TOKEN_REQUIRED_WHEN_CONFIGURED,
        ),
        operator_tool(
            "approve_risk_payout",
            "Approve a NeedsReview payout risk event so the matching verification request can continue after operator review.",
            object_tool_schema(
                json!({
                    "risk_event_id": uuid_property("Payout risk event UUID being approved."),
                    "operator_id": string_property("Human or service operator identifier."),
                    "note": string_property("Concise reason for approving this payout review item.")
                }),
                &["risk_event_id", "operator_id", "note"],
            ),
            OPERATOR_TOKEN_REQUIRED_WHEN_CONFIGURED,
        ),
        operator_tool(
            "reject_risk_event",
            "Reject a NeedsReview risk event and record an operator audit note without mutating bounty or payment state.",
            object_tool_schema(
                json!({
                    "risk_event_id": uuid_property("Risk event UUID being rejected."),
                    "operator_id": string_property("Human or service operator identifier."),
                    "note": string_property("Concise reason for rejecting this review item.")
                }),
                &["risk_event_id", "operator_id", "note"],
            ),
            OPERATOR_TOKEN_REQUIRED_WHEN_CONFIGURED,
        ),
    ])
}

const OPERATOR_TOKEN_REQUIRED_WHEN_CONFIGURED: &str =
    "Always; OPERATOR_API_TOKEN must be configured and supplied by the caller.";

fn tool(name: &'static str, description: &'static str, input_schema: Value) -> ToolDescriptor {
    ToolDescriptor {
        name,
        description,
        input_schema,
        authorization: None,
    }
}

fn operator_tool(
    name: &'static str,
    description: &'static str,
    input_schema: Value,
    required_when: &'static str,
) -> ToolDescriptor {
    ToolDescriptor {
        name,
        description,
        input_schema,
        authorization: Some(ToolAuthorization {
            kind: "operator_api_token",
            header: OPERATOR_TOKEN_HEADER,
            bearer: true,
            required_when,
        }),
    }
}

fn empty_tool_schema() -> Value {
    object_tool_schema(json!({}), &[])
}

fn bounty_solver_schema() -> Value {
    object_tool_schema(
        json!({
            "bounty_id": uuid_property("Bounty UUID."),
            "solver_agent_id": uuid_property("Solver agent UUID.")
        }),
        &["bounty_id", "solver_agent_id"],
    )
}

fn object_tool_schema(properties: Value, required: &[&str]) -> Value {
    json!({
        "type": "object",
        "properties": properties,
        "required": required,
        "additionalProperties": false
    })
}

fn open_competition_v2_inspect_schema() -> Value {
    let network = json!({
        "type": ["string", "null"],
        "enum": ["base-mainnet", "base-sepolia", null],
        "description": "Defaults to base-mainnet."
    });
    let operation_schema = |operation: &str, properties: Value, fields: &[&str]| {
        let mut properties = properties.as_object().cloned().unwrap_or_default();
        properties.insert("operation".to_string(), json!({"const": operation}));
        let mut required = vec!["operation"];
        required.extend_from_slice(fields);
        object_tool_schema(Value::Object(properties), &required)
    };
    json!({
        "type": "object",
        "description": "Start with guide, then use only the fields accepted by the selected read operation.",
        "properties": {
            "operation": {"type": "string", "enum": ["guide", "release", "profiles", "inventory", "events", "proof_job"]},
            "network": {"type": ["string", "null"], "enum": ["base-mainnet", "base-sepolia", null]},
            "state": {"type": ["string", "null"], "enum": ["announced", "funding", "active", "settled", "cancelled", null]},
            "bounty_id": {"type": ["string", "null"], "pattern": "^0x[0-9a-fA-F]{64}$"},
            "job_id": {"type": ["string", "null"], "format": "uuid"}
        },
        "required": [],
        "additionalProperties": false,
        "oneOf": [
            operation_schema("guide", json!({"network": network.clone()}), &[]),
            operation_schema("release", json!({"network": network.clone()}), &[]),
            operation_schema("profiles", json!({"network": network.clone()}), &[]),
            operation_schema("inventory", json!({
                "network": network.clone(),
                "state": {
                    "type": ["string", "null"],
                    "enum": ["announced", "funding", "active", "settled", "cancelled", null]
                }
            }), &[]),
            operation_schema("events", json!({
                "network": network,
                "bounty_id": {
                    "type": ["string", "null"],
                    "pattern": "^0x[0-9a-fA-F]{64}$"
                }
            }), &[]),
            operation_schema("proof_job", json!({
                "job_id": {"type": "string", "format": "uuid"}
            }), &["job_id"])
        ]
    })
}

fn open_competition_v2_mutation_schema() -> Value {
    let network = json!({
        "type": ["string", "null"],
        "enum": ["base-mainnet", "base-sepolia", null],
        "description": "Defaults to base-mainnet."
    });
    let address = json!({
        "type": "string",
        "pattern": "^0x[0-9a-fA-F]{40}$"
    });
    let bytes32 = json!({
        "type": "string",
        "pattern": "^0x[0-9a-fA-F]{64}$"
    });
    let described_bytes32 = |description: &str| {
        json!({
            "type": "string",
            "pattern": "^0x[0-9a-fA-F]{64}$",
            "description": description
        })
    };
    let unsigned_decimal = json!({
        "type": "string",
        "pattern": "^(0|[1-9][0-9]*)$",
        "description": "Unsigned base-unit decimal string; USDC uses 6 decimals."
    });
    let signed_decimal = json!({
        "type": "string",
        "pattern": "^-?(0|[1-9][0-9]*)$",
        "description": "Signed integer decimal string."
    });
    let nonempty_hex = json!({
        "type": "string",
        "pattern": "^0x(?:[0-9a-fA-F]{2})+$"
    });
    let artifact_requirement = json!({
        "oneOf": [
            object_tool_schema(json!({
                "kind": {"const": "utf8_contains"},
                "needle": {"type": "string", "minLength": 1, "maxLength": 4096},
                "minimum_occurrences": {"type": "integer", "minimum": 1},
                "weight": {"type": "integer", "minimum": 1}
            }), &["kind", "needle", "minimum_occurrences", "weight"]),
            object_tool_schema(json!({
                "kind": {"const": "utf8_excludes"},
                "needle": {"type": "string", "minLength": 1, "maxLength": 4096},
                "weight": {"type": "integer", "minimum": 1}
            }), &["kind", "needle", "weight"]),
            object_tool_schema(json!({
                "kind": {"const": "maximum_bytes"},
                "maximum": {"type": "integer", "minimum": 1, "maximum": 1048576},
                "weight": {"type": "integer", "minimum": 1}
            }), &["kind", "maximum", "weight"]),
            object_tool_schema(json!({
                "kind": {"const": "json_valid"},
                "weight": {"type": "integer", "minimum": 1}
            }), &["kind", "weight"]),
            object_tool_schema(json!({
                "kind": {"const": "json_pointer_exists"},
                "pointer": {"type": "string"},
                "weight": {"type": "integer", "minimum": 1}
            }), &["kind", "pointer", "weight"]),
            object_tool_schema(json!({
                "kind": {"const": "json_pointer_string_equals"},
                "pointer": {"type": "string"},
                "expected": {"type": "string"},
                "weight": {"type": "integer", "minimum": 1}
            }), &["kind", "pointer", "expected", "weight"]),
            object_tool_schema(json!({
                "kind": {"const": "json_array_minimum_length"},
                "pointer": {"type": "string"},
                "minimum": {"type": "integer", "minimum": 0},
                "weight": {"type": "integer", "minimum": 1}
            }), &["kind", "pointer", "minimum", "weight"])
        ]
    });
    let requirements = json!({
        "type": "array",
        "minItems": 1,
        "maxItems": 256,
        "items": artifact_requirement
    });
    let creation_params = object_tool_schema(
        json!({
            "solver_reward": unsigned_decimal.clone(),
            "keeper_reward": unsigned_decimal.clone(),
            "funding_deadline": {"type": "integer", "minimum": 1, "description": "UTC Unix timestamp after which incomplete funding can be cancelled."},
            "proof_window_seconds": {"type": "integer", "minimum": 1, "description": "Proof-entry window after canonical activation."},
            "winner_mode": {"type": "string", "enum": ["first_proven", "best_score"]},
            "score_direction": {"type": "string", "enum": ["higher_is_better", "lower_is_better"]},
            "score_threshold": signed_decimal,
            "proof_system": {"type": "string", "enum": ["groth16", "plonk"]},
            "program_vkey": described_bytes32("Copy from the selected reviewed profiles entry."),
            "source_hash": described_bytes32("Copy from the selected reviewed profiles entry."),
            "elf_hash": described_bytes32("Copy from the selected reviewed profiles entry."),
            "journal_schema_hash": described_bytes32("Copy from the selected reviewed profiles entry."),
            "metric_program_hash": described_bytes32("Copy from the selected reviewed profiles entry."),
            "execution_policy_hash": described_bytes32("Copy from prepare_policies."),
            "verification_policy_hash": described_bytes32("Copy from prepare_profile."),
            "settlement_policy_hash": described_bytes32("Copy from prepare_policies."),
            "beta_risk_hash": described_bytes32("Copy from the live release beta_risk_hash.")
        }),
        &[
            "solver_reward",
            "keeper_reward",
            "funding_deadline",
            "proof_window_seconds",
            "winner_mode",
            "score_direction",
            "score_threshold",
            "proof_system",
            "program_vkey",
            "source_hash",
            "elf_hash",
            "journal_schema_hash",
            "metric_program_hash",
            "execution_policy_hash",
            "verification_policy_hash",
            "settlement_policy_hash",
            "beta_risk_hash",
        ],
    );
    let creation = object_tool_schema(
        json!({
            "network": network.clone(),
            "creator": address.clone(),
            "creation_nonce": described_bytes32("Copy from prepare_policies; reuse only when retrying the same intended competition."),
            "acknowledged_risk_hash": described_bytes32("Copy the live release beta_risk_hash to acknowledge the exact public-beta risk bundle."),
            "initial_funding": {"type": "string", "pattern": "^(0|[1-9][0-9]*)$", "description": "Initial Base USDC contribution in 6-decimal base units; remaining funding can be pooled later."},
            "params": creation_params
        }),
        &[
            "creator",
            "creation_nonce",
            "acknowledged_risk_hash",
            "initial_funding",
            "params",
        ],
    );
    let public_vector_metric = object_tool_schema(
        json!({
            "mode": {"type": "string", "enum": ["all_equal", "maximize_exact_matches", "minimize_absolute_error"]},
            "threshold": signed_decimal.clone(),
            "vectors": {
                "type": "array",
                "minItems": 1,
                "maxItems": 10000,
                "items": object_tool_schema(json!({
                    "expected": {"type": "integer"},
                    "observed": {"type": "integer"},
                    "weight": {"type": "integer", "minimum": 1}
                }), &["expected", "observed", "weight"])
            }
        }),
        &["mode", "threshold", "vectors"],
    );
    let structured_artifact_metric = object_tool_schema(
        json!({
            "profile_id": {"const": "structured-artifact-metric-v1"},
            "threshold": unsigned_decimal.clone(),
            "artifact_utf8": {"type": "string", "minLength": 1, "maxLength": 1048576},
            "requirements": requirements.clone()
        }),
        &["profile_id", "threshold", "artifact_utf8", "requirements"],
    );
    let fixed_wire_bytes = |length: usize| {
        json!({
            "type": "array",
            "minItems": length,
            "maxItems": length,
            "items": {"type": "integer", "minimum": 0, "maximum": 255}
        })
    };
    let wire_address = fixed_wire_bytes(20);
    let wire_bytes32 = fixed_wire_bytes(32);
    let wire_unsigned = json!({"type": "integer", "minimum": 0});
    let forward_funding = object_tool_schema(
        json!({
            "contributor": wire_address.clone(),
            "amount_base_units": wire_unsigned.clone()
        }),
        &["contributor", "amount_base_units"],
    );
    let forward_settlement = object_tool_schema(
        json!({
            "protocol": {"type": "string", "enum": ["autonomous", "open_competition_v1", "open_competition_v2"]},
            "bounty_contract": wire_address.clone(),
            "bounty_id": wire_bytes32.clone(),
            "creator": wire_address.clone(),
            "solver": wire_address.clone(),
            "settled_at": wire_unsigned.clone(),
            "block_number": wire_unsigned.clone(),
            "transaction_hash": wire_bytes32.clone(),
            "log_index": wire_unsigned.clone(),
            "gmv_base_units": wire_unsigned.clone(),
            "funding": {"type": "array", "minItems": 1, "maxItems": 256, "items": forward_funding}
        }),
        &[
            "protocol",
            "bounty_contract",
            "bounty_id",
            "creator",
            "solver",
            "settled_at",
            "block_number",
            "transaction_hash",
            "log_index",
            "gmv_base_units",
            "funding",
        ],
    );
    let forward_campaign = object_tool_schema(
        json!({
            "epoch_id": wire_bytes32.clone(),
            "starts_at": wire_unsigned.clone(),
            "ends_at": wire_unsigned.clone(),
            "minimum_score_base_units": wire_unsigned.clone(),
            "excluded_wallets": {"type": "array", "maxItems": 4096, "items": wire_address.clone()},
            "excluded_bounty_contracts": {"type": "array", "maxItems": 4096, "items": wire_address.clone()},
            "snapshot_attesters": {"type": "array", "minItems": 2, "maxItems": 255, "items": wire_address.clone()},
            "snapshot_attestation_threshold": {"type": "integer", "minimum": 2, "maximum": 255}
        }),
        &[
            "epoch_id",
            "starts_at",
            "ends_at",
            "minimum_score_base_units",
            "excluded_wallets",
            "excluded_bounty_contracts",
            "snapshot_attesters",
            "snapshot_attestation_threshold",
        ],
    );
    let forward_attestation = object_tool_schema(
        json!({
            "signer": wire_address,
            "signature": {
                "type": "array",
                "minItems": 65,
                "maxItems": 65,
                "items": {"type": "integer", "minimum": 0, "maximum": 255}
            }
        }),
        &["signer", "signature"],
    );
    let forward_snapshot = object_tool_schema(
        json!({
            "start_block": wire_unsigned.clone(),
            "end_safe_block": wire_unsigned.clone(),
            "end_block_hash": wire_bytes32,
            "settlements": {"type": "array", "maxItems": 4096, "items": forward_settlement},
            "attestations": {"type": "array", "minItems": 2, "maxItems": 255, "items": forward_attestation}
        }),
        &[
            "start_block",
            "end_safe_block",
            "end_block_hash",
            "settlements",
            "attestations",
        ],
    );
    let forward_gmv_metric = object_tool_schema(
        json!({
            "profile_id": {"const": "forward-canonical-gmv-attribution-metric-v2"},
            "campaign": forward_campaign,
            "snapshot": forward_snapshot
        }),
        &["profile_id", "campaign", "snapshot"],
    );
    let structured_artifact_profile = object_tool_schema(
        json!({
            "profile_id": {"const": "structured-artifact-metric-v1"},
            "network": network.clone(),
            "threshold": unsigned_decimal.clone(),
            "requirements": requirements
        }),
        &["threshold", "requirements"],
    );
    let public_vector_profile = object_tool_schema(
        json!({
            "profile_id": {"const": "public-vector-metric-v1"},
            "network": network.clone(),
            "mode": {"type": "string", "enum": ["all_equal", "maximize_exact_matches", "minimize_absolute_error"]},
            "threshold": signed_decimal.clone(),
            "vectors": {
                "type": "array",
                "minItems": 1,
                "maxItems": 10000,
                "items": object_tool_schema(json!({
                    "expected": {"type": "integer", "minimum": -9223372036854775808_i64, "maximum": 9223372036854775807_i64},
                    "weight": {"type": "integer", "minimum": 1, "maximum": 4294967295_u64}
                }), &["expected", "weight"])
            }
        }),
        &["profile_id", "mode", "threshold", "vectors"],
    );
    let definitions = json!({
        "prepare_profile": {
            "description": "Derive immutable fields for either reviewed built-in profile. profile_id is optional only for the legacy structured-artifact request shape.",
            "oneOf": [structured_artifact_profile, public_vector_profile]
        },
        "prepare_policies": object_tool_schema(json!({
            "execution_policy": {"type": "object", "minProperties": 1, "description": "Complete public execution-policy JSON to commit."},
            "settlement_policy": {"type": "object", "minProperties": 1, "description": "Complete public settlement-policy JSON to commit."},
            "creation_nonce_seed": {"type": "string", "minLength": 1, "maxLength": 256, "description": "Stable unique public seed for this intended competition. Reuse it only when retrying the same creation."}
        }), &["execution_policy", "settlement_policy", "creation_nonce_seed"]),
        "validate": creation.clone(),
        "create": creation,
        "fund": object_tool_schema(json!({
            "network": network.clone(),
            "contributor": address.clone(),
            "competition_contract": address.clone(),
            "amount": unsigned_decimal.clone(),
            "acknowledged_risk_hash": bytes32.clone()
        }), &["contributor", "competition_contract", "amount", "acknowledged_risk_hash"]),
        "quote_proof": object_tool_schema(json!({
            "network": network.clone(),
            "competition_contract": address.clone(),
            "solver": address.clone(),
            "solver_nonce": unsigned_decimal.clone(),
            "artifact_hash": described_bytes32("Required for public-vector and structured-artifact metrics. Omit for forward GMV; the API derives and binds the solver-specific submission hash from the attested snapshot."),
            "relay": {"type": "boolean"},
            "metric": {"oneOf": [public_vector_metric, structured_artifact_metric, forward_gmv_metric]}
        }), &["competition_contract", "solver", "solver_nonce", "relay", "metric"]),
        "pay_proof": object_tool_schema(json!({
            "proof_job_id": {"type": "string", "format": "uuid"},
            "payment_signature": {"type": ["string", "null"], "minLength": 1, "description": "Omit on the first call to receive the exact x402 challenge; include only after explicit approval and signing."}
        }), &["proof_job_id"]),
        "prepare_proof": object_tool_schema(json!({
            "network": network.clone(),
            "competition_contract": address.clone(),
            "solver": address.clone(),
            "solver_nonce": unsigned_decimal,
            "proof_system": {"type": "string", "enum": ["groth16", "plonk"]},
            "public_values": nonempty_hex.clone(),
            "proof": nonempty_hex.clone(),
            "authorization_deadline": {"type": "integer", "minimum": 1},
            "solver_signature": {"type": ["string", "null"], "pattern": "^0x(?:[0-9a-fA-F]{2})+$"}
        }), &["competition_contract", "solver", "solver_nonce", "proof_system", "public_values", "proof", "authorization_deadline"]),
        "authorize_relay": object_tool_schema(json!({
            "proof_job_id": {"type": "string", "format": "uuid"},
            "authorization_deadline": {"type": "integer", "minimum": 1},
            "solver_signature": {"type": ["string", "null"], "pattern": "^0x(?:[0-9a-fA-F]{2})+$", "description": "Omit to receive exact EIP-712 typed data; include only after explicit approval and signing."}
        }), &["proof_job_id", "authorization_deadline"]),
        "prepare_action": object_tool_schema(json!({
            "network": network,
            "competition_contract": address.clone(),
            "caller": {"oneOf": [address.clone(), {"type": "null"}]},
            "action": {"type": "string", "enum": ["finalize_best_score", "cancel_funding", "expire_competition", "cancel_unavailable_verifier", "withdraw_refund_for"]},
            "contributor": {"oneOf": [address, {"type": "null"}], "description": "Required only for withdraw_refund_for; refunds always go to this contributor."}
        }), &["competition_contract", "action"])
    });
    let operations = [
        "prepare_profile",
        "prepare_policies",
        "validate",
        "create",
        "fund",
        "quote_proof",
        "pay_proof",
        "prepare_proof",
        "authorize_relay",
        "prepare_action",
    ];
    let operation_rules = operations
        .iter()
        .map(|operation| {
            json!({
                "if": {
                    "properties": {"operation": {"const": operation}},
                    "required": ["operation"]
                },
                "then": {
                    "properties": {
                        "arguments": {"$ref": format!("#/$defs/{operation}")}
                    }
                }
            })
        })
        .collect::<Vec<_>>();
    json!({
        "type": "object",
        "description": "Start with inspect_open_competition_v2(operation=guide). Match arguments to the selected operation exactly.",
        "properties": {
            "operation": {
                "type": "string",
                "enum": operations,
                "description": "Execute one ordered V2 Beta3 transition."
            },
            "arguments": {
                "type": "object",
                "description": "Operation-specific body selected by the conditional schema. Never add guessed fields."
            }
        },
        "required": ["operation", "arguments"],
        "additionalProperties": false,
        "allOf": operation_rules,
        "$defs": definitions
    })
}

fn string_property(description: &str) -> Value {
    json!({ "type": "string", "description": description })
}

fn nullable_string_property(description: &str) -> Value {
    json!({ "type": ["string", "null"], "description": description })
}

fn uuid_property(description: &str) -> Value {
    json!({ "type": "string", "format": "uuid", "description": description })
}

fn nullable_uuid_property(description: &str) -> Value {
    json!({ "type": ["string", "null"], "format": "uuid", "description": description })
}

fn integer_property(description: &str) -> Value {
    json!({ "type": "integer", "description": description })
}

fn nullable_integer_property(description: &str) -> Value {
    json!({ "type": ["integer", "null"], "description": description })
}

fn nullable_number_property(description: &str) -> Value {
    json!({ "type": ["number", "null"], "description": description })
}

fn boolean_property(description: &str) -> Value {
    json!({ "type": "boolean", "description": description })
}

fn nullable_boolean_property(description: &str) -> Value {
    json!({ "type": ["boolean", "null"], "description": description })
}

fn object_property(description: &str) -> Value {
    json!({ "type": "object", "description": description })
}

fn money_property(description: &str, allow_zero: bool) -> Value {
    json!({
        "type": "object",
        "description": description,
        "properties": {
            "amount": {
                "type": "integer",
                "minimum": if allow_zero { 0 } else { 1 },
                "description": "USDC base units; native USDC uses six decimal places."
            },
            "currency": {
                "type": "string",
                "const": "usdc"
            }
        },
        "required": ["amount", "currency"],
        "additionalProperties": false
    })
}

fn autonomous_bounty_create_property() -> Value {
    json!({
        "type": "object",
        "description": "Complete immutable autonomous bounty policy. Hashes must commit to public or retrievable canonical terms before any wallet signs.",
        "properties": {
            "creator": string_property("Creator or posting agent wallet address."),
            "solver_reward": money_property("Amount paid atomically to the successful solver.", false),
            "verifier_reward": money_property("Amount split across successful precommitted verifiers; may be zero.", true),
            "terms_hash": string_property("0x-prefixed bytes32 canonical terms hash."),
            "policy_hash": string_property("0x-prefixed bytes32 full verification-policy hash."),
            "acceptance_criteria_hash": string_property("0x-prefixed bytes32 explicit acceptance-criteria hash."),
            "benchmark_hash": string_property("0x-prefixed bytes32 deterministic benchmark or judge benchmark hash."),
            "evidence_schema_hash": string_property("0x-prefixed bytes32 evidence-package schema hash."),
            "funding_deadline": integer_property("Unix timestamp after which an incomplete crowdfund can be cancelled."),
            "claim_window_seconds": integer_property("Seconds a solver has to submit after claiming."),
            "verification_window_seconds": integer_property("Seconds committed verifiers have to settle after submission."),
            "verification_mode": enum_property(&["deterministic_module", "signed_quorum", "ai_judge_quorum"], "Immutable on-chain verification mechanism. Use signed_quorum with threshold 1 for one verifier; add verifiers only when higher-risk work needs independent review."),
            "verifier_module": nullable_string_property("Deterministic verifier contract; null for quorum modes."),
            "verifier_reward_recipient": nullable_string_property("Deterministic verifier reward wallet; null for quorum modes."),
            "verifiers": string_array_property("One to eight precommitted verifier wallets for quorum modes; empty for deterministic mode."),
            "threshold": integer_property("Number of matching verifier signatures required. Default to 1 for signed verification; AI judge mode requires at least 2."),
            "initial_funding": money_property("Creation-time funding. Zero creates a crowdfundable bounty; target funding makes it immediately claimable.", true),
            "creation_nonce": string_property("Unique nonzero random bytes32. It binds the CREATE2 bounty id and address.")
        },
        "required": [
            "creator", "solver_reward", "verifier_reward", "terms_hash", "policy_hash",
            "acceptance_criteria_hash", "benchmark_hash", "evidence_schema_hash",
            "funding_deadline", "claim_window_seconds", "verification_window_seconds",
            "verification_mode", "verifiers", "threshold", "initial_funding", "creation_nonce"
        ],
        "additionalProperties": false
    })
}

fn authorization_signature_property() -> Value {
    json!({
        "type": "object",
        "properties": {
            "v": integer_property("EIP-3009 recovery id: 0, 1, 27, or 28."),
            "r": string_property("0x-prefixed bytes32 signature r."),
            "s": string_property("0x-prefixed bytes32 signature s.")
        },
        "required": ["v", "r", "s"],
        "additionalProperties": false
    })
}

fn discovery_subscription_filters_property() -> Value {
    json!({
        "type": "object",
        "description": "All non-empty filter groups are ANDed; values within one group are ORed.",
        "properties": {
            "skills": string_array_property("Required skill labels; case-insensitive exact matches."),
            "categories": string_array_property("Required deterministic categories such as engineering, creative, or research."),
            "minimum_committed_reward": {
                "type": ["object", "null"],
                "properties": {
                    "amount": string_property("Unsigned integer amount in the stated unit."),
                    "currency": string_property("Currency code such as USDC."),
                    "unit": enum_property(&["base_units", "minor_units"], "Amount unit."),
                    "decimals": integer_property("Currency decimals, 0 through 18.")
                },
                "required": ["amount", "currency", "unit", "decimals"],
                "additionalProperties": false
            },
            "work_states": string_array_property("Any of open, claimable, in_progress, submitted, completed."),
            "payment_states": string_array_property("Any of none, seeking_funding, escrowed, paid."),
            "verification_methods": string_array_property("Case-insensitive exact verification method labels."),
            "source_types": string_array_property("Any of unfunded_offchain, legacy_bounty, canonical_base."),
            "deadline_within_hours": nullable_integer_property("Positive deadline window, up to 8760 hours.")
        },
        "additionalProperties": false
    })
}

fn autonomous_verification_attestation_property() -> Value {
    json!({
        "type": "object",
        "properties": {
            "bounty_contract": string_property("Indexed canonical submitted bounty contract."),
            "bounty_id": string_property("0x-prefixed canonical bounty id."),
            "round": integer_property("Current positive submission round."),
            "verifier": string_property("Wallet in the immutable verifier set."),
            "submission_hash": string_property("Current indexed artifact commitment."),
            "evidence_hash": string_property("Current indexed evidence commitment."),
            "policy_hash": string_property("Immutable policy commitment."),
            "passed": boolean_property("Verifier decision."),
            "response_hash": string_property("0x-prefixed hash of the verifier response and reproducibility record."),
            "deadline": integer_property("Unix signature expiry no later than the submission verification deadline.")
        },
        "required": [
            "bounty_contract", "bounty_id", "round", "verifier", "submission_hash",
            "evidence_hash", "policy_hash", "passed", "response_hash", "deadline"
        ],
        "additionalProperties": false
    })
}

fn autonomous_submission_authorization_property() -> Value {
    json!({
        "type": "object",
        "properties": {
            "bounty_contract": string_property("Claimed canonical bounty contract."),
            "bounty_id": string_property("Current canonical bytes32 bounty id."),
            "round": integer_property("Current positive claim round."),
            "solver": string_property("Wallet holding the current claim."),
            "submission_hash": string_property("Nonzero bytes32 artifact commitment."),
            "evidence_hash": string_property("Nonzero bytes32 evidence commitment."),
            "policy_hash": string_property("Immutable bytes32 verification-policy commitment."),
            "deadline": integer_property("Unix expiry no later than the active claim deadline.")
        },
        "required": ["bounty_contract", "bounty_id", "round", "solver", "submission_hash", "evidence_hash", "policy_hash", "deadline"],
        "additionalProperties": false
    })
}

fn autonomous_signed_attestation_property() -> Value {
    json!({
        "type": "object",
        "properties": {
            "verifier": string_property("Committed verifier wallet that signed the exact EIP-712 payload."),
            "passed": boolean_property("Signed verifier decision; every quorum member must agree."),
            "response_hash": string_property("Signed 0x-prefixed verifier response hash."),
            "deadline": integer_property("Signed Unix expiry."),
            "signature": string_property("0x-prefixed EOA or ERC-1271-compatible signature bytes.")
        },
        "required": ["verifier", "passed", "response_hash", "deadline", "signature"],
        "additionalProperties": false
    })
}

fn autonomous_bounty_terms_property() -> Value {
    json!({
        "type": "object",
        "description": "Public content-addressed task specification. On-chain creation commits the returned hashes.",
        "properties": {
            "schema_version": { "type": "string", "const": "agent-bounties/terms-v1" },
            "contract_terms": object_property("Immutable protocol version, creator, Base network, native USDC token, solver/verifier rewards, equal claim bond, initial funding, deadlines, work windows, and creation nonce."),
            "title": string_property("Short digital-work bounty title."),
            "goal": string_property("Complete outcome the solver must produce."),
            "acceptance_criteria": string_array_property("Explicit binary or measurable acceptance criteria."),
            "benchmark": object_property("Deterministic benchmark or AI-judge benchmark definition."),
            "evidence_schema": object_property("Required submission evidence fields and formats."),
            "verification_policy": object_property("Complete immutable verifier mechanism, engines, wallets, thresholds, model versions, prompts, rubrics, and decoding parameters."),
            "source_url": nullable_string_property("Optional public issue, repository, or task source URL."),
            "discovery_source": nullable_string_property("Optional answer describing how the poster found Agent Bounties.")
        },
        "required": ["schema_version", "contract_terms", "title", "goal", "acceptance_criteria", "benchmark", "evidence_schema", "verification_policy"],
        "additionalProperties": false
    })
}

fn nullable_object_property(description: &str) -> Value {
    json!({ "type": ["object", "null"], "description": description })
}

fn array_property(items: Value, description: &str) -> Value {
    json!({ "type": "array", "items": items, "description": description })
}

fn string_array_property(description: &str) -> Value {
    array_property(string_property("Array item."), description)
}

fn enum_property(values: &[&str], description: &str) -> Value {
    json!({ "type": "string", "enum": values, "description": description })
}

fn nullable_enum_property(values: &[&str], description: &str) -> Value {
    json!({ "type": ["string", "null"], "enum": values, "description": description })
}

fn privacy_property() -> Value {
    enum_property(
        &["Public", "RedactedPublicProof", "Private"],
        "Privacy level.",
    )
}

fn funding_mode_property() -> Value {
    enum_property(
        &["Simulated", "StripeFiatLedger"],
        "Off-chain funding mode. Base USDC uses autonomous-v1 tools.",
    )
}

fn verifier_kind_property() -> Value {
    enum_property(
        &[
            "Manual",
            "JsonSchema",
            "DockerCommand",
            "GitHubCi",
            "HttpCallback",
            "AiJudgeFilter",
        ],
        "Verifier kind.",
    )
}

async fn route_blocked_goal(
    State(state): State<SharedState>,
    Json(args): Json<RouteBlockedGoalArgs>,
) -> Json<serde_json::Value> {
    let agent = Agent::new("mcp-requester");
    let request = HelpRequest::new(
        agent.id,
        args.goal,
        args.context,
        Money::new(args.budget_minor, args.currency).unwrap_or(Money {
            amount: 1,
            currency: "usdc".to_string(),
        }),
        args.privacy,
    );
    let capabilities = state
        .network
        .lock()
        .expect("state poisoned")
        .capabilities
        .values()
        .cloned()
        .collect::<Vec<_>>();
    let decision = BountyRouter::default().route_blocked_goal(&request, &capabilities);
    mcp_json(decision)
}

async fn plan_objective_creation(
    Json(args): Json<PlanObjectiveCreationArgs>,
) -> Json<serde_json::Value> {
    match Objective::plan_creation(args.draft) {
        Ok(plan) => mcp_json(plan),
        Err(error) => mcp_error(error),
    }
}

async fn create_objective(
    State(state): State<SharedState>,
    Json(args): Json<SignedObjectiveCreation>,
) -> Json<serde_json::Value> {
    let now = Utc::now();
    let objective = match Objective::create(args, now) {
        Ok(objective) => objective,
        Err(error) => return mcp_error(error),
    };
    if let Err(error) = persist_new_objective(&state, &objective).await {
        return mcp_error(error);
    }
    match objective.view(&ObjectiveCanonicalEvidence::default(), now) {
        Ok(view) => mcp_json(view),
        Err(error) => mcp_error(error),
    }
}

async fn list_objectives(State(state): State<SharedState>) -> Json<serde_json::Value> {
    let objectives = match load_objectives(&state).await {
        Ok(objectives) => objectives,
        Err(error) => return mcp_error(error),
    };
    let evidence = match load_objective_canonical_evidence(&state, &objectives).await {
        Ok(evidence) => evidence,
        Err(error) => return mcp_error(error),
    };
    let now = Utc::now();
    let views = match objectives
        .iter()
        .map(|objective| objective.view(&evidence, now))
        .collect::<Result<Vec<_>, _>>()
    {
        Ok(views) => views,
        Err(error) => return mcp_error(error),
    };
    mcp_json(views)
}

async fn get_objective(
    State(state): State<SharedState>,
    Json(args): Json<ObjectiveIdArgs>,
) -> Json<serde_json::Value> {
    let objective = match load_objective(&state, args.objective_id).await {
        Ok(objective) => objective,
        Err(error) => return mcp_error(error),
    };
    let evidence =
        match load_objective_canonical_evidence(&state, std::slice::from_ref(&objective)).await {
            Ok(evidence) => evidence,
            Err(error) => return mcp_error(error),
        };
    match objective.view(&evidence, Utc::now()) {
        Ok(view) => mcp_json(view),
        Err(error) => mcp_error(error),
    }
}

async fn plan_objective_action(
    State(state): State<SharedState>,
    Json(args): Json<PlanObjectiveActionArgs>,
) -> Json<serde_json::Value> {
    let objective = match load_objective(&state, args.objective_id).await {
        Ok(objective) => objective,
        Err(error) => return mcp_error(error),
    };
    match objective.plan_action(args.action, Utc::now()) {
        Ok(plan) => mcp_json(plan),
        Err(error) => mcp_error(error),
    }
}

async fn apply_objective_action(
    State(state): State<SharedState>,
    Json(args): Json<ApplyObjectiveActionArgs>,
) -> Json<serde_json::Value> {
    if args.signed_action.plan.objective_id != args.objective_id {
        return mcp_error("signed action objective_id does not match the requested objective");
    }
    let mut objective = match load_objective(&state, args.objective_id).await {
        Ok(objective) => objective,
        Err(error) => return mcp_error(error),
    };
    let expected_revision = objective.revision;
    let evidence =
        match load_objective_canonical_evidence(&state, std::slice::from_ref(&objective)).await {
            Ok(evidence) => evidence,
            Err(error) => return mcp_error(error),
        };
    let now = Utc::now();
    if let Err(error) = objective.apply_action(args.signed_action, now, &evidence) {
        return mcp_error(error);
    }
    if let Err(error) = persist_objective_replacement(&state, &objective, expected_revision).await {
        return mcp_error(error);
    }
    match objective.view(&evidence, now) {
        Ok(view) => mcp_json(view),
        Err(error) => mcp_error(error),
    }
}

async fn reconcile_objective(
    State(state): State<SharedState>,
    Json(args): Json<ObjectiveIdArgs>,
) -> Json<serde_json::Value> {
    let mut objective = match load_objective(&state, args.objective_id).await {
        Ok(objective) => objective,
        Err(error) => return mcp_error(error),
    };
    let expected_revision = objective.revision;
    let evidence =
        match load_objective_canonical_evidence(&state, std::slice::from_ref(&objective)).await {
            Ok(evidence) => evidence,
            Err(error) => return mcp_error(error),
        };
    let now = Utc::now();
    match objective.reconcile_canonical_evidence(&evidence, now) {
        Ok(true) => {
            if let Err(error) =
                persist_objective_replacement(&state, &objective, expected_revision).await
            {
                return mcp_error(error);
            }
        }
        Ok(false) => {}
        Err(error) => return mcp_error(error),
    }
    match objective.view(&evidence, now) {
        Ok(view) => mcp_json(view),
        Err(error) => mcp_error(error),
    }
}

async fn prepare_bounty_post(
    State(state): State<SharedState>,
    Json(args): Json<PrepareBountyPostArgs>,
) -> Json<serde_json::Value> {
    match chatgpt_app::prepare_bounty_post_handoff(&state, &args, None).await {
        Ok(handoff) => mcp_json(handoff),
        Err(error) => mcp_error(error),
    }
}

async fn publish_unfunded_bounty(
    State(_state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<PublishUnfundedBountyArgs>,
) -> Json<serde_json::Value> {
    secured_api_tool(
        &headers,
        "/v1/unfunded-bounties",
        Some(serde_json::to_value(&args).expect("serializable tool arguments")),
    )
    .await
}

async fn list_unfunded_bounties(
    Json(args): Json<ListUnfundedBountiesArgs>,
) -> Json<serde_json::Value> {
    let url = format!(
        "{}/v1/unfunded-bounties",
        api_upstream_base_url_from_env().trim_end_matches('/')
    );
    proxy_hosted_json(
        reqwest::Client::new()
            .get(url)
            .query(&[("limit", args.limit.unwrap_or(20))]),
    )
    .await
}

async fn submit_unfunded_bounty_solution(
    State(_state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<SubmitUnfundedBountySolutionArgs>,
) -> Json<serde_json::Value> {
    secured_api_tool(&headers, &format!("/v1/unfunded-bounties/{}/solutions", args.bounty_id), Some(json!({
        "agent_id":args.agent_id,"summary":args.summary,"deliverable_markdown":args.deliverable_markdown,"evidence":args.evidence
    }))).await
}

fn hosted_generation_removed() -> Json<serde_json::Value> {
    Json(json!({
        "error": "hosted_generation_removed",
        "error_code": "hosted_generation_removed",
        "retryable": false,
        "http_status": 410,
        "message": "Platform-hosted AI generation has been removed.",
        "next_action": "Use your own AI account to prepare or analyze the draft, then review it at https://agentbounties.app/post.html."
    }))
}

async fn retired_generation_http() -> (StatusCode, Json<serde_json::Value>) {
    (StatusCode::GONE, hosted_generation_removed())
}

async fn get_autonomous_inventory_summary(
    Json(args): Json<AutonomousInventorySummaryArgs>,
) -> Json<serde_json::Value> {
    let url = format!(
        "{}/v1/base/autonomous-bounties/inventory-summary",
        api_upstream_base_url_from_env().trim_end_matches('/')
    );
    proxy_hosted_json(reqwest::Client::new().get(url).query(&[
        (
            "network",
            args.network.unwrap_or_else(|| "base-mainnet".to_string()),
        ),
        (
            "claimable_only",
            args.claimable_only.unwrap_or(true).to_string(),
        ),
    ]))
    .await
}

async fn get_solver_leaderboard(
    Json(args): Json<SolverLeaderboardArgs>,
) -> Json<serde_json::Value> {
    let url = format!(
        "{}/v1/base/autonomous-bounties/leaderboard",
        api_upstream_base_url_from_env().trim_end_matches('/')
    );
    let mut query = vec![(
        "network",
        args.network.unwrap_or_else(|| "base-mainnet".to_string()),
    )];
    if let Some(at) = args.at {
        query.push(("at", at));
    }
    proxy_hosted_json(reqwest::Client::new().get(url).query(&query)).await
}

async fn proxy_hosted_json(request: reqwest::RequestBuilder) -> Json<serde_json::Value> {
    match request.send().await {
        Ok(response) => {
            let status = response.status();
            match response.bytes().await {
                Ok(body) if status.is_success() && body.is_empty() => mcp_json(json!({
                    "http_status": status.as_u16(),
                    "success": true
                })),
                Ok(body) => match serde_json::from_slice::<serde_json::Value>(&body) {
                    Ok(body) if status.is_success() => mcp_json(body),
                    Ok(body) => mcp_error(format!("hosted API returned {status}: {body}")),
                    Err(error) => mcp_error(format!(
                        "hosted API returned {status} with invalid JSON: {error}"
                    )),
                },
                Err(error) => mcp_error(format!(
                    "hosted API returned {status} with unreadable body: {error}"
                )),
            }
        }
        Err(error) => mcp_error(format!("hosted API request failed: {error}")),
    }
}

fn with_caller_authorization(
    mut request: reqwest::RequestBuilder,
    headers: &HeaderMap,
) -> reqwest::RequestBuilder {
    for name in [
        "authorization",
        "cookie",
        "origin",
        "idempotency-key",
        "x-operator-token",
    ] {
        if let Some(value) = headers.get(name) {
            request = request.header(name, value);
        }
    }
    request
}

async fn secured_api_tool(headers: &HeaderMap, path: &str, body: Option<Value>) -> Json<Value> {
    let client = reqwest::Client::builder()
        .redirect(reqwest::redirect::Policy::none())
        .build()
        .expect("HTTP client");
    let url = format!(
        "{}{}",
        api_upstream_base_url_from_env().trim_end_matches('/'),
        path
    );
    let request = match body {
        Some(body) => client.post(url).json(&body),
        None => client.get(url),
    };
    proxy_hosted_json(with_caller_authorization(request, headers)).await
}

async fn register_agent(
    State(state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<RegisterAgentRequest>,
) -> Json<serde_json::Value> {
    let _ = state;
    secured_api_tool(
        &headers,
        "/v1/agents",
        Some(serde_json::to_value(&args).expect("serializable tool arguments")),
    )
    .await
}

async fn register_capability(
    State(state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<RegisterCapabilityRequest>,
) -> Json<serde_json::Value> {
    let _ = state;
    secured_api_tool(
        &headers,
        "/v1/capabilities",
        Some(serde_json::to_value(&args).expect("serializable tool arguments")),
    )
    .await
}

async fn search_capabilities(
    State(state): State<SharedState>,
    Json(args): Json<SearchCapabilitiesArgs>,
) -> Json<serde_json::Value> {
    let (capabilities, agents, reputation_events, settlements) = {
        let guard = state.network.lock().expect("state poisoned");
        let network = service_runtime::privacy::public_network(&guard);
        (
            network.capabilities.values().cloned().collect::<Vec<_>>(),
            network.agents.values().cloned().collect::<Vec<_>>(),
            network
                .reputation_events
                .values()
                .cloned()
                .collect::<Vec<_>>(),
            network.settlements.values().cloned().collect::<Vec<_>>(),
        )
    };
    let api_base_url =
        env::var("PUBLIC_BASE_URL").unwrap_or_else(|_| "http://127.0.0.1:8080".to_string());
    let class_filter = args.class.map(|class| format!("{class:?}"));
    let template_filter = args.template_slug;
    let currency_filter = args.currency.map(|currency| currency.to_ascii_lowercase());
    let mut feed = web_public::public_capability_feed(
        &capabilities,
        &agents,
        &reputation_events,
        &settlements,
        &api_base_url,
    );
    feed.retain(|item| {
        class_filter
            .as_ref()
            .map(|class| item.class == *class)
            .unwrap_or(true)
            && template_filter
                .as_ref()
                .map(|template| item.template_slugs.iter().any(|slug| slug == template))
                .unwrap_or(true)
            && currency_filter
                .as_ref()
                .map(|currency| item.currency == *currency)
                .unwrap_or(true)
            && args
                .max_price_minor
                .map(|max_price| item.min_price_minor <= max_price)
                .unwrap_or(true)
    });
    mcp_json(feed)
}

async fn request_quotes(
    State(state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<CreateHelpRequestRequest>,
) -> Json<serde_json::Value> {
    let _ = state;
    let result = secured_api_tool(
        &headers,
        "/v1/help-requests",
        Some(serde_json::to_value(&args).expect("serializable request")),
    )
    .await;
    let Some(id) = result
        .0
        .pointer("/content/0/json/id")
        .and_then(Value::as_str)
    else {
        return result;
    };
    secured_api_tool(
        &headers,
        &format!("/v1/help-requests/{id}/quotes"),
        Some(json!({})),
    )
    .await
}

async fn fund_quote_as_bounty(
    State(state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<FundQuoteRequest>,
) -> Json<serde_json::Value> {
    let _ = state;
    secured_api_tool(
        &headers,
        &format!("/v1/quotes/{}/fund-bounty", args.quote_id),
        Some(serde_json::to_value(&args).expect("serializable tool arguments")),
    )
    .await
}

async fn post_bounty(
    State(state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<PostBountyRequest>,
) -> Json<serde_json::Value> {
    let _ = state;
    secured_api_tool(
        &headers,
        "/v1/bounties",
        Some(serde_json::to_value(&args).expect("serializable tool arguments")),
    )
    .await
}

async fn open_pooled_bounty(
    State(state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<OpenPooledBountyRequest>,
) -> Json<serde_json::Value> {
    let _ = state;
    secured_api_tool(
        &headers,
        "/v1/bounties/pooled",
        Some(serde_json::to_value(&args).expect("serializable tool arguments")),
    )
    .await
}

async fn add_bounty_funding(
    State(_state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<AddFundingContributionRequest>,
) -> Json<serde_json::Value> {
    secured_api_tool(
        &headers,
        &format!("/v1/bounties/{}/funding-contributions", args.bounty_id),
        Some(serde_json::to_value(&args).expect("serializable tool arguments")),
    )
    .await
}

async fn create_funding_intent(
    State(_state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<CreateFundingIntentRequest>,
) -> Json<serde_json::Value> {
    secured_api_tool(
        &headers,
        &format!("/v1/bounties/{}/funding-intents", args.bounty_id),
        Some(serde_json::to_value(&args).expect("serializable tool arguments")),
    )
    .await
}

async fn list_claimable_bounties(State(state): State<SharedState>) -> Json<serde_json::Value> {
    let bounties = {
        let network = state.network.lock().expect("state poisoned");
        service_runtime::privacy::public_claimable_bounties(&network)
    };
    let api_base_url =
        env::var("PUBLIC_BASE_URL").unwrap_or_else(|_| "http://127.0.0.1:8080".to_string());
    mcp_json(web_public::public_bounty_feed(&bounties, &api_base_url))
}

async fn claim_bounty(
    State(state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<ClaimBountyRequest>,
) -> Json<serde_json::Value> {
    let _ = state;
    secured_api_tool(
        &headers,
        &format!("/v1/bounties/{}/claim", args.bounty_id),
        Some(serde_json::to_value(&args).expect("serializable tool arguments")),
    )
    .await
}

async fn submit_result(
    State(state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<SubmitResultRequest>,
) -> Json<serde_json::Value> {
    let _ = state;
    secured_api_tool(
        &headers,
        &format!("/v1/bounties/{}/submit", args.bounty_id),
        Some(serde_json::to_value(&args).expect("serializable tool arguments")),
    )
    .await
}

async fn request_verification(
    State(state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<VerifySubmissionRequest>,
) -> Json<serde_json::Value> {
    let _ = state;
    secured_api_tool(
        &headers,
        &format!("/v1/bounties/{}/verify", args.bounty_id),
        Some(serde_json::to_value(&args).expect("serializable tool arguments")),
    )
    .await
}

tool_args! {
    struct BountyIdArgs { bounty_id: Uuid }
    schema object_tool_schema(
        json!({ "bounty_id": uuid_property("Bounty UUID.") }),
        &["bounty_id"],
    );
}

tool_args! {
    #[derive(Default)]
    struct PaidStatusArgs { bounty_id: Option<Uuid>, agent_id: Option<Uuid> }
    schema object_tool_schema(
        json!({
            "bounty_id": nullable_uuid_property("Optional bounty UUID for bounty-level payout status."),
            "agent_id": nullable_uuid_property("Optional agent UUID for agent-level earnings and payout status.")
        }),
        &[],
    );
}

async fn get_bounty_status(
    State(state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<BountyIdArgs>,
) -> Json<serde_json::Value> {
    if headers.contains_key("authorization")
        || headers.contains_key("cookie")
        || headers.contains_key("x-operator-token")
    {
        return secured_api_tool(&headers, &format!("/v1/bounties/{}", args.bounty_id), None).await;
    }
    match bounty_status_snapshot(&state, args.bounty_id).await {
        Ok(status) => mcp_json(status),
        Err(error) => mcp_error(error),
    }
}

async fn bounty_status_snapshot(
    state: &SharedState,
    bounty_id: Uuid,
) -> Result<BountyStatusResponse, String> {
    service_runtime::privacy::bounty_status_for_principal(
        state.store.as_ref(),
        &state.network,
        bounty_id,
        &service_runtime::auth::Principal::Anonymous,
    )
    .await
    .map_err(|error| error.to_string())
}

async fn get_paid_status(
    State(state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<PaidStatusArgs>,
) -> Json<serde_json::Value> {
    if headers.contains_key("authorization")
        || headers.contains_key("cookie")
        || headers.contains_key("x-operator-token")
    {
        let path = match (args.bounty_id, args.agent_id) {
            (Some(id), None) => format!("/v1/bounties/{id}"),
            (None, Some(id)) => format!("/v1/agents/{id}/paid-status"),
            _ => return mcp_error("get_paid_status accepts either bounty_id or agent_id"),
        };
        let response = secured_api_tool(&headers, &path, None).await.0;
        return authorized_paid_status_response(args, response);
    }
    match (args.bounty_id, args.agent_id) {
        (Some(bounty_id), None) => match bounty_status_snapshot(&state, bounty_id).await {
            Ok(status) => paid_bounty_status_response(bounty_id, status),
            Err(error) => mcp_error(error),
        },
        (None, Some(agent_id)) => {
            let guard = state.network.lock().expect("state poisoned");
            let network = service_runtime::privacy::public_network(&guard);
            match network.agent_payout_status(agent_id) {
                Ok(status) => {
                    let paid = status.payouts.iter().find(|payout| {
                        payout.status == PayoutStatus::Paid && payout.rail != PaymentRail::Simulated
                    });
                    let evidence_payout = paid.or_else(|| status.payouts.first());
                    let trigger = if paid.is_some() {
                        Some(web_public::PostValueTrigger::ReconciledPayout)
                    } else if evidence_payout.is_some() || !status.reputation_events.is_empty() {
                        Some(web_public::PostValueTrigger::VerifiedCompletion)
                    } else {
                        None
                    };
                    let api = public_base_url_from_env();
                    let share_url = evidence_payout
                        .map(|payout| {
                            format!(
                                "{}/public/proofs/{}",
                                api.trim_end_matches('/'),
                                payout.proof_record_id
                            )
                        })
                        .unwrap_or_else(|| {
                            format!("{}/public/agents/{agent_id}", api.trim_end_matches('/'))
                        });
                    let post_value_loop = trigger.map(|trigger| {
                        web_public::post_value_loop(Some(trigger), Some(&share_url))
                    });
                    mcp_json(serde_json::json!({
                        "scope": "agent",
                        "agent_id": agent_id,
                        "agent": status.agent,
                        "payouts": status.payouts,
                        "totals": status.totals,
                        "reputation_events": status.reputation_events,
                        "post_value_loop": post_value_loop
                    }))
                }
                Err(error) => mcp_error(error),
            }
        }
        (None, None) => mcp_error("get_paid_status requires bounty_id or agent_id"),
        (Some(_), Some(_)) => {
            mcp_error("get_paid_status accepts either bounty_id or agent_id, not both")
        }
    }
}

fn paid_bounty_status_response(bounty_id: Uuid, status: BountyStatusResponse) -> Json<Value> {
    let api = public_base_url_from_env();
    let proof_url = status
        .proofs
        .first()
        .map(|proof| format!("{}/public/proofs/{}", api.trim_end_matches('/'), proof.id));
    let trigger = if status.bounty.status == BountyStatus::Paid
        && status.bounty.funding_mode != domain::FundingMode::Simulated
    {
        Some(web_public::PostValueTrigger::ReconciledPayout)
    } else if !status.proofs.is_empty() {
        Some(web_public::PostValueTrigger::VerifiedCompletion)
    } else if status.funding_summary.claimable {
        Some(web_public::PostValueTrigger::FundedBounty)
    } else {
        None
    };
    let share_url = proof_url
        .unwrap_or_else(|| format!("{}/public/bounties/{bounty_id}", api.trim_end_matches('/')));
    let post_value_loop =
        trigger.map(|trigger| web_public::post_value_loop(Some(trigger), Some(&share_url)));
    mcp_json(serde_json::json!({
        "scope": "bounty",
        "bounty_id": bounty_id,
        "bounty_status": status.bounty.status,
        "settlements": status.settlements,
        "template_signals": status.template_signals,
        "risk_events": status.risk_events,
        "post_value_loop": post_value_loop
    }))
}

fn authorized_paid_status_response(args: PaidStatusArgs, response: Value) -> Json<Value> {
    if response.get("error").is_some() {
        return Json(response);
    }
    let Some(mut value) = response.pointer("/content/0/json").cloned() else {
        return mcp_error("authorized API returned an invalid payout response");
    };
    match (args.bounty_id, args.agent_id) {
        (Some(id), None) => match serde_json::from_value::<BountyStatusResponse>(value) {
            Ok(status) if status.bounty.id == id => paid_bounty_status_response(id, status),
            _ => mcp_error("authorized API returned an invalid bounty status"),
        },
        (None, Some(id)) => {
            match serde_json::from_value::<app::AgentPayoutStatusResponse>(value.clone()) {
                Ok(status) if status.agent.id == id => {}
                _ => return mcp_error("authorized API returned an invalid agent payout status"),
            }
            value["scope"] = json!("agent");
            value["agent_id"] = json!(id);
            mcp_json(value)
        }
        _ => mcp_error("get_paid_status accepts either bounty_id or agent_id"),
    }
}

async fn plan_stripe_checkout_top_up(
    State(state): State<SharedState>,
    Json(args): Json<PlanStripeCheckoutTopUpArgs>,
) -> Json<serde_json::Value> {
    match stripe_checkout_top_up_intent(&state, args) {
        Ok(intent) => mcp_json(intent),
        Err(error) => mcp_error(error),
    }
}

fn stripe_checkout_top_up_intent(
    state: &SharedState,
    args: PlanStripeCheckoutTopUpArgs,
) -> Result<StripeRequestIntent, Box<dyn std::error::Error + Send + Sync>> {
    let platform_base_url =
        env::var("PUBLIC_BASE_URL").unwrap_or_else(|_| "http://127.0.0.1:8080".to_string());
    let planner = stripe_planner_for_state(state, platform_base_url.clone());
    let amount = Money::new(args.amount_minor, args.currency)?;
    Ok(planner.checkout_top_up(&CheckoutTopUpRequest {
        organization_id: args.organization_id,
        amount,
        success_url: args
            .success_url
            .unwrap_or_else(|| format!("{platform_base_url}/stripe/success")),
        cancel_url: args
            .cancel_url
            .unwrap_or_else(|| format!("{platform_base_url}/stripe/cancel")),
    })?)
}

fn stripe_planner_for_state(
    state: &SharedState,
    platform_base_url: impl Into<String>,
) -> StripePlanner {
    let planner = StripePlanner::new(platform_base_url);
    if let Some(payment_method_configuration) = state.stripe_payment_method_configuration.as_deref()
    {
        planner.with_payment_method_configuration(payment_method_configuration)
    } else {
        planner
    }
}

async fn plan_stripe_connect_account(
    Json(args): Json<PlanStripeConnectAccountArgs>,
) -> Json<serde_json::Value> {
    match stripe_connect_account_intent(args) {
        Ok(intent) => mcp_json(intent),
        Err(error) => mcp_error(error),
    }
}

fn stripe_connect_account_intent(
    args: PlanStripeConnectAccountArgs,
) -> Result<payments_stripe::ConnectAccountV2CreateIntent, payments_stripe::StripeIntegrationError>
{
    StripePlanner::new("http://127.0.0.1:8080").connect_account_v2(args.agent_id)
}

async fn plan_stripe_connect_transfer(
    State(_state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<PlanStripeConnectTransferArgs>,
) -> Json<serde_json::Value> {
    secured_api_tool(
        &headers,
        "/v1/stripe/connect-transfers",
        Some(serde_json::to_value(&args).expect("serializable tool arguments")),
    )
    .await
}

fn stripe_connect_transfer_plan(
    state: &SharedState,
    args: PlanStripeConnectTransferArgs,
) -> Result<app::StripeTransferPlan, app::AppError> {
    let platform_base_url =
        env::var("PUBLIC_BASE_URL").unwrap_or_else(|_| "http://127.0.0.1:8080".to_string());
    let network = state.network.lock().expect("state poisoned");
    network.plan_stripe_transfer(
        PlanStripeTransferRequest {
            payout_intent_id: args.payout_intent_id,
            connected_account_id: args.connected_account_id,
        },
        platform_base_url,
    )
}

async fn execute_stripe_checkout_top_up(
    State(state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<PlanStripeCheckoutTopUpArgs>,
) -> Json<serde_json::Value> {
    if let Err(error) = require_operator(&state, &headers) {
        return error;
    }
    let intent = match stripe_checkout_top_up_intent(&state, args) {
        Ok(intent) => intent,
        Err(error) => return mcp_error(error),
    };
    execute_stripe_intent(&state, intent).await
}

async fn execute_stripe_connect_account(
    State(state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<PlanStripeConnectAccountArgs>,
) -> Json<serde_json::Value> {
    if let Err(error) = require_operator(&state, &headers) {
        return error;
    }
    let intent = match stripe_connect_account_intent(args) {
        Ok(intent) => intent.request,
        Err(error) => return mcp_error(error),
    };
    execute_stripe_intent(&state, intent).await
}

async fn execute_stripe_connect_transfer(
    State(state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<PlanStripeConnectTransferArgs>,
) -> Json<serde_json::Value> {
    if let Err(error) = require_operator(&state, &headers) {
        return error;
    }
    let plan = match stripe_connect_transfer_plan(&state, args) {
        Ok(plan) => plan,
        Err(error) => return mcp_error(error),
    };
    execute_stripe_intent(&state, plan.request).await
}

async fn execute_stripe_intent(
    state: &SharedState,
    intent: StripeRequestIntent,
) -> Json<serde_json::Value> {
    if !state.stripe_live_execution_enabled {
        return mcp_error("live Stripe execution is disabled");
    }
    let secret_key = match state
        .stripe_secret_key
        .as_deref()
        .filter(|secret| !secret.trim().is_empty())
    {
        Some(secret_key) => secret_key,
        None => return mcp_error("STRIPE_SECRET_KEY is not configured"),
    };
    match execute_stripe_request(&intent, secret_key, &state.stripe_api_base_url).await {
        Ok(report) => mcp_json(report),
        Err(error) => mcp_error(error),
    }
}

async fn reconcile_stripe_connect_snapshot(
    State(state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<ConnectAccountSnapshot>,
) -> Json<serde_json::Value> {
    if let Err(error) = require_operator(&state, &headers) {
        return error;
    }
    let reconciliation = {
        let mut network = state.network.lock().expect("state poisoned");
        match network.apply_stripe_connect_snapshot(args) {
            Ok(reconciliation) => reconciliation,
            Err(error) => return mcp_error(error),
        }
    };
    if let Some(store) = &state.store {
        for bounty in &reconciliation.bounties {
            if let Err(error) = store.upsert_bounty(bounty).await {
                return mcp_error(error);
            }
        }
        for settlement in &reconciliation.settlements {
            if let Err(error) = store.upsert_settlement(settlement).await {
                return mcp_error(error);
            }
        }
        if let Err(error) = persist_ledger_entries(store, &reconciliation.ledger_entries).await {
            return mcp_error(error);
        }
    }
    mcp_json(reconciliation)
}

async fn reconcile_stripe_transfer_event(
    State(state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<StripeWebhookEvent>,
) -> Json<serde_json::Value> {
    if let Err(error) = require_operator(&state, &headers) {
        return error;
    }
    let evidence = match StripeEventDeduper::default().apply_connect_transfer(&args) {
        Ok(evidence) => evidence,
        Err(error) => return mcp_error(error),
    };
    let reconciliation = {
        let mut network = state.network.lock().expect("state poisoned");
        match network.apply_stripe_transfer_evidence(evidence) {
            Ok(reconciliation) => reconciliation,
            Err(error) => return mcp_error(error),
        }
    };
    if let Some(store) = &state.store {
        if !reconciliation.duplicate {
            if let Err(error) = store
                .upsert_payment_event(&reconciliation.evidence.payment_event)
                .await
            {
                return mcp_error(error);
            }
        }
        if let Some(settlement) = &reconciliation.settlement {
            if let Err(error) = store.upsert_settlement(settlement).await {
                return mcp_error(error);
            }
        }
        if let Some(bounty) = &reconciliation.bounty {
            if let Err(error) = store.upsert_bounty(bounty).await {
                return mcp_error(error);
            }
        }
        if let Err(error) = persist_ledger_entries(store, &reconciliation.ledger_entries).await {
            return mcp_error(error);
        }
    }
    mcp_json(reconciliation)
}

async fn reconcile_stripe_checkout_webhook(
    State(state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<StripeWebhookEvent>,
) -> Json<serde_json::Value> {
    if let Err(error) = require_operator(&state, &headers) {
        return error;
    }
    let funding_credit = match StripeEventDeduper::default().apply_checkout_top_up(&args) {
        Ok(funding_credit) => funding_credit,
        Err(error) => return mcp_error(error),
    };
    let reconciliation = {
        let mut network = state.network.lock().expect("state poisoned");
        match network.apply_stripe_funding_credit(funding_credit) {
            Ok(reconciliation) => reconciliation,
            Err(error) => return mcp_error(error),
        }
    };
    if let Some(store) = &state.store {
        if !reconciliation.duplicate {
            if let Err(error) = store
                .upsert_payment_event(&reconciliation.funding_credit.payment_event)
                .await
            {
                return mcp_error(error);
            }
        }
        if let Some(intent) = &reconciliation.funding_intent {
            if let Err(error) = store.upsert_funding_intent(intent).await {
                return mcp_error(error);
            }
        }
        if let Some(report) = &reconciliation.funding_report {
            if let Err(error) = store.upsert_bounty(&report.bounty).await {
                return mcp_error(error);
            }
            if let Err(error) = store
                .upsert_funding_contribution(&report.contribution)
                .await
            {
                return mcp_error(error);
            }
        }
        if let Err(error) = persist_ledger_entries(store, &reconciliation.ledger_entries).await {
            return mcp_error(error);
        }
    }
    mcp_json(reconciliation)
}

async fn plan_github_issue_bounty(
    Json(args): Json<PlanGitHubIssueBountyArgs>,
) -> Json<serde_json::Value> {
    let parsed =
        parse_issue_form_bounty(&args.repository, &args.issue_url, &args.title, &args.body);
    match parsed {
        Ok(bounty) => {
            let check = bounty_check_output(Ok(&bounty));
            mcp_json(serde_json::json!({
                "ready": true,
                "parsed": bounty,
                "error": null,
                "check": check
            }))
        }
        Err(error) => {
            let check = bounty_check_output(Err(&error));
            mcp_json(serde_json::json!({
                "ready": false,
                "parsed": null,
                "error": error.to_string(),
                "check": check
            }))
        }
    }
}

async fn plan_github_funding_comment(
    Json(args): Json<PlanGitHubFundingCommentArgs>,
) -> Json<serde_json::Value> {
    mcp_json(funding_comment_plan(GitHubFundingCommentInput {
        repository: args.repository,
        issue_url: args.issue_url,
        title: args.title,
        body: args.body,
        comment_body: args.comment_body,
        contributor_login: args.contributor_login,
        comment_id: args.comment_id,
        funding_api_base_url: args.funding_api_base_url,
        existing_idempotency_keys: args.existing_idempotency_keys,
    }))
}

async fn plan_github_create_comment(
    Json(args): Json<PlanGitHubCreateCommentArgs>,
) -> Json<serde_json::Value> {
    mcp_json(create_comment_plan(GitHubCreateCommentInput {
        repository: args.repository,
        issue_url: args.issue_url,
        title: args.title,
        body: args.body,
        comment_body: args.comment_body,
        contributor_login: args.contributor_login,
        comment_id: args.comment_id,
        existing_idempotency_keys: args.existing_idempotency_keys,
    }))
}

async fn plan_social_mention_draft(
    Json(args): Json<PlanSocialMentionDraftArgs>,
) -> Json<serde_json::Value> {
    let url = format!(
        "{}/v1/social/mention-draft-plan",
        api_upstream_base_url_from_env().trim_end_matches('/')
    );
    proxy_hosted_json(reqwest::Client::new().post(url).json(&args)).await
}

async fn plan_github_claim_comment(
    Json(args): Json<PlanGitHubClaimCommentArgs>,
) -> Json<serde_json::Value> {
    mcp_json(claim_comment_plan(GitHubClaimCommentInput {
        repository: args.repository,
        issue_url: args.issue_url,
        title: args.title,
        body: args.body,
        comment_body: args.comment_body,
        contributor_login: args.contributor_login,
        comment_id: args.comment_id,
        claim_age_minutes: args.claim_age_minutes,
        progress_signal_count: args.progress_signal_count,
        active_claim_login: args.active_claim_login,
    }))
}

async fn plan_github_proof_comment(
    Json(args): Json<PlanGitHubProofCommentArgs>,
) -> Json<serde_json::Value> {
    let comment = GitHubProofComment {
        bounty_id: args.bounty_id,
        proof_url: args.proof_url,
        verifier_summary: args.verifier_summary,
        settlement_url: args.settlement_url,
    };
    mcp_json(proof_comment_plan(comment))
}

async fn plan_github_proof_comment_for_proof(
    State(state): State<SharedState>,
    Json(args): Json<PlanGitHubProofCommentForProofArgs>,
) -> Json<serde_json::Value> {
    let public_base_url = public_base_url_from_env();
    let network = state.network.lock().expect("state poisoned");
    let Some((proof, verifier)) =
        service_runtime::privacy::public_proof_details(&network, args.proof_id)
    else {
        return mcp_error("proof not found");
    };
    let verifier_summary = if verifier.summary.trim().is_empty() {
        format!("{:?} verifier accepted", verifier.kind)
    } else {
        format!("{:?}: {}", verifier.kind, verifier.summary.trim())
    };
    let comment = GitHubProofComment {
        bounty_id: proof.bounty_id,
        proof_url: format!(
            "{}/public/proofs/{}",
            public_base_url.trim_end_matches('/'),
            proof.id
        ),
        verifier_summary,
        settlement_url: args.settlement_url,
    };
    mcp_json(proof_comment_plan(comment))
}

async fn broadcast_base_signed_transaction(
    State(state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<BroadcastBaseSignedTransactionArgs>,
) -> Json<serde_json::Value> {
    if let Err(error) = require_operator(&state, &headers) {
        return error;
    }
    if !state.base_broadcast_enabled {
        return mcp_error(
            "Base transaction broadcast is disabled; set ENABLE_BASE_TX_BROADCAST=true",
        );
    }
    let request_id = args.request_id.unwrap_or(1);
    let network_name = args.network.as_deref().unwrap_or("base-sepolia");
    let (network, rpc_url) = match state.base_rpc_urls.resolve(network_name) {
        Ok(resolved) => resolved,
        Err(error) => return mcp_error(error),
    };
    let request = match eth_send_raw_transaction_request(&args.signed_transaction, request_id) {
        Ok(request) => request,
        Err(error) => return mcp_error(error),
    };
    let response =
        match broadcast_signed_transaction(&rpc_url, &args.signed_transaction, request_id).await {
            Ok(response) => response,
            Err(error) => return mcp_error(error),
        };

    mcp_json(serde_json::json!({
        "network": network,
        "request": request,
        "tx_hash": response.result,
        "next_step": "Poll get_base_transaction_receipt for inclusion. The autonomous indexer independently reconciles canonical factory and bounty logs; a receipt alone never proves settlement."
    }))
}

async fn get_base_transaction_receipt(
    State(state): State<SharedState>,
    Json(args): Json<GetBaseTransactionReceiptArgs>,
) -> Json<serde_json::Value> {
    let request_id = args.request_id.unwrap_or(1);
    let network_name = args.network.as_deref().unwrap_or("base-sepolia");
    let (network, rpc_url) = match state.base_rpc_urls.resolve(network_name) {
        Ok(resolved) => resolved,
        Err(error) => return mcp_error(error),
    };
    let request = match eth_get_transaction_receipt_request(&args.tx_hash, request_id) {
        Ok(request) => request,
        Err(error) => return mcp_error(error),
    };
    let tx_hash = request.params[0].clone();
    let response = match fetch_transaction_receipt(&rpc_url, &tx_hash, request_id).await {
        Ok(response) => response,
        Err(error) => return mcp_error(error),
    };
    let Some(receipt) = response.result else {
        return mcp_json(serde_json::json!({
            "network": network,
            "request": request,
            "receipt_found": false,
            "tx_hash": tx_hash,
            "block_number": null,
            "succeeded": null,
            "log_count": 0,
            "receipt": null
        }));
    };
    let block_number = match receipt.block_number() {
        Ok(block_number) => block_number,
        Err(error) => return mcp_error(error),
    };
    let succeeded = match receipt.succeeded() {
        Ok(succeeded) => succeeded,
        Err(error) => return mcp_error(error),
    };
    let log_count = receipt.logs.len();

    mcp_json(serde_json::json!({
        "network": network,
        "request": request,
        "receipt_found": true,
        "tx_hash": tx_hash,
        "block_number": block_number,
        "succeeded": succeeded,
        "log_count": log_count,
        "receipt": receipt
    }))
}

fn configured_autonomous_planner(network: &str) -> Result<AutonomousBountyTxPlanner, String> {
    let descriptor = base_network_descriptor(network).map_err(|error| error.to_string())?;
    let (factory_env, implementation_env) = match descriptor.chain_id {
        8_453 => (
            "BASE_MAINNET_BOUNTY_FACTORY",
            "BASE_MAINNET_BOUNTY_IMPLEMENTATION",
        ),
        84_532 => (
            "BASE_SEPOLIA_BOUNTY_FACTORY",
            "BASE_SEPOLIA_BOUNTY_IMPLEMENTATION",
        ),
        _ => return Err("unsupported Base network".to_string()),
    };
    let (factory, implementation) = autonomous_planner_addresses(
        descriptor.chain_id,
        env::var(factory_env).ok(),
        env::var(implementation_env).ok(),
    )?;
    AutonomousBountyTxPlanner::new(factory, implementation).map_err(|error| error.to_string())
}

fn autonomous_planner_addresses(
    chain_id: u64,
    configured_factory: Option<String>,
    configured_implementation: Option<String>,
) -> Result<(String, String), String> {
    service_runtime::autonomous_planner_addresses(
        chain_id,
        configured_factory,
        configured_implementation,
    )
    .map_err(|error| match error {
        PlannerAddressError::UnsupportedNetwork => "unsupported Base network".to_string(),
        PlannerAddressError::NoncanonicalMainnet => "configured Base mainnet autonomous deployment does not match the canonical attested deployment".to_string(),
        PlannerAddressError::MissingFactory => "hosted autonomous protocol is not configured: set BASE_SEPOLIA_BOUNTY_FACTORY".to_string(),
        PlannerAddressError::MissingImplementation => "hosted autonomous protocol is not configured: set BASE_SEPOLIA_BOUNTY_IMPLEMENTATION".to_string(),
    })
}

async fn require_indexed_canonical_bounty(
    state: &SharedState,
    network: &str,
    bounty_contract: &str,
) -> Result<(), String> {
    let item = indexed_autonomous_bounty(state, network, bounty_contract).await?;
    if item.terms_valid {
        Ok(())
    } else {
        Err(format!(
            "canonical bounty terms do not match contract commitments: {}",
            item.validation_errors.join("; ")
        ))
    }
}

async fn indexed_autonomous_bounty(
    state: &SharedState,
    network: &str,
    bounty_contract: &str,
) -> Result<AutonomousBountyFeedItem, String> {
    let Some(store) = &state.store else {
        return Err(
            "DATABASE_URL is required before planning actions against a canonical bounty"
                .to_string(),
        );
    };
    let planner = configured_autonomous_planner(network)?;
    let events = store
        .list_autonomous_bounty_events(network)
        .await
        .map_err(|error| error.to_string())?;
    let contracts = store
        .list_canonical_autonomous_bounty_contracts(network, &planner.factory_contract)
        .await
        .map_err(|error| error.to_string())?;
    if !contracts
        .iter()
        .any(|contract| contract.eq_ignore_ascii_case(bounty_contract))
    {
        return Err("bounty contract is not indexed as canonical for this network".to_string());
    }
    let terms = store
        .list_autonomous_bounty_terms()
        .await
        .map_err(|error| error.to_string())?;
    let mut feed =
        build_autonomous_bounty_feed(events, terms, false).map_err(|error| error.to_string())?;
    state.recovery_reservations.apply(&mut feed, false);
    feed.into_iter()
        .find(|item| item.bounty_contract.eq_ignore_ascii_case(bounty_contract))
        .ok_or_else(|| "canonical bounty has no indexed feed state".to_string())
}

async fn plan_autonomous_canonical_child_terms(
    Json(args): Json<CanonicalChildBountyTermsRequest>,
) -> Json<serde_json::Value> {
    match build_canonical_child_bounty_terms_plan(&args) {
        Ok(plan) => mcp_json(plan),
        Err(error) => mcp_error(error),
    }
}

async fn prepare_standing_meta_v2_child(
    State(state): State<SharedState>,
    Json(args): Json<StandingMetaV2ChildPreparationRequest>,
) -> Json<serde_json::Value> {
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    if network != "base-mainnet" {
        return mcp_error("standing-meta child preparation is deployed only on Base mainnet");
    }
    let parent =
        match indexed_autonomous_bounty(&state, network, &args.parent_bounty_contract).await {
            Ok(parent) => parent,
            Err(error) => return mcp_error(error),
        };
    let context = match standing_meta_v2_parent_context(&parent) {
        Ok(context) => context,
        Err(error) => return mcp_error(error),
    };
    if args.parent_solver.eq_ignore_ascii_case(&parent.creator) {
        return mcp_error("the parent bounty creator cannot be its solver");
    }
    let planner = match configured_autonomous_planner(network) {
        Ok(planner) => planner,
        Err(error) => return mcp_error(error),
    };
    let mut plan = match planner.plan_standing_meta_v2_child(&args, &context, Utc::now()) {
        Ok(plan) => plan,
        Err(error) => return mcp_error(error),
    };
    let Some(store) = &state.store else {
        return mcp_error(
            "DATABASE_URL is required to publish child terms; do not send on-chain calls first",
        );
    };
    if let Err(error) = store.upsert_autonomous_bounty_terms(&plan.terms).await {
        return mcp_error(format!(
            "hosted child terms publication failed: {error}; retry the identical request and do not send the on-chain calls"
        ));
    }
    plan.hosted_terms_published = true;
    plan.current_state = "hosted_routed_v3_child_terms_published_parent_unclaimed".to_string();
    mcp_json(plan)
}

async fn plan_autonomous_bounty_creation(
    State(state): State<SharedState>,
    Json(args): Json<PlanAutonomousBountyCreationArgs>,
) -> Json<serde_json::Value> {
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    if let Err(error) = require_autonomous_creation_terms(&state, network, &args.create).await {
        return mcp_error(error);
    }
    match configured_autonomous_planner(network).and_then(|planner| {
        planner
            .plan_creation(network, &args.create)
            .map_err(|e| e.to_string())
    }) {
        Ok(plan) => mcp_json(plan),
        Err(error) => mcp_error(error),
    }
}

async fn plan_autonomous_bounty_authorized_creation(
    State(state): State<SharedState>,
    Json(args): Json<PlanAutonomousBountyAuthorizedCreationArgs>,
) -> Json<serde_json::Value> {
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    if let Err(error) = require_autonomous_creation_terms(&state, network, &args.create).await {
        return mcp_error(error);
    }
    match configured_autonomous_planner(network).and_then(|planner| {
        planner
            .plan_authorized_creation(
                network,
                &args.create,
                &args.signature,
                args.relayer.as_deref(),
            )
            .map_err(|error| error.to_string())
    }) {
        Ok(plan) => mcp_json(plan),
        Err(error) => mcp_error(error),
    }
}

async fn require_autonomous_creation_terms(
    state: &SharedState,
    network: &str,
    create: &AutonomousBountyCreate,
) -> Result<(), String> {
    let Some(store) = &state.store else {
        return Err("DATABASE_URL is required before planning canonical creation".to_string());
    };
    let terms = store
        .get_autonomous_bounty_terms(&create.terms_hash)
        .await
        .map_err(|error| error.to_string())?
        .ok_or_else(|| "published autonomous bounty terms are unavailable".to_string())?;
    validate_autonomous_creation_for_public_earning(network, create, &terms)
        .map_err(|error| error.to_string())
}

async fn plan_autonomous_bounty_contribution(
    State(state): State<SharedState>,
    Json(args): Json<PlanAutonomousBountyContributionArgs>,
) -> Json<serde_json::Value> {
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    if let Err(error) =
        require_indexed_canonical_bounty(&state, network, &args.contribution.bounty_contract).await
    {
        return mcp_error(error);
    }
    match configured_autonomous_planner(network).and_then(|planner| {
        planner
            .plan_contribution(network, &args.contribution)
            .map_err(|error| error.to_string())
    }) {
        Ok(plan) => mcp_json(plan),
        Err(error) => mcp_error(error),
    }
}

async fn plan_autonomous_bounty_authorized_contribution(
    State(state): State<SharedState>,
    Json(args): Json<PlanAutonomousBountyAuthorizedContributionArgs>,
) -> Json<serde_json::Value> {
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    if let Err(error) =
        require_indexed_canonical_bounty(&state, network, &args.contribution.bounty_contract).await
    {
        return mcp_error(error);
    }
    match configured_autonomous_planner(network).and_then(|planner| {
        planner
            .plan_authorized_contribution(
                network,
                &args.contribution,
                &args.signature,
                args.relayer.as_deref(),
            )
            .map_err(|error| error.to_string())
    }) {
        Ok(plan) => mcp_json(plan),
        Err(error) => mcp_error(error),
    }
}

async fn fund_bounty_with_x402(
    State(_state): State<SharedState>,
    Json(args): Json<X402BountyFundingArgs>,
) -> Json<serde_json::Value> {
    let bounty_contract = match normalize_evm_address(&args.bounty_contract) {
        Ok(address) => address,
        Err(error) => return mcp_error(error),
    };
    let network = args.network.unwrap_or_else(|| "base-mainnet".to_string());
    if base_network_descriptor(&network).is_err() {
        return mcp_error("network must be base-mainnet or base-sepolia");
    }
    let url = format!(
        "{}/v1/x402/base/bounties/{}/funding",
        api_upstream_base_url_from_env().trim_end_matches('/'),
        bounty_contract
    );
    let mut query = vec![("network", network)];
    if let Some(amount) = args.amount {
        query.push(("amount", amount.to_string()));
    }
    if let Some(relayer) = args.relayer {
        query.push(("relayer", relayer));
    }
    let mut request = reqwest::Client::new().get(url).query(&query);
    if let Some(payment_signature) = args.payment_signature {
        request = request.header("PAYMENT-SIGNATURE", payment_signature);
    }
    proxy_x402_response(request).await
}

async fn get_x402_relay_status(
    State(_state): State<SharedState>,
    Json(args): Json<GetX402RelayStatusArgs>,
) -> Json<serde_json::Value> {
    let url = format!(
        "{}/v1/x402/base/relays/{}",
        api_upstream_base_url_from_env().trim_end_matches('/'),
        args.relay_id
    );
    proxy_x402_response(reqwest::Client::new().get(url)).await
}

async fn prepare_agent_to_earn(
    State(_state): State<SharedState>,
    Json(args): Json<PrepareAgentToEarnInput>,
) -> Json<serde_json::Value> {
    let url = format!(
        "{}/v1/base/agent-wallet/readiness",
        api_upstream_base_url_from_env().trim_end_matches('/')
    );
    proxy_public_json_response(
        reqwest::Client::new().post(url).json(&args),
        "agent wallet readiness API",
    )
    .await
}

async fn list_open_competition_verifiers(
    State(_state): State<SharedState>,
    Json(args): Json<OpenCompetitionVerifierArgs>,
) -> Json<serde_json::Value> {
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    let url = format!(
        "{}/v1/base/open-competition-v1/verifiers",
        api_upstream_base_url_from_env().trim_end_matches('/')
    );
    proxy_public_json_response(
        reqwest::Client::new()
            .get(url)
            .query(&[("network", network)]),
        "open-competition verifier catalog API",
    )
    .await
}

async fn prepare_open_competition_creation(
    State(_state): State<SharedState>,
    Json(args): Json<OpenCompetitionCreationArgs>,
) -> Json<serde_json::Value> {
    let path = if args.funding_authorization.is_some() {
        "authorized-creation-preparation"
    } else {
        "creation-preparation"
    };
    proxy_open_competition_json(path, &args).await
}

async fn get_open_competition_readiness(
    State(_state): State<SharedState>,
    Json(args): Json<OpenCompetitionReadinessArgs>,
) -> Json<serde_json::Value> {
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    let url = format!(
        "{}/v1/base/open-competition-v1/readiness",
        api_upstream_base_url_from_env().trim_end_matches('/')
    );
    let mut query = vec![
        ("network", network.to_string()),
        ("bounty_contract", args.bounty_contract),
    ];
    if let Some(solver) = args.solver {
        query.push(("solver", solver));
    }
    if let Some(profile_id) = args.verifier_profile_id {
        query.push(("verifier_profile_id", profile_id));
    }
    proxy_public_json_response(
        reqwest::Client::new().get(url).query(&query),
        "open-competition readiness API",
    )
    .await
}

async fn prepare_open_competition_commit(
    State(_state): State<SharedState>,
    Json(args): Json<OpenCompetitionCommitArgs>,
) -> Json<serde_json::Value> {
    proxy_open_competition_json("commit-preparation", &args).await
}

async fn prepare_open_competition_reveal(
    State(_state): State<SharedState>,
    Json(args): Json<OpenCompetitionRevealArgs>,
) -> Json<serde_json::Value> {
    proxy_open_competition_json("reveal-preparation", &args).await
}

async fn get_open_competition_status(
    State(_state): State<SharedState>,
    Json(args): Json<OpenCompetitionActionArgs>,
) -> Json<serde_json::Value> {
    proxy_open_competition_action("status", args).await
}

async fn withdraw_open_competition_bond(
    State(_state): State<SharedState>,
    Json(args): Json<OpenCompetitionActionArgs>,
) -> Json<serde_json::Value> {
    proxy_open_competition_action("bond-withdrawal-preparation", args).await
}

async fn prepare_open_competition_entrant_action(
    State(_state): State<SharedState>,
    Json(args): Json<OpenCompetitionEntrantActionArgs>,
) -> Json<serde_json::Value> {
    proxy_open_competition_json_with_timeout("entrant-action-preparation", &args, 60).await
}

async fn relay_open_competition_entrant_action(
    State(_state): State<SharedState>,
    Json(args): Json<OpenCompetitionEntrantRelayArgs>,
) -> Json<serde_json::Value> {
    proxy_open_competition_json_with_timeout("entrant-action-relays", &args, 90).await
}

async fn get_open_competition_entrant_relay(
    State(_state): State<SharedState>,
    Json(args): Json<GetOpenCompetitionEntrantRelayArgs>,
) -> Json<serde_json::Value> {
    let relay_id = match uuid::Uuid::parse_str(&args.relay_id) {
        Ok(relay_id) => relay_id,
        Err(_) => return mcp_error("relay_id must be a UUID"),
    };
    let url = format!(
        "{}/v1/base/open-competition-v1/entrant-action-relays/{relay_id}",
        api_upstream_base_url_from_env().trim_end_matches('/')
    );
    proxy_public_json_response_with_timeout(
        reqwest::Client::new().get(url),
        "open-competition entrant relay API",
        60,
    )
    .await
}

fn open_competition_v2_mcp_guide() -> Value {
    json!({
        "schema_version": "agent-bounties/open-competition-v2-mcp-guide-v1",
        "protocol_version": "agent-bounties/open-competition-v2-beta3",
        "default_network": "base-mainnet",
        "start": {
            "tool": "inspect_open_competition_v2",
            "arguments": {"operation": "release", "network": "base-mainnet"},
            "continue_only_if": "activation_state=public_beta and indexer_agreement.agrees=true"
        },
        "flows": {
            "post": [
                {"step": 1, "tool": "inspect_open_competition_v2", "operation": "release", "purpose": "Confirm the current release and activation state."},
                {"step": 2, "tool": "inspect_open_competition_v2", "operation": "profiles", "purpose": "Choose only a reviewed metric profile."},
                {"step": 3, "tool": "prepare_open_competition_v2", "operation": "prepare_profile", "purpose": "Derive immutable fields for structured-artifact or public-vector work. Use profile_id to select the exact schema; legacy structured-artifact requests may omit it."},
                {"step": 4, "tool": "prepare_open_competition_v2", "operation": "prepare_policies", "purpose": "Derive the exact execution-policy hash, settlement-policy hash, and retry-safe creation nonce from complete public policy JSON and one stable unique seed."},
                {"step": 5, "tool": "prepare_open_competition_v2", "operation": "validate", "purpose": "Validate the complete creation body before any signature."},
                {"step": 6, "tool": "prepare_open_competition_v2", "operation": "create", "purpose": "Receive exact unsigned wallet calls; execute them only after explicit approval."},
                {"step": 7, "tool": "prepare_open_competition_v2", "operation": "fund", "purpose": "Prepare any remaining pooled funding; wait for canonical activation."},
                {"step": 8, "tool": "get_bounty_feed", "arguments": {"network": "base-mainnet", "source_type": "canonical_base", "limit": 300}, "purpose": "Match the returned item's network and source_id to the exact competition contract. Advertise it as ready to earn only when that item has verification_ready=true. If the item is missing or false, wait; active escrow alone is not readiness. Use the chosen network if different from base-mainnet."}
            ],
            "earn_hosted": [
                {"step": 1, "tool": "inspect_open_competition_v2", "operation": "inventory", "arguments": {"state": "active"}, "purpose": "Check hosted_proof_block first. If it is non-null, stop this hosted flow and follow its message; do not fund child work, request a quote, or sign a new payment. Otherwise select by immutable criteria, deadline, winner mode, and net prize if won."},
                {"step": 2, "tool": "prepare_open_competition_v2", "operation": "quote_proof", "purpose": "Create one solver- and artifact-bound hosted proof job; do not duplicate a live quote."},
                {"step": 3, "tool": "prepare_open_competition_v2", "operation": "pay_proof", "purpose": "First omit payment_signature, then obtain explicit approval, sign the exact x402 challenge, and call once with that signature."},
                {"step": 4, "tool": "inspect_open_competition_v2", "operation": "proof_job", "purpose": "Poll the same proof_job_id; never repay payment_pending, paid, proving, proved, relaying, or confirmed."},
                {"step": 5, "tool": "prepare_open_competition_v2", "operation": "authorize_relay", "purpose": "After proved, first omit solver_signature, then obtain explicit approval, sign the exact EIP-712 data, and call once with that signature."},
                {"step": 6, "tool": "inspect_open_competition_v2", "operation": "events", "purpose": "Confirm safe-block CompetitionSettledV2 before reporting solver payment."}
            ],
            "earn_byo_proof": [
                {"step": 1, "tool": "inspect_open_competition_v2", "operation": "inventory", "arguments": {"state": "active"}},
                {"step": 2, "tool": "prepare_open_competition_v2", "operation": "prepare_proof", "purpose": "Receive a direct call or exact relay authorization for already-generated proof bytes."},
                {"step": 3, "instruction": "Execute only the returned exact call after explicit approval, then inspect events."}
            ],
            "finish_or_refund": [
                {"tool": "prepare_open_competition_v2", "operation": "prepare_action", "actions": ["finalize_best_score", "cancel_funding", "expire_competition", "cancel_unavailable_verifier", "withdraw_refund_for"]},
                {"instruction": "Execute the returned unsigned wallet call only after explicit approval and confirm its named safe-block event."}
            ]
        },
        "operations": ["prepare_profile", "prepare_policies", "validate", "create", "fund", "quote_proof", "pay_proof", "prepare_proof", "authorize_relay", "prepare_action"],
        "profile_support": {
            "structured-artifact-metric-v1": "prepare_profile accepts threshold and deterministic artifact requirements.",
            "public-vector-metric-v1": "prepare_profile accepts mode, threshold, and expected/weight policy vectors; quote_proof later adds each observed value. Copy the matching reviewed profile fields from profiles into validate.",
            "forward-canonical-gmv-attribution-metric-v2": "Verification is on hold. New quotes and payments for unpaid quotes return 409 verification_not_ready. Do not fund child work or pay for a proof. Wait for a reviewed release that verifies the exact snapshot, attester quorum and proof path. Existing accepted payments retain reconciliation and existing job IDs must not be repaid."
        },
        "side_effects": {
            "quote_proof": "Creates one hosted proof-job record.",
            "pay_proof": "With payment_signature, may submit an approved Base USDC payment.",
            "authorize_relay": "With solver_signature, may queue the approved proof relay.",
            "other_operations": "Return deterministic calculations or unsigned wallet calls; executing a returned call is a separate user-approved action."
        },
        "safety": [
            "Never request or transmit a private key or recovery phrase.",
            "Ask immediately before a wallet signature, payment signature, or solver relay signature.",
            "Do not infer state from a plan, signature, proof, database row, or transaction hash.",
            "Only a safe-block CompetitionSettledV2 event proves solver payment."
        ],
        "documentation": "https://github.com/NSPG13/agent-bounties/blob/main/docs/open-competition-v2-beta3.md",
        "next_action": "Call inspect_open_competition_v2 with operation=release on base-mainnet."
    })
}

async fn inspect_open_competition_v2(
    State(_state): State<SharedState>,
    Json(args): Json<OpenCompetitionV2InspectArgs>,
) -> Json<serde_json::Value> {
    if args.operation == "guide" {
        return mcp_json(open_competition_v2_mcp_guide());
    }
    let api = api_upstream_base_url_from_env();
    let root = format!(
        "{}/v1/base/open-competition-v2-beta3",
        api.trim_end_matches('/')
    );
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    let request = match args.operation.as_str() {
        "release" => reqwest::Client::new()
            .get(format!("{root}/release"))
            .query(&[("network", network)]),
        "profiles" => reqwest::Client::new()
            .get(format!("{root}/profiles"))
            .query(&[("network", network)]),
        "inventory" => {
            let mut query = vec![("network", network.to_string())];
            if let Some(state) = args.state {
                query.push(("state", state));
            }
            reqwest::Client::new()
                .get(format!("{root}/inventory"))
                .query(&query)
        }
        "events" => {
            let mut query = vec![("network", network.to_string())];
            if let Some(bounty_id) = args.bounty_id {
                query.push(("bounty_id", bounty_id));
            }
            reqwest::Client::new()
                .get(format!("{root}/events"))
                .query(&query)
        }
        "proof_job" => {
            let Some(job_id) = args.job_id else {
                return mcp_error("job_id is required for proof_job");
            };
            if uuid::Uuid::parse_str(&job_id).is_err() {
                return mcp_error("job_id must be a UUID");
            }
            reqwest::Client::new().get(format!("{root}/proof-jobs/{job_id}"))
        }
        _ => return mcp_error("unsupported V2 inspect operation"),
    };
    proxy_public_json_response_with_timeout(request, "Open Competition V2 API", 60).await
}

async fn prepare_open_competition_v2(
    State(_state): State<SharedState>,
    Json(args): Json<OpenCompetitionV2MutationArgs>,
) -> Json<serde_json::Value> {
    let mut arguments = args.arguments;
    if args.operation == "prepare_policies" {
        return prepare_open_competition_v2_policies(arguments);
    }
    if args.operation == "prepare_profile" {
        let profile_id = arguments
            .get("profile_id")
            .and_then(Value::as_str)
            .map(str::to_string);
        if profile_id.as_deref() == Some("public-vector-metric-v1") {
            let Some(object) = arguments.as_object_mut() else {
                return mcp_error("prepare_profile arguments must be an object");
            };
            object.remove("profile_id");
            return prepare_open_competition_v2_public_vector_profile(arguments);
        }
        if profile_id.as_deref() == Some("structured-artifact-metric-v1") {
            arguments
                .as_object_mut()
                .expect("schema requires prepare_profile arguments to be an object")
                .remove("profile_id");
        } else if profile_id.is_some() {
            return mcp_error(
                "prepare_profile profile_id must be structured-artifact-metric-v1 or public-vector-metric-v1",
            );
        }
    }
    if args.operation == "pay_proof" {
        let Some(object) = arguments.as_object_mut() else {
            return mcp_error("pay_proof arguments must be an object");
        };
        let Some(job_id) = object
            .remove("proof_job_id")
            .and_then(|value| value.as_str().map(str::to_string))
        else {
            return mcp_error("pay_proof requires proof_job_id");
        };
        if uuid::Uuid::parse_str(&job_id).is_err() {
            return mcp_error("proof_job_id must be a UUID");
        }
        let payment_signature = object
            .remove("payment_signature")
            .and_then(|value| value.as_str().map(str::to_string));
        if payment_signature.as_deref().is_some_and(|value| {
            value.is_empty() || value.bytes().any(|byte| byte.is_ascii_control())
        }) {
            return mcp_error("payment_signature cannot be empty or contain control characters");
        }
        let url = format!(
            "{}/v1/base/open-competition-v2-beta3/proof-jobs/{job_id}/payment",
            api_upstream_base_url_from_env().trim_end_matches('/')
        );
        let mut request = reqwest::Client::new().post(url);
        if let Some(signature) = payment_signature {
            request = request.header("PAYMENT-SIGNATURE", signature);
        }
        return proxy_open_competition_v2_payment(request).await;
    }
    let path = match args.operation.as_str() {
        "prepare_profile" => "structured-artifact-profile".to_string(),
        "validate" => "validate".to_string(),
        "create" => "creation-preparation".to_string(),
        "fund" => "funding-preparation".to_string(),
        "quote_proof" => "proof-quotes".to_string(),
        "prepare_proof" => "proof-preparation".to_string(),
        "authorize_relay" => {
            let Some(object) = arguments.as_object_mut() else {
                return mcp_error("authorize_relay arguments must be an object");
            };
            let Some(job_id) = object
                .remove("proof_job_id")
                .and_then(|value| value.as_str().map(str::to_string))
            else {
                return mcp_error("authorize_relay requires proof_job_id");
            };
            if uuid::Uuid::parse_str(&job_id).is_err() {
                return mcp_error("proof_job_id must be a UUID");
            }
            format!("proof-jobs/{job_id}/relay-authorization")
        }
        "prepare_action" => "action-preparation".to_string(),
        _ => return mcp_error("unsupported V2 preparation operation"),
    };
    let url = format!(
        "{}/v1/base/open-competition-v2-beta3/{path}",
        api_upstream_base_url_from_env().trim_end_matches('/')
    );
    proxy_public_json_response_with_timeout(
        reqwest::Client::new().post(url).json(&arguments),
        "Open Competition V2 API",
        90,
    )
    .await
}

fn prepare_open_competition_v2_policies(arguments: Value) -> Json<serde_json::Value> {
    let body: OpenCompetitionV2PolicyBody = match serde_json::from_value(arguments) {
        Ok(body) => body,
        Err(error) => return mcp_error(format!("invalid V2 policies: {error}")),
    };
    if body
        .execution_policy
        .as_object()
        .is_none_or(|policy| policy.is_empty())
        || body
            .settlement_policy
            .as_object()
            .is_none_or(|policy| policy.is_empty())
    {
        return mcp_error("execution_policy and settlement_policy must be non-empty objects");
    }
    let seed = body.creation_nonce_seed.trim();
    if seed.is_empty() || seed.len() > 256 {
        return mcp_error("creation_nonce_seed must contain 1..256 UTF-8 bytes");
    }
    let execution_policy_hash = match chain_base::keccak256_canonical_json(&body.execution_policy) {
        Ok(hash) => hash,
        Err(error) => {
            return mcp_error(format!("execution policy is not canonicalizable: {error}"))
        }
    };
    let settlement_policy_hash = match chain_base::keccak256_canonical_json(&body.settlement_policy)
    {
        Ok(hash) => hash,
        Err(error) => {
            return mcp_error(format!("settlement policy is not canonicalizable: {error}"))
        }
    };
    let creation_nonce = match chain_base::keccak256_canonical_json(&json!({
        "schema_version": "agent-bounties/open-competition-v2-creation-nonce-v1",
        "seed": seed
    })) {
        Ok(hash) => hash,
        Err(error) => return mcp_error(format!("creation nonce is not canonicalizable: {error}")),
    };
    mcp_json(json!({
        "schema_version": "agent-bounties/open-competition-v2-policy-commitments-v1",
        "execution_policy": body.execution_policy,
        "execution_policy_hash": execution_policy_hash,
        "settlement_policy": body.settlement_policy,
        "settlement_policy_hash": settlement_policy_hash,
        "creation_nonce": creation_nonce,
        "next_action": "Copy these exact hashes and nonce into validate. Reuse the same seed only for an idempotent retry of this intended competition.",
        "evidence_boundary": "Deterministic policy commitments and a nonce are not creation, funding, qualification, settlement, or payment evidence."
    }))
}

fn prepare_open_competition_v2_public_vector_profile(arguments: Value) -> Json<serde_json::Value> {
    let body: OpenCompetitionV2PublicVectorProfileBody = match serde_json::from_value(arguments) {
        Ok(body) => body,
        Err(error) => return mcp_error(format!("invalid public-vector profile: {error}")),
    };
    let network = body.network.unwrap_or_else(|| "base-mainnet".to_string());
    if !matches!(network.as_str(), "base-mainnet" | "base-sepolia") {
        return mcp_error("network must be base-mainnet or base-sepolia");
    }
    let threshold = match body.threshold.parse::<i128>() {
        Ok(threshold) => threshold,
        Err(_) => return mcp_error("threshold must be an i128 decimal string"),
    };
    if body.mode != PublicVectorMode::AllEqual && threshold < 0 {
        return mcp_error("threshold cannot be negative for this public-vector mode");
    }
    if body.vectors.is_empty() || body.vectors.len() > 10_000 {
        return mcp_error("vectors must contain 1..10000 cases");
    }
    if body.vectors.iter().any(|case| case.weight == 0) {
        return mcp_error("every public-vector weight must be positive");
    }
    let vectors = body
        .vectors
        .iter()
        .map(|case| PublicVectorCase {
            expected: case.expected,
            observed: case.expected,
            weight: case.weight,
        })
        .collect::<Vec<_>>();
    let input = PublicVectorProgramInput {
        scope: JournalScopeV2 {
            chain_id: 0,
            competition: [0; 20],
            bounty_id: [0; 32],
            solver: [0; 20],
            solver_nonce: 0,
            proof_system: [0; 32],
            program_vkey: [0; 32],
            source_hash: [0; 32],
            elf_hash: [0; 32],
            execution_policy_hash: [0; 32],
            settlement_policy_hash: [0; 32],
            beta_risk_hash: [0; 32],
        },
        mode: body.mode,
        threshold,
        vectors,
    };
    let policy_hash = verification_policy_hash(&input);
    let policy_hash = policy_hash
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect::<String>();
    let mode = match body.mode {
        PublicVectorMode::AllEqual => "all_equal",
        PublicVectorMode::MaximizeExactMatches => "maximize_exact_matches",
        PublicVectorMode::MinimizeAbsoluteError => "minimize_absolute_error",
    };
    let score_direction = match body.mode {
        PublicVectorMode::AllEqual | PublicVectorMode::MaximizeExactMatches => "higher_is_better",
        PublicVectorMode::MinimizeAbsoluteError => "lower_is_better",
    };
    mcp_json(json!({
        "schema_version": "agent-bounties/open-competition-v2-public-vector-profile-v1",
        "protocol_version": "agent-bounties/open-competition-v2-beta3",
        "network": network,
        "profile_id": "public-vector-metric-v1",
        "mode": mode,
        "verification_policy_hash": format!("0x{policy_hash}"),
        "score_threshold": threshold.to_string(),
        "score_direction": score_direction,
        "vectors": body.vectors,
        "next_action": "From the latest profiles response, copy the exact reviewed public-vector profile fields plus this threshold, direction, and verification policy hash into validate; stop if that profile is not reviewed.",
        "evidence_boundary": "This deterministic profile calculation is not profile review, creation, funding, qualification, settlement, or payment evidence."
    }))
}

async fn proxy_open_competition_v2_payment(
    request: reqwest::RequestBuilder,
) -> Json<serde_json::Value> {
    let response =
        match tokio::time::timeout(std::time::Duration::from_secs(90), request.send()).await {
            Ok(Ok(response)) => response,
            Ok(Err(error)) => {
                return mcp_error(format!("Open Competition V2 payment API failed: {error}"))
            }
            Err(_) => return mcp_error("Open Competition V2 payment API timed out"),
        };
    let status = response.status().as_u16();
    let payment_required = response
        .headers()
        .get("PAYMENT-REQUIRED")
        .and_then(|value| value.to_str().ok())
        .map(str::to_string);
    let payment_response = response
        .headers()
        .get("PAYMENT-RESPONSE")
        .and_then(|value| value.to_str().ok())
        .map(str::to_string);
    let body = match response.text().await {
        Ok(body) => serde_json::from_str(&body).unwrap_or_else(|_| json!({"text": body})),
        Err(error) => {
            return mcp_error(format!("Open Competition V2 payment body failed: {error}"))
        }
    };
    Json(json!({
        "status": status,
        "payment_required": payment_required,
        "payment_response": payment_response,
        "body": body,
        "next_action": if status == 402 {
            "Sign the exact PAYMENT-REQUIRED challenge, then call pay_proof once with payment_signature."
        } else if status == 202 {
            "Poll proof_job; do not sign or pay again."
        } else if status == 200 {
            "Poll proof_job until proved, then sign the relay authorization only if relay was requested."
        } else {
            "Read body.error_code and retry only when it says retryable."
        }
    }))
}

async fn proxy_open_competition_action(
    path: &str,
    args: OpenCompetitionActionArgs,
) -> Json<serde_json::Value> {
    let url = format!(
        "{}/v1/base/open-competition-v1/{path}",
        api_upstream_base_url_from_env().trim_end_matches('/')
    );
    proxy_public_json_response(
        reqwest::Client::new().post(url).json(&args),
        "open-competition action API",
    )
    .await
}

async fn proxy_open_competition_json<T>(path: &str, args: &T) -> Json<serde_json::Value>
where
    T: Serialize + ?Sized,
{
    proxy_open_competition_json_with_timeout(path, args, 20).await
}

async fn proxy_open_competition_json_with_timeout<T>(
    path: &str,
    args: &T,
    timeout_seconds: u64,
) -> Json<serde_json::Value>
where
    T: Serialize + ?Sized,
{
    let url = format!(
        "{}/v1/base/open-competition-v1/{path}",
        api_upstream_base_url_from_env().trim_end_matches('/')
    );
    proxy_public_json_response_with_timeout(
        reqwest::Client::new().post(url).json(args),
        "open-competition action API",
        timeout_seconds,
    )
    .await
}

async fn get_standing_meta_v4_readiness(
    State(_state): State<SharedState>,
    Json(args): Json<StandingMetaV4ReadinessArgs>,
) -> Json<serde_json::Value> {
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    let url = format!(
        "{}/v1/base/standing-meta-v4/readiness?network={network}",
        api_upstream_base_url_from_env().trim_end_matches('/')
    );
    proxy_public_json_response(
        reqwest::Client::new().get(url),
        "standing-meta-v4 readiness API",
    )
    .await
}

async fn prepare_standing_meta_v4_claim(
    State(_state): State<SharedState>,
    Json(args): Json<StandingMetaV4ActionArgs>,
) -> Json<serde_json::Value> {
    proxy_standing_meta_v4_action("claim-preparation", args).await
}

async fn prepare_anonymous_stake_registration(
    State(_state): State<SharedState>,
    Json(args): Json<StandingMetaV4ActionArgs>,
) -> Json<serde_json::Value> {
    proxy_standing_meta_v4_action("stake-registration-preparation", args).await
}

async fn set_anonymous_stake_availability(
    State(_state): State<SharedState>,
    Json(args): Json<StandingMetaV4ActionArgs>,
) -> Json<serde_json::Value> {
    proxy_standing_meta_v4_action("stake-availability-preparation", args).await
}

async fn list_verification_assignments(
    State(_state): State<SharedState>,
    Json(args): Json<StandingMetaV4ActionArgs>,
) -> Json<serde_json::Value> {
    proxy_standing_meta_v4_action("verification-assignments", args).await
}

async fn submit_primary_verdict(
    State(_state): State<SharedState>,
    Json(args): Json<StandingMetaV4ActionArgs>,
) -> Json<serde_json::Value> {
    proxy_standing_meta_v4_action("primary-verdict-preparation", args).await
}

async fn waive_verification_appeal(
    State(_state): State<SharedState>,
    Json(args): Json<StandingMetaV4ActionArgs>,
) -> Json<serde_json::Value> {
    proxy_standing_meta_v4_action("appeal-waiver-preparation", args).await
}

async fn open_verification_appeal(
    State(_state): State<SharedState>,
    Json(args): Json<StandingMetaV4ActionArgs>,
) -> Json<serde_json::Value> {
    proxy_standing_meta_v4_action("appeal-opening-preparation", args).await
}

async fn submit_appeal_vote(
    State(_state): State<SharedState>,
    Json(args): Json<StandingMetaV4ActionArgs>,
) -> Json<serde_json::Value> {
    proxy_standing_meta_v4_action("appeal-vote-preparation", args).await
}

async fn finalize_verification_case(
    State(_state): State<SharedState>,
    Json(args): Json<StandingMetaV4ActionArgs>,
) -> Json<serde_json::Value> {
    proxy_standing_meta_v4_action("finalization-preparation", args).await
}

async fn proxy_standing_meta_v4_action(
    path: &str,
    args: StandingMetaV4ActionArgs,
) -> Json<serde_json::Value> {
    let url = format!(
        "{}/v1/base/standing-meta-v4/{path}",
        api_upstream_base_url_from_env().trim_end_matches('/')
    );
    proxy_public_json_response(
        reqwest::Client::new().post(url).json(&args),
        "standing-meta-v4 action API",
    )
    .await
}

async fn proxy_public_json_response(
    request: reqwest::RequestBuilder,
    service: &str,
) -> Json<serde_json::Value> {
    proxy_public_json_response_with_timeout(request, service, 20).await
}

async fn proxy_public_json_response_with_timeout(
    request: reqwest::RequestBuilder,
    service: &str,
    timeout_seconds: u64,
) -> Json<serde_json::Value> {
    let response = match request
        .timeout(std::time::Duration::from_secs(timeout_seconds))
        .send()
        .await
    {
        Ok(response) => response,
        Err(error) => {
            return mcp_error(if error.is_timeout() {
                format!("{service} timed out")
            } else {
                format!("{service} is unavailable")
            })
        }
    };
    let status = response.status();
    match response.json::<serde_json::Value>().await {
        Ok(body) => mcp_json(json!({"http_status": status.as_u16(), "body": body})),
        Err(_) => mcp_error(format!("{service} returned an unreadable response")),
    }
}

async fn agent_native_claim(
    State(_state): State<SharedState>,
    headers: HeaderMap,
    Json(mut args): Json<AgentNativeClaimArgs>,
) -> Json<serde_json::Value> {
    if args.source.as_deref().is_none_or(str::is_empty) {
        args.source = Some("mcp".to_string());
    }
    let url = format!(
        "{}/v1/base/autonomous-bounties/claims",
        api_upstream_base_url_from_env().trim_end_matches('/')
    );
    proxy_agent_claim_response(with_caller_authorization(
        reqwest::Client::builder()
            .redirect(reqwest::redirect::Policy::none())
            .build()
            .expect("valid HTTP client")
            .post(url)
            .json(&args),
        &headers,
    ))
    .await
}

async fn proxy_agent_claim_response(request: reqwest::RequestBuilder) -> Json<serde_json::Value> {
    let response = match request
        .timeout(std::time::Duration::from_secs(60))
        .send()
        .await
    {
        Ok(response) => response,
        Err(error) => {
            return mcp_error(if error.is_timeout() {
                "agent-native claim API timed out; replay the same idempotency_key"
            } else {
                "agent-native claim API is unavailable; use plan_autonomous_bounty_claim as the direct-wallet fallback"
            })
        }
    };
    let status = response.status();
    let body_text = match response.text().await {
        Ok(body) => body,
        Err(_) => return mcp_error("agent-native claim response body is unavailable"),
    };
    let body = serde_json::from_str::<serde_json::Value>(&body_text).unwrap_or_else(|_| {
        json!({
            "schema_version": "agent-bounties/claim-problem-v1",
            "state": "failed",
            "failed_transition": "read_hosted_response",
            "error": "invalid_hosted_response",
            "message": if body_text.is_empty() { format!("HTTP {}", status.as_u16()) } else { body_text },
            "next_action": "Call plan_autonomous_bounty_claim. Submit its exact direct-wallet calls."
        })
    });
    mcp_json(json!({
        "http_status": status.as_u16(),
        "body": body
    }))
}

async fn proxy_x402_response(request: reqwest::RequestBuilder) -> Json<serde_json::Value> {
    let response = match request
        .timeout(std::time::Duration::from_secs(45))
        .send()
        .await
    {
        Ok(response) => response,
        Err(error) => {
            return mcp_error(if error.is_timeout() {
                "canonical x402 API timed out"
            } else {
                "canonical x402 API is unavailable"
            })
        }
    };
    let status = response.status();
    let payment_required = response
        .headers()
        .get("PAYMENT-REQUIRED")
        .and_then(|value| value.to_str().ok())
        .map(ToOwned::to_owned);
    let payment_response = response
        .headers()
        .get("PAYMENT-RESPONSE")
        .and_then(|value| value.to_str().ok())
        .map(ToOwned::to_owned);
    let body_text = match response.text().await {
        Ok(body) => body,
        Err(_) => return mcp_error("canonical x402 API response body is unavailable"),
    };
    let body = serde_json::from_str::<serde_json::Value>(&body_text).unwrap_or_else(|_| {
        json!({
            "error": if body_text.is_empty() {
                format!("HTTP {}", status.as_u16())
            } else {
                body_text
            }
        })
    });
    mcp_json(json!({
        "http_status": status.as_u16(),
        "payment_required_header": payment_required,
        "payment_response_header": payment_response,
        "body": body
    }))
}

async fn plan_autonomous_bounty_claim(
    State(state): State<SharedState>,
    Json(args): Json<PlanAutonomousBountyClaimArgs>,
) -> Json<serde_json::Value> {
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    let item = match indexed_autonomous_bounty(&state, network, &args.bounty_contract).await {
        Ok(item) => item,
        Err(error) => return mcp_error(error),
    };
    if let Err(error) = require_claimable_autonomous_item(&item) {
        return mcp_error(error);
    }
    let claim_bond = match item.claim_bond.parse::<u128>() {
        Ok(value) => value,
        Err(_) => return mcp_error("indexed claim bond is invalid"),
    };
    match configured_autonomous_planner(network).and_then(|planner| {
        planner
            .plan_claim(
                network,
                &args.bounty_contract,
                &args.solver,
                claim_bond,
                args.authorization_nonce.as_deref(),
                args.authorization_valid_before,
            )
            .map_err(|error| error.to_string())
    }) {
        Ok(plan) => mcp_json(plan),
        Err(error) => mcp_error(error),
    }
}

async fn plan_autonomous_bounty_authorized_claim(
    State(state): State<SharedState>,
    Json(args): Json<PlanAutonomousBountyAuthorizedClaimArgs>,
) -> Json<serde_json::Value> {
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    let item = match indexed_autonomous_bounty(&state, network, &args.bounty_contract).await {
        Ok(item) => item,
        Err(error) => return mcp_error(error),
    };
    if let Err(error) = require_claimable_autonomous_item(&item) {
        return mcp_error(error);
    }
    let claim_bond = match item.claim_bond.parse::<u128>() {
        Ok(value) => value,
        Err(_) => return mcp_error("indexed claim bond is invalid"),
    };
    match configured_autonomous_planner(network).and_then(|planner| {
        planner
            .plan_authorized_claim(
                network,
                &args.bounty_contract,
                &args.solver,
                claim_bond,
                &args.authorization_nonce,
                args.authorization_valid_before,
                &args.signature,
                args.relayer.as_deref(),
            )
            .map_err(|error| error.to_string())
    }) {
        Ok(plan) => mcp_json(plan),
        Err(error) => mcp_error(error),
    }
}

fn require_claimable_autonomous_item(item: &AutonomousBountyFeedItem) -> Result<(), String> {
    if !item.terms_valid {
        return Err(format!(
            "canonical bounty terms do not match contract commitments: {}",
            item.validation_errors.join("; ")
        ));
    }
    if !autonomous_bounty_is_earning_ready(item) {
        return Err(format!(
            "canonical bounty is not executable earning inventory: {}",
            item.verification_readiness_reason
        ));
    }
    Ok(())
}

async fn plan_autonomous_bounty_submission(
    State(state): State<SharedState>,
    Json(args): Json<PlanAutonomousBountySubmissionArgs>,
) -> Json<serde_json::Value> {
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    if let Err(error) =
        require_indexed_canonical_bounty(&state, network, &args.bounty_contract).await
    {
        return mcp_error(error);
    }
    match configured_autonomous_planner(network).and_then(|planner| {
        planner
            .plan_submission(
                &args.bounty_contract,
                &args.solver,
                &args.submission_hash,
                &args.evidence_hash,
            )
            .map_err(|error| error.to_string())
    }) {
        Ok(plan) => mcp_json(plan),
        Err(error) => mcp_error(error),
    }
}

async fn prepare_autonomous_bounty_submission(
    State(state): State<SharedState>,
    Json(args): Json<PrepareAutonomousBountySubmissionArgs>,
) -> Json<serde_json::Value> {
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    let item = match indexed_autonomous_bounty(&state, network, &args.bounty_contract).await {
        Ok(item) => item,
        Err(error) => return mcp_error(error),
    };
    let observed_at_unix = match u64::try_from(Utc::now().timestamp()) {
        Ok(value) => value,
        Err(_) => return mcp_error("system clock is before Unix epoch"),
    };
    match configured_autonomous_planner(network).and_then(|planner| {
        build_autonomous_submission_preparation(
            &planner,
            network,
            &item,
            &args.solver_wallet,
            &args.artifact_reference,
            args.evidence,
            observed_at_unix,
        )
        .map_err(|error| error.to_string())
    }) {
        Ok(preparation) => mcp_json(preparation),
        Err(error) => mcp_error(error),
    }
}

async fn plan_autonomous_bounty_submission_authorization(
    State(state): State<SharedState>,
    Json(args): Json<PlanAutonomousBountySubmissionAuthorizationArgs>,
) -> Json<serde_json::Value> {
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    if let Err(error) =
        require_indexed_canonical_bounty(&state, network, &args.submission.bounty_contract).await
    {
        return mcp_error(error);
    }
    match configured_autonomous_planner(network).and_then(|planner| {
        planner
            .plan_submission_authorization(network, &args.submission)
            .map_err(|error| error.to_string())
    }) {
        Ok(plan) => mcp_json(plan),
        Err(error) => mcp_error(error),
    }
}

async fn plan_autonomous_verification_attestation(
    State(state): State<SharedState>,
    Json(args): Json<PlanAutonomousVerificationAttestationArgs>,
) -> Json<serde_json::Value> {
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    let item =
        match indexed_autonomous_bounty(&state, network, &args.attestation.bounty_contract).await {
            Ok(item) => item,
            Err(error) => return mcp_error(error),
        };
    let observed_at = match u64::try_from(Utc::now().timestamp()) {
        Ok(value) => value,
        Err(_) => return mcp_error("system clock is before Unix epoch"),
    };
    if let Err(error) =
        validate_attestation_request_against_feed(&item, &args.attestation, observed_at)
    {
        return mcp_error(error);
    }
    match configured_autonomous_planner(network).and_then(|planner| {
        planner
            .plan_verification_attestation(network, &args.attestation)
            .map_err(|error| error.to_string())
    }) {
        Ok(plan) => mcp_json(plan),
        Err(error) => mcp_error(error),
    }
}

async fn plan_autonomous_module_settlement(
    State(state): State<SharedState>,
    Json(args): Json<PlanAutonomousModuleSettlementArgs>,
) -> Json<serde_json::Value> {
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    let item = match indexed_autonomous_bounty(&state, network, &args.bounty_contract).await {
        Ok(item) => item,
        Err(error) => return mcp_error(error),
    };
    if !item.terms_valid
        || item.status != "submitted"
        || autonomous_item_mode(&item).as_deref() != Some("deterministic_module")
    {
        return mcp_error("bounty is not a submitted deterministic-module bounty");
    }
    match configured_autonomous_planner(network).and_then(|planner| {
        planner
            .plan_module_settlement(&args.bounty_contract, args.caller.as_deref(), &args.proof)
            .map_err(|error| error.to_string())
    }) {
        Ok(plan) => mcp_json(plan),
        Err(error) => mcp_error(error),
    }
}

async fn plan_autonomous_attestation_settlement(
    State(state): State<SharedState>,
    Json(args): Json<PlanAutonomousAttestationSettlementArgs>,
) -> Json<serde_json::Value> {
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    let item = match indexed_autonomous_bounty(&state, network, &args.bounty_contract).await {
        Ok(item) => item,
        Err(error) => return mcp_error(error),
    };
    if !item.terms_valid {
        return mcp_error(format!(
            "canonical bounty terms do not match contract commitments: {}",
            item.validation_errors.join("; ")
        ));
    }
    let Some(policy) = item
        .terms
        .as_ref()
        .map(|terms| &terms.document.verification_policy)
    else {
        return mcp_error("canonical bounty terms are unavailable");
    };
    let mechanism = policy
        .get("mechanism")
        .and_then(Value::as_str)
        .unwrap_or_default();
    let threshold = policy
        .get("threshold")
        .and_then(Value::as_u64)
        .and_then(|value| usize::try_from(value).ok());
    let allowed = policy.get("verifiers").and_then(Value::as_array);
    if item.status != "submitted"
        || !matches!(mechanism, "signed_quorum" | "ai_judge_quorum")
        || threshold != Some(args.attestations.len())
        || allowed.is_none_or(|verifiers| {
            args.attestations.iter().any(|attestation| {
                !verifiers.iter().any(|value| {
                    value.as_str().is_some_and(|verifier| {
                        verifier.eq_ignore_ascii_case(&attestation.verifier)
                    })
                })
            })
        })
    {
        return mcp_error("attestation quorum does not match the current immutable policy");
    }
    match configured_autonomous_planner(network).and_then(|planner| {
        planner
            .plan_attestation_settlement(
                &args.bounty_contract,
                args.caller.as_deref(),
                &args.attestations,
            )
            .map_err(|error| error.to_string())
    }) {
        Ok(plan) => mcp_json(plan),
        Err(error) => mcp_error(error),
    }
}

async fn plan_autonomous_expire_claim(
    State(state): State<SharedState>,
    Json(args): Json<PlanAutonomousLifecycleArgs>,
) -> Json<serde_json::Value> {
    plan_autonomous_lifecycle(state, args, "claimed", "expireClaim()").await
}

async fn plan_autonomous_expire_submission(
    State(state): State<SharedState>,
    Json(args): Json<PlanAutonomousLifecycleArgs>,
) -> Json<serde_json::Value> {
    plan_autonomous_lifecycle(state, args, "submitted", "expireSubmission()").await
}

async fn plan_autonomous_cancel(
    State(state): State<SharedState>,
    Json(args): Json<PlanAutonomousCancelArgs>,
) -> Json<serde_json::Value> {
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    let item = match indexed_autonomous_bounty(&state, network, &args.bounty_contract).await {
        Ok(item) => item,
        Err(error) => return mcp_error(error),
    };
    if !matches!(item.status.as_str(), "open" | "claimable") {
        return mcp_error("bounty is not cancellable");
    }
    let caller = args.caller.as_str();
    let funding_deadline = item
        .terms
        .as_ref()
        .and_then(|terms| terms.document.contract_terms["funding_deadline"].as_u64());
    let observed_at = match u64::try_from(Utc::now().timestamp()) {
        Ok(value) => value,
        Err(_) => return mcp_error("current time is unavailable"),
    };
    let caller = match validate_autonomous_cancel_authority(
        &item.status,
        &item.creator,
        caller,
        funding_deadline,
        observed_at,
    ) {
        Ok(caller) => caller,
        Err(error) => return mcp_error(error),
    };
    match configured_autonomous_planner(network).and_then(|planner| {
        planner
            .plan_cancel(&args.bounty_contract, Some(&caller))
            .map_err(|error| error.to_string())
    }) {
        Ok(plan) => mcp_json(plan),
        Err(error) => mcp_error(error),
    }
}

async fn plan_autonomous_refund_withdrawal(
    State(state): State<SharedState>,
    Json(args): Json<PlanAutonomousLifecycleArgs>,
) -> Json<serde_json::Value> {
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    let item = match indexed_autonomous_bounty(&state, network, &args.bounty_contract).await {
        Ok(item) => item,
        Err(error) => return mcp_error(error),
    };
    if item.status != "cancelled" {
        return mcp_error("bounty is not cancelled");
    }
    let Some(contributor) = args.caller.as_deref() else {
        return mcp_error("caller is required for refund withdrawal");
    };
    match configured_autonomous_planner(network).and_then(|planner| {
        planner
            .plan_refund_withdrawal(&args.bounty_contract, contributor)
            .map_err(|error| error.to_string())
    }) {
        Ok(plan) => mcp_json(plan),
        Err(error) => mcp_error(error),
    }
}

async fn plan_bounded_wallet_cancel_refund(
    State(state): State<SharedState>,
    Json(args): Json<PlanBoundedWalletCancelRefundArgs>,
) -> Json<serde_json::Value> {
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    let item = match indexed_autonomous_bounty(&state, network, &args.bounty_contract).await {
        Ok(item) => item,
        Err(error) => return mcp_error(error),
    };
    if !item.creator.eq_ignore_ascii_case(&args.bounded_wallet) {
        return mcp_error("bounded wallet is not the indexed bounty creator");
    }
    match configured_autonomous_planner(network).and_then(|planner| {
        match item.status.as_str() {
            "open" | "claimable" => planner.plan_bounded_wallet_cancel_refund(
                &args.bounded_wallet,
                &args.bounty_contract,
                &args.caller,
            ),
            "cancelled" => planner.plan_bounded_wallet_refund(
                &args.bounded_wallet,
                &args.bounty_contract,
                &args.caller,
            ),
            _ => Err(
                chain_base::ChainBaseError::InvalidVerificationConfiguration(
                    "bounty is not cancellable or refundable".to_string(),
                ),
            ),
        }
        .map_err(|error| error.to_string())
    }) {
        Ok(plan) => mcp_json(plan),
        Err(error) => mcp_error(error),
    }
}

async fn plan_autonomous_lifecycle(
    state: SharedState,
    args: PlanAutonomousLifecycleArgs,
    expected_status: &str,
    function: &str,
) -> Json<serde_json::Value> {
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    let item = match indexed_autonomous_bounty(&state, network, &args.bounty_contract).await {
        Ok(item) => item,
        Err(error) => return mcp_error(error),
    };
    if item.status != expected_status {
        return mcp_error("bounty lifecycle state does not allow this call");
    }
    match configured_autonomous_planner(network).and_then(|planner| {
        match function {
            "expireClaim()" => {
                planner.plan_expire_claim(&args.bounty_contract, args.caller.as_deref())
            }
            "expireSubmission()" => {
                planner.plan_expire_submission(&args.bounty_contract, args.caller.as_deref())
            }
            _ => unreachable!("known autonomous lifecycle function"),
        }
        .map_err(|error| error.to_string())
    }) {
        Ok(plan) => mcp_json(plan),
        Err(error) => mcp_error(error),
    }
}

fn autonomous_item_mode(item: &AutonomousBountyFeedItem) -> Option<String> {
    item.terms
        .as_ref()
        .and_then(|terms| terms.document.verification_policy.get("mechanism"))
        .and_then(Value::as_str)
        .map(str::to_string)
}

async fn decode_autonomous_bounty_events(
    Json(args): Json<DecodeAutonomousBountyEventsArgs>,
) -> Json<serde_json::Value> {
    match decode_autonomous_bounty_logs(args.logs) {
        Ok(events) => mcp_json(events),
        Err(error) => mcp_error(error),
    }
}

async fn list_autonomous_bounty_events(
    State(state): State<SharedState>,
    Json(args): Json<ListAutonomousBountyEventsArgs>,
) -> Json<serde_json::Value> {
    let Some(store) = &state.store else {
        return mcp_json(Vec::<serde_json::Value>::new());
    };
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    match store.list_autonomous_bounty_events(network).await {
        Ok(mut events) => {
            if let Some(bounty_id) = args.bounty_id {
                events.retain(|event| event.bounty_id.eq_ignore_ascii_case(&bounty_id));
            }
            mcp_json(events)
        }
        Err(error) => mcp_error(error),
    }
}

async fn publish_autonomous_bounty_terms(
    State(state): State<SharedState>,
    Json(args): Json<PublishAutonomousBountyTermsArgs>,
) -> Json<serde_json::Value> {
    let record =
        match build_autonomous_bounty_terms_record(&args.creator_wallet, args.document, Utc::now())
        {
            Ok(record) => record,
            Err(error) => return mcp_error(error),
        };
    let Some(store) = &state.store else {
        return mcp_error("DATABASE_URL is required to publish public bounty terms");
    };
    match store.upsert_autonomous_bounty_terms(&record).await {
        Ok(()) => mcp_json(record),
        Err(error) => mcp_error(error),
    }
}

async fn get_autonomous_bounty_terms(
    State(state): State<SharedState>,
    Json(args): Json<GetAutonomousBountyTermsArgs>,
) -> Json<serde_json::Value> {
    let Some(store) = &state.store else {
        return mcp_error("DATABASE_URL is required to resolve public bounty terms");
    };
    match store.get_autonomous_bounty_terms(&args.terms_hash).await {
        Ok(Some(record)) => mcp_json(record),
        Ok(None) => mcp_error("unknown autonomous bounty terms hash"),
        Err(error) => mcp_error(error),
    }
}

async fn publish_autonomous_submission_evidence(
    State(state): State<SharedState>,
    Json(args): Json<PublishAutonomousSubmissionEvidenceArgs>,
) -> Json<serde_json::Value> {
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    let item = match indexed_autonomous_bounty(&state, network, &args.bounty_contract).await {
        Ok(item) => item,
        Err(error) => return mcp_error(error),
    };
    let record = match build_autonomous_submission_evidence_record(
        network,
        &item,
        &args.bounty_contract,
        &args.bounty_id,
        args.round,
        &args.solver_wallet,
        &args.artifact_reference,
        args.evidence,
        Utc::now(),
    ) {
        Ok(record) => record,
        Err(error) => return mcp_error(error),
    };
    let Some(store) = &state.store else {
        return mcp_error("DATABASE_URL is required to publish submission evidence");
    };
    match store.upsert_autonomous_submission_evidence(&record).await {
        Ok(persisted) => mcp_json(persisted),
        Err(error) => mcp_error(error),
    }
}

async fn get_autonomous_submission_evidence(
    State(state): State<SharedState>,
    Json(args): Json<GetAutonomousSubmissionEvidenceArgs>,
) -> Json<serde_json::Value> {
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    if let Err(error) =
        require_indexed_canonical_bounty(&state, network, &args.bounty_contract).await
    {
        return mcp_error(error);
    }
    let Some(store) = &state.store else {
        return mcp_error("DATABASE_URL is required to resolve submission evidence");
    };
    match store
        .get_autonomous_submission_evidence(network, &args.bounty_contract, args.round)
        .await
    {
        Ok(Some(record)) => mcp_json(record),
        Ok(None) => mcp_error("submission evidence has not been published"),
        Err(error) => mcp_error(error),
    }
}

async fn list_autonomous_bounties(
    State(state): State<SharedState>,
    Json(args): Json<AutonomousBountyFeedArgs>,
) -> Json<serde_json::Value> {
    let Some(store) = &state.store else {
        return mcp_error("DATABASE_URL is required to discover indexed autonomous bounties");
    };
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    let events = match store.list_autonomous_bounty_events(network).await {
        Ok(events) => events,
        Err(error) => return mcp_error(error),
    };
    let terms = match store.list_autonomous_bounty_terms().await {
        Ok(terms) => terms,
        Err(error) => return mcp_error(error),
    };
    let mut feed = match build_autonomous_bounty_feed(events, terms, false) {
        Ok(feed) => feed,
        Err(error) => return mcp_error(error),
    };
    state
        .recovery_reservations
        .apply(&mut feed, args.claimable_only.unwrap_or(false));
    mcp_json(feed)
}

async fn list_opportunities(Json(args): Json<OpportunityListArgs>) -> Json<serde_json::Value> {
    let url = format!(
        "{}/v1/opportunities",
        api_upstream_base_url_from_env().trim_end_matches('/')
    );
    let response = proxy_hosted_json(reqwest::Client::new().get(url).query(&args)).await;
    attach_mcp_discovery_links(response, "opportunity_list")
}

fn attach_mcp_discovery_links(
    mut response: Json<serde_json::Value>,
    campaign: &str,
) -> Json<serde_json::Value> {
    let Some(items) = response
        .0
        .pointer_mut("/content/0/json/items")
        .and_then(serde_json::Value::as_array_mut)
    else {
        return response;
    };
    for item in items {
        let Some(object) = item.as_object_mut() else {
            continue;
        };
        let canonical_url = object
            .get("public_url")
            .and_then(serde_json::Value::as_str)
            .map(str::to_string);
        let discovery_id = object
            .get("opportunity_id")
            .and_then(serde_json::Value::as_str)
            .map(str::to_string);
        let (Some(canonical_url), Some(discovery_id)) = (canonical_url, discovery_id) else {
            continue;
        };
        let mut attributed_url = canonical_url.clone();
        if let Ok(mut url) = Url::parse(&canonical_url) {
            url.query_pairs_mut()
                .append_pair("utm_source", "mcp")
                .append_pair("utm_medium", "agent")
                .append_pair("utm_campaign", campaign)
                .append_pair("discovery_id", &discovery_id);
            attributed_url = url.to_string();
        }
        object.insert(
            "discovery_links".to_string(),
            json!({
                "canonical_url": canonical_url,
                "attributed_url": attributed_url,
                "attribution_reliability": "observed"
            }),
        );
    }
    response
}

async fn create_discovery_subscription(
    Json(args): Json<CreateDiscoverySubscriptionArgs>,
) -> Json<serde_json::Value> {
    let url = format!(
        "{}/v1/discovery/subscriptions",
        api_upstream_base_url_from_env().trim_end_matches('/')
    );
    proxy_hosted_json(reqwest::Client::new().post(url).json(&args)).await
}

async fn get_discovery_subscription(
    Json(args): Json<ManageDiscoverySubscriptionArgs>,
) -> Json<serde_json::Value> {
    let url = format!(
        "{}/v1/discovery/subscriptions/{}",
        api_upstream_base_url_from_env().trim_end_matches('/'),
        args.subscription_id
    );
    proxy_hosted_json(
        reqwest::Client::new()
            .get(url)
            .bearer_auth(args.management_token),
    )
    .await
}

async fn delete_discovery_subscription(
    Json(args): Json<ManageDiscoverySubscriptionArgs>,
) -> Json<serde_json::Value> {
    let url = format!(
        "{}/v1/discovery/subscriptions/{}",
        api_upstream_base_url_from_env().trim_end_matches('/'),
        args.subscription_id
    );
    proxy_hosted_json(
        reqwest::Client::new()
            .delete(url)
            .bearer_auth(args.management_token),
    )
    .await
}

async fn get_opportunity_conversion_funnel(
    Json(args): Json<OpportunityConversionFunnelArgs>,
) -> Json<serde_json::Value> {
    let url = format!(
        "{}/v1/opportunities/conversion-funnel",
        api_upstream_base_url_from_env().trim_end_matches('/')
    );
    proxy_hosted_json(reqwest::Client::new().get(url).query(&args)).await
}

async fn get_site_analytics(Json(args): Json<SiteAnalyticsArgs>) -> Json<serde_json::Value> {
    let url = format!(
        "{}/v1/analytics/site",
        api_upstream_base_url_from_env().trim_end_matches('/')
    );
    proxy_hosted_json(reqwest::Client::new().get(url).query(&args)).await
}

async fn list_autonomous_verification_jobs(
    State(state): State<SharedState>,
    Json(args): Json<AutonomousVerificationJobsArgs>,
) -> Json<serde_json::Value> {
    let Some(store) = &state.store else {
        return mcp_error("DATABASE_URL is required to discover verification jobs");
    };
    let network = args.network.as_deref().unwrap_or("base-mainnet");
    let events = match store.list_autonomous_bounty_events(network).await {
        Ok(events) => events,
        Err(error) => return mcp_error(error),
    };
    let terms = match store.list_autonomous_bounty_terms().await {
        Ok(terms) => terms,
        Err(error) => return mcp_error(error),
    };
    let evidence = match store.list_autonomous_submission_evidence(network).await {
        Ok(evidence) => evidence,
        Err(error) => return mcp_error(error),
    };
    let mut feed = match build_autonomous_bounty_feed(events, terms, false) {
        Ok(feed) => feed,
        Err(error) => return mcp_error(error),
    };
    state
        .recovery_reservations
        .exclude_from_verification_jobs(&mut feed);
    let observed_at = match u64::try_from(Utc::now().timestamp()) {
        Ok(value) => value,
        Err(_) => return mcp_error("system clock is before Unix epoch"),
    };
    let mut jobs = match build_autonomous_verification_jobs(network, feed, evidence, observed_at) {
        Ok(jobs) => jobs,
        Err(error) => return mcp_error(error),
    };
    if let Some(verifier) = args.verifier {
        let verifier = match normalize_evm_address(verifier) {
            Ok(verifier) => verifier,
            Err(error) => return mcp_error(error),
        };
        jobs.retain(|job| {
            job.verification_mode == "deterministic_module"
                || job
                    .eligible_verifiers
                    .iter()
                    .any(|candidate| candidate.eq_ignore_ascii_case(&verifier))
        });
    }
    mcp_json(jobs)
}

async fn run_bountybench(State(state): State<SharedState>) -> Json<serde_json::Value> {
    let result = eval_harness::BountyBench::default()
        .run(&eval_harness::bundled_fixtures())
        .expect("bundled routing fixtures pass");
    if let Err(error) = record_eval_run(&state, eval_run_from_suite(&result)).await {
        return mcp_error(error);
    }
    mcp_json(result)
}

async fn run_abusebench(State(state): State<SharedState>) -> Json<serde_json::Value> {
    let result = eval_harness::AbuseBench::default()
        .run(&eval_harness::bundled_abuse_fixtures())
        .expect("bundled abuse fixtures pass");
    if let Err(error) = record_eval_run(&state, eval_run_from_suite(&result)).await {
        return mcp_error(error);
    }
    mcp_json(result)
}

async fn run_judgebench(State(state): State<SharedState>) -> Json<serde_json::Value> {
    let result = eval_harness::JudgeBench::default()
        .run(&eval_harness::bundled_judge_fixtures())
        .expect("bundled judge fixtures pass");
    if let Err(error) = record_eval_run(&state, eval_run_from_suite(&result)).await {
        return mcp_error(error);
    }
    mcp_json(result)
}

async fn run_eval_loops(State(state): State<SharedState>) -> Json<serde_json::Value> {
    let result = eval_harness::run_eval_loops()
        .await
        .expect("bundled eval loops pass");
    if let Err(error) = record_eval_run(&state, eval_run_from_loop_suite(&result)).await {
        return mcp_error(error);
    }
    mcp_json(result)
}

async fn get_eval_runs(State(state): State<SharedState>) -> Json<serde_json::Value> {
    let runs = state.eval_runs.lock().expect("state poisoned").clone();
    mcp_json(runs)
}

async fn get_risk_policy() -> Json<serde_json::Value> {
    mcp_json(RiskPolicy::default().descriptor())
}

async fn get_live_money_readiness(
    State(state): State<SharedState>,
    Json(args): Json<LiveMoneyReadinessArgs>,
) -> Json<serde_json::Value> {
    let network = args
        .network
        .filter(|network| !network.trim().is_empty())
        .unwrap_or_else(|| "base-mainnet".to_string());
    match build_live_money_readiness_report(live_money_readiness_config(&state, &network)) {
        Ok(report) => mcp_json(report),
        Err(error) => mcp_error(error.to_string()),
    }
}

fn live_money_readiness_config(state: &SharedState, network: &str) -> LiveMoneyReadinessConfig {
    service_runtime::live_money_readiness_config(
        network,
        LiveMoneyRuntimeSettings {
            stripe_secret_key: state.stripe_secret_key.as_deref(),
            stripe_live_execution_enabled: state.stripe_live_execution_enabled,
            stripe_payment_method_configuration_configured: state
                .stripe_payment_method_configuration
                .as_deref()
                .is_some_and(|value| !value.trim().is_empty()),
            stripe_webhook_secret_configured: env::var("STRIPE_WEBHOOK_SECRET")
                .ok()
                .and_then(non_empty_secret)
                .is_some(),
            allow_unsigned_stripe_webhooks: env::var("ALLOW_UNSIGNED_STRIPE_WEBHOOKS")
                .ok()
                .is_some_and(|value| value.eq_ignore_ascii_case("true") || value == "1"),
            operator_auth_configured: state.operator_api_token.is_some(),
            base_rpc_url_configured: state.base_rpc_urls.resolve(network).is_ok(),
            base_broadcast_enabled: state.base_broadcast_enabled,
        },
    )
}

async fn list_risk_events(
    State(state): State<SharedState>,
    headers: HeaderMap,
    Json(filter): Json<RiskEventFilter>,
) -> Json<serde_json::Value> {
    if let Err(error) = require_operator(&state, &headers) {
        return error;
    }
    let network = state.network.lock().expect("state poisoned");
    mcp_json(network.list_risk_events(filter))
}

async fn list_risk_reviews(
    State(state): State<SharedState>,
    headers: HeaderMap,
) -> Json<serde_json::Value> {
    if let Err(error) = require_operator(&state, &headers) {
        return error;
    }
    let network = state.network.lock().expect("state poisoned");
    mcp_json(network.list_risk_reviews())
}

async fn approve_risk_bounty(
    State(state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<ApproveRiskBountyRequest>,
) -> Json<serde_json::Value> {
    if let Err(error) = require_operator(&state, &headers) {
        return error;
    }
    mcp_mutation(
        service_runtime::approve_risk_bounty(state.store.as_ref(), &state.network, args).await,
    )
}

async fn approve_risk_payout(
    State(state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<ApproveRiskPayoutRequest>,
) -> Json<serde_json::Value> {
    if let Err(error) = require_operator(&state, &headers) {
        return error;
    }
    mcp_mutation(
        service_runtime::approve_risk_payout(state.store.as_ref(), &state.network, args).await,
    )
}

async fn reject_risk_event(
    State(state): State<SharedState>,
    headers: HeaderMap,
    Json(args): Json<RejectRiskEventRequest>,
) -> Json<serde_json::Value> {
    if let Err(error) = require_operator(&state, &headers) {
        return error;
    }
    mcp_mutation(
        service_runtime::reject_risk_event(state.store.as_ref(), &state.network, args).await,
    )
}

async fn record_eval_run(state: &SharedState, run: EvalRun) -> Result<(), String> {
    service_runtime::record_eval_run(state.store.as_ref(), &state.eval_runs, run)
        .await
        .map_err(|error| error.to_string())
}

#[cfg(test)]
#[allow(clippy::items_after_test_module)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn retired_generation_adapters_return_permanent_error() {
        let (status, Json(value)) = retired_generation_http().await;
        assert_eq!(status, StatusCode::GONE);
        assert_eq!(value["http_status"], 410);
        assert_eq!(value["error"], "hosted_generation_removed");
        assert!(value["next_action"]
            .as_str()
            .unwrap()
            .contains("your own AI"));
        for removed in [
            "draft_bounty_with_cloud_agent",
            "compile_objective_with_cloud_agent",
            "analyze_bounty_fit",
        ] {
            assert!(!tools()
                .await
                .0
                .iter()
                .any(|descriptor| descriptor.name == removed));
        }
    }

    #[test]
    fn authorized_paid_status_keeps_the_mcp_contract_and_authorization_errors() {
        let mut network = BountyNetwork::default();
        let mut bounty = domain::Bounty::new(
            "Private owned record",
            "patch-with-tests",
            domain::Money::new(100, "usdc").unwrap(),
            domain::FundingMode::Simulated,
            PrivacyLevel::Private,
        );
        bounty.status = BountyStatus::Paid;
        let id = bounty.id;
        network.bounties.insert(id, bounty);
        let response = authorized_paid_status_response(
            PaidStatusArgs {
                bounty_id: Some(id),
                agent_id: None,
            },
            mcp_json(network.status(id).unwrap()).0,
        )
        .0;
        assert_eq!(response["content"][0]["json"]["scope"], "bounty");
        assert_eq!(response["content"][0]["json"]["bounty_status"], "Paid");
        let agent = network.register_agent(RegisterAgentRequest {
            handle: "owned-agent".into(),
            payout_wallet: None,
        });
        let mut source =
            serde_json::to_value(network.agent_payout_status(agent.id).unwrap()).unwrap();
        source["post_value_loop"] = Value::Null;
        let response = authorized_paid_status_response(
            PaidStatusArgs {
                bounty_id: None,
                agent_id: Some(agent.id),
            },
            mcp_json(source).0,
        )
        .0;
        assert_eq!(response["content"][0]["json"]["scope"], "agent");
        assert_eq!(
            response["content"][0]["json"]["agent_id"],
            agent.id.to_string()
        );
        let error = mcp_error("hosted API returned 404 Not Found").0;
        assert_eq!(
            authorized_paid_status_response(
                PaidStatusArgs {
                    bounty_id: Some(id),
                    agent_id: None
                },
                error.clone()
            )
            .0,
            error
        );
    }

    #[test]
    fn health_identifies_protocol_and_deployed_revision() {
        let response = health_response("0123456789abcdef0123456789abcdef01234567").into_response();

        assert_eq!(
            response.headers()["x-agent-bounties-revision"],
            "0123456789abcdef0123456789abcdef01234567"
        );
        assert_eq!(
            response.headers()["x-agent-bounties-protocol"],
            "agent-bounties/autonomous-v1"
        );
    }

    #[test]
    fn chatgpt_card_preview_is_a_no_store_first_party_download_page() {
        let (headers, body) = chatgpt_bounty_card_preview_response();
        assert_eq!(headers[header::CONTENT_TYPE], "text/html; charset=utf-8");
        assert_eq!(headers[header::CACHE_CONTROL], "no-store");
        assert_eq!(headers["referrer-policy"], "no-referrer");
        assert!(headers["content-security-policy"]
            .to_str()
            .unwrap()
            .contains("frame-ancestors 'none'"));
        assert!(body.contains("First-party share handoff"));
        assert!(body.contains("Download PNG"));
        assert!(body.contains("canvas.toBlob"));
        assert!(body.contains("data:image/webp;base64,"));
        assert!(!body.contains("__BOUNTY_CARD_ART_DATA_URI__"));
    }

    #[test]
    fn openai_apps_challenge_returns_only_the_exact_configured_token() {
        let token = "openai-apps-challenge_test-123";
        let (status, headers, body) = openai_apps_challenge_response(Some(format!(" {token}\n")));
        assert_eq!(status, StatusCode::OK);
        assert_eq!(headers[header::CONTENT_TYPE], "text/plain; charset=utf-8");
        assert_eq!(headers[header::CACHE_CONTROL], "no-store");
        assert_eq!(body, token);

        for invalid in [
            None,
            Some(String::new()),
            Some("too-short".chars().take(7).collect()),
            Some("contains whitespace".to_string()),
            Some("x".repeat(513)),
        ] {
            let (status, _, body) = openai_apps_challenge_response(invalid);
            assert_eq!(status, StatusCode::NOT_FOUND);
            assert!(body.is_empty());
        }
    }

    #[test]
    fn glama_claim_challenge_returns_only_valid_public_claim_json() {
        let token = "glama_claim_test-1234567890";
        let (status, headers, body) = glama_claim_challenge_response(Some(format!(" {token}\n")));
        assert_eq!(status, StatusCode::OK);
        assert_eq!(
            headers[header::CONTENT_TYPE],
            "application/json; charset=utf-8"
        );
        assert_eq!(headers[header::CACHE_CONTROL], "no-store");
        assert_eq!(
            serde_json::from_str::<Value>(&body).unwrap(),
            json!({
                "$schema": "https://glama.ai/mcp/schemas/connector.json",
                "claim": token,
            })
        );

        for invalid in [
            None,
            Some(String::new()),
            Some("wrong_prefix_1234567890".to_string()),
            Some("glama_claim_contains whitespace".to_string()),
            Some("glama_claim_invalid!character".to_string()),
            Some("x".repeat(513)),
        ] {
            let (status, _, body) = glama_claim_challenge_response(invalid);
            assert_eq!(status, StatusCode::NOT_FOUND);
            assert!(body.is_empty());
        }
    }

    #[test]
    fn oauth_authorization_accepts_only_chatgpt_callbacks_scoped_resource_and_s256_pkce() {
        let resource = "https://mcp.agentbounties.app";
        let request = OAuthAuthorizationQuery {
            response_type: "code".to_string(),
            client_id: "https://chatgpt.com/oauth/agent-bounties/client.json".to_string(),
            redirect_uri: "https://chatgpt.com/connector/oauth/callback_123".to_string(),
            code_challenge: "a".repeat(43),
            code_challenge_method: "S256".to_string(),
            scope: ANALYTICS_EXCLUSION_SCOPE.to_string(),
            state: Some("opaque-state".to_string()),
            resource: Some(resource.to_string()),
        };
        assert!(validate_oauth_authorization_request(&request, resource));

        let mut evil_redirect = request.clone();
        evil_redirect.redirect_uri =
            "https://chatgpt.com.evil.example/connector/oauth/callback_123".to_string();
        assert!(!validate_oauth_authorization_request(
            &evil_redirect,
            resource
        ));

        let mut wrong_resource = request.clone();
        wrong_resource.resource = Some("https://api.agentbounties.app".to_string());
        assert!(!validate_oauth_authorization_request(
            &wrong_resource,
            resource
        ));

        let mut weak_pkce = request;
        weak_pkce.code_challenge_method = "plain".to_string();
        assert!(!validate_oauth_authorization_request(&weak_pkce, resource));
    }

    #[tokio::test]
    async fn oauth_code_exchange_is_pkce_bound_single_use_and_analytics_only() {
        let state = test_state_with_analytics_token("analytics-secret");
        let verifier = "v".repeat(64);
        let challenge = URL_SAFE_NO_PAD.encode(Sha256::digest(verifier.as_bytes()));
        state.oauth_codes.lock().expect("OAuth code mutex").insert(
            "one-time-code".to_string(),
            OAuthAuthorizationCode {
                client_id: "agent-bounties-chatgpt-11111111-1111-4111-8111-111111111111"
                    .to_string(),
                redirect_uri: "https://chatgpt.com/connector/oauth/callback_123".to_string(),
                code_challenge: challenge,
                scope: ANALYTICS_EXCLUSION_SCOPE.to_string(),
                resource: "https://mcp.agentbounties.app".to_string(),
                expires_at: Utc::now() + chrono::Duration::minutes(1),
            },
        );
        let request = OAuthTokenRequest {
            grant_type: "authorization_code".to_string(),
            code: "one-time-code".to_string(),
            redirect_uri: "https://chatgpt.com/connector/oauth/callback_123".to_string(),
            client_id: "agent-bounties-chatgpt-11111111-1111-4111-8111-111111111111".to_string(),
            code_verifier: verifier,
            resource: Some("https://mcp.agentbounties.app".to_string()),
        };
        let response = oauth_token(State(state.clone()), Form(request)).await;
        assert_eq!(response.status(), StatusCode::OK);
        let body = axum::body::to_bytes(response.into_body(), 4096)
            .await
            .unwrap();
        let body: Value = serde_json::from_slice(&body).unwrap();
        let access_token = body["access_token"].as_str().unwrap();
        assert_ne!(access_token, "analytics-secret");
        assert!(analytics_oauth_access_token_is_authorized(
            "analytics-secret",
            access_token,
            "https://mcp.agentbounties.app",
            Utc::now()
        ));
        assert_eq!(body["scope"], ANALYTICS_EXCLUSION_SCOPE);
        assert!(state
            .oauth_codes
            .lock()
            .expect("OAuth code mutex")
            .is_empty());

        let mut headers = HeaderMap::new();
        headers.insert(
            header::AUTHORIZATION,
            HeaderValue::from_str(&format!("Bearer {access_token}")).unwrap(),
        );
        assert!(analytics_exclusion_is_authorized(&state, &headers));
        assert!(require_operator(&state, &headers).is_err());

        assert!(!analytics_oauth_access_token_is_authorized(
            "analytics-secret",
            access_token,
            "https://wrong.example",
            Utc::now()
        ));
        assert!(!analytics_oauth_access_token_is_authorized(
            "wrong-secret",
            access_token,
            "https://mcp.agentbounties.app",
            Utc::now()
        ));
        let expired = analytics_oauth_access_token(
            "analytics-secret",
            "https://mcp.agentbounties.app",
            Utc::now() - chrono::Duration::days(91),
        )
        .unwrap();
        assert!(!analytics_oauth_access_token_is_authorized(
            "analytics-secret",
            &expired,
            "https://mcp.agentbounties.app",
            Utc::now()
        ));

        let mut attested = StatusCode::OK.into_response();
        attest_analytics_exclusion(&mut attested, true);
        assert_eq!(
            attested
                .headers()
                .get(ANALYTICS_EXCLUDED_HEADER)
                .and_then(|value| value.to_str().ok()),
            Some("true")
        );
    }

    #[tokio::test]
    async fn tool_descriptors_publish_machine_readable_input_schemas() {
        let descriptors = tools().await.0;
        let registry: Value = serde_json::from_str(include_str!("../fixtures/tool-registry.json"))
            .expect("tool registry fixture is valid JSON");
        assert_eq!(
            registry["schema_version"],
            "agent-bounties/mcp-tool-registry-v1"
        );
        assert_eq!(
            app::hash_artifact(&serde_json::to_string(&descriptors).unwrap()),
            registry["normalized_descriptors_sha256"]
        );
        let registered_names = registry["tools"]
            .as_array()
            .expect("tool registry contains tools");

        assert_eq!(descriptors.len(), 118);
        assert_eq!(
            descriptors
                .iter()
                .map(|descriptor| descriptor.name)
                .collect::<Vec<_>>(),
            registered_names
                .iter()
                .map(|name| name.as_str().expect("registered tool name is a string"))
                .collect::<Vec<_>>()
        );
        for descriptor in &descriptors {
            assert!(!descriptor.description.trim().is_empty());
            assert_eq!(
                descriptor.input_schema["type"], "object",
                "{}",
                descriptor.name
            );
            assert_eq!(
                descriptor.input_schema["additionalProperties"], false,
                "{}",
                descriptor.name
            );
            assert!(
                descriptor.input_schema["required"].is_array(),
                "{} missing required array",
                descriptor.name
            );
        }

        for objective_tool in [
            "plan_objective_creation",
            "create_objective",
            "list_objectives",
            "get_objective",
            "plan_objective_action",
            "apply_objective_action",
            "reconcile_objective",
        ] {
            let descriptor = descriptors
                .iter()
                .find(|descriptor| descriptor.name == objective_tool)
                .unwrap_or_else(|| panic!("{objective_tool} descriptor exists"));
            assert!(descriptor.authorization.is_none());
        }

        let route = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "route_blocked_goal")
            .expect("route_blocked_goal descriptor exists");
        assert_eq!(route.input_schema["type"], "object");
        assert!(route.authorization.is_none());
        assert!(route.input_schema["properties"]["privacy"]["enum"]
            .as_array()
            .unwrap()
            .iter()
            .any(|value| value == "Private"));

        for removed in [
            "draft_bounty_with_cloud_agent",
            "compile_objective_with_cloud_agent",
            "analyze_bounty_fit",
        ] {
            assert!(!descriptors
                .iter()
                .any(|descriptor| descriptor.name == removed));
        }

        let operator_tools = [
            "execute_stripe_checkout_top_up",
            "execute_stripe_connect_account",
            "execute_stripe_connect_transfer",
            "reconcile_stripe_connect_snapshot",
            "reconcile_stripe_transfer_event",
            "reconcile_stripe_checkout_webhook",
            "broadcast_base_signed_transaction",
            "list_risk_events",
            "list_risk_reviews",
            "approve_risk_bounty",
            "approve_risk_payout",
            "reject_risk_event",
        ];
        for tool_name in operator_tools {
            let descriptor = descriptors
                .iter()
                .find(|descriptor| descriptor.name == tool_name)
                .unwrap_or_else(|| panic!("{tool_name} descriptor exists"));
            let authorization = descriptor
                .authorization
                .as_ref()
                .unwrap_or_else(|| panic!("{tool_name} missing operator authorization metadata"));
            assert_eq!(authorization.kind, "operator_api_token");
            assert_eq!(authorization.header, OPERATOR_TOKEN_HEADER);
            assert!(authorization.bearer);
        }
        assert_eq!(
            descriptors
                .iter()
                .filter(|descriptor| descriptor.authorization.is_some())
                .map(|descriptor| descriptor.name)
                .collect::<Vec<_>>(),
            operator_tools
        );

        let stripe_checkout = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "plan_stripe_checkout_top_up")
            .expect("plan_stripe_checkout_top_up descriptor exists");
        assert!(stripe_checkout.input_schema["required"]
            .as_array()
            .unwrap()
            .iter()
            .any(|value| value == "amount_minor"));
        assert_eq!(
            stripe_checkout.input_schema["properties"]["organization_id"]["format"],
            "uuid"
        );

        let execute_stripe_checkout = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "execute_stripe_checkout_top_up")
            .expect("execute_stripe_checkout_top_up descriptor exists");
        assert!(execute_stripe_checkout.input_schema["required"]
            .as_array()
            .unwrap()
            .iter()
            .any(|value| value == "organization_id"));

        let execute_stripe_connect = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "execute_stripe_connect_account")
            .expect("execute_stripe_connect_account descriptor exists");
        assert_eq!(
            execute_stripe_connect.input_schema["properties"]["agent_id"]["format"],
            "uuid"
        );

        let plan_stripe_transfer = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "plan_stripe_connect_transfer")
            .expect("plan_stripe_connect_transfer descriptor exists");
        assert!(plan_stripe_transfer.input_schema["required"]
            .as_array()
            .unwrap()
            .iter()
            .any(|value| value == "payout_intent_id"));

        let plan_github_issue = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "plan_github_issue_bounty")
            .expect("plan_github_issue_bounty descriptor exists");
        assert!(plan_github_issue.input_schema["required"]
            .as_array()
            .unwrap()
            .iter()
            .any(|value| value == "body"));

        let plan_github_create = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "plan_github_create_comment")
            .expect("plan_github_create_comment descriptor exists");
        assert!(plan_github_create.input_schema["required"]
            .as_array()
            .unwrap()
            .iter()
            .any(|value| value == "comment_body"));
        assert_eq!(
            plan_github_create.input_schema["properties"]["existing_idempotency_keys"]["type"],
            "array"
        );

        let plan_social_mention = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "plan_social_mention_draft")
            .expect("plan_social_mention_draft descriptor exists");
        assert!(plan_social_mention.input_schema["required"]
            .as_array()
            .unwrap()
            .iter()
            .any(|value| value == "mention_text"));

        let plan_github_funding = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "plan_github_funding_comment")
            .expect("plan_github_funding_comment descriptor exists");
        assert!(plan_github_funding.input_schema["required"]
            .as_array()
            .unwrap()
            .iter()
            .any(|value| value == "comment_body"));
        assert_eq!(
            plan_github_funding.input_schema["properties"]["existing_idempotency_keys"]["type"],
            "array"
        );
        assert_eq!(
            plan_github_funding.input_schema["properties"]["funding_api_base_url"]["type"][0],
            "string"
        );

        let plan_github_claim = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "plan_github_claim_comment")
            .expect("plan_github_claim_comment descriptor exists");
        assert!(plan_github_claim.input_schema["required"]
            .as_array()
            .unwrap()
            .iter()
            .any(|value| value == "comment_body"));
        assert_eq!(
            plan_github_claim.input_schema["properties"]["progress_signal_count"]["type"],
            "integer"
        );

        let plan_github_proof = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "plan_github_proof_comment")
            .expect("plan_github_proof_comment descriptor exists");
        assert_eq!(
            plan_github_proof.input_schema["properties"]["bounty_id"]["format"],
            "uuid"
        );
        let plan_github_proof_for_proof = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "plan_github_proof_comment_for_proof")
            .expect("plan_github_proof_comment_for_proof descriptor exists");
        assert_eq!(
            plan_github_proof_for_proof.input_schema["properties"]["proof_id"]["format"],
            "uuid"
        );

        let list_claimable = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "list_claimable_bounties")
            .expect("list_claimable_bounties descriptor exists");
        assert!(list_claimable.input_schema["required"]
            .as_array()
            .unwrap()
            .is_empty());

        let open_pooled = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "open_pooled_bounty")
            .expect("open_pooled_bounty descriptor exists");
        assert!(open_pooled.input_schema["required"]
            .as_array()
            .unwrap()
            .iter()
            .any(|value| value == "target_amount_minor"));
        assert!(open_pooled.input_schema["properties"]["funding_targets"].is_null());
        assert!(
            !open_pooled.input_schema["properties"]["funding_mode"]["enum"]
                .as_array()
                .unwrap()
                .iter()
                .any(|value| value == "MixedRails")
        );

        let create_intent = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "create_funding_intent")
            .expect("create_funding_intent descriptor exists");
        assert!(create_intent.input_schema["required"]
            .as_array()
            .unwrap()
            .iter()
            .any(|value| value == "bounty_id"));
        assert_eq!(
            create_intent.input_schema["properties"]["rail"]["enum"],
            json!(["StripeFiat"])
        );

        let add_funding = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "add_bounty_funding")
            .expect("add_bounty_funding descriptor exists");
        assert_eq!(
            add_funding.input_schema["properties"]["bounty_id"]["format"],
            "uuid"
        );
        assert_eq!(
            add_funding.input_schema["properties"]["source_organization_id"]["format"],
            "uuid"
        );
        assert!(add_funding.input_schema["required"]
            .as_array()
            .unwrap()
            .iter()
            .any(|value| value == "amount_minor"));

        let get_paid_status = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "get_paid_status")
            .expect("get_paid_status descriptor exists");
        assert!(get_paid_status.input_schema["required"]
            .as_array()
            .unwrap()
            .is_empty());
        assert_eq!(
            get_paid_status.input_schema["properties"]["agent_id"]["format"],
            "uuid"
        );

        let search_capabilities = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "search_capabilities")
            .expect("search_capabilities descriptor exists");
        assert_eq!(
            search_capabilities.input_schema["properties"]["max_price_minor"]["type"][0],
            "integer"
        );
        assert!(
            search_capabilities.input_schema["properties"]["class"]["enum"]
                .as_array()
                .unwrap()
                .iter()
                .any(|value| value == "Coding")
        );

        let broadcast_base_signed_transaction = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "broadcast_base_signed_transaction")
            .expect("broadcast_base_signed_transaction descriptor exists");
        assert!(broadcast_base_signed_transaction.input_schema["required"]
            .as_array()
            .unwrap()
            .iter()
            .any(|value| value == "signed_transaction"));

        let get_base_transaction_receipt = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "get_base_transaction_receipt")
            .expect("get_base_transaction_receipt descriptor exists");
        assert!(get_base_transaction_receipt.input_schema["required"]
            .as_array()
            .unwrap()
            .iter()
            .any(|value| value == "tx_hash"));
        assert!(get_base_transaction_receipt.input_schema["properties"]
            .get("reconcile_logs")
            .is_none());
        assert!(get_base_transaction_receipt.authorization.is_none());

        for retired in [
            "plan_base_log_query",
            "reconcile_base_escrow_event",
            "reconcile_base_evm_logs",
            "reconcile_base_rpc_logs",
            "fetch_base_rpc_logs",
            "get_base_indexer_status",
            "plan_base_funding",
            "plan_base_release",
            "plan_base_refund",
            "plan_base_dispute",
            "list_base_release_queue",
        ] {
            assert!(
                descriptors
                    .iter()
                    .all(|descriptor| descriptor.name != retired),
                "retired escrow tool {retired} must not be discoverable"
            );
        }

        for autonomous in [
            "plan_autonomous_canonical_child_terms",
            "prepare_standing_meta_v2_child",
            "plan_autonomous_bounty_creation",
            "plan_autonomous_bounty_authorized_creation",
            "plan_autonomous_bounty_contribution",
            "plan_autonomous_bounty_authorized_contribution",
            "fund_bounty_with_x402",
            "get_x402_relay_status",
            "prepare_agent_to_earn",
            "agent_native_claim",
            "plan_autonomous_bounty_claim",
            "plan_autonomous_bounty_authorized_claim",
            "plan_autonomous_bounty_submission",
            "prepare_autonomous_bounty_submission",
            "plan_autonomous_bounty_submission_authorization",
            "list_autonomous_verification_jobs",
            "decode_autonomous_bounty_events",
            "list_autonomous_bounty_events",
            "get_solver_leaderboard",
            "publish_autonomous_bounty_terms",
            "get_autonomous_bounty_terms",
            "list_autonomous_bounties",
            "list_opportunities",
            "create_discovery_subscription",
            "get_discovery_subscription",
            "delete_discovery_subscription",
            "get_opportunity_conversion_funnel",
            "get_site_analytics",
        ] {
            assert!(
                descriptors
                    .iter()
                    .any(|descriptor| descriptor.name == autonomous),
                "autonomous tool {autonomous} must be discoverable"
            );
        }

        let x402_funding = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "fund_bounty_with_x402")
            .expect("fund_bounty_with_x402 descriptor exists");
        assert!(x402_funding.input_schema["required"]
            .as_array()
            .unwrap()
            .iter()
            .any(|value| value == "bounty_contract"));
        assert!(x402_funding.authorization.is_none());

        let prepare_agent = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "prepare_agent_to_earn")
            .expect("prepare_agent_to_earn descriptor exists");
        assert!(!prepare_agent.input_schema["required"]
            .as_array()
            .unwrap()
            .iter()
            .any(|value| value == "claim_bond_base_units"));
        assert_eq!(
            prepare_agent.input_schema["properties"]["policy"]["additionalProperties"],
            false
        );
        assert!(prepare_agent.authorization.is_none());

        let agent_claim = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "agent_native_claim")
            .expect("agent_native_claim descriptor exists");
        assert_eq!(
            agent_claim.input_schema["properties"]["wallet_signature"]["type"],
            serde_json::json!(["string", "null"])
        );
        assert!(
            agent_claim.input_schema["properties"]["wallet_signature"]["description"]
                .as_str()
                .unwrap()
                .contains("unchanged")
        );
        assert!(agent_claim.authorization.is_none());

        let prepare_submission = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "prepare_autonomous_bounty_submission")
            .expect("prepare submission descriptor exists");
        assert_eq!(
            prepare_submission.input_schema["properties"]["evidence"]["type"],
            "object"
        );
        assert!(prepare_submission.input_schema["required"]
            .as_array()
            .unwrap()
            .iter()
            .any(|value| value == "artifact_reference"));
        assert!(prepare_submission.authorization.is_none());

        let canonical_child_terms = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "plan_autonomous_canonical_child_terms")
            .expect("canonical child terms descriptor exists");
        assert!(canonical_child_terms.input_schema["required"]
            .as_array()
            .unwrap()
            .iter()
            .any(|value| value == "child_acceptance_criteria"));
        assert_eq!(
            canonical_child_terms.input_schema["properties"]["child_acceptance_criteria"]
                ["minItems"],
            1
        );
        assert!(
            canonical_child_terms.input_schema["properties"]["verifier_module"]["description"]
                .as_str()
                .unwrap()
                .contains("child task")
        );
        assert!(
            canonical_child_terms.input_schema["properties"]["verifier_module"]["description"]
                .as_str()
                .unwrap()
                .contains("Do not pass the parent's canonical-child verifier")
        );

        let standing_meta_v2 = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "prepare_standing_meta_v2_child")
            .expect("standing-meta-v2 preparation descriptor exists");
        for required in [
            "parent_bounty_contract",
            "parent_solver",
            "intended_child_solver",
            "acceptance_criteria",
            "benchmark_source",
            "runner_manifest",
        ] {
            assert!(standing_meta_v2.input_schema["required"]
                .as_array()
                .unwrap()
                .iter()
                .any(|value| value == required));
        }
        assert_eq!(
            standing_meta_v2.input_schema["properties"]["benchmark_source"]["additionalProperties"],
            false
        );
        assert_eq!(
            standing_meta_v2.input_schema["properties"]["runner_manifest"]["additionalProperties"],
            false
        );

        let get_live_money_readiness = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "get_live_money_readiness")
            .expect("get_live_money_readiness descriptor exists");
        assert!(
            get_live_money_readiness.input_schema["properties"]["network"]["enum"]
                .as_array()
                .unwrap()
                .iter()
                .any(|value| value == "base-mainnet")
        );

        let get_eval_runs = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "get_eval_runs")
            .expect("get_eval_runs descriptor exists");
        assert!(get_eval_runs.input_schema["required"]
            .as_array()
            .unwrap()
            .is_empty());

        let get_risk_policy = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "get_risk_policy")
            .expect("get_risk_policy descriptor exists");
        assert!(get_risk_policy.input_schema["required"]
            .as_array()
            .unwrap()
            .is_empty());

        let list_risk_events = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "list_risk_events")
            .expect("list_risk_events descriptor exists");
        assert!(list_risk_events.input_schema["required"]
            .as_array()
            .unwrap()
            .is_empty());
        assert!(
            list_risk_events.input_schema["properties"]["action"]["enum"]
                .as_array()
                .unwrap()
                .iter()
                .any(|value| value == "NeedsReview")
        );

        let approve_risk_bounty = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "approve_risk_bounty")
            .expect("approve_risk_bounty descriptor exists");
        assert!(approve_risk_bounty.input_schema["required"]
            .as_array()
            .unwrap()
            .iter()
            .any(|value| value == "risk_event_id"));

        let approve_risk_payout = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "approve_risk_payout")
            .expect("approve_risk_payout descriptor exists");
        assert!(approve_risk_payout.input_schema["required"]
            .as_array()
            .unwrap()
            .iter()
            .any(|value| value == "operator_id"));

        let reject_risk_event = descriptors
            .iter()
            .find(|descriptor| descriptor.name == "reject_risk_event")
            .expect("reject_risk_event descriptor exists");
        assert!(reject_risk_event.input_schema["required"]
            .as_array()
            .unwrap()
            .iter()
            .any(|value| value == "note"));
    }

    #[tokio::test]
    async fn github_claim_comment_planner_rejects_claim_without_progress() {
        let response = plan_github_claim_comment(Json(PlanGitHubClaimCommentArgs {
            repository: "agent-bounties/agent-bounties".to_string(),
            issue_url: "https://github.com/agent-bounties/agent-bounties/issues/58".to_string(),
            title: "[bounty]: Add stale-claim controls".to_string(),
            body: valid_github_issue_body(),
            comment_body:
                "/agent-bounty claim\nI'm reviewing the codebase and will open a PR shortly."
                    .to_string(),
            contributor_login: Some("claim-bot".to_string()),
            comment_id: Some("789".to_string()),
            claim_age_minutes: Some(1),
            progress_signal_count: 0,
            active_claim_login: None,
        }))
        .await
        .0;

        let payload = &response["content"][0]["json"];
        assert_eq!(payload["ready"], false);
        assert_eq!(payload["check"]["conclusion"], "ActionRequired");
        assert!(payload["error"]
            .as_str()
            .unwrap()
            .contains("concrete progress signal"));
    }

    #[tokio::test]
    async fn github_proof_comment_for_proof_uses_stored_public_proof() {
        let mut network = BountyNetwork::default();
        let solver = network.register_agent(RegisterAgentRequest {
            handle: "solver".to_string(),
            payout_wallet: Some("0x2222222222222222222222222222222222222222".to_string()),
        });
        let bounty = network
            .post_funded_bounty(PostBountyRequest {
                title: "Fix MCP proof comments".to_string(),
                template_slug: "small-code-change".to_string(),
                amount_minor: 1_000_000,
                currency: "usdc".to_string(),
                funding_mode: domain::FundingMode::Simulated,
                privacy: PrivacyLevel::Public,
            })
            .unwrap();
        network
            .claim_bounty(ClaimBountyRequest {
                bounty_id: bounty.id,
                solver_agent_id: solver.id,
            })
            .unwrap();
        let artifact = "{\"ok\":true}";
        let submission = network
            .submit_result(SubmitResultRequest {
                bounty_id: bounty.id,
                solver_agent_id: solver.id,
                artifact_uri: "s3://mcp/artifact.json".to_string(),
                artifact_body: artifact.to_string(),
            })
            .unwrap();
        let proof = network
            .verify_submission(VerifySubmissionRequest {
                bounty_id: bounty.id,
                submission_id: submission.id,
                expected_artifact_digest: app::hash_artifact(artifact),
                verifier_kind: Some(domain::VerifierKind::JsonSchema),
                rubric: None,
                evidence: None,
                approved_risk_event_id: None,
            })
            .await
            .unwrap();
        let state = test_state_with_network(network);

        let response = plan_github_proof_comment_for_proof(
            State(state.clone()),
            Json(PlanGitHubProofCommentForProofArgs {
                proof_id: proof.id,
                settlement_url: None,
            }),
        )
        .await
        .0;
        let plan = &response["content"][0]["json"];

        assert_eq!(plan["comment"]["bounty_id"], bounty.id.to_string());
        assert_eq!(
            plan["comment"]["proof_url"],
            format!("http://127.0.0.1:8080/public/proofs/{}", proof.id)
        );
        assert!(plan["comment"]["verifier_summary"]
            .as_str()
            .unwrap()
            .contains("JsonSchema"));
        assert!(plan["markdown"]
            .as_str()
            .unwrap()
            .contains("Tell your human or operator"));
        assert_eq!(plan["fingerprint"].as_str().unwrap().len(), 64);

        let paid_status = get_paid_status(
            State(state),
            HeaderMap::new(),
            Json(PaidStatusArgs {
                bounty_id: None,
                agent_id: Some(solver.id),
            }),
        )
        .await
        .0;
        let paid_status = &paid_status["content"][0]["json"];
        assert_eq!(
            paid_status["post_value_loop"]["trigger"],
            "verified_completion"
        );
        assert!(paid_status["post_value_loop"]["actions"]
            .as_array()
            .unwrap()
            .iter()
            .any(|action| action["kind"] == "tell_your_human"));
        assert!(paid_status["post_value_loop"]["self_interest"]
            .as_str()
            .unwrap()
            .contains("more and higher-value funded bounties"));
    }

    #[tokio::test]
    async fn risk_policy_tool_exposes_settlement_limits() {
        let policy = get_risk_policy().await.0;
        let body = &policy["content"][0]["json"];

        assert_eq!(body["low_value_usdc_cap_minor"], 10_000_000);
        assert_eq!(body["low_value_usdc_cap_currency"], "usdc");
        assert_eq!(body["ai_judges_can_authorize_payment"], false);
        assert!(body["settlement_invariants"]
            .as_array()
            .unwrap()
            .iter()
            .any(|rule| rule.as_str().unwrap().contains("indexed escrow logs")));
    }

    #[tokio::test]
    async fn live_money_readiness_tool_reports_non_secret_defaults() {
        let response = get_live_money_readiness(
            State(test_state()),
            Json(LiveMoneyReadinessArgs {
                network: Some("base-mainnet".to_string()),
            }),
        )
        .await
        .0;
        let body = &response["content"][0]["json"];

        assert_eq!(body["network"], "Base");
        assert_eq!(body["network_chain_id"], 8_453);
        assert_eq!(body["stripe_secret_key_mode"], "unset");
        assert_eq!(
            body["stripe_payment_method_configuration_configured"],
            false
        );
        assert_eq!(body["supplied_usdc_token_matches_native"], true);
        assert_eq!(body["live_money_ready"], false);
        assert!(body["checks"].as_array().unwrap().iter().any(|check| {
            check["name"] == "Autonomous bounty factory" && check["configured"] == true
        }));
        assert!(body["checks"].as_array().unwrap().iter().any(|check| {
            check["name"]
                .as_str()
                .unwrap()
                .contains("Stripe live-money execution")
        }));
        assert!(body["checks"].as_array().unwrap().iter().any(|check| {
            check["name"]
                .as_str()
                .unwrap()
                .contains("payment-method configuration")
        }));
    }

    #[test]
    fn mainnet_planner_and_readiness_pin_the_attested_deployment() {
        let expected = autonomous_planner_addresses(8_453, None, None).unwrap();
        assert_eq!(expected.0, CANONICAL_BASE_MAINNET_BOUNTY_FACTORY);
        assert_eq!(expected.1, CANONICAL_BASE_MAINNET_BOUNTY_IMPLEMENTATION);
        assert_eq!(
            canonical_mainnet_factory(None, None).as_deref(),
            Some(CANONICAL_BASE_MAINNET_BOUNTY_FACTORY)
        );

        assert!(autonomous_planner_addresses(
            8_453,
            Some("0x1111111111111111111111111111111111111111".to_string()),
            None,
        )
        .is_err());
        assert_eq!(
            canonical_mainnet_factory(
                Some("0x1111111111111111111111111111111111111111".to_string()),
                None,
            ),
            None
        );
        assert_eq!(
            canonical_mainnet_factory(
                None,
                Some("0x2222222222222222222222222222222222222222".to_string()),
            ),
            None
        );
    }

    #[tokio::test]
    async fn live_money_readiness_tool_reports_payment_method_configuration_without_id() {
        let response = get_live_money_readiness(
            State(test_state_with_stripe_payment_method_configuration(
                "pmc_paypal_enabled",
            )),
            Json(LiveMoneyReadinessArgs {
                network: Some("base-mainnet".to_string()),
            }),
        )
        .await
        .0;
        let body = &response["content"][0]["json"];
        let text = serde_json::to_string(body).unwrap();

        assert_eq!(body["stripe_payment_method_configuration_configured"], true);
        assert!(body["checks"].as_array().unwrap().iter().any(|check| {
            check["name"] == "Stripe Checkout payment-method configuration"
                && check["configured"] == true
        }));
        assert!(!text.contains("pmc_paypal_enabled"));
    }

    #[tokio::test]
    async fn stripe_checkout_webhook_replay_preserves_applied_event() {
        let state = test_state_with_operator_token("local-test-operator");
        let organization_id = Uuid::new_v4();
        let event = stripe_checkout_event("evt_mcp_paid", "cs_mcp_paid", organization_id);

        let first = reconcile_stripe_checkout_webhook(
            State(state.clone()),
            test_operator_headers(),
            Json(event.clone()),
        )
        .await
        .0;
        let first_body = &first["content"][0]["json"];

        assert_eq!(first_body["duplicate"], false);
        assert_eq!(first_body["ledger_entries"].as_array().unwrap().len(), 1);
        assert_eq!(
            first_body["funding_credit"]["payment_event"]["status"],
            "Applied"
        );

        let replay = reconcile_stripe_checkout_webhook(
            State(state.clone()),
            test_operator_headers(),
            Json(event),
        )
        .await
        .0;
        let replay_body = &replay["content"][0]["json"];

        assert_eq!(replay_body["duplicate"], true);
        assert!(replay_body["ledger_entries"].as_array().unwrap().is_empty());
        assert_eq!(
            replay_body["funding_credit"]["payment_event"]["status"],
            "IgnoredDuplicate"
        );

        let network = state.network.lock().expect("state poisoned");
        assert_eq!(network.payment_events.len(), 1);
        assert_eq!(network.ledger.entries().len(), 1);
        assert_eq!(
            network.payment_events.values().next().unwrap().status,
            domain::PaymentEventStatus::Applied
        );
    }

    #[tokio::test]
    async fn risk_read_tools_require_explicit_operator_authority() {
        let mut unrelated = HeaderMap::new();
        unrelated.insert(
            header::AUTHORIZATION,
            HeaderValue::from_static("Bearer abws_unrelated"),
        );
        for (state, headers) in [
            (test_state(), HeaderMap::new()),
            (test_state(), test_operator_headers()),
            (
                test_state_with_operator_token("local-test-operator"),
                HeaderMap::new(),
            ),
            (
                test_state_with_operator_token("local-test-operator"),
                unrelated,
            ),
        ] {
            let events = list_risk_events(
                State(state.clone()),
                headers.clone(),
                Json(RiskEventFilter::default()),
            )
            .await
            .0;
            let reviews = list_risk_reviews(State(state), headers).await.0;
            assert_eq!(events["error"], "operator authorization required");
            assert_eq!(reviews["error"], "operator authorization required");
            assert!(events.get("content").is_none() && reviews.get("content").is_none());
        }
        let state = test_state_with_operator_token("local-test-operator");
        assert!(list_risk_events(
            State(state.clone()),
            test_operator_headers(),
            Json(RiskEventFilter::default())
        )
        .await
        .0
        .get("content")
        .is_some());
        assert!(list_risk_reviews(State(state), test_operator_headers())
            .await
            .0
            .get("content")
            .is_some());
    }

    #[tokio::test]
    async fn risk_events_tool_lists_review_queue() {
        let state = test_state_with_operator_token("local-test-operator");
        {
            let mut network = state.network.lock().expect("state poisoned");
            let result = network.post_funded_bounty(PostBountyRequest {
                title: "Fix deterministic payout reconciliation failure".to_string(),
                template_slug: "fix-ci-failure".to_string(),
                amount_minor: 25_000_000,
                currency: "usdc".to_string(),
                funding_mode: domain::FundingMode::BaseUsdcEscrow,
                privacy: PrivacyLevel::Public,
            });
            assert!(matches!(result, Err(app::AppError::RiskNeedsReview(_))));
        }

        let response = list_risk_events(
            State(state),
            test_operator_headers(),
            Json(RiskEventFilter {
                action: Some(domain::RiskAction::NeedsReview),
                surface: Some(domain::RiskSurface::Bounty),
                limit: Some(10),
                ..RiskEventFilter::default()
            }),
        )
        .await
        .0;
        let events = response["content"][0]["json"].as_array().unwrap();

        assert_eq!(events.len(), 1);
        assert_eq!(events[0]["action"], "NeedsReview");
        assert!(events[0]["reasons"][0]
            .as_str()
            .unwrap()
            .contains("low-value cap"));
    }

    #[tokio::test]
    async fn risk_review_tools_approve_and_list_review_records() {
        let state = test_state_with_operator_token("local-test-operator");
        let risk_event_id = {
            let mut network = state.network.lock().expect("state poisoned");
            let result = network.post_funded_bounty(PostBountyRequest {
                title: "Fix deterministic payout reconciliation failure".to_string(),
                template_slug: "fix-ci-failure".to_string(),
                amount_minor: 25_000_000,
                currency: "usdc".to_string(),
                funding_mode: domain::FundingMode::BaseUsdcEscrow,
                privacy: PrivacyLevel::Public,
            });
            assert!(matches!(result, Err(app::AppError::RiskNeedsReview(_))));
            network.risk_events.values().next().unwrap().id
        };

        let approval = approve_risk_bounty(
            State(state.clone()),
            test_operator_headers(),
            Json(ApproveRiskBountyRequest {
                risk_event_id,
                title: "Fix deterministic payout reconciliation failure".to_string(),
                template_slug: "fix-ci-failure".to_string(),
                amount_minor: 25_000_000,
                currency: "usdc".to_string(),
                funding_mode: domain::FundingMode::StripeFiatLedger,
                privacy: PrivacyLevel::Public,
                operator_id: "operator-1".to_string(),
                note: "Approved after manual scope review".to_string(),
            }),
        )
        .await
        .0;

        assert_eq!(
            approval["content"][0]["json"]["bounty"]["status"],
            "Unfunded"
        );
        assert_eq!(
            approval["content"][0]["json"]["review"]["outcome"],
            "Approved"
        );
        let reviews = list_risk_reviews(State(state), test_operator_headers())
            .await
            .0;
        let review_items = reviews["content"][0]["json"].as_array().unwrap();
        assert_eq!(review_items.len(), 1);
        assert_eq!(review_items[0]["outcome"], "Approved");
    }

    #[tokio::test]
    async fn reject_risk_event_tool_records_rejection_without_bounty() {
        let state = test_state_with_operator_token("local-test-operator");
        let risk_event_id = {
            let mut network = state.network.lock().expect("state poisoned");
            let result = network.post_funded_bounty(PostBountyRequest {
                title: "Fix deterministic payout reconciliation failure".to_string(),
                template_slug: "fix-ci-failure".to_string(),
                amount_minor: 25_000_000,
                currency: "usdc".to_string(),
                funding_mode: domain::FundingMode::BaseUsdcEscrow,
                privacy: PrivacyLevel::Public,
            });
            assert!(matches!(result, Err(app::AppError::RiskNeedsReview(_))));
            network.risk_events.values().next().unwrap().id
        };

        let response = reject_risk_event(
            State(state.clone()),
            test_operator_headers(),
            Json(RejectRiskEventRequest {
                risk_event_id,
                operator_id: "operator-1".to_string(),
                note: "Rejected until payer completes manual onboarding".to_string(),
            }),
        )
        .await
        .0;

        assert_eq!(response["content"][0]["json"]["outcome"], "Rejected");
        let network = state.network.lock().expect("state poisoned");
        assert!(network.bounties.is_empty());
    }

    #[tokio::test]
    async fn eval_tools_record_local_run_history() {
        let state = test_state();

        let result = run_bountybench(State(state.clone())).await.0;
        assert_eq!(
            result["content"][0]["json"]["suite"],
            "BountyBench/router-v0"
        );

        let runs = get_eval_runs(State(state)).await.0;
        let history = runs["content"][0]["json"].as_array().unwrap();
        assert_eq!(history.len(), 1);
        assert_eq!(history[0]["suite"], "BountyBench/router-v0");
        assert_eq!(history[0]["passed"], true);
    }

    #[tokio::test]
    async fn operator_token_blocks_protected_mcp_tools_when_configured() {
        let state = test_state_with_operator_token("secret-token");

        let response = broadcast_base_signed_transaction(
            State(state.clone()),
            HeaderMap::new(),
            Json(BroadcastBaseSignedTransactionArgs {
                signed_transaction: "0x010203".to_string(),
                request_id: Some(13),
                network: Some("base-sepolia".to_string()),
            }),
        )
        .await
        .0;
        assert_eq!(response["error"], "operator authorization required");

        let mut headers = HeaderMap::new();
        headers.insert(OPERATOR_TOKEN_HEADER, "secret-token".parse().unwrap());
        let response = broadcast_base_signed_transaction(
            State(state),
            headers,
            Json(BroadcastBaseSignedTransactionArgs {
                signed_transaction: "0x010203".to_string(),
                request_id: Some(13),
                network: Some("base-sepolia".to_string()),
            }),
        )
        .await
        .0;
        assert!(response["error"]
            .as_str()
            .unwrap()
            .contains("Base transaction broadcast is disabled"));
    }

    #[tokio::test]
    async fn llms_txt_exposes_agent_orientation() {
        let text = llms_txt().await;

        assert!(text.contains("# Agent Bounties"));
        assert!(text.contains("agent-bounties/autonomous-v1"));
        assert!(text.contains("## MCP default"));
        assert!(text.contains("server/discover"));
        assert!(text.contains("the larger HTTP catalog is not the MCP catalog"));
        assert!(text.contains("prepare_bounty_action"));
        assert!(text.contains("get_bounty_action_status"));
        assert!(text.contains("Advanced earning flow"));
        assert!(text.contains("plan_autonomous_bounty_creation"));
        assert!(text.contains("list_autonomous_bounties"));
        assert!(text.contains("agent_native_claim"));
        assert!(text.contains("/.well-known/agent-bounties.json"));
        assert!(text.contains("BountySettled"));
        assert!(!text.contains("createEscrow"));
    }

    #[tokio::test]
    async fn stripe_checkout_tool_applies_payment_method_configuration() {
        let state = test_state_with_stripe_payment_method_configuration("pmc_paypal_enabled");

        let response = plan_stripe_checkout_top_up(
            State(state),
            Json(PlanStripeCheckoutTopUpArgs {
                organization_id: Uuid::new_v4(),
                amount_minor: 5_000,
                currency: "usd".to_string(),
                success_url: None,
                cancel_url: None,
            }),
        )
        .await
        .0;
        let body = &response["content"][0]["json"]["body"];

        assert_eq!(body["payment_method_configuration"], "pmc_paypal_enabled");
        assert!(body.get("payment_method_types").is_none());
    }

    fn test_operator_headers() -> HeaderMap {
        let mut headers = HeaderMap::new();
        headers.insert(
            OPERATOR_TOKEN_HEADER,
            "local-test-operator".parse().unwrap(),
        );
        headers
    }

    fn test_state() -> SharedState {
        test_state_with_network(BountyNetwork::default())
    }

    #[test]
    fn interface_attribution_distinguishes_http_adapter_from_protocol_endpoint() {
        assert!(is_mcp_http_adapter_path("/tools"));
        assert!(is_mcp_http_adapter_path("/tools/list_opportunities"));
        assert!(!is_mcp_http_adapter_path("/mcp"));
        assert!(!is_mcp_http_adapter_path("/health"));
        assert!(!analytics_exclusion_is_authorized(
            &test_state(),
            &HeaderMap::new()
        ));
    }

    #[test]
    fn mcp_opportunity_response_keeps_canonical_and_adds_attributed_link() {
        let response = mcp_json(json!({
            "items": [{
                "opportunity_id": "eip155:8453:agent-bounties/autonomous-v1:0xabc",
                "public_url": "https://agentbounties.app/?bounty=0xabc"
            }]
        }));
        let enriched = attach_mcp_discovery_links(response, "opportunity_list");
        let links = enriched
            .0
            .pointer("/content/0/json/items/0/discovery_links")
            .expect("discovery links");
        assert_eq!(
            links["canonical_url"],
            "https://agentbounties.app/?bounty=0xabc"
        );
        let attributed = Url::parse(links["attributed_url"].as_str().unwrap()).unwrap();
        let query = attributed.query_pairs().collect::<HashMap<_, _>>();
        assert_eq!(
            query.get("utm_source").map(|value| value.as_ref()),
            Some("mcp")
        );
        assert_eq!(
            query.get("discovery_id").map(|value| value.as_ref()),
            Some("eip155:8453:agent-bounties/autonomous-v1:0xabc")
        );
    }

    #[test]
    fn interface_attribution_exclusion_evidence_is_redacted_and_revision_bound() {
        for (era, expected) in [
            (ObservedProtocolEra::McpModern, "modern"),
            (ObservedProtocolEra::McpLegacy, "legacy"),
        ] {
            let event = interface_usage_excluded_event(era, &"a".repeat(40));
            assert_eq!(
                event,
                json!({
                    "event": "interface_usage_excluded",
                    "interface": "mcp",
                    "protocol_era": expected,
                    "success": true,
                    "revision": "a".repeat(40),
                })
            );
            let fields = event
                .as_object()
                .unwrap()
                .keys()
                .cloned()
                .collect::<BTreeSet<_>>();
            assert_eq!(
                fields,
                BTreeSet::from([
                    "event".to_string(),
                    "interface".to_string(),
                    "protocol_era".to_string(),
                    "revision".to_string(),
                    "success".to_string(),
                ])
            );
        }
    }

    fn test_state_with_network(network: BountyNetwork) -> SharedState {
        Arc::new(AppState {
            network: Mutex::new(network),
            eval_runs: Mutex::new(Vec::new()),
            base_rpc_urls: BaseRpcUrlConfig::default(),
            base_broadcast_enabled: false,
            stripe_secret_key: None,
            stripe_live_execution_enabled: false,
            stripe_api_base_url: STRIPE_API_BASE_URL.to_string(),
            stripe_payment_method_configuration: None,
            operator_api_token: None,
            analytics_exclusion_token: None,
            distribution_attribution_signing_secret: None,
            mcp_base_url: "http://127.0.0.1:8090".to_string(),
            oauth_authorizations: Mutex::new(HashMap::new()),
            oauth_codes: Mutex::new(HashMap::new()),
            store: None,
            recovery_reservations: AutonomousBountyRecoveryReservations::default(),
        })
    }

    fn test_state_with_stripe_payment_method_configuration(
        payment_method_configuration: &str,
    ) -> SharedState {
        Arc::new(AppState {
            network: Mutex::new(BountyNetwork::default()),
            eval_runs: Mutex::new(Vec::new()),
            base_rpc_urls: BaseRpcUrlConfig::default(),
            base_broadcast_enabled: false,
            stripe_secret_key: None,
            stripe_live_execution_enabled: false,
            stripe_api_base_url: STRIPE_API_BASE_URL.to_string(),
            stripe_payment_method_configuration: Some(payment_method_configuration.to_string()),
            operator_api_token: None,
            analytics_exclusion_token: None,
            distribution_attribution_signing_secret: None,
            mcp_base_url: "http://127.0.0.1:8090".to_string(),
            oauth_authorizations: Mutex::new(HashMap::new()),
            oauth_codes: Mutex::new(HashMap::new()),
            store: None,
            recovery_reservations: AutonomousBountyRecoveryReservations::default(),
        })
    }

    fn test_state_with_operator_token(token: &str) -> SharedState {
        Arc::new(AppState {
            network: Mutex::new(BountyNetwork::default()),
            eval_runs: Mutex::new(Vec::new()),
            base_rpc_urls: BaseRpcUrlConfig::default(),
            base_broadcast_enabled: false,
            stripe_secret_key: None,
            stripe_live_execution_enabled: false,
            stripe_api_base_url: STRIPE_API_BASE_URL.to_string(),
            stripe_payment_method_configuration: None,
            operator_api_token: Some(token.to_string()),
            analytics_exclusion_token: None,
            distribution_attribution_signing_secret: None,
            mcp_base_url: "http://127.0.0.1:8090".to_string(),
            oauth_authorizations: Mutex::new(HashMap::new()),
            oauth_codes: Mutex::new(HashMap::new()),
            store: None,
            recovery_reservations: AutonomousBountyRecoveryReservations::default(),
        })
    }

    fn test_state_with_analytics_token(token: &str) -> SharedState {
        Arc::new(AppState {
            network: Mutex::new(BountyNetwork::default()),
            eval_runs: Mutex::new(Vec::new()),
            base_rpc_urls: BaseRpcUrlConfig::default(),
            base_broadcast_enabled: false,
            stripe_secret_key: None,
            stripe_live_execution_enabled: false,
            stripe_api_base_url: STRIPE_API_BASE_URL.to_string(),
            stripe_payment_method_configuration: None,
            operator_api_token: Some("operator-secret".to_string()),
            analytics_exclusion_token: Some(token.to_string()),
            distribution_attribution_signing_secret: None,
            mcp_base_url: "https://mcp.agentbounties.app".to_string(),
            oauth_authorizations: Mutex::new(HashMap::new()),
            oauth_codes: Mutex::new(HashMap::new()),
            store: None,
            recovery_reservations: AutonomousBountyRecoveryReservations::default(),
        })
    }

    fn valid_github_issue_body() -> String {
        "### Goal\nFix the failing CI check.\n\n### Acceptance criteria\nThe test job is green and the patch explains the failure.\n\n### Template\nfix-ci-failure\n\n### Suggested amount\n10 USDC\n".to_string()
    }

    fn stripe_checkout_event(
        event_id: &str,
        session_id: &str,
        organization_id: Uuid,
    ) -> StripeWebhookEvent {
        StripeWebhookEvent {
            id: event_id.to_string(),
            event_type: "checkout.session.completed".to_string(),
            payload: json!({
                "id": session_id,
                "client_reference_id": organization_id.to_string(),
                "amount_total": 5_000,
                "currency": "usd",
                "payment_status": "paid",
                "payment_intent": "pi_mcp_paid"
            }),
        }
    }

    #[test]
    fn mcp_bind_addr_prefers_explicit_config_then_host_port() {
        assert_eq!(
            service_bind_addr(Some("0.0.0.0:9001"), Some("10000"), "127.0.0.1:8090"),
            "0.0.0.0:9001"
        );
        assert_eq!(
            service_bind_addr(Some(""), Some("10000"), "127.0.0.1:8090"),
            "0.0.0.0:10000"
        );
        assert_eq!(
            service_bind_addr(None, Some(" 10002 "), "127.0.0.1:8090"),
            "0.0.0.0:10002"
        );
        assert_eq!(
            service_bind_addr(None, None, "127.0.0.1:8090"),
            "127.0.0.1:8090"
        );
    }
}

async fn hydrate_network(store: &PostgresStore) -> anyhow::Result<BountyNetwork> {
    service_runtime::hydrate_bounty_network(store).await
}

async fn load_objective(state: &SharedState, id: Id) -> Result<Objective, String> {
    if let Some(store) = &state.store {
        return store
            .get_objective(id)
            .await
            .map_err(|error| error.to_string())?
            .ok_or_else(|| format!("objective {id} was not found"));
    }
    state
        .network
        .lock()
        .expect("state poisoned")
        .objectives
        .get(&id)
        .cloned()
        .ok_or_else(|| format!("objective {id} was not found"))
}

async fn load_objectives(state: &SharedState) -> Result<Vec<Objective>, String> {
    if let Some(store) = &state.store {
        return store
            .list_objectives()
            .await
            .map_err(|error| error.to_string());
    }
    let mut objectives = state
        .network
        .lock()
        .expect("state poisoned")
        .objectives
        .values()
        .cloned()
        .collect::<Vec<_>>();
    objectives.sort_by(|left, right| {
        right
            .created_at
            .cmp(&left.created_at)
            .then_with(|| left.id.cmp(&right.id))
    });
    Ok(objectives)
}

async fn persist_new_objective(state: &SharedState, objective: &Objective) -> Result<(), String> {
    if let Some(store) = &state.store {
        store
            .create_objective(objective)
            .await
            .map_err(|error| error.to_string())?;
    } else {
        let mut network = state.network.lock().expect("state poisoned");
        if network.objectives.contains_key(&objective.id) {
            return Err(format!("objective {} already exists", objective.id));
        }
        network.objectives.insert(objective.id, objective.clone());
        return Ok(());
    }
    state
        .network
        .lock()
        .expect("state poisoned")
        .objectives
        .insert(objective.id, objective.clone());
    Ok(())
}

async fn persist_objective_replacement(
    state: &SharedState,
    objective: &Objective,
    expected_revision: u64,
) -> Result<(), String> {
    if let Some(store) = &state.store {
        store
            .replace_objective(objective, expected_revision)
            .await
            .map_err(|error| error.to_string())?;
    } else {
        let mut network = state.network.lock().expect("state poisoned");
        let current_revision = network
            .objectives
            .get(&objective.id)
            .map(|current| current.revision)
            .ok_or_else(|| format!("objective {} was not found", objective.id))?;
        if current_revision != expected_revision {
            return Err(format!(
                "objective {} revision conflict: expected {expected_revision}",
                objective.id
            ));
        }
        network.objectives.insert(objective.id, objective.clone());
        return Ok(());
    }
    state
        .network
        .lock()
        .expect("state poisoned")
        .objectives
        .insert(objective.id, objective.clone());
    Ok(())
}

async fn load_objective_canonical_evidence(
    state: &SharedState,
    objectives: &[Objective],
) -> Result<ObjectiveCanonicalEvidence, String> {
    let Some(store) = &state.store else {
        return Ok(ObjectiveCanonicalEvidence::default());
    };
    let mut networks = BTreeSet::new();
    for objective in objectives {
        let Some(bundle) = objective.accepted_value_bundle.as_ref() else {
            continue;
        };
        if let Some(payment) = &bundle.monetary_payment {
            networks.insert(payment.bounty.network.clone());
        }
        for need in &bundle.contribution_needs {
            if let domain::ContributionCompensation::Paid { payment } = &need.compensation {
                networks.insert(payment.bounty.network.clone());
            }
        }
    }
    if networks.is_empty() {
        return Ok(ObjectiveCanonicalEvidence::default());
    }
    let terms = store
        .list_autonomous_bounty_terms()
        .await
        .map_err(|error| error.to_string())?;
    let mut evidence = ObjectiveCanonicalEvidence::default();
    for network in networks {
        let events = store
            .list_autonomous_bounty_events(&network)
            .await
            .map_err(|error| error.to_string())?;
        let mut feed = build_autonomous_bounty_feed(events, terms.clone(), false)
            .map_err(|error| error.to_string())?;
        state.recovery_reservations.apply(&mut feed, false);
        state
            .recovery_reservations
            .exclude_from_reported_outcomes(&mut feed);
        let mut network_evidence = build_objective_canonical_evidence(&network, &feed);
        evidence.funding.append(&mut network_evidence.funding);
        evidence
            .settlements
            .append(&mut network_evidence.settlements);
    }
    Ok(evidence)
}

async fn persist_ledger_entries(
    store: &PostgresStore,
    entries: &[ledger::LedgerEntry],
) -> Result<(), String> {
    service_runtime::persist_ledger_entries(store, entries)
        .await
        .map_err(|error| error.to_string())
}

fn mcp_json(value: impl Serialize) -> Json<serde_json::Value> {
    Json(serde_json::json!({ "content": [{ "type": "json", "json": value }] }))
}

fn mcp_mutation<T: Serialize>(
    result: Result<T, service_runtime::MutationError>,
) -> Json<serde_json::Value> {
    match result {
        Ok(value) => mcp_json(value),
        Err(error) => mcp_error(error),
    }
}

fn mcp_error(error: impl ToString) -> Json<serde_json::Value> {
    Json(serde_json::json!({ "error": error.to_string() }))
}

#[allow(dead_code)]
fn _register_agent(network: &mut BountyNetwork, handle: &str) -> domain::Agent {
    network.register_agent(RegisterAgentRequest {
        handle: handle.to_string(),
        payout_wallet: None,
    })
}

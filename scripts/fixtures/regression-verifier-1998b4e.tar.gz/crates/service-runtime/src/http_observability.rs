//! Bounded server-error records. Callers may pass only router-matched templates.
//! Request/response bodies, headers, raw URLs and caller correlation IDs are not inputs.
use serde_json::{json, Value};
use std::io::Write;

#[derive(Clone, Copy)]
pub enum HttpService {
    Api,
    Mcp,
}

pub fn http_error_event(
    service: HttpService,
    method: &str,
    matched_route_template: Option<&str>,
    revision: &str,
    status: u16,
) -> Option<Value> {
    if !(500..600).contains(&status) {
        return None;
    }
    let method = match method {
        "GET" => "GET",
        "HEAD" => "HEAD",
        "POST" => "POST",
        "PUT" => "PUT",
        "PATCH" => "PATCH",
        "DELETE" => "DELETE",
        "OPTIONS" => "OPTIONS",
        "CONNECT" => "CONNECT",
        "TRACE" => "TRACE",
        _ => "OTHER",
    };
    let route = matched_route_template
        .filter(|route| {
            route.starts_with('/')
                && route.len() <= 240
                && route.bytes().all(|byte| {
                    byte.is_ascii_alphanumeric()
                        || matches!(byte, b'/' | b'-' | b'_' | b'.' | b':' | b'*' | b'{' | b'}')
                })
        })
        .unwrap_or("unmatched");
    let revision = if revision.len() == 40 && revision.bytes().all(|byte| byte.is_ascii_hexdigit())
    {
        revision
    } else {
        "local"
    };
    let code = match status {
        500 => "internal_server_error",
        501 => "not_implemented",
        502 => "bad_gateway",
        503 => "service_unavailable",
        504 => "gateway_timeout",
        _ => "server_error",
    };
    Some(json!({
        "event": "http_server_error",
        "level": "error",
        "service": match service { HttpService::Api => "api", HttpService::Mcp => "mcp" },
        "route": route,
        "method": method,
        "status": status,
        "revision": revision,
        "code": code,
    }))
}

pub fn record_http_error(
    service: HttpService,
    method: &str,
    matched_route_template: Option<&str>,
    revision: &str,
    status: u16,
) {
    if let Some(event) = http_error_event(service, method, matched_route_template, revision, status)
    {
        // A logging failure must not replace the handler's response or panic.
        let _ = writeln!(std::io::stderr().lock(), "{event}");
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn server_errors_have_only_bounded_operational_fields() {
        let event = http_error_event(
            HttpService::Api,
            "GET",
            Some("/v1/bounties/:id"),
            "0123456789abcdef0123456789abcdef01234567",
            503,
        )
        .unwrap();
        assert_eq!(
            event,
            json!({
                "event": "http_server_error", "level": "error", "service": "api", "route": "/v1/bounties/:id",
                "method": "GET", "status": 503, "revision": "0123456789abcdef0123456789abcdef01234567",
                "code": "service_unavailable",
            })
        );
    }

    #[test]
    fn unknown_methods_unmatched_routes_and_invalid_revisions_never_echo_inputs() {
        let long_route = "/".repeat(241);
        for route in [
            None,
            Some("/path?private-query"),
            Some("/path\nprivate-header"),
            Some(long_route.as_str()),
        ] {
            let event = http_error_event(
                HttpService::Mcp,
                "PRIVATE-METHOD",
                route,
                "private-revision",
                500,
            )
            .unwrap();
            assert_eq!(event["route"], "unmatched");
            assert_eq!(event["method"], "OTHER");
            assert_eq!(event["revision"], "local");
            assert!(!event.to_string().to_ascii_lowercase().contains("private"));
        }
    }

    #[test]
    fn success_and_expected_client_errors_are_not_server_errors() {
        for status in [200, 202, 301, 400, 401, 403, 404, 410, 429, 499, 600] {
            assert!(
                http_error_event(HttpService::Mcp, "POST", Some("/mcp"), "local", status).is_none()
            );
        }
        assert_eq!(
            http_error_event(HttpService::Mcp, "POST", Some("/mcp"), "local", 599).unwrap()["code"],
            "server_error"
        );
    }
}
